---
source_url: https://www.canada.ca/en/services/benefits/publicpensions.html
scraped_at: 2025-08-24 14:39:15
filename: en/services/benefits/publicpensions_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Public pensions

## Information about wildfires

Service Canada programs and services might be affected by recent wildfires.

Find out more by visiting the [Help for individuals affected by hazardous weather page](/en/employment-social-development/corporate/notices/hazardous-weather.html).

## Potential delays in Canada Post delivery services

Mail delivery for some programs and services may be delayed. Consult the measures in place during the [potential disruption of Canada Post services](/en/employment-social-development/corporate/portfolio/service-canada/postal-disruption.html).

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

## File your taxes to continue receiving your GIS payments

If you haven’t filed your 2024 taxes with the CRA, your Guaranteed Income Supplement (GIS) payments may stop or be reduced.

To avoid interruptions, [file your taxes](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes.html) as soon as possible.

You can also report your income directly to us to renew or confirm your eligibility.

If you have questions or concerns about your GIS payments, [contact us](/en/employment-social-development/corporate/contact/oas.html).

Information on pensions and benefits available from the Canada Pension Plan (CPP) and Old Age Security (OAS) programs. Learn about retirement income, survivor income, disability benefits, eligibility, and the application process.

## Most requested

* [Access My Service Canada Account](/en/employment-social-development/services/my-account.html)
* [Change your personal information](/en/employment-social-development/services/my-account/personal-information.html)

* [CPP payment amounts](/en/services/benefits/publicpensions/cpp/payment-amounts.html)
* [Payment dates](/en/services/benefits/calendar.html)

## Retirement tools

* [Retirement Hub: retirement planning tool](/en/services/retirement.html)
* [Canadian Retirement income Calculator](/en/services/benefits/publicpensions/cpp/retirement-income-calculator.html)
* [Estimate OAS payment amounts](/en/services/benefits/publicpensions/old-age-security/payments.html)

## Retirement income

### [Canada Pension Plan (CPP)](/en/services/benefits/publicpensions/cpp.html)

Decide when and how to apply for your CPP retirement.

### [Old Age Security (OAS) pension](/en/services/benefits/publicpensions/old-age-security.html)

Apply for OAS if you are 65 and older even if you have never worked or are still working.

### [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

Apply for this benefit if you are an Old Age Security recipient with low income.

### [Receive public pensions outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html)

Receiving OAS and CPP pensions and benefits, if living outside Canada.

### [Guaranteed Income Supplement – Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)

Apply for a monthly benefit if you are age 60-64, have low income, and your spouse or common-law partner receives the Guaranteed Income Supplement.

### [Canada Pension Plan Post-Retirement Benefit (PRB)](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)

If you're under 70 and working while receiving your CPP, you can still contribute to increase your pension.

## Disability benefits

### [CPP disability benefits](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

Apply if you are unable to work due to a severe and prolonged disability.

### [CPP Post-Retirement Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit.html)

Apply if you are under 65, receiving a CPP retirement pension, and now have a severe and prolonged disability.

### [CPP children’s benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

Apply for a monthly benefit for a dependent child of a person receiving a CPP disability benefit or CPP post-retirement disability benefit.

## Following a death

### [CPP survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)

Apply for a monthly payment paid to the legal spouse or common-law partner of a deceased CPP contributor.

### [CPP children’s benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

Apply for a monthly benefit for a dependent child of a deceased CPP contributor.

### [What to do when someone dies](/en/services/death.html)

What to do following the loss of a loved one. Documents you need, who to notify, how to cancel benefits and avoid overpayment.

### [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)

Apply for a one-time payment on behalf of a deceased CPP contributor.

### [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

Apply for a monthly benefit if you are low-income, widowed, age 60 to 64 and not yet eligible for OAS.

## Video: My Service Canada Account

[Video: What is My Service Canada Account

![Desktop monitor opened on a Canada website page](/content/dam/esdc-edsc/images/services/my-account/video-access-services/MSCA_image.png)

See what MSCA offers and how having an account can help you access your pension services and benefits.

Watch the MSCA video](/en/employment-social-development/services/my-account/video-access-services.html)

## Contact us

* [Contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html)
* [Contact Old Age Security](/en/employment-social-development/corporate/contact/oas.html)
* [Ask us to call you by using eServiceCanada](https://eservices.canada.ca/en/service/)
* [Visit us](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## Page details

Date modified:
:   2025-08-11

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
