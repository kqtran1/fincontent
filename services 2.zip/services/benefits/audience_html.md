---
source_url: https://www.canada.ca/en/services/benefits/audience.html
scraped_at: 2025-08-24 20:18:34
filename: en/services/benefits/audience_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/clientele.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Benefits by audience

# Benefits by audience

Find information about benefits and programs, including eligibility.

## Most requested

* [Sign up for direct deposit](https://www.tpsgc-pwgsc.gc.ca/recgen/txt/depot-deposit-eng.html)
* [My VAC Account (Veterans Affairs Canada)](http://www.veterans.gc.ca/eng/e_services)
* [My VAC Book](http://www.veterans.gc.ca/eng/services/resources/mvb)
* [VAC Benefits Browser](http://www.veterans.gc.ca/eng/services/resources/benefits)
* [Payment calendar](/en/services/benefits/calendar.html)
* [Benefits finder](https://www.canada.ca/en/services/benefits/finder.html)

## Services and information

### [Benefits for Indigenous peoples](/en/services/benefits/audience/indigenous.html)

Benefits and programs for Indigenous peoples, including education and training, income assistance and more.

### [Military benefits](/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits.html)

Medical, dental, injury and disability benefits, children education allowance, and benefits after death.

### [Benefits for Veterans](/en/services/benefits/audience/veterans.html)

Financial assistance, health, disability and death benefits for current or former Canadian Forces members and their families.

### [Disability benefits](/en/services/benefits/disability.html)

Disability pensions and children's benefits, residential home rehabilitation, savings plans and a gasoline tax refund program.

### [Retirees](/en/services/benefits/publicpensions.html)

Information on the Canada Pension Plan, Old Age Security pension and related benefits, the Canadian retirement income calculator and retirement planning.

### [Benefits for Canadians living abroad](/en/services/benefits/audience/canadiansabroad.html)

Includes information on Employment Insurance (EI), pensions, benefits and taxes, for those who work or live outside of Canada.

### [Public service group insurance benefit plans](/en/treasury-board-secretariat/topics/benefit-plans.html?utm_content=pension-benefits&utm_source=canada.ca&utm_medium=benefits-theme)

Get information on group insurance benefit plans, which include health, dental, disability and life insurance plans. Learn about terms and conditions for eligibility, premiums, contributions and benefits.

### [Victim services and funding](/en/services/policing/victims/servicesfunding.html)

Get information and assistance for victims of crime.

## Features

![](/content/dam/themes/benefits/features/20150627-1.jpg)

### [My Service Canada Account](/en/employment-social-development/services/my-account.html)

Access your Employment Insurance, Canada Pension Plan, and Old Age Security information online.

## From:

* [Employment and Social Development Canada](/en/employment-social-development.html)
* [National Defence](/en/department-national-defence.html)
* [Treasury Board of Canada Secretariat](/en/treasury-board-secretariat.html)

## Page details

Date modified:
:   2025-05-09

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
