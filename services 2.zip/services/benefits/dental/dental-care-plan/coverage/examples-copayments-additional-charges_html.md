---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/coverage/examples-copayments-additional-charges.html
scraped_at: 2025-08-24 17:12:37
filename: en/services/benefits/dental/dental-care-plan/coverage/examples-copayments-additional-charges_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/couverture/exemples-quotesparts-frais-supplementaires.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - What is covered](/en/services/benefits/dental/dental-care-plan/coverage.html)

# Canadian Dental Care Plan: Examples of co‑payments and additional charges factsheet

## Alternate formats

[![](/content/dam/canada/doc.png)

Canadian Dental Care Plan: Examples of co‑payments and additional charges factsheet [PDF - 274.02 KB]](/content/dam/esdc-edsc/documents/services/benefits/dental/dental-care-plan/providers/factsheet/CDCP-PaymentFactsheet-EN.pdf)

## Factsheet text

### **Canadian Dental Care Plan**

#### Examples of co‑payments and additional charges

The Canadian Dental Care Plan (CDCP) is helping make the cost of dental care more affordable for eligible Canadian residents by covering a portion of the cost for a wide range of oral health care services. You may have to pay additional charges, including co‑payments, directly to your oral health provider. Before receiving care, you should always ask your oral health provider about any costs that won’t be covered by the plan.

The following examples are all based on 2 units of scaling, which is 30 minutes of teeth cleaning.

##### No co‑payment

Jane has an adjusted family net income of $32,000. This means that she does not have a co‑payment.

* Jane has an appointment to get her teeth cleaned
* Her provider charges $145\* for 2 units of scaling
* The CDCP established fee for 2 units of scaling is $134
* The CDCP will pay Jane’s provider $134
* Jane will need to pay the remaining $11 to her provider

##### 40% co‑payment

Hakeem and his spouse, Anita, have an adjusted family net income of $76,000. This means that their family has a 40% co‑payment.

* Hakeem has an appointment to get his teeth cleaned
* His provider charges $145\* for 2 units of scaling
* The CDCP established fee for 2 units of scaling is $134
* Hakeem must pay the remaining $11 to the provider, plus his co‑payment
* Hakeem’s co‑payment is $53.60 (40% of $134)
* The CDCP will pay Hakeem’s provider $80.40 (60% of $134)
* Hakeem’s total payment to his provider is $64.60 ($11 plus $53.60)

##### 60% co‑payment

Kate and her spouse, Mary, have an adjusted family net income of $82,000. This means that their family has a 60% co‑payment.

* Kate has an appointment to get her teeth cleaned
* Her provider charges $145\* for 2 units of scaling
* The CDCP established fee for 2 units of scaling is $134
* Kate must pay the remaining $11 to the provider, plus her co‑payment
* Kate’s co‑payment is $80.40 (60% of $134)
* The CDCP will pay Kate’s provider $53.60 (40% of $134)
* Kate’s total payment to her provider is $91.40 ($11 plus $80.40)

\* For illustrative purposes only

For more details on the CDCP, visit **Canada.ca/dental** or call **1-833-537-4342**

## Page details

Date modified:
:   2024-11-06

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
