---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit.html
scraped_at: 2025-08-24 13:55:13
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Canadian Dental Care Plan promotional toolkit: Overview

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

The Canadian Dental Care Plan (CDCP) will help make the cost of oral health care more affordable for up to nine million uninsured Canadian residents with an adjusted family net income of less than $90,000.

Applications for the [CDCP](/en/services/benefits/dental/dental-care-plan.html) are open in phases.

We have prepared some tools and resources that stakeholders can use to help their patients, clients, and members better understand and access the plan.

**What's included in the toolkit**

* a [poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [web banners and web buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [social media shareables](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)

**How to use the resources**

* download these ready-to-use tools and resources
* use this information in your own communication efforts
* use these resources to inform your clients about the Canadian Dental Care Plan

**Related links**

* [Examples of co‑payments and additional charges factsheet](/en/services/benefits/dental/dental-care-plan/coverage/examples-copayments-additional-charges.html)
* [Learn more about what to do before booking your first appointment and receiving care](/en/services/benefits/dental/dental-care-plan/visit-provider/video-booking-first-appointment.html)

## Page details

Date modified:
:   2024-12-11

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
