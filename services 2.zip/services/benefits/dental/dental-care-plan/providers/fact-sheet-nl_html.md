---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nl.html
scraped_at: 2025-08-24 17:27:21
filename: en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nl_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/fiche-nl.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Coordination of benefits between the CDCP and Newfoundland and Labrador’s provincial dental programs

November 2024
Version 2.0

This fact sheet is intended to provide information on the approach to coordination of benefits between the Canadian Dental Care Plan (CDCP) and the Newfoundland and Labrador's provincial dental programs noted below.

**Note: Individuals with private insurance are not eligible for the CDCP, and therefore there would be no coordination of benefits with the CDCP. Should clients have dental benefits through a private plan, then providers must not submit claims to the CDCP.**

| Program Name | Contact Information |
| --- | --- |
| Children’s Dental Health Program | Department of Health and Community Services  Dental Consultant  Medical Services Division  P.O. Box 8700  1st Floor, West Block  St. John’s, NL A1B 4J6  Tel: (709) 758-1503  Email: MichelleZwicker@gov.nl.ca |
| Income Support Program |
| Low Income (Access) Program |
| Adult Dental Program |

| Administrator | Contact Information |
| --- | --- |
| Medical Care Plan (MCP) (TeleClaim) | Medical Care Plan (MCP) - Administration Office   Residents of the Avalon region:  Phone: 709-758-1600    Residents of all other areas, including Labrador:   Phone: 709-292-4000 |

## What is the payer order between the CDCP and Newfoundland and Labrador's provincial dental programs?

The CDCP will be the **primary payer** relative to the Newfoundland and Labrador's provincial dental programs.

Newfoundland and Labrador will be the **payer of last resort.**

## How will the CDCP and Newfoundland and Labrador coordinate benefits?

* The claim should be submitted to the CDCP first, through Sun Life. Sun Life will generate an Explanation of Benefits (EOB) that will show the eligible amount covered under the CDCP (Total Payable to Provider).
* Providers will then need to submit the claim to MCP-TeleClaim, as payer of last resort, within 90 days of the date the service has been rendered, either electronically or by paper, for any remaining amounts, and the claim will be processed in accordance with Newfoundland and Labrador's program policies.
* The EOB will not be immediately required to be submitted unless requested by MCP adjudicators, either electronically or by paper, but it should be kept for potential review.
* In cases where Newfoundland and Labrador's program fees are greater than the CDCP's fees, **providers will be able to seek additional reimbursement from the Newfoundland and Labrador's program up to the Newfoundland and Labrador's program fee guide rates, through coordination of benefits**. In cases where program fees are equal to or lower than CDCP fees, there will be no additional reimbursement on fees.
* Some services covered by the CDCP and by Newfoundland and Labrador's programs are subject to frequency limits. These frequency limits are not cumulative - neither the CDCP nor the Newfoundland and Labrador's programs will provide coverage for services beyond their respective frequency limits.
* CDCP clients will continue to be responsible for paying, directly to the provider, any applicable co-payment and any remaining amounts not covered by the CDCP and/or the Newfoundland and Labrador's provincial dental programs.

## What if services require preauthorization under the CDCP?

* Some services under the CDCP require prior approval through preauthorization before the treatment is confirmed for coverage under the plan. Certain services always require preauthorization, and services above CDCP frequency limitations can also be requested through preauthorization.
* CDCP is accepting preauthorization requests effective November 1, 2024.
* Providers should refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for services covered by the CDCP and the policies, including criteria, guidelines and limitations, as well as the [CDCP Dental Benefit Grids](https://www.sunlife.ca/sl/cdcp/en/provider/dental-benefit-grids/) for the list of procedure codes that always require preauthorization - under "Schedule B" or identified with a "P". This also includes treatment for services available without prior approval, but that would be above established frequency limits.
* Oral health providers need to submit all required and relevant documentation available to support the request directly to Sun Life. Please refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for documentation requirements.
* If a service requires preauthorization under the CDCP, the preauthorization request for that service must always be submitted to the CDCP, regardless of whether the service is covered or has been preauthorized by another Federal or Provincial dental program.

## Resource:

For more guidance on the claims submission process for CDCP, including preauthorization, post-determination, and reconsideration steps, please refer to the Sun Life [claims submission information resource](https://www.sunlife.ca/content/dam/sunlife/regional/canada/documents/cxo/cdcp/cdcp-csi-en.pdf) (PDF, 375 KB).

## Page details

Date modified:
:   2024-11-21

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
