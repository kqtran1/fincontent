---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-on.html
scraped_at: 2025-08-24 16:50:30
filename: en/services/benefits/dental/dental-care-plan/providers/fact-sheet-on_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/fiche-on.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Coordination of benefits between the CDCP and Ontario’s provincial dental programs

November 2024
Version 2.0

This fact sheet is intended to provide information on the approach to coordination of benefits between the Canadian Dental Care Plan (CDCP) and Ontario's dental programs noted below.

**Note: Individuals with private insurance are not eligible for the CDCP, and therefore there would be no coordination of benefits with the CDCP. Should clients have dental benefits through a private plan, then providers must not submit claims to the CDCP.**

Dental providers that have questions about how Healthy Smiles Ontario and dental benefits under the Ontario Disability Support Program will coordinate with the CDCP should contact Accerta, Ontario's third-party dental administrator.

**Note:** the Ontario Seniors Dental Care Program is operated by Public Health Units and does not coordinate benefits with the CDCP.

| Program Name | Contact Information |
| --- | --- |
| Healthy Smiles Ontario (HSO) | Toll-free: 1-844-296-6306  Toll-free TTY: 1-800-387-5559  TTY: 416-327-4282 |
| Ontario Disability Support Program (ODSP) | Toll free: 1-888-999-1142  TTY: 1-800-387-5559 |
| Ontario Seniors Dental Care Program (OSDCP) | Tel: 416-916-0204  Toll-free: 1-833-207-4435  Toll-free TTY: 1-800-855-0511 |
| Ontario Works (OW) | Ontario Works is administered by municipalities and First Nations communities. A list of Ontario Works offices can be found at this website: [Ontario Social Assistance Office Finder](http://www.officelocator.mcss.gov.on.ca/?q=toronto). |

| Third-Party Administrator | Contact Information |
| --- | --- |
| Accerta | Phone: 416-922-6565  Toll-Free: 1-800-505-7430  Fax: 416-922-4323  Toll-Free Fax: 1-800-467-1839  General Inquiries: info@accerta.ca |

## What is the payer order between the CDCP and Ontario's provincial dental programs?

* The CDCP will be the **primary payer** relative to the Healthy Smiles Ontario Program, the Ontario Disability Support Program and the Ontario Works program.
* Where coordination is possible, Ontario's programs — the Heathy Smiles Ontario Program and the Ontario Disability Support Program — will serve as the **secondary payer**.
* For information on coordination of benefits with Ontario Works and with the Ontario Seniors Dental Care Program, please see below.

## How will the CDCP and Ontario coordinate benefits?

Please consult the information below for the coordination process for each of Ontario's dental programs.

### Healthy Smiles Ontario Program and Ontario Disability Support Program

Where patients are eligible for CDCP and dental benefits under these two Ontario programs, providers will need to submit claims as follows.

* The claim should be submitted to the CDCP first, through Sun Life. Sun Life will generate an Explanation of Benefits (EOB) that will show the eligible amount covered under the CDCP (*Total Payable to Provider*).
* Providers will then need to submit the claim to Accerta as second payer, within 30 days of the date the service has been rendered, either electronically or by paper, and the claim will be processed in accordance with the relevant Ontario program policies and process.
* For clients who are eligible for both the CDCP and Healthy Smiles Ontario or the Ontario Disability Support Program, providers may be able to seek additional reimbursement for the portion of their fees that is not covered by the CDCP, up to the maximums in the provincial schedules, through coordination of benefits.
* Two examples (for clients who do not have a co-payment under the CDCP) are shown below for illustrative purposes only.
  + **Example 1: 2 units of scaling**
    - Provider charges: $145.00
    - CDCP pays $134.00
    - HSO/ODSP pays up to $76.02
    - Provider can bill up to $11.00 to HSO/ODSP
    - Total paid to provider = $145.00
  + **Example 2: 0.5 units of polishing**
    - Provider charges: $35.00
    - CDCP pays $8.75
    - HSO/ODSP pays up to $12.67
    - Provider can bill up to $12.67 to HSO/ODSP
    - Total paid to provider $21.42
    - Provider cannot balance bill the remaining $13.58 to the client.
* Note: Where providers are coordinating benefits for clients, balance billing is not permitted where the Healthy Smiles Ontario and the Ontario Disability Support Program schedules are used to supplement CDCP established fees. Please contact Accerta if you require a copy of the schedules.
* Some services covered by the CDCP and by the Ontario programs are subject to frequency limits. These frequency limits are not cumulative — neither the CDCP nor the Ontario programs will provide coverage for services beyond their respective frequency limits. If a client's frequency limit under an Ontario program has been met by the CDCP coverage, the Ontario program will not provide for any additional services.

### Ontario Works

Dental benefits under Ontario Works are administered by municipalities and First Nations communities. Providers will need to contact the clients' local Ontario Works office for details about how the CDCP and Ontario Works dental benefits interact. Providers can use the [Ontario Social Assistance Office finder](http://www.officelocator.mcss.gov.on.ca/?q=toronto) to find contact information for their clients' local Ontario Works office.

### Ontario Seniors Dental Care Program (OSDCP)

* At this time, there is no coordination of benefits between the CDCP and the Ontario Seniors Dental Care Program.
* The Ontario Seniors Dental Care Program is administered by Public Health Units and not funded on a fee-for-service basis.
* It is the patient/client's choice whether they wish to access benefits through the Ontario Seniors Dental Care program or the CDCP, and they are encouraged to discuss with their provider the best option for them.
* Patient's/clients choosing to access benefits through the CDCP may have to pay additional fees if the oral health provider charges more than the CDCP fees and/or if the patient/client agrees to receive dental care that the CDCP doesn't cover.

CDCP clients will continue to be responsible for paying, directly to the provider, any applicable amounts or services not covered by the CDCP and/or Ontario dental programs, based on the guidance provided above.

## What if services require preauthorization under the CDCP?

* Some services under the CDCP will require prior approval through preauthorization request before the treatment is confirmed for coverage. Certain services always require preauthorization, and services above CDCP frequency limitations can also be requested through preauthorization.
* CDCP is accepting preauthorization requests effective November 1, 2024.
* Providers should refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for services covered by the CDCP and the policies, including criteria, guidelines and limitations, as well as the [CDCP Dental Benefit Grids](https://www.sunlife.ca/sl/cdcp/en/provider/dental-benefit-grids/) for the list of procedure codes that always require preauthorization - under "Schedule B" or identified with a "P". This also includes treatment for services available without prior approval, but that would be above established frequency limits.
* Oral health providers need to submit all required and relevant documentation available to support the request directly to Sun Life. Please refer to the **[CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html)** for documentation requirements.
* If a service requires preauthorization under the CDCP, the preauthorization request for that service must always be submitted to the CDCP, regardless of whether the service is covered or has been preauthorized by another federal or provincial dental program.

## What else do providers need to know?

* For inquiries related to preauthorization under the CDCP and how those services may be coordinated with HSO or ODSP, dental providers are encouraged to contact Accerta.

## Resource:

For more guidance on the claims submission process for CDCP, including preauthorization, post-determination, and reconsideration steps, please refer to the Sun Life [claims submission information resource](https://www.sunlife.ca/content/dam/sunlife/regional/canada/documents/cxo/cdcp/cdcp-csi-en.pdf).

## Page details

Date modified:
:   2025-01-31

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
