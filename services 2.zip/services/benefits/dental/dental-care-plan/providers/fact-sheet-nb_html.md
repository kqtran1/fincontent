---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nb.html
scraped_at: 2025-08-24 15:57:21
filename: en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nb_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/fiche-nb.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Coordination of benefits between the CDCP and the province of New Brunswick’s social development dental programs

November 2024
Version 2.0

At this time, coordination of benefits between the CDCP and the province of New Brunswick's social development dental programs is not being implemented.

**Note:** Individuals with private insurance are not eligible for the CDCP, and therefore there would be no coordination of benefits with the CDCP. Should clients have dental benefits through a private plan, then providers must not submit claims to the CDCP.

| Program Name | Contact Information |
| --- | --- |
| Healthy Smiles Clear Vision | Website: [Healthy Smiles, Clear Vision (gnb.ca)](https://www2.gnb.ca/content/gnb/en/departments/social_development/promos/healthy_smiles_clear_vision.html) |
| Health Services Dental Program | Website: [Health Services Dental Program (gnb.ca)](https://www2.gnb.ca/content/gnb/en/services/services_renderer.8075.html) |

| Third-Party Administrator | Contact Information |
| --- | --- |
| Medavie Blue Cross (for Healthy Smiles Clear Vision only) | Toll-free: 1-855-839-9229  Greater Moncton Area: 867-6026 |

## How will the CDCP and New Brunswick coordinate benefits?

* At this time, coordination of benefits between the CDCP and the province of New Brunswick's social development dental programs is not being implemented.
* It is the patient/client's choice whether they wish to access benefits through the province of New Brunswick's social development dental programs or the CDCP, and they are encouraged to discuss with their provider the best option for them.
* CDCP clients will continue to be responsible for paying, directly to the provider, any applicable co-payment and any remaining amounts not covered by the CDCP.

## What if services require preauthorization under the CDCP?

* Some services under the CDCP require prior approval through preauthorization before the treatment is confirmed for coverage under the plan. Certain services always require preauthorization, and services above CDCP frequency limitations can also be requested through preauthorization.
* CDCP is accepting preauthorization requests effective November 1, 2024.
* Providers should refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for services covered by the CDCP and the policies, including criteria, guidelines and limitations, as well as the [CDCP Dental Benefit Grids](https://www.sunlife.ca/sl/cdcp/en/provider/dental-benefit-grids/) for the list of procedure codes that always require preauthorization - under "Schedule B" or identified with a "P". This also includes treatment for services available without prior approval, but that would be above established frequency limits.
* Oral health providers need to submit all required and relevant documentation available to support the request directly to Sun Life. Please refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for documentation requirements.
* If a service requires preauthorization under the CDCP, the preauthorization request for that service must always be submitted to the CDCP, regardless of whether the service is covered or has been preauthorized by another federal or provincial dental program.

## What else do providers need to know?

**For additional information regarding the province of New Brunswick's social development dental programs:**

Please visit the [Health Services Dental Program (gnb.ca)](https://www2.gnb.ca/content/gnb/en/services/services_renderer.8075.html) homepage for information pertaining to the province of New Brunswick's social development dental programs.

**Resource:**

For more guidance on the claims submission process for CDCP, including preauthorization, post-determination, and reconsideration steps, please refer to the Sun Life [claims submission information resource](https://www.sunlife.ca/content/dam/sunlife/regional/canada/documents/cxo/cdcp/cdcp-csi-en.pdf).

## Page details

Date modified:
:   2024-12-19

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
