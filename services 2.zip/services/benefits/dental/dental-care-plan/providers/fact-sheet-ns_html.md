---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-ns.html
scraped_at: 2025-08-24 18:03:34
filename: en/services/benefits/dental/dental-care-plan/providers/fact-sheet-ns_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/fiche-ne.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Coordination of benefits between the CDCP and Nova Scotia's provincial dental programs

November 2024
Version 2.0

This fact sheet is intended to provide information on the approach to coordination of benefits between the Canadian Dental Care Plan (CDCP) and Nova Scotia’s provincial dental programs noted below.

**Note: Individuals with private insurance are not eligible for the CDCP, and therefore there would be no coordination of benefits with the CDCP. Should clients have dental benefits through a private plan, then providers must not submit claims to the CDCP.**

| Program Name | Contact Information |
| --- | --- |
| Individuals with Special Needs Health Program | Green Shield Canada on behalf of the Department of Health and Wellness  Toll-free: 1-833-739-4035 |
| Children’s Oral Health Program |
| Cleft Palate-Craniofacial Program |
| Maxillofacial Prosthodontics Program |
| Oral and Maxillofacial Surgery Program |
| Employment Support and Income Assistance Program (ESIA) | Department of Opportunities and Social Development (DOSD)  Toll-free: 1-877-424-1177 |
| Disability Support Program (DSP) |

| Third-Party Administrator | Contact Information |
| --- | --- |
| Green Shield Canada | * Customer Service Centre * Toll-free: 1-833-739-4035 |

## What is the payer order between the CDCP and Nova Scotia’s provincial dental programs?

* The CDCP will be the **primary payer** relative to Nova Scotia’s provincial dental programs, but providers have the choice of billing the Maxillofacial Prosthodontics Program or the Oral and Maxillofacial Surgery Program first instead, if services are eligible.
* Nova Scotia will be the **secondary payer**.

## How will the CDCP and Nova Scotia coordinate benefits?

* The claim should be submitted to the CDCP first, through Sun Life. Sun Life will generate an Explanation of Benefits (EOB) that will show the eligible amount covered under the CDCP (*Total Payable to Provider*).
* If there are any charges remaining after payment by the CDCP, including any co-payments, **the Nova Scotia program will reimburse these charges up to the maximum established by the Nova Scotia provincial dental program’s fees**.
* Providers will need to submit the EOB to DOSD (for the DSP program) or to Nova Scotia’s third-party administrator, Green Shield Canada (for all other programs) within 6 months (flexible for ESIA clients) of the date the service has been rendered, either electronically or by paper. The claim will be processed in accordance with the existing process for the relevant Nova Scotia dental program.
* Balance billing is **not permitted** for programs administered by DHW. Oral health providers may not bill any amount exceeding the fee established by the DHW program directly to clients.
* However, for programs administered by DOSD, CDCP clients will continue to be responsible for paying, directly to the provider, any remaining amounts not covered  by CDCP and/or under the relevant DOSD program. Providers should follow the same process as they do currently with DOSD for other plans.

  Examples of coordination of benefits between CDCP and **Nova Scotia dental programs** are given below for illustrative purposes only:

  **Example 1: No co-payment**

  + Provider charges: $200
  + CDCP fee grid maximum: $200
    - CDCP pays provider: $200
  + Provincial program fee maximum: $100
    - Both DHW and DOSD programs pay provider: $0 (provincial program maximum reached with CDCP payment)
  + Client pays: $0

  **Example 2: 60% co-payment (when coordinating with DHW programs)**

  + Provider charges: $200
  + CDCP fee grid maximum: $200
    - CDCP pays provider: $80 (40% of $200)
    - Client’s co-payment: $120 (60% of $200)
  + Provincial program fee maximum: $100
  + DHW program pays provider: $20 ($100-$80)
  + Total paid to provider: $100 ($80 +$20)
  + Balance remaining: $100 ($200- ($80+20))
    - Provider **cannot** bill the remaining $100 to the client.

  **Example 3: 60% co-payment (when coordinating with DOSD programs)**

  + Provider charges: $200
  + CDCP fee grid maximum: $200
    - CDCP pays provider: $80 (40% of $200)
    - Client’s co-payment: $120 (60% of $200)
  + Provincial program fee maximum: $100
    - DOSD program pays provider: $100 (up to the provincial program fee maximum)
  + Total paid to provider: $180 ($80+$100)
  + Balance remaining: $20 ($120-$100)
  - Provider could bill the remaining $20 to the client

* Some services covered by the CDCP and by Nova Scotia programs are subject to frequency limits. These frequency limits are not cumulative – neither the CDCP nor the Nova Scotia dental programs will provide coverage for services beyond their respective frequency limits. For both ESIA and DSP clients, there are no frequency limits.

## What if services require preauthorization under the CDCP?

* Some services under the CDCP require prior approval through preauthorization before the treatment is confirmed for coverage under the plan. Certain services always require preauthorization, and services above CDCP frequency limitations can also be requested through preauthorization.
* CDCP is accepting preauthorization requests effective November 1, 2024.
* Providers should refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for services covered by the CDCP and the policies, including criteria, guidelines and limitations, as well as the [CDCP Dental Benefit Grids](https://can01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.sunlife.ca%2Fsl%2Fcdcp%2Fen%2Fprovider%2Fdental-benefit-grids%2F&data=05%7C02%7Cshirley.thai%40hc-sc.gc.ca%7C31f58f7dec6d467371ab08dda42f854c%7C42fd9015de4d4223a368baeacab48927%7C0%7C0%7C638847246481995004%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=mpAABWE8%2BbXopwQtJE8udn68cOmmOWnY%2FN6yK29es%2Fk%3D&reserved=0) for the list of procedure codes that always require preauthorization - under “Schedule B” or identified with a “P”. This also includes treatment for services available without prior approval, but that would be above established frequency limits.
* Oral health providers need to submit all required and relevant information available to support the request directly to Sun Life. Please refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for documentation requirements.
* If a service requires preauthorization under the CDCP, the preauthorization request for that service must always be submitted to CDCP, regardless of whether the service is covered or has been preauthorized by another federal or provincial dental program.

## What else do providers need to know?

* ESIA clients must present an MSI (Medical Services Insurance) health card to validate their coverage under ESIA, and for providers to continue with any predetermination of oral health services.

* Providers may bill patients for services deemed ineligible under the Nova Scotia program or exceeding the frequency limit of the program, as they do with CDCP.

## Resource:

For more guidance on the claims submission process for CDCP, including preauthorization, post-determination, and reconsideration steps, please refer to the Sun Life [claims submission information resource](https://www.sunlife.ca/content/dam/sunlife/regional/canada/documents/cxo/cdcp/cdcp-csi-en.pdf).

## Page details

Date modified:
:   2025-06-13

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
