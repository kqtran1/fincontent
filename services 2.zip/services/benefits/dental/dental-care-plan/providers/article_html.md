---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/article.html
scraped_at: 2025-08-24 14:25:44
filename: en/services/benefits/dental/dental-care-plan/providers/article_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/article.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Canadian Dental Care Plan: Updates for oral health providers

Date published: April 22, 2024

Being at the forefront of delivering oral health care, you play a crucial role in the overall health and well-being of Canadians. Unfortunately, we know that for many Canadians, cost is a barrier to receiving care.

Last December, we launched the [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html) (CDCP). The CDCP will help make oral health care more affordable for up to 9 million Canadian residents with an adjusted family net income of less than $90,000 who do not currently have access to dental insurance. As of today, more than 1.7 million Canadian residents have been approved for oral health care services under the CDCP.

The CDCP will reduce financial barriers to access oral health care. As professionals dedicated to improving the oral health of Canadians, this will help you provide care to existing patients covered under the plan, and is an opportunity to have new patients through the CDCP visit your practices and benefit from your care. We thank the more than 5,000 oral health providers who, as of April 16, have agreed to help CDCP clients get the care they need, and the many more who continue to join every day.

As oral health care providers, you can easily confirm your participation in the CDCP with [Sun Life.](https://www.sunlife.ca/sl/cdcp/en/provider/) To ensure you have all the information you need on the CDCP, we have been hosting virtual information sessions for the oral health community and answering many questions.

[Learn more about participating in the CDCP as a provider](/en/services/benefits/dental/dental-care-plan/providers.html)

We know there is misinformation circulating within the oral health care community. We would like to address this directly and share some key facts.

**Fact: Claims processing and payment under the CDCP will operate like many existing insurance plans**

Being a CDCP oral health provider will NOT impose an additional administrative burden on your office. You can submit your digital CDCP claims in the same way you submit your claims for private insurance plans through your existing electronic data interchange (EDI) software. In fact, the CDCP will operate like many of the insurance plans that are already familiar to you.

We have made it as easy as possible for you to submit claims and receive accurate and fast reimbursement. You will be able to sign up for Electronic Funds Transfer (EFT) on Sun Life Direct to receive claim payments by direct deposit. You can receive claim payments by direct deposit within 48 hours initially, and we will move towards a 24-hour turnaround time.

There is no calculation required by you or your staff related to the costs that will be covered or not covered under the plan. You will submit, as you do now for other plans, the amount billed. Sun Life will provide an Explanation of Benefit (EOB) almost instantaneously that will indicate the amount that will be reimbursed by the CDCP directly to you. CDCP clients may have to pay additional charges not covered by the plan directly to you.

Like private insurance plans, the CDCP requires preauthorization for some services. The vast majority of claims expected for the CDCP—well above 90%—will not require preauthorization. For the remaining services that do require it, Health Canada is committed to standardizing the preauthorization process with the goal of reducing the administrative burden for your staff.

Starting in November 2024, preauthorization requests can be submitted electronically and will allow attachments and digital x-rays. We know this will be an important improvement for your offices.

**Fact: A provider agreement is simply a billing agreement**

When you agree to submit claims for any type of insurance, you are agreeing to terms which are similar to those outlined in the CDCP claims processing and payment agreement. The CDCP agreement to participate is simply a billing agreement, and we will not change its terms without first consulting with oral health care providers.

You are asked to confirm participation in the CDCP to ensure advance understanding of the principles of the CDCP, particularly that you will submit the claim on behalf of the patient and accept direct payment from Sun Life to limit the out-of-pocket costs that your CDCP patients will have to pay. Patients need to know upfront that the claims will be submitted by the practitioner, who will accept direct payment from Sun Life. We ask that patients discuss payment, including any possible additional charges, with their practitioner ahead of seeking care.

In choosing to participate, oral health care providers continue to conduct business as they currently do, including determining their own capacity and building relationships with patients.

You can end your participation at any time by calling Sun Life or ceasing to submit claims under the CDCP. There is no penalty for doing so.

**Fact: Provider-patient relationship remains the same**

The claims processing and payment agreement for the CDCP is solely related to the claims you are submitting for reimbursement under the CDCP. The relationship between you and your patient does not change and you will always own your patient’s chart. If you see information online that says differently, it is false.

**Fact: Supporting patient choice and increasing access to care**

We understand that some oral health providers may choose not to participate fully as a CDCP provider but would still like to provide care to CDCP clients.

That is why we have developed a new process to allow oral health providers who choose not to sign-up officially in the CDCP to still have a way to submit electronic claims to Sun Life for services provided to CDCP clients.

As of July 8, 2024, if you have not already signed up as a CDCP provider, you will be able to treat CDCP clients and bill Sun Life for services provided on a claim-by-claim basis, in accordance with the CDCP payment agreement.

You have told us patient choice is important. The new claim-by-claim process will mean that CDCP clients can see any oral health provider they choose for their care, as long as the provider agrees to direct bill Sun Life for services provided under the plan. CDCP clients should not pay the full amount to their provider as they will not be reimbursed under the plan. CDCP clients will only be required to pay any amount not covered by the plan, which will be paid directly to the provider.

**Fact: There may be additional costs to getting care, it may not be entirely free for CDCP clients**

The aim of the CDCP is to help make the cost of dental care more affordable for Canadian residents who do not currently have access to dental insurance.

However, the [CDCP fees](https://www.sunlife.ca/sl/cdcp/fr/provider/dental-benefit-grids/) may not be the same as what you charge. We understand that the cost of providing oral health care services may differ from one office to another and may be more than what the CDCP will reimburse.

CDCP clients are being reminded that they may have to pay additional charges, in addition to any co-payment, and to always ask you about any costs that will not be covered by the plan.

However, even when patients have to pay additional charges, the CDCP will still result in significantly lower costs for them, compared to what they face now without any dental coverage.

**Fact: No money can or will ever be withdrawn from your bank account**

Neither the Government of Canada nor Sun Life have the ability to withdraw funds directly from your bank account. If you see this information being shared, it is false.

**Fact: CDCP is being rolled out in all provinces and territories**

The Government of Canada is committed to ensuring that everyone who is eligible for the CDCP, no matter where they live in Canada, can receive oral health care through the CDCP. This includes people living in the province of Quebec, where many seniors have already applied and will be looking to receive care from participating providers.

**Fact: CDCP fees will be reassessed each year**

Consistent with existing industry practice, the CDCP has different fee grids for each province and territory and for each oral health profession that can bill independently.

CDCP fees differ from those set out by oral health professional associations in provincial and territorial fee guides, but on average represent 80-90% of those fee guides.

The full 2024 [CDCP Dental Benefit Grids](https://www.sunlife.ca/sl/cdcp/en/provider/dental-benefit-grids/) are now available for each province and territory and are sorted by oral health profession.

Fees will be reassessed annually to account for new scientific evidence, inflation, and changes in costs over time. The Government will continue to work with oral health provider associations to inform the methodology for determining fees for 2025 and beyond.

**Fact: Coordination of benefits with existing social dental programs**

The CDCP is intended to complement existing provincial and territorial dental programs and to fill existing gaps in coverage for those programs. For most provincial and territorial public dental programs, the CDCP will be the primary payer. Where provincial dental programs are legislated, the CDCP will comply with the legislative payer order (first or last payer depending on the legislation). More details will be provided and published before May 1, including detailed, easy-to-reference information to help you and your office staff know how to coordinate across various plans in their region.

For more information:

* [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
* [Sun Life CDCP oral health providers](https://www.sunlife.ca/sl/cdcp/en/provider/)
* Sun Life’s designated CDCP call centre: l 1-888-888-8110

Additional resources and tools for informing your patients:

* [Sun Life: CDCP](https://www.sunlife.ca/sl/cdcp/en/)

## Page details

Date modified:
:   2024-04-22

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
