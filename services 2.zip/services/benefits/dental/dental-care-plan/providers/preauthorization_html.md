---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/preauthorization.html
scraped_at: 2025-08-24 19:54:34
filename: en/services/benefits/dental/dental-care-plan/providers/preauthorization_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/autorisation-prealable.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)

# Canadian Dental Care Plan providers: Preauthorization resources

## On this page

* [About preauthorization](#h2.1)
* [Supporting documentation requirements for preauthorization submissions](#h2.2)
* [Preauthorization process videos](#h2.3)

## About preauthorization

Since November 1, 2024, oral health providers have been able to submit Canadian Dental Care Plan (CDCP) preauthorization requests for services that require prior approval. The CDCP preauthorization process is different from private insurance plans and the CDCP coverage criteria are more stringent.

The CDCP assesses preauthorization requests based on clinical criteria established by Health Canada, which take into account basic treatment needs that may impact the service being requested. In those instances, basic treatment needs are defined as any treatment required to address any existing active biological disease (caries, periodontal and periapical). **Not all requests will be approved.**

Oral health providers and their staff should consult the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for covered services, coverage criteria, guidelines and limitations and what documentation and details they need to include with their preauthorization submissions, before submitting their request, to avoid delays in processing time.

Also, to help minimize delays, providers should not submit the same preauthorization submissions or claims multiple times, as each submission or claim submitted is considered as a new request every time. Providers will receive a decision once their submission or claim has been processed. Claims and submissions are being processed on a first-come, first-processed basis.

Health Canada and Sun Life continue to take steps to help improve the preauthorization process, where possible, and are working closely with national, provincial and territorial associations to address the challenges raised by their members.

## Supporting documentation requirements for preauthorization submissions

The following chart is intended as a summary reference guide of the documentation required to support a request for preauthorization under the CDCP. In some circumstances and for some services, different requirements may apply. Refer to the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html) for comprehensive and authoritative information, including CDCP coverage criteria, guidelines and policies for services. If there are discrepancies between this chart and the Guide, the policies in the Guide prevail.

Providers should submit as much relevant documentation as possible to support a thorough assessment of the preauthorization request. The CDCP reserves the right to request additional information, and to deny submissions that do not sufficiently demonstrate the eligibility criteria are met.

**CDCP: Supporting documentation requirements for preauthorization submissions**

| CDCP service | Claim form | Treatment plan details | Dated periapical and bitewing radiographs (within last 12-months) | Dated complete periodontal chart (within last 12-months) | Missing teeth or most recent dated panoramic radiograph | Planned extractions | Duration of planned sedation session | Referral, with justification | Rationale |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Specialist examinations | Yes | N.A. | N.A. | N.A. | N.A. | N.A. | N.A. | Yes | N.A. |
| Restorative services | Yes | Yes1 | Yes | Yes, only for crowns | N.A. | N.A. | N.A. | N.A. | N.A. |
| Endodontic services | Yes | Yes1 | Yes3 | Yes | N.A. | N.A. | N.A. | N.A. | N.A. |
| Additional units of scaling and root planing | Yes | Yes1 | Yes4 | Yes6 | N.A. | N.A. | N.A. | N.A. | N.A. |
| Removable complete dentures | Yes | Yes1 | N.A. | N.A. | Yes | Yes, if any | N.A. | N.A. | N.A. |
| Removable partial dentures | Yes | Yes1 | Yes5 | N.A. | Yes | Yes, if any | N.A. | N.A. | N.A. |
| Oral surgery services | Yes | Yes1 | Yes3 | N.A. | N.A. | N.A. | N.A. | N.A. | Yes |
| Sedation services | Yes | Yes2 | Yes3 | N.A. | N.A. | N.A. | Yes | N.A. | Yes |

* 1 Treatment plan details indicating all relevant completed and pending treatment needs, or, based on the provider’s scope of practice, confirmation that potential basic treatment needs are being referred and/or will be addressed. This does not need to be submitted as a stand-alone document labelled ‘treatment plan’ so long as the information is included in the documentation submitted.
* 2 Planned/proposed treatment to be completed during sedation session.
* 3 Dated panoramic radiograph will be considered when it is not possible to obtain periapical or bitewing radiographs, as indicated in a rationale.
* 4 If radiographs cannot be provided, a rationale must be provided accounting for the missing radiographs.
* 5 **One** of the following is required:
  + dated periapical radiographs of abutment teeth and dated bitewing radiographs (within last 12 months); or
  + when it is not possible to obtain periapical or bitewing radiographs, the most recent dated panoramic radiograph; or
  + if radiographs are not available, **one** of the following:
    - dated photos of the maxillary and mandibular arches (2) (upper and lower separate); or
    - dated photos of stone models (2) (upper and lower separate); or
    - dated stone models (upper and lower)
* 6 If completion of the periodontal chart is not possible, a rationale is required to explain why the chart is incomplete and to provide any relevant information not captured in the chart.

[![](/content/dam/canada/doc.png)

Download the PDF of the table: CDCP: Supporting documentation requirements for preauthorization submissions [PDF - 119 KB]](/content/dam/canada/employment-social-development/services/benefits/dental/dental-care-plan/providers/CDCP-Supporting-Documentation-Requirements-for-Preauthorization-Submissions.pdf)

## Preauthorization process videos

To help providers and their staff, we have created tutorial videos explaining what documentation is needed when submitting a preauthorization request.

Videos:

* [CDCP preauthorization process video: Partial dentures](/en/services/benefits/dental/dental-care-plan/providers/preauthorization/partial-dentures-video.html)
* [CDCP preauthorization process video: Additional units of scaling](/en/services/benefits/dental/dental-care-plan/providers/preauthorization/scaling-video.html)

## Page details

Date modified:
:   2025-05-13

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
