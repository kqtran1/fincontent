---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/vietnamese.html
scraped_at: 2025-08-24 20:04:13
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/vietnamese_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/fiches-information-multilingues/vietnamien.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
6. [Canadian Dental Care Plan promotional toolkit: Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)

# Bộ công cụ quảng cáo về chương trình chăm sóc răng miệng của Canada: Tờ thông tin bằng tiếng Việt

## Định dạng PDF

[![](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Vietnamese.jpg)

Bộ công cụ quảng cáo về chương trình chăm sóc răng miệng của Canada: Tờ thông tin bằng tiếng Việt [PDF - 271 KB]](/content/dam/esdc-edsc/documents/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP_Factsheet-Vietnamese.pdf)

## Nội dung của tờ thông tin

**Chương trình Chăm sóc Nha khoa Canada**

## Chương trình Chăm sóc Nha khoa Canada(CDCP) sẽ giúp giảm nhẹ các rào cản tài chính cho 9 triệu người Canada.

Tiêu chí

Để được hưởng chương trình, quý vị phải hội đủ những tiêu chí sau:

* không có bảo hiểm nha khoa
* thu nhập sau thuế của gia đình quý vị đã điều chỉnh chưa đến $90,000
* là một cư dân Canada có nghĩa vụ đóng thuế
* Bạn và vợ/chồng/bạn đời chung sống của bạn (nếu có) đã khai thuế ở Canada để có thể đánh giá mức thu nhập của gia đình bạn trong năm truớc

Các dịch Vụ Nha khoa

Quý vị được chi trả nhiều dịch vụ nha khoa theo chương trình CDCP, theo đề nghị của nhà cung cấp dịch vụ nha khoa:

* Lấy cao răng Scaling (cleaning)
* Khám
* Chụp X quang
* Trám rang
* Răng giả tháo lắp
* Các điều trị tủy răng
* Phẫu thuật nha khoa

Chương trình CDCP sẽ hoàn trả một tỷ lệ phần trăm chi phí dựa trên các chi phí của CDCP và thu nhập sau thuế đã điều chỉnh của gia đình quý vị.

Quý vị có thể trả các chi phí thêm trực tiếp cho nhân viên chăm sóc nha khoa nếu:

* thu nhập sau thuế của gia đình quý vị đã điều chỉnh nằm trong khoảng $70,000 đến $89,999
* chi phí các dịch vụ chăm sóc nha khoa của quý vị lớn hơn các chi phí của chương trình CDCP, hoặc
* quý vị và nhà cung cấp dịch vụ chăm sóc nha khoa thỏa thuận về các dịch vụ mà chương trình CDCP không chi trả

Chương trình CDCP sẽ chỉ hoàn trả trực tiếp cho các nhà cung cấp. Khách hàng của CDCP nên xác nhận tại thời điểm hẹn cũng như trước khi nhận dịch vụ chăm sóc rằng nhà cung cấp của họ đã đồng ý gửi hóa đơn trực tiếp cho Sunlife đối với các dịch vụ được bao trả theo CDCP.

Chăm sóc nha khoa rất quan trọng đối với sức khỏe và hạnh phúc tổng thể của quý vị. Việc thường xuyên đến gặp chuyên viên nha đã được chứng minh là làm giảm nguy cơ sâu răng, bệnh nướu răng và các vấn đề sức khỏe nghiêm trọng khác như bệnh tim mạch và đột quỵ.

Để biết thêm chi tiết về chương trình CDCP và tiêu chí đủ điều kiện, hãy truy cập Canada.ca/dental

## Page details

Date modified:
:   2025-01-15

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
