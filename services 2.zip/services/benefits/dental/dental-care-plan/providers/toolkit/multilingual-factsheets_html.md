---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html
scraped_at: 2025-08-24 19:19:39
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/fiches-information-multilingues.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

# Canadian Dental Care Plan promotional toolkit: Multilingual factsheets

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

## How to use the factsheets

Download and print these factsheets on your printer, or use a printing service.

Multilingual factsheets

| Language | Title/link | Preview |
| --- | --- | --- |
| Arabic | [Canadian Dental Care Plan promotional toolkit: Arabic factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/arabic.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Arabic.jpg) |
| English | [Canadian Dental Care Plan promotional toolkit: English factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/english.html) (includes large print and audio formats) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-English.jpg) |
| French | [Canadian Dental Care Plan promotional toolkit: French factsheet](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/fiches-information-multilingues/francais.html) (includes large print and audio formats) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-French.jpg) |
| Hindi | [Canadian Dental Care Plan promotional toolkit: Hindi factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/hindi.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Hindi.jpg) |
| Korean | [Canadian Dental Care Plan promotional toolkit: Korean factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/korean.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Korean.jpg) |
| Michif Cree | [Canadian Dental Care Plan promotional toolkit: Michif Cree factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/michif-cree.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Michif-Cree.jpg) |
| Portuguese | [Canadian Dental Care Plan promotional toolkit: Portuguese factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/portuguese.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Portuguese.jpg) |
| Punjabi | [Canadian Dental Care Plan promotional toolkit: Punjabi factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/punjabi.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Punjabi.jpg) |
| Spanish | [Canadian Dental Care Plan promotional toolkit: Spanish factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/spanish.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Spanish.jpg) |
| Simplified Chinese | [Canadian Dental Care Plan promotional toolkit: Simplified Chinese factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/simplified-chinese.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Simplified%20Chinese.jpg) |
| Tagalog | [Canadian Dental Care Plan promotional toolkit: Tagalog factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/tagalog.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Tagalog.jpg) |
| Traditional Chinese | [Canadian Dental Care Plan promotional toolkit: Traditional Chinese factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/traditional-chinese.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Traditional%20Chinese.jpg) |
| Ukrainian | [Canadian Dental Care Plan promotional toolkit: Ukrainian factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/ukrainian.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Ukrainian.jpg) |
| Vietnamese | [Canadian Dental Care Plan promotional toolkit: Vietnamese factsheet](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets/vietnamese.html) | ![thumnail](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/factsheet/39-24-3653-CDCP-Factsheet-Vietnamese.jpg) |

## Page details

Date modified:
:   2025-01-15

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
