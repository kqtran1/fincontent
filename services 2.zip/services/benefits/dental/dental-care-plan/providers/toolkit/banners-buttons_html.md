---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html
scraped_at: 2025-08-24 19:58:14
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/bannieres-boutons.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

# Canadian Dental Care Plan promotional toolkit: Web banner and button images

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

Resources to help you spread awareness about the Canadian Dental Care Plan (CDCP) through your website.

## On this page

* [How to use the banner and button images](#h2.1)
* [Banner and button images](#h2.2)

## How to us the banner and button images

From the tables below, you can select CDCP banner or button images for download. Once downloaded, the images can be added to your professional website.

## Banner and button images

Banner images

| Image | Image text | Download |
| --- | --- | --- |
| ![Father and daughter brushing their teeth while looking into the mirror.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner1_EN.png) | Are you eligible for the new Canadian Dental Care Plan? Find out on Canada.ca/dental | [Canadian Dental Care Plan – Banner image 1 (PNG – 38.1 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner1_EN.png) |
| ![Senior couple laughing together.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner2_EN.png) | Find out how the Canadian Dental Care Plan can help you get oral health care. Visit Canada.ca/dental | [Canadian Dental Care Plan – Banner image 2 (PNG – 44.2 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner2_EN.png) |
| ![Mother and daughter brushing their teeth while looking into the mirror.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner3_EN.png) | Find out how the Canadian Dental Care Plan can help you get oral health care. Visit Canada.ca/dental | [Canadian Dental Care Plan – Banner image 3 (PNG – 40.1 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Banner3_EN.png) |

Button images

| Image | Image text | Download |
| --- | --- | --- |
| ![A woman smiling while seeing an oral health professional ](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button1_EN.png) | Learn about the new Canadian Dental Care Plan. Canada.ca/dental | [Canadian Dental Care Plan – Button image 1 (PNG - 33.3 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button1_EN.png) |
| ![Three icons including a tooth brush, tooth, and mouth wash with text saying “Canadian Dental Care Plan Accessible, Affordable, Essential”](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button2_EN.png) | Canadian Dental Care Plan Accessible, Affordable, Essential. Canada.ca/dental | [Canadian Dental Care Plan – Button image 2 (PNG - 12 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button2_EN.png) |
| ![Father and daughter brushing their teeth while looking into the mirror.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button3_EN.png) | Are you eligible for the new Canadian Dental Care Plan? Find out at Canada.ca/dental | [Canadian Dental Care Plan – Button image 3 (PNG – 40.1 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button3_EN.png) |
| ![Mother and daughter brushing their teeth while looking into the mirror.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button4_EN.png) | Find out how the Canadian Dental Care Plan can help you get oral health care. Visit Canada.ca/dental | [Canadian Dental Care Plan – Button image 4 (PNG – 43.5 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button4_EN.png) |
| ![Woman points to her smile](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button5_EN.png) | Learn about the new Canadian Dental Care Plan. Canada.ca/dental | [Canadian Dental Care Plan – Button image 5 (PNG - 30 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/banners-buttons/Button5_EN.png) |

## Page details

Date modified:
:   2024-12-11

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
