---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html
scraped_at: 2025-08-24 14:05:21
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/temoignages.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

# Canadian Dental Care Plan promotional toolkit: Testimonials

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

Learn how Canadian residents are benefitting from being part of the Canadian Dental Care Plan (CDCP) and what motivates oral health providers to participate and deliver care to Canadian residents under the CDCP.

## On this page

* [Patient testimonials](#h2.01)
* [Oral health provider testimonials](#h2.02)

## Patient testimonials

![Susan's testimonial](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-thumbnail.png)

[Video: Patient testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-video.html)

Testimonials from patients participating in the Canadian Dental Care Program.

Disclaimer: This video contains both English and French audio. You may use the available transcript and/or closed captions to read the testimonials in your preferred language.

![Catherine, CDCP patient](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Patient_Catherine.jpg)

> “Oh, it is so good. That day I jumped, I danced, I was running around and telling everyone, get this, get this! I say, it's going to help our health. And after having seen my dentist, I am more confident, I feel great. And now I can go ahead with life again.”
>
> Catherine, CDCP patient

![Catherine, CDCP patient](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Patient_Catherine.jpg)

![Susan's testimonial](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Patient_Susan.jpg)

> “The initial X-rays and visits were covered. Then I went to a denturist, who created these beautiful teeth. I never had dentures before, so it's a journey. I'm looking forward to doing many more things now instead of hiding in my apartment.”
>
> Susan, CDCP patient

![Morton's testimonial](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Patient_Martin.jpg)

> “My ten-year-old grandson is part of the plan, so starting at age ten he’ll have good teeth. We should keep this program going for life!”
>
> Morton, CDCP patient

![Morton's testimonial](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Patient_Martin.jpg)

![Susan's testimonial](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Geraldine_765x400_2white.jpg)

> “I got my dental card in the mail, and I was so relieved to know I could finally get the care I needed to fix my cavity. I didn't have to search every corner of my purse to cover the cost. Instead, I was able to move forward with my treatment.”
>
> Geraldine, CDCP patient

## Oral health provider testimonials

![Dr. Anil Makkar, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/provider_thumbnail.jpg)

[Video: Provider testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/provider-video.html)

Testimonials from Health Care providers that are participating in the Canadian Dental Care Program.

![Dr. Anil Makkar, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/provider_thumbnail.jpg)

![Dr. Anil Makkar, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/dr-makkar_765x400_2white.jpg)

> “This dental plan is about providing care for the patient. So, I said, why wouldn't I do this? Especially when you see how some patients haven't seen a dentist for a long time because they can't afford it, you just got to do it.”
>
> Dr. Anil Makkar, Dentist

![Guylaine Souligny-Théoret, Independent dental hygienist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Dr_Guylaine_Theoret.jpg)

> “Having plaque constantly on your teeth or inflammation in your mouth has an impact on your health because these harmful bacteria enter your blood stream and spread throughout your body. The plan represents access to dental care, and that is why I talk about it to people who may be eligible.”
>
> Guylaine Souligny-Théoret, Independent dental hygienist

![Guylaine Souligny-Théoret, Independent dental hygienist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Dr_Guylaine_Theoret.jpg)

![Jaro Wojcicki, President of the Denturist Association of Canada](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Jaro_765x400_2white.jpg)

> “Our focus as denturists remains unwavering to provide much-needed care to our patients. The CDCP has united us in our mission to enhance oral health care accessibility and delivery. It's very heartening to see the entire profession come together for a common cause that benefits so many.”
>
> Jaro Wojcicki, President of the Denturist Association of Canada

![Dr. David C. Mady, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/dr-david-mady_765x400_2white.jpg)

> “Participating in the CDCP was a no brainer as it's going to help the 25 to 30% of our patients who don't have dental insurance.”
>
> Dr. David C. Mady, Dentist

![Dr. David C. Mady, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/dr-david-mady_765x400_2white.jpg)

![Dr. Bob Schroth, Professor and dentist clinician-scientist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Schroth_765x400_2white.jpg)

> “In my 28 years of clinical practice, I have never seen such an investment in children’s oral health. It is a first step in addressing access to oral health care for children in Canada.”
>
> Dr. Bob Schroth, Professor and dentist clinician-scientist

Read Dr. Bob Schroth's full testimonial

### Connecting families with children to oral health care

By: Dr. Bob Schroth

Professor and Clinician Scientist, Rady Faculty of Health Sciences
Section Head, Pediatric Dentistry, Winnipeg Regional Health Authority
Scientist, Children's Hospital Research Institute of Manitoba

As both a dentist and a professor, I understand that you can't have a healthy child without healthy teeth. That's why I have dedicated my 28-year career and clinical practice to set kids down that perfect trajectory for a lifetime of good overall health.

Sadly, too many children continue to experience preventable tooth decay for a variety of reasons, including a lack of access to affordable dental care. I hear this from the parents that visit the community clinics where I work in Winnipeg who explain how they have avoided taking their child for regular check-ups due to the cost.

### Participating in the CDCP

When the Canadian Dental Care Plan (CDCP) was rolled out to include children and youth under 18 years, I had never seen such an investment in children's oral health in all my years of clinical practice. Being able to connect more kids to essential dental care is what motivated me to be one of the first dentists to join this national initiative.

After joining, more children started visiting our clinic for care who otherwise would not have visited because their parents either didn't have dental insurance or the financial means. I recognized immediately that the plan was acting like a lifeline to families because it took away the financial burden.

### Grateful families

The families I treat represent diverse groups from across Canadian society who often can't afford care. They are so appreciative when they learn they may be eligible for coverage under the CDCP or when our team offers to help them apply. They can't wait to get their welcome package so they can book their visit.

Most recently, I had a parent of a two-year-old with extensive tooth decay come in for a visit. The mother, who is a Canadian resident and newcomer, shared how she had been hesitant to bring her son in because she couldn't afford the appointment, let alone the treatment. Once I explained how her child was eligible under the plan, she was relieved and grateful to find a solution, particularly when they are struggling to provide the basics.

I also had a parent return with their 8-year-old daughter. The child was identified to be in need of treatment over 18 months ago, but the parents held off with her restorative care, partly because of cost. Now with the CDCP, we are able to begin restorative work.

Without the CDCP, that child's family would suffer financial hardship. Moving forward, her parents have the peace of mind knowing that their daughter can receive the treatment she needs and the benefits of preventative care that comes with regular check-ups and cleanings. Being able to deliver essential care to young children and see their confidence as they smile back at you is quite frankly rewarding.

### Dedicated staff and community engagement

Each visit, my team and I prompt meaningful discussions with parents so they can actively take part in helping to protect their child's teeth and gums. Many are surprised to learn that protecting your child's teeth starts early by bringing in their baby for a check-up before their first year. Protecting your child's teeth throughout their development also involves limiting sugar and supporting healthy oral health habits like daily brushing and regular check-ups.

As a further service to our community, you will find our Healthy Smile Happy Child Initiative team and our dental, dental hygiene, and undergraduate students visiting local community centres and events to promote early childhood oral health. By engaging with the community, they can reach more families to spread the word about why maintaining your oral health is part of good overall health and well-being. One of my students said to me, "We try and go above and beyond to let more people know why maintaining good oral health is important and is more accessible thanks to the CDCP." Providing this little extra support has gone a long way to help parents understand oral health issues that can arise during childhood like tooth decay, teething problems or misaligned teeth.

### Prevention is key to living cavity free

My ongoing research and community practice has shown me that prevention is key to offsetting the burden to both families and society. That's why it is important to address cavities in a timely manner to protect children from infections due to untreated tooth decay. When children develop severe tooth decay or oral health issues go unaddressed, some children may end up having to receive treatment in the hospital and may require general anesthesia to facilitate their dental care. Unfortunately, long wait lists for pediatric dental surgery continue in parts of Canada.

Making oral health care more accessible has been and continues to be my life's work. If prevention is key, then I cannot help being inspired with how the CDCP is benefitting children and youth so they can live a life that is cavity free.

![Dr. Lauretta Gray, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/dr-lauretta-grey_765x400_2white.jpg)

> “We quickly realized the first day that the CDCP was accepted that our patients were expecting us to participate. There was no way I was saying no. We signed up that day and hit the ground running.”
>
> Dr. Lauretta Gray, Dentist

![Dr. Lauretta Gray, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/dr-lauretta-grey_765x400_2white.jpg)

![Shannon Maitland, Dental hygienist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Shannon-Maitland.jpg)

> “I'm getting to know clients who are getting care under the CDCP and it makes it real. Many of these seniors haven't received dental care in the last 20 or 30 years.”
>
> Shannon Maitland, Dental hygienist

Read Shannon Maitland's full testimonial

### The gift of improving oral health

By: Shannon Maitland RDH, CAE

Registered Dental Hygienist

Dental Hygiene Educator

![Female dental hygienist with mask and gloves using magnifying glasses with light working on a patient reclined in a dental chair inside a mobile dental clinic.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Shannontestimonial-closedentist.jpg)

![Shannon smiling while wearing burgundy medical scrubs seated beside a dental exam chair inside a mobile dental clinic.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Shannon_Maitland_headshot.jpg)

![Female dental hygienist using a magnifying glass with light working on a male patient reclined in a dental chair inside a mobile dental clinic.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Shannontestimonial-fardentist.jpg)

Growing up my family didn't have dental benefits. My dental care was limited to dental emergencies. As a child, I broke my two front teeth and needed restoration work. A few years later, I had a root canal and eventually needed a crown. These interactions with oral health professionals could have been traumatic, but instead they left a positive impression. Their kindness and compassion led me to a career in oral health care as a dental hygienist.

#### Starting a mobile practice

After working in a dental clinic for several years, I started to feel that I needed a change. In 2021, my mom passed away and it solidified my decision to take a step back from practice to recover and heal. I ended up teaching at the school where I trained as a hygienist, but after some time, I started to miss caring for clients.

I knew that I could have a greater impact on people's lives by working directly with them, so I decided to open my independent practice. What makes my practice special is that I go to my clients. I treat a range of clients, including seniors who can no longer drive, busy families, and people with physical disabilities or crippling anxiety, right in my dental hygiene van. The inside is fitted as a dental hygiene clinic and I've created a welcoming and friendly atmosphere, accessible right there in my client's own surroundings.

#### Signing-up for the CDCP

I registered for the Canadian Dental Care Plan (CDCP) as soon as it opened for providers. It was an easy decision as someone who grew up without regular dental care. Now that I'm a hygienist, I know how important preventative care is to our overall health and well-being.

The people who are eligible for the CDCP qualify based on their income. I'm hearing directly from CDCP clients that they simply couldn't afford dental care before the CDCP because their small income goes towards groceries and electricity. The advantage of the CDCP is that they don't have to sacrifice their basics needs to take care of their teeth.

I'm getting to know clients who are getting care under the CDCP and it makes it real. Many of these seniors haven't received dental care in the last 20 or 30 years. They need a lot of care and have a lot of anxiety. I spend a good amount of time speaking to them to try and ease their worries and make them comfortable. I love getting to know people in my community through my work. I get to hear a whole life come to fruition, all while educating them about their oral health.

#### Oral health care is health care

I'm not just taking care of my client's teeth. During a visit, I'm doing screenings for high blood pressure, signs of oral cancer and possible airway obstruction, and I also do medical referrals if needed. I once had a patient call me, after I had referred him for high blood pressure, to tell me he ended up needing a stress test on his heart. It turns out they found a blockage and he needed a stent put in. By simply doing my job, I potentially prevented a heart attack.

Recently I treated a Ukrainian couple who immigrated to Canada because of the war. They qualified for the CDCP and came to me after a very long time without dental care. They had a lot of dental work that was failing over the years and didn't have the money to have it fixed. Although they didn't speak much English and communication was limited, I could tell how much getting care meant to them. At the end of the appointment the wife was crying and hugging me. That's enough communication for me.

I'm having to find a new normal since the passing of my mom, but my experience as an independent dental hygienist has solidified that what I do is so good for people. Nothing makes me happier than knowing that I'm improving people's lives. It is truly a gift.

![Benoit Talbot, Denturist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Mainimage-Benoit_Talbot_765x400.jpg)

> “For most of my CDCP patients, receiving new dentures gave them not only the opportunity to smile again but also the ability to bite into life!”
>
> Benoit Talbot, Denturist

Read Benoit Talbot’s full testimonial

### Canadian Dental Care Plan: a better way to bite into life

By: Benoit Talbot

President, Association des denturologistes du Québec

As a denturist, when I heard about the Canadian Dental Care Plan (CDCP), I knew I couldn’t pass it up, especially since the first cohorts to be covered by the Plan were seniors. They’re our main customers: seniors are the ones wearing dentures and very seldomly 20- or 30-year-olds.

#### Seniors responded

![Benoit Talbot, Denturist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Longform_image_benoit.jpg)

As soon as the Plan was launched, seniors turned out! If I may offer a thought, whether we like it or not, seniors are sometimes forgotten members of our society and, once they’ve retired, we tend to put them into a separate category. But with the Plan’s introduction, these people are so happy and grateful for what the CDCP represents for them, especially in terms of their quality of life.

Over the past few months, I’ve seen patients who have gone 10 or 15 years without dentures because they couldn’t afford them. These people are really looking forward to being able to bite into their food and eat something other than a soft diet because their dentures were too worn or simply could no longer be used. While I am happy to treat these people, the denturist in me also needs to do a bit of educating. Sometimes we have to tell them that there has been gum (bone) resorption or that their tongue has become very wide from having to aid with chewing, and that they won’t be able to eat a steak the next day. We have to explain that the restoration is going to take a little longer but that we’re going to support them through the process.

For most of my CDCP patients, receiving new dentures gave them not only the opportunity to smile again but also the ability to bite into life! I remember a lady, after a successful fitting, who came to bring me homemade jam because she was so grateful to be able to eat everyday food again. Small things like that go straight to the heart. That is what we see with the CDCP: people who have access to new dentures after suffering for years or decades and who can now enjoy life!

Lastly, as far as the technical aspect of the CDCP goes, everything is going quite well with the reimbursement submissions. There may be exceptions and more time may be needed to sort things out, but the process is efficient in most cases. In my 43-year career, rarely have I seen a claim submitted on a Monday and then the reimbursement already deposited in our bank account on Wednesday!

#### A few words about the denturist profession

A denturist’s work goes beyond taking impressions to determine the size and shape of the dentures to be made. There’s everything from fitting and placing dentures into the mouth, to adjustments and repairs. Basically, I’d say that being a denturist also means being able to work at 2 levels: you have to be good with your hands and enjoy working the material to make dentures, and you have to enjoy interacting with people. I like talking to them. I wish for every patient to leave my office with a positive experience.

![Dr. Lauretta Gray, Dentist](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/Mainimage-Benoit_Talbot_765x400.jpg)

Participation in the CDCP is voluntary. Learn more about the CDCP by visiting [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html).

## Page details

Date modified:
:   2025-01-28

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
