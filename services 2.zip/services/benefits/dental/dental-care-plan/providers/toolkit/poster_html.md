---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html
scraped_at: 2025-08-24 17:38:10
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/poster_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/affiche.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

# Canadian Dental Care Plan promotional toolkit: Poster

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

## How to use the poster

Download and print this poster on your printer, or use a printing service.

## PDF format

[![](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/poster/4423-CDCP-Cohort-Poster-EN-v24.jpg)

Canadian Dental Care Plan promotional toolkit: Poster [PDF - 1.56 MB]](/content/dam/esdc-edsc/documents/services/benefits/dental/dental-care-plan/providers/4423-CDCP-Cohort-Poster-EN-v24.pdf)

## Poster text

**Canadian Dental Care Plan**

Accessible. Affordable. Essential.

### Eligibility

To qualify, you must:

* not have access to dental insurance
* have an adjusted family net income of less than $90,000
* be a Canadian resident for tax purposes
* have filed your tax return in the previous year

The Canadian Dental Care Plan (CDCP) will help make the cost of dental care more affordable for up to 9 million eligible Canadian residents.

Oral health care is important to your overall health and well being. Regular visits reduce the risk of health problems.

In 2022, 1 in 4 Canadians reported avoiding visiting an oral health professional due to the cost. Every Canadian deserves accessible, affordable and essential dental care.

### How to apply

Eligible Canadians of all ages can now apply for the CDCP.

You must meet all 4 eligibility requirements before applying.

Eligible Canadians can apply online at Canada.ca/dental, by calling 1-833-537-4342, or by visiting a Service Canada Centre.

For more details on the CDCP and eligibility criteria, visit Canada.ca/dental.

## Page details

Date modified:
:   2025-06-16

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
