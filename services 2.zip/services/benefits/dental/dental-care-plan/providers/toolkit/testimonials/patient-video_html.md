---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-video.html
scraped_at: 2025-08-24 18:08:20
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-video_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/temoignages/video-patients.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
6. [Canadian Dental Care Plan promotional toolkit: Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

# Canadian Dental Care Plan promotional toolkit: Testimonials – Patient testimonials video

Testimonials from patients participating in the Canadian Dental Care Program.

Disclaimer: This video contains both English and French audio. You may use the available transcript and/or closed captions to read the testimonials in your preferred language.

[![

](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-thumbnail.png)](/content/dam/esdc-edsc/videos/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials/patient-video/Patients_Full Length_CLEAN_EN.mp4)

Transcript

*Upbeat music*

*Canadian Dental Care Plan animated logo*

**[English audio]**

***CDCP patient Catherine Hamilton***

There was a senior's care plan before, but dentists were not taking it. So, I was happy to see a dentist because I was really suffering. My health was failing, and I didn't have dental coverage.

My name is Catherine Hamilton and I'm a senior and I have received care through the Canadian Dental Care plan.

After having seen my dentist, I'm more confident, I feel great, and now I can go ahead with life again.

**[French audio]**

***CDCP patient Morton Brisard***

Before, when I was working, I had insurance for the doctor. I would go at least twice a year. Since my wife and I retired, we go as little as possible. After we got the Government of Canada's dental service, we started to go to the dentist as much as possible. We're going to take advantage of it. It would help everyone save money, time and their health.

**[English audio]**

***CDCP patient Susan Sikala***

I'm turning 76 in a week, and if you saw me a few months ago, you would have thought this woman hasn't smiled in years, and here I am.

I haven't actually seen a dentist for about 11 years because I was going through cancer treatment. I had a dentist and I had some assessments done. I was asked, could you afford?

And I said, well, if I don't eat, I could probably afford dental work, you know? So, I was like… desperate, desperate to find another way. Once this program came out, I was so excited.

It's an opportunity for everyone in Canada to have the dental care that they require, I'm just so happy.

*Animated CDCP logo*

Canada.ca/dental

Canada wordmark

## Page details

Date modified:
:   2024-12-11

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
