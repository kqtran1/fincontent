---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html
scraped_at: 2025-08-24 20:08:27
filename: en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs/trousse-outils/medias-sociaux.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
5. [Canadian Dental Care Plan promotional toolkit: Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

# Canadian Dental Care Plan promotional toolkit: Social media shareables

* [Overview](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Social media](/en/services/benefits/dental/dental-care-plan/providers/toolkit/social-media.html)
* [Poster](/en/services/benefits/dental/dental-care-plan/providers/toolkit/poster.html)
* [Banners and buttons](/en/services/benefits/dental/dental-care-plan/providers/toolkit/banners-buttons.html)
* [Multilingual factsheets](/en/services/benefits/dental/dental-care-plan/providers/toolkit/multilingual-factsheets.html)
* [Testimonials](/en/services/benefits/dental/dental-care-plan/providers/toolkit/testimonials.html)

Help get the word out about the Canadian Dental Care Plan through your social media accounts!

## On this page

* [How to share on social media](#h2.1)
* [Social media images and text](#h2.2)

## How to share on social media

* Select a social media platform
* Download the image
* Copy and paste the text to include with the image

The sharing of social media posts directly from Health Canada's official accounts is encouraged :

* Twitter: @GovCanHealth
* Facebook: @Healthy Canadians
* LinkedIn: @Health Canada/Santé Canada

These posts may be reproduced without permission in whole or in part when used for non-commercial reproduction as long as the source is fully acknowledged (Source: Health Canada, [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)).

If you want to create new content to promote the Canadian Dental Care Plan, please submit your request for copyright permission, using the following form: [Application for Copyright Clearance on Health Canada Works](/en/health-canada/corporate/contact-us/application-copyright-clearance.html).

## Social media images and text

Social media images and text: X (Formerly Twitter)

| Platform | Image | Description text | Download |
| --- | --- | --- | --- |
| X (Formerly Twitter) | ![Smiling mother and son spending time together and hugging](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Ximage1_EN.png) | The #CanadianDentalCarePlan is helping to make oral health care more affordable in Canada. The plan will help reduce the cost of a wide range of oral health services for eligible Canadians. Learn more: [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html). | [Canadian Dental Care Plan - X image 1 (PNG - 476.8 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Ximage1_EN.png) |
| X (Formerly Twitter) | ![Senior citizen sitting in a dental chair looking at an oral health provider.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Ximage2_EN.png) | The #CanadianDentalCarePlan will help ease financial barriers to accessing oral health care for up to 9 million uninsured Canadian residents. To qualify, applicants must meet the [eligibility criteria](/en/services/benefits/dental/dental-care-plan/qualify.html). | [Canadian Dental Care Plan - X image 2 (PNG - 483.5 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Ximage2_EN.png) |

Social media images and text: Facebook

| Platform | Image | Description text | Download |
| --- | --- | --- | --- |
| Facebook | ![A happy looking elderly man brushing his teeth in front of the mirror. Image text says Canadian dental care plan.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Facebookimage1_EN.png) | The #CanadianDentalCarePlan is helping ease financial barriers for up to 9 million people who don't have dental insurance. To qualify, applicants must meet the following eligibility criteria:  * no access to dental insurance * an adjusted family net income of less than $90,000 * be a Canadian resident for tax purposes * have filed their tax return in the previous year  Learn more: [Canada.ca/dental](https://www.canada.ca/en/services/benefits/dental/dental-care-plan.html?utm_campaign=esdc-edsc-cdcp-rcsd-23-24&utm_medium=vanity-url&utm_source=canada-ca_dental) | [Canadian Dental Care Plan - Facebook image 1 (PNG - 573.3 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Facebookimage1_EN.png) |
| Facebook | ![Woman smiling in wheelchair](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Facebookimage2_EN.png) | The #CanadianDentalCarePlan is helping ease financial barriers for 9 million people who don't have dental insurance. It helps reduce the cost of a wide range of services that will prevent and treat oral health issues and disease. Learn more: [Canadian Dental Care Plan - Services covered](/en/services/benefits/dental/dental-care-plan/coverage.html). | [Canadian Dental Care Plan - Facebook image 2 (PNG - 529.2 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/Facebookimage2_EN.png) |

Social media images and text: LinkedIn

| Platform | Image | Description text | Download |
| --- | --- | --- | --- |
| LinkedIn | ![Oral health provider high fiving patient while working on her teeth in his dental office.](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/LinkedInimage_EN.png) | The Canadian Dental Care Plan (CDCP) supports Canadians who do not have access to dental insurance. When fully implemented, the CDCP will benefit up to 9 million uninsured Canadian residents and help reduce the cost of a wide range of services. Services include:  * preventive services, including scaling (cleaning), sealants and fluoride * diagnostic services, including examinations and x-rays * restorative services, including fillings * endodontic services, including root canal treatments * prosthodontic services, including dentures * periodontal services, including deep scaling * oral surgery services, including extractions  Learn more: [Canada.ca/dental](https://www.canada.ca/en/services/benefits/dental/dental-care-plan.html?utm_campaign=esdc-edsc-cdcp-rcsd-23-24&utm_medium=vanity-url&utm_source=canada-ca_dental) | [Canadian Dental Care Plan - LinkedIn image (PNG - 514.4 KB)](/content/dam/esdc-edsc/images/services/benefits/dental/dental-care-plan/providers/social-media/LinkedInimage_EN.png) |

## Page details

Date modified:
:   2024-12-11

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
