---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/statistics.html
scraped_at: 2025-08-24 16:38:20
filename: en/services/benefits/dental/dental-care-plan/statistics_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/statistiques.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

Canadian Dental Care Plan

# Statistics

The Canadian Dental Care Plan (CDCP) is one of the country’s largest social programs and it is expected to make the cost of dental care more affordable for up to 9 million Canadian residents.

Statistics for the CDCP is valid as of: **July 31, 2025** and will be updated on a monthly basis.

## Summary data

### Total number of approved applicants  for benefit year 2025 to 2026 (new applications & renewals)

4,864,417

Total number of approved applicants by province and territory for benefit year 2025 to 2026

| Provinces and territories | Number of approved applicants |
| --- | --- |
| Alberta | 306,584 |
| British Columbia | 639,390 |
| Manitoba | 129,274 |
| New Brunswick | 94,558 |
| Newfoundland and Labrador | 84,478 |
| Northwest Territories/ Nunavut/Yukon1 | 1,956 |
| Nova Scotia | 129,223 |
| Ontario | 1,927,081 |
| Prince Edward Island | 16,469 |
| Quebec | 1,454,507 |
| Saskatchewan | 80,897 |
| Total | **4,864,417** |

* 1For confidentiality purposes due to lower numbers Northwest Territories, Nunavut and Yukon data have been combined.

### **Total number of approved applicants for benefit year 2024 to 2025**

3,174,330

Total number of approved applicants by province and territory for benefit year 2024 to 2025

| Provinces and territories | Number of approved applicants |
| --- | --- |
| Alberta | 188,826 |
| British Columbia | 407,502 |
| Manitoba | 93,511 |
| New Brunswick | 72,422 |
| Newfoundland and Labrador | 59,086 |
| Northwest Territories/ Nunavut/Yukon1 | 1,447 |
| Nova Scotia | 95,402 |
| Ontario | 1,153,760 |
| Prince Edward Island | 11,703 |
| Quebec | 1,031,146 |
| Saskatchewan | 59,525 |
| Total | **3,174,330** |

* 1 For confidentiality purposes due to lower numbers Northwest Territories, Nunavut and Yukon data have been combined.

### **Total number of approved applicants that received care for benefit year 2025 to 2026**

843,354

Total number of approved applicants that received care by province and territory for benefit year 2025 to 2026

| Province and territories | Number of members for whom a claim was approved |
| --- | --- |
| Alberta | 48,549 |
| British Columbia | 115,350 |
| Manitoba | 20,254 |
| New Brunswick | 14,694 |
| Newfoundland and Labrador | 13,427 |
| Northwest Territories/Nunavut/Yukon1 | 221 |
| Nova Scotia | 20,726 |
| Ontario | 381,605 |
| Prince Edward Island | 2,694 |
| Quebec | 214,703 |
| Saskatchewan | 11,131 |
| Total number for benefit year 2025-2026 | **843,354** |
| Total number since the launch of the CDCP2 | **2,515,429** |

* 1 For confidentiality purposes due to lower numbers Northwest Territories, Nunavut and Yukon data have been combined.
* 2 The total number since the launch of the CDCP reflects the number of unique applicants who have received care during at least one benefit year.

### **Total number of approved applicants that received care for benefit year 2024 to 2025**

2,073,125

Total number of approved applicants that received care by province and territory for benefit year 2024 to 2025

| Province and territories | Number of members for whom a claim was approved |
| --- | --- |
| Alberta | 101,940 |
| British Columbia | 277,355 |
| Manitoba | 56,438 |
| New Brunswick | 37,522 |
| Newfoundland and Labrador | 34,215 |
| Northwest Territories/Nunavut/Yukon1 | 315 |
| Nova Scotia | 55,888 |
| Ontario | 822,485 |
| Prince Edward Island | 6,976 |
| Quebec | 645,898 |
| Saskatchewan | 34,093 |
| Total number for benefit year 2024 to 2025 | **2,073,125** |
| Total number since the launch of the CDCP2 | **2,515,429** |

* 1 For confidentiality purposes due to lower numbers Northwest Territories, Nunavut and Yukon data have been combined.
* 2 The total number since the launch of the CDCP reflects the number of unique applicants who have received care during at least one benefit year.

### **Total number of oral health providers participating in the CDCP**

26,399

Total number of oral health providers participating in the CDCP by province and territory

| Province and territories | Dentists & dental specialists | Denturist | Independently practicing hygienist | Grand total |
| --- | --- | --- | --- | --- |
| Alberta | 2,662 | 289 | 190 | **3,141** |
| British Columbia | 3,568 | 232 | 152 | **3,952** |
| Manitoba | 732 | 38 | <10 | **N/A2** |
| New Brunswick | 339 | 27 | 32 | **398** |
| Newfoundland and Labrador | 230 | 19 | 23 | **272** |
| Northwest Territories/Nunavut/Yukon1 | 53 | <10 | <10 | **N/A2** |
| Nova Scotia | 546 | 30 | 23 | **599** |
| Ontario | 10,040 | 592 | 753 | **11,383** |
| Prince Edward Island | 72 | <10 | <10 | **80** |
| Quebec | 4,540 | 781 | 123 | **5,443** |
| Saskatchewan | 530 | 62 | 10 | **602** |
| Total | **23,031** | **2,054** | **1,317** | **26,399** |

* 1 For confidentiality purposes due to lower numbers Northwest Territories, Nunavut and Yukon data have been combined.
* 2 For confidentiality purposes due to lower numbers for some professions, the combined total is not provided at this time.
* Note: Some oral health providers participating in the CDCP may be providing care in more than one province or territory.

## Page details

Date modified:
:   2025-08-15

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
