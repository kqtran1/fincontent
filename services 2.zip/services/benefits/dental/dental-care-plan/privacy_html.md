---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/privacy.html
scraped_at: 2025-08-24 16:52:21
filename: en/services/benefits/dental/dental-care-plan/privacy_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/vie-privee.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan - Privacy

**Official title:** Privacy protection in the Canadian Dental Care Plan

## On this page

* [Privacy management](#h2.1)
* [Privacy notice](#h2.2)
* [Additional privacy information](#h2.3)
* [Glossary](#h2.4)

## Privacy management

To deliver the Canadian Dental Care Plan (CDCP), Health Canada works with Government of Canada partners and Sun Life Financial Inc. (Sun Life), a contracted third-party administrator.

Government of Canada institutions must protect your personal information and uphold your privacy rights as required by the *Privacy Act* and related policies.

Health Canada works with the following Government of Canada partners to deliver the CDCP:

* **Employment and Social Development Canada/Service Canada (ESDC/Service Canada)** administers member applications and member renewals and answers questions from applicants
* the **Canada Revenue Agency (CRA)** confirms applicants' eligibility
* **Public Service and Procurement Canada (PSPC)** is responsible for the Government of Canada's contract with Sun Life. PSPC is also responsible for the Contract Security Program that helps ensure that CDCP contractors meet security requirements. Finally, PSPC sends and receives member eligibility review letters on behalf of Health Canada
* **Statistics Canada (StatCan)** produces CDCP statistical data and insights

Sun Life, as a private-sector partner, complies with the *Personal Information Protection and Electronic Documents Act*. As the contracted third-party administrator for the CDCP, Sun Life must also comply with the *Privacy Act* and related policies.

## Privacy notice

ESDC/Service Canada provides CDCP member applicants with a [privacy notice](#dt5), and Sun Life provides oral health providers agreeing to participate in the CDCP with a privacy notice. The privacy notice that follows does not replace other CDCP privacy notices. It is an overview of Health Canada and Sun Life's handling of personal information to administer the CDCP. It also tells you about your privacy rights.

### Collection and use of personal information

Health Canada and Sun Life collect your personal information under the authority of the Government of Canada's *Dental Care Measures Act*, the *Department of Health Act*, and the *Income Tax Act*. Your personal information is protected by the provisions of the *Privacy Act*.

Health Canada and Sun Life collect your personal information at different points, and through different ways, for activities that relate directly to the CDCP. This can include:

* **enrollment** - to ensure that only individuals who are eligible to receive CDCP services are members
* **claims processing and verification** - to process CDCP claims received from oral health providers and pay oral health providers directly for services covered under the plan, while ensuring the accuracy and integrity of CDCP claims
* **contact centre and problem resolution** - to respond to enquiries about the CDCP and resolve issues
* **authentication** - to ensure that you are who you say you are before sharing certain information with you (for example, multi-factor authentication to access Sun Life CDCP portals)
* **training and quality assurance** - to help ensure that customer care representatives are responding to your calls with clear, consistent and accurate information
* **reporting suspicious activity** - to allow individuals to report possible benefits claim misconduct to Sun Life, including via subcontractor ClearView Strategic Partners Inc

### Disclosure of personal information

Health Canada and Sun Life securely share personal information that is necessary for the administration of the CDCP. In specific and limited cases, Health Canada or Sun Life may lawfully [disclose personal information](#dt1) to regulatory bodies or law enforcement agencies, such as in cases of suspected or confirmed fraud.

In addition, Sun Life may share limited personal information with CDCP subcontractors for purposes such as:

* printing and mailing CDCP materials
* responding to your inquiries through the CDCP Customer Care Centre

Health Canada may also share your personal information with:

* ESDC, the CRA and PSPC for the purposes of administering the CDCP
* StatCan, as authorized by the *Statistics Act*, for producing CDCP statistical data and insights

For CDCP members, when enrolling in the CDCP, you also provide consent to your oral health providers to disclose all personal information, as authorized by the *Department of Health Act* and the *Dental Care Measures Act*, that may be considered useful by Sun Life in the context of program administration, conducting claims verifications, managing claims, and patient/client safety. This information may include, but is not limited to, details on the services provided, patient clinical data, payments, and X-rays.

### Voluntary participation

Your participation in the CDCP is voluntary. However, if you do not provide the necessary personal information, you cannot participate in the CDCP (or specific CDCP activities).

### Your rights and how to contact us

You have the right to access, and where applicable, to correct your personal information. Health Canada describes CDCP personal information under its control in the Canadian Dental Care Plan [Personal Information Bank](#dt3) (HC PPU 440). Visit [Info Source: Source of Federal Government and Employee Information Health Canada](/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html) for more information.

For privacy-related questions:

* **CDCP members and oral health providers** may contact Sun Life by calling 1-888-888-8110
* **general enquiries** - contact Service Canada at 1-833-537-4342 or visit [Contact us - Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan/contact.html) for more options

If have you been unable to resolve a privacy issue with us, you may file a formal complaint with the Privacy Commissioner of Canada about how we have handled your personal information. Visit [Report a concern](https://www.priv.gc.ca/en/report-a-concern/) for more information.

Visit the [CDCP Terms and conditions of use and privacy notice statement](https://srv024.service.canada.ca/en/apply/95546625-1d17-48a1-9149-a526d318efca/terms-and-conditions), specifically under the sections Apply and Privacy Notice Statement, for [privacy notice](#dt5) provided to applicants.

Visit the [CDCP Claims Processing and Payment Terms](https://www.sunlife.ca/sl/cdcp/en/provider/claims-processing-and-payment-terms/), specifically under the sections Privacy and Information Sharing Statement, for [privacy notice](#dt5) provided to oral health providers participating in the CDCP.

## Additional privacy information

This section provides links to additional Government of Canada privacy information related to the CDCP.

### Personal information banks

Government of Canada institutions describe personal information under their control, and that they use to administer the CDCP, in [personal information bank (PIB)](#dt3) descriptions.

* For Health Canada's CDCP PIB (HC PPU 440), visit [Info Source: Sources of Federal Government and Employee Information Health Canada - Canada.ca](/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html)
* For ESDC's CDCP PIB (ESDC PPU 712), visit [Info Source: Sources of Federal Government and Employee Information 2023 to 2024 - Canadian Dental Care Plan (PIB)](/en/employment-social-development/corporate/transparency/access-information/reports/infosource/infosource-detailed.html#h3.5.25)
* For CRA PIBs relevant to the CDCP (CRA PPU 063, CRA PPU 005, CRA PPU 218, CRA PPU 120, CRA PPU 182) visit [Info Source: Appendix - Personal Information Banks](/en/revenue-agency/corporate/about-canada-revenue-agency-cra/access-information-privacy-canada-revenue-agency/info-source-appendix.html)
* For PSPC's PIB relevant to the CDCP - Document Imaging Solutions PIB (PWGSC PCU 709)- visit [Info Source: Sources of federal government and employee information](/en/public-services-procurement/corporate/transparency/access-information-privacy/understanding-your-right-obtain-information/info-source-federal-government-employee-information.html)

### Privacy impact assessment summaries

Health Canada and its Government of Canada partners publish summaries of completed [privacy impact assessments (PIAs)](#dt4). These PIAs help identify, assess and mitigate privacy risks related to CDCP activities.

* For Health Canada's CDCP PIA summaries, visit:
  + [Canadian Dental Care Plan - Phase 1 - Canada.ca](/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/privacy/canadian-dental-care-plan.html)
  + Canadian Dental Care Plan - Phase 2 [upcoming publication]
  + Canadian Dental Care Plan - Phase 3 [upcoming publication]
  + Canadian Dental Care Plan - Claims Verification Program [upcoming publication]
* For ESDC's CDCP PIA summaries visit:
  + [Privacy Impact Reports 2023 to 2024 - Canadian Dental Care Plan Privacy Impact Assessment](/en/employment-social-development/corporate/transparency/access-information/reports/pia/2023-2024.html#a11)
  + [Privacy Impact Reports 2024 to 2025 - Canadian Dental Care Plan (CDCP) - Phase 2](/en/employment-social-development/corporate/transparency/access-information/reports/pia/2024-2025.html#h2.1-1)
* For CRA's CDCP-relevant PIA summaries, visit:
  + [Individual Returns Assessment Program v3.0](/en/revenue-agency/services/about-canada-revenue-agency-cra/protecting-your-privacy/privacy-impact-assessment/individual-returns-assessment-program-v3.html)
  + [Disability Tax Credit Program v2.0](/en/revenue-agency/services/about-canada-revenue-agency-cra/protecting-your-privacy/privacy-impact-assessment/disability-tax-credit-program-v2.html)
  + [Employer Accounts Program v3.0](/en/revenue-agency/services/about-canada-revenue-agency-cra/protecting-your-privacy/privacy-impact-assessment/employer-accounts-program-pia-v3-ic-129717.html)
  + Canada Child Benefit and Related Benefits v2.0 [upcoming publication]
  + Trust Accounts Examination (Payroll) v3.0 [upcoming publication]
* For StatCan's CDCP-related PIA, visit [Supplement to Statistics Canada's Generic Privacy Impact Assessment related to the Oral Health Statistics Program](https://www.statcan.gc.ca/en/about/pia/generic/ohsp)

### Information-sharing arrangements and disclosure summaries

Government of Canada institutions publish [information sharing-arrangements/agreements](#dt2) and disclosure summaries for personal information under their control.

* For Health Canada's CDCP information sharing arrangement summaries, visit [Info Source: Source of Federal Government and Employee Information Health Canada](/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html) [upcoming publications]
* For Health Canada's Health System Priorities Class of Records (HC CHS 005) disclosure summary, visit [Info Source: Source of Federal Government and Employee Information Health Canada](/en/health-canada/corporate/about-health-canada/activities-responsibilities/access-information-privacy/info-source-federal-government-employee-information.html)
* [More entries upcoming]

## Glossary

Disclosure (of personal information)
:   The release of personal information by any method (for example, transmission, provision of a copy, examination of a record) to any body or person.

    Reference: [*Policy on Privacy Protection*](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=12510)

Information-sharing arrangement
:   A written record of understanding that outlines the terms and conditions under which personal information is disclosed between parties. An information-sharing arrangement is usually employed to facilitate the disclosure of personal information between and within federal institutions. An information-sharing arrangement is not legally binding.

    Reference: [*Directive on Privacy Practices*](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=18309)

Personal Information Bank (PIB)
:   A description of personal information that is organized or intended to be retrieved by a person's name or by an identifying number, symbol or other particular assigned only to that person. The personal information described in the personal information bank has been used, is being used or is available for an administrative purpose and is under the control of a government institution.

    Reference: [*Policy on Privacy Protection*](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=12510)

Privacy Impact Assessment (PIA)
:   A process prescribed in policy for identifying, assessing and mitigating privacy risks. Government institutions are to develop and maintain privacy impact assessments for all new or modified programs and activities that involve the use of personal information for an administrative purpose.

    Reference: [*Policy on Privacy Protection*](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=12510)

Privacy notice
:   A verbal or written notice informing an individual of the purpose of collecting their personal information as well as the government institution's legal authority for the collection. The notice, which must reference the personal information bank described in *Info Source*, also informs the individual of how their personal information will be used and disclosed, their right to access and request the correction of the personal information, any consequences of refusing to provide the information requested, and their right to file a complaint to the Privacy Commissioner of Canada.

    Reference: [*Directive on Privacy Practices*](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=18309)

## Page details

Date modified:
:   2025-04-10

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
