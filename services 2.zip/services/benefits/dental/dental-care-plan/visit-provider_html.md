---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/visit-provider.html
scraped_at: 2025-08-24 15:27:43
filename: en/services/benefits/dental/dental-care-plan/visit-provider_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/consulter-fournisseur.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan

* [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html) [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html#wb-cont)
* [Apply](/en/services/benefits/dental/dental-care-plan/apply.html) [Apply](/en/services/benefits/dental/dental-care-plan/apply.html#wb-cont)
* [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html) [When can you visit an oral health provider](#wb-cont)
* [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html) [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html#wb-cont)
* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html) [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html#wb-cont)
* [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html) [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html#wb-cont)

# When can you visit an oral health provider

## On this page

* [Enrolment confirmation and your start date](#enrolment)
* [Find an oral health provider](#find)
* [Annual renewal](#renewal)

## Enrolment confirmation and your start date

Once you've [applied](/en/services/benefits/dental/dental-care-plan/apply.html) and we've confirmed that you qualify to the Canadian Dental Care Plan (CDCP), you will receive a letter from the Government of Canada with your CDCP member ID, coverage start date and co-payment level (if applicable). You can also get a copy of your letter through your [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html?utm_campaign=not-applicable&utm_medium=vanity-url&utm_source=canada-ca_msca). You can use your letter with your member ID to book your first appointment with an oral health provider on or after your coverage start date.

Your information will also be shared with Sun Life who will enrol you in the CDCP and send you a welcome package. It will include:

* information on the CDCP
* your physical member card
* your benefit start date (listed on your welcome letter and not on your member card)

**Note:** You do not need to wait for your welcome package from Sun Life to get care, as long as you provide your CDCP member ID, coverage start date, and co-payment level at your first appointment. Your provider will need your information to confirm your coverage under the plan.

For your services to be covered under the CDCP, you can only book your appointment on or after your benefit effective date (start date).

Your benefit effective date will depend on:

* when we receive your application **and**
* when we complete your enrolment

You should always confirm your CDCP coverage is active before seeking treatment from your oral health provider, and understand your co-payment level and any additional costs that won’t be covered by the plan.

### Reimbursement for services

You should only pay for services not covered under the CDCP. If you pay the full cost yourself, you will not get reimbursed by Sun Life.

**Note:** Oral health care services received during a gap in coverage will not be covered nor reimbursed retroactively.

## Find an oral health provider

If you don’t already have an oral health care provider, you can talk to a provider in your community or consult Sun Life's [CDCP Provider Search](https://www.sunlife.ca/sl/cdcp/en/member/provider-search/).

You can also call the Sun Life CDCP Contact Centre at 1-888-888-8110 for help.

[Find a CDCP oral health provider near you](https://www.sunlife.ca/sl/cdcp/en/member/provider-search/)

If you’re a CDCP client, there are things you should do **before** accepting care from an oral health care provider. When booking an appointment or discussing care options, always:

* confirm that the provider will accept a CDCP client and will bill Sun Life directly for services covered under the plan
* know your benefit effective coverage start date and your co-payment level, if you have one
* ask your provider if there are any costs you will have to pay in addition to your co-payment

Never pay for the full amount for services in advance. It’s not possible for Sun Life to pay you back.

After receiving care, you will have to pay any outstanding amounts not covered by the plan directly to your provider.

* [Learn more about your co-payment](/en/services/benefits/dental/dental-care-plan/coverage.html#how-much).
* [Learn more about what to do before booking your first appointment and receiving care](/en/services/benefits/dental/dental-care-plan/visit-provider/video-booking-first-appointment.html).

## Annual renewal

To continue to be covered under the CDCP, you will need to renew your coverage every year, to confirm that you still [meet the eligibility requirements](/en/services/benefits/dental/dental-care-plan/qualify.html). The renewal process for the 2025 to 2026 benefit coverage period has ended. If you haven't renewed and your CDCP coverage ended on June 30, 2025, you can submit a new application. Please note that your co-payment level could change when you submit a new application. Any preauthorized treatments will be paid at the co-payment level at the time of treatment.

* [Submit a new application](/en/services/benefits/dental/dental-care-plan/apply.html)

## Document navigation

* [Previous - Renew your coverage](/en/services/benefits/dental/dental-care-plan/renew.html)
* [Next - What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
