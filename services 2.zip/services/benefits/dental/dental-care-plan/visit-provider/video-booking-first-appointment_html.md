---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/visit-provider/video-booking-first-appointment.html
scraped_at: 2025-08-24 17:18:14
filename: en/services/benefits/dental/dental-care-plan/visit-provider/video-booking-first-appointment_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/consulter-fournisseur/video-prendre-premier-rendez-vous.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)
4. [Canadian Dental Care Plan - When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html)

# Canadian Dental Care Plan: What you need to know before booking your first appointment and receiving care

This video provides you with important information before booking your first appointment and/or before receiving care now that you are covered under the Canadian Dental Care Plan (CDCP).

[

](/content/dam/esdc-edsc/videos/services/dental/dental-care-plan/visit-provider/video-booking-first-appointment/CDCP-Dental-Visit-EN.mp4)

Transcript

If you've been approved for the Canadian Dental Care Plan, also known as the CDCP, you might be asking yourself, now what?

You will receive a welcome package. Have a look at the package and find your benefit start date - that's when you can start seeing an oral health care provider using your CDCP coverage.

Before making an appointment:

* Confirm that the oral health provider of your choice will accept you as a CDCP patient and that they will bill Sun Life directly.
* Remember the CDCP does not mean that all care is free, but it does help reduce the cost of your dental care treatment.
* If you have a co-payment, know what percentage you are responsible for - and that you will need to pay to your provider out of your own pocket.
* Ask your provider what additional costs, if any, are not covered by the CDCP and that you will be required to pay during your visit, in addition to any co-payment if applicable.
* Remember you will not be able to seek reimbursement from Sun Life, so you should not pay for the full cost of care upfront. The CDCP can only reimburse oral health providers, not patients.

For help finding a provider near you, check out the Provider Search Tool on the CDCP Sun Life website.

* Start by searching by name or select a specialty in the first field
* Enter your address or current location in the second field
* Hit: Search

Not all providers participating in the CDCP are listed in the search tool.

Don't hesitate to contact oral health providers or dental schools in your area and ask if they are accepting CDCP patients.

For more information, visit **Canada.ca/dental**.

## Page details

Date modified:
:   2024-11-29

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
