---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/qualify.html
scraped_at: 2025-08-24 18:07:51
filename: en/services/benefits/dental/dental-care-plan/qualify_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About this site"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](http://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan

* [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html) [Do you qualify](#wb-cont)
* [Apply](/en/services/benefits/dental/dental-care-plan/apply.html) [Apply](/en/services/benefits/dental/dental-care-plan/apply.html#wb-cont)
* [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html) [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html#wb-cont)
* [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html) [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html#wb-cont)
* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html) [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html#wb-cont)
* [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html) [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html#wb-cont)

# Do you qualify

## Eligibility requirements

To qualify for the CDCP, you must meet all 4 of these requirements:

* **You don’t** have access to dental insurance

  What does this mean?

  It means you do **not** have access to any type of dental insurance or coverage through:

  + your employment benefits or a family member’s employment benefits, including health and wellness accounts
  + a professional or student organization
    - Note: If you’re eligible for dental coverage through your employment benefits or through a professional or student organization, you’re not eligible for CDCP. This is true even if:
      * you decide not to take it
      * you have to pay a premium for it
      * you don’t use it
  + your pension benefits or a family member’s pension benefits
    - this includes federal, provincial and territorial government employer pension plans
    - **Exception**: You may be eligible for the CDCP if you’re retired and:
      * you opted out of **pension** benefits before December 11, 2023, and
      * you can’t opt back in under the pension rules
  + coverage bought by you or a family member or through a group plan from an insurance or benefits company
    - if you purchased your current dental insurance policy privately  (and not as part of any of the coverage described above), you’re not eligible for the CDCP while that coverage is in effect.
* You and your spouse/common-law-partner (if applicable) must have filed your tax returns in Canada so that your family income can be assessed for the previous year

  What if my spouse/common law partner is not in Canada?

  If you have a spouse or common-law partner that is not living in Canada and does not file their tax return in Canada, you will not be eligible for the CDCP.
* Your adjusted family net income is less than $90,000

  What is adjusted family net income?

  Your family net income (line 23600 of your tax return plus line 23600 of your spouse's or common-law partner's tax return)

  Minus any universal child care benefit (UCCB) and registered disability savings plan (RDSP) income received (line 11700 and line 12500 of your or your spouse's or common-law partner's tax return)

  Plus any UCCB and RDSP amounts repaid (line 21300 and line 23200 of your or your spouse's or common-law partner's tax return)

  equals adjusted family net income
* You’re a Canadian resident for tax purposes

You need to meet all the eligibility criteria to qualify for the CDCP.

If you meet all the eligibility criteria, you may qualify for the CDCP. [Apply now](/en/services/benefits/dental/dental-care-plan/apply.html).

### If you have dental coverage through government social programs

If you have dental coverage through a provincial, territorial or federal government social program, **you can still qualify** for the CDCP. If you [qualify](#eligibility), your coverage will be coordinated between the plans to make sure there are no duplication or gaps in coverage.

If you provide false information on your application, you and your family may be removed from the plan. If you weren’t eligible for the CDCP, you may have to repay the full cost of services received.

## Document navigation

* [Next - How to apply](/en/services/benefits/dental/dental-care-plan/apply.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finance](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
