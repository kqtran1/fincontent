---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/coverage.html
scraped_at: 2025-08-24 16:29:13
filename: en/services/benefits/dental/dental-care-plan/coverage_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/couverture.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan

* [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html) [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html#wb-cont)
* [Apply](/en/services/benefits/dental/dental-care-plan/apply.html) [Apply](/en/services/benefits/dental/dental-care-plan/apply.html#wb-cont)
* [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html) [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html#wb-cont)
* [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html) [What services are covered](#wb-cont)
* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html) [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html#wb-cont)
* [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html) [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html#wb-cont)

# What services are covered

## On this page

* [Services covered](#services)
* [How much will be covered](#how-much)

## Services covered

The Canadian Dental Care Plan (CDCP) will help pay a portion of the cost for a wide range of oral health care services.

**Services including those beyond the frequency limits that require approval in advance are available as of November 1, 2024.**

Examples of services that could be covered under the CDCP when recommended by an oral health provider, include:

* ### Diagnostic and preventive services

  These are services to check your oral health status, keep your teeth, gums and mouth healthy, and prevent cavities and gum disease and detect mouth conditions (like cancer) earlier. CDCP covers:

  + dental exams, including complete, routine, specific and emergency exams
  + x-rays
  + cleaning (scaling)
  + fluoride applications
  + sealants
* ### Basic services

  #### Restorative services

  These services treat cavities and broken teeth. CDCP covers:

  + permanent fillings
  + temporary fillings
  + pain control for diseased teeth
  + other treatments for cavities

  #### Endodontic services

  These services treat teeth that are severely decayed, infected or broken. CDCP covers:

  + root canal treatments
  + pulpectomies (first step of a root canal treatment)
  + procedures to reduce infection and relieve pain
  + re-treatment of previously completed root canal treatment (requires preauthorization)

  #### Periodontal services

  These services treat areas around the teeth, including gums and bone. CDCP covers:

  + cleaning under the gumline
  + treating abscesses
  + bonding for mobile teeth (requires preauthorization)
  + post-surgical evaluations (requires preauthorization)
  + non-surgical gum disease management
* ### Major services

  #### Restorative services

  These services restore teeth when they’re too damaged to be fixed with basic fillings. CDCP covers:

  + posts and post removal
  + repairs to crowns and re-bonding of crowns and posts
  + crowns (requires preauthorization)
  + cores (to support crowns) (requires preauthorization)
  + posts for crown (requires preauthorization)

  #### Removable prosthodontic services

  These services replace missing teeth. CDCP covers:

  + complete dentures, including standard and temporary dentures
  + denture repairs, relines and rebases
  + placing lining in dentures to condition oral tissues (for comfort and healing)
  + complete immediate and overdentures (requires preauthorization)
  + partial dentures (require preauthorization)

  #### Oral surgery

  These services remove teeth or tumours and fix other problems in the mouth and jaw that need surgery. CDCP covers:

  + removal of teeth and roots
  + surgical removal of tumours and cysts
  + surgical incisions, including draining
  + treatments for broken jaw bones
* ### Anesthesia or sedation services

  These are services to sedate you and control your pain while another service is being performed. CDCP covers:

  + minimal sedation (conscious)
  + moderate sedation (requires preauthorization)
  + deep sedation (requires preauthorization)
  + general anaesthesia (requires preauthorization)
* ### Orthodontic services

  These are not available yet. In 2025, we’ll add orthodontic services to the CDCP. These services will only be covered in cases of medical need based on strict criteria. There will be a maximum spending limit for them.

For more information on services covered, consult the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html).

**Note:** Some services including those beyond established frequency limits require preauthorization by the CDCP. This means your provider will recommend services and the CDCP will confirm whether they will be covered by the plan. This pre-approval must happen before you can receive these services. The decision will take into consideration your oral health history and medical conditions. Not all requests will be approved for coverage. You may still decide to proceed with the services proposed by your provider, even if not covered by the plan and pay for these directly to your provider.

## How much will be covered

The CDCP will reimburse a portion of the cost of your treatment, but it may not pay the full amount. You may have to pay additional charges directly to the oral health provider, if:

* your adjusted family net income is between $70,000 and $89,999
* the cost of your oral health care services are more than what the CDCP will reimburse for these services, or
* you and your oral health provider agree to services that the CDCP doesn’t cover.

### Reimbursement for services

Only oral health providers get reimbursed for services covered under the CDCP.

If you are covered by the CDCP, you shouldn’t pay the full cost upfront, but you may have to pay any additional charges directly to the oral health provider.

Please [contact us](/en/services/benefits/dental/dental-care-plan/contact.html) if you have questions or require support.

### Co-payments

You may have a co-payment based on your adjusted family net income. A co-payment is the percentage of the CDCP fees that isn’t covered by the CDCP, and that you will have to pay directly to the oral health provider. Your co-payment is based on your adjusted family net income.

**Co-payments based on adjusted family net income**

| Adjusted family net income | How much will the CDCP cover | How much you will cover |
| --- | --- | --- |
| Lower than $70,000 | 100% of eligible oral health care service costs will be covered at the CDCP established fees. | 0% of the CDCP established fees. You may face additional charges as described below. |
| Between $70,000 and $79,999 | 60% of eligible oral health care service costs will be covered at the CDCP established fees. | 40% of the CDCP established fees. You may face additional fees as described below. |
| Between $80,000 and $89,999 | 40% of eligible oral health care service costs will be covered at the CDCP established fees. | 60% of the CDCP established fees. You may face additional fees as described below. |

### Additional charges

The CDCP fees may not be the same as what providers charge. You may have to pay fees in addition to the potential co-payment if:

* the cost of your oral health care services is more than what the CDCP will reimburse for these services
* you and your oral health provider agree to services that the CDCP doesn’t cover

Before receiving oral health care, you should always ask your oral health provider about any costs that won’t be covered by the plan. Make sure you know what you’ll have to pay directly to your oral health provider before accepting and receiving treatment.

### Examples of co-payments and additional charges

For detailed examples, refer to the [Examples of co‑payments and additional charges factsheet](/en/services/benefits/dental/dental-care-plan/coverage/examples-copayments-additional-charges.html).

## Document navigation

* [Previous - When can you visit oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html)
* [Next - How oral health providers can enrol to the CDCP](/en/services/benefits/dental/dental-care-plan/providers.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
