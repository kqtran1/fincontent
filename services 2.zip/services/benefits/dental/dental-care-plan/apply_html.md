---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/apply.html
scraped_at: 2025-08-24 16:26:20
filename: en/services/benefits/dental/dental-care-plan/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About this site"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](http://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan

* [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html) [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html#wb-cont)
* [Apply](/en/services/benefits/dental/dental-care-plan/apply.html) [Apply](#wb-cont)
* [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html) [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html#wb-cont)
* [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html) [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html#wb-cont)
* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html) [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html#wb-cont)
* [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html) [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html#wb-cont)

# Apply

## On this page

* [When you can apply](#when)
* [Apply online](#apply-online)
* [If someone is helping you apply](#helping)
* [Check the status of your application](#status)

## When you can apply

**Applications are open**

All eligible Canadians can now apply for the Canadian Dental Care Plan (CDCP).

You must meet all 4 of the [eligibility requirements](/en/services/benefits/dental/dental-care-plan/qualify.html) before applying.

## Apply online

### What you need to apply

You’ll need to provide the following information for each applicant, and your spouse or common-law partner (if you have one):

* Social Insurance Number (SIN) (if available for children)
* date of birth
* full name
* home and mailing address
* list of dental coverage through government social programs (if applicable)
* you and your spouse or common-law partner (if applicable) must have filed your tax return in Canada for the previous year and have received your notice of assessment

### If you are ready to apply or if your previous coverage has expired

**[Apply](https://srv024.service.canada.ca/en/apply/)**

#### Renewing your yearly coverage

You will need to renew your coverage to the CDCP every year to confirm that you still meet the eligibility requirements. The renewal process for the 2025 to 2026 benefit coverage period has ended.

If you didn't renew and your CDCP coverage ended on June 30, 2025, you can submit a new application. There will be a gap in your coverage until it is reinstated. Oral health care services received during this gap will not be covered nor reimbursed retroactively.

You should always confirm that your CDCP coverage is active before seeking treatment from your oral health provider. Please note that your co-payment level could change when you renew. Any preauthorized treatments will be paid at the [co-payment level](/en/services/benefits/dental/dental-care-plan/coverage.html#co-payments) at the time of treatment.

#### Accessing your CDCP information through My Service Canada Account (MSCA)

You can apply to the CDCP and access CDCP letters using your MSCA account. Register for a [My Service Canada Account](/en/employment-social-development/services/my-account.html) if you don’t already have an account. Once registered or signed in, go to the “Canadian Dental Care Plan” section on your MSCA dashboard to:

* apply to the CDCP:
  + select “Apply for the Canadian Dental Care Plan”
* view your letters related to the CDCP:
  + select “View my letters”

#### If you can't use the application tool or MSCA

Call Service Canada at 1-833-537-4342. For TTY, call 1-833-677-6262.

## If someone is helping you apply

You can ask someone you trust or a delegate to help you apply for the CDCP.

* Applying with the help of someone you trust

  You can ask a trusted person to help you apply by phone. This could be a:

  + friend
  + relative
  + caregiver
  + translator, or
  + interpreter

  You must be able to give clear consent that you agree to let them help you.
* Applying through a delegate

  A delegate is someone who has the legal authority to represent you and make decisions on your behalf.

  They can represent you if they’re listed as your delegate on documents such as:

  + power of attorney
  + mandate
  + trusteeship

  Before you apply, your delegate must prove that they have the legal authority to represent you. The documents listed above are considered proof. Mail original documents or certified copies to us, or bring them in person to any Service Canada office (see mailing addresses by region).

  Once we’ve processed the documents, we’ll contact your delegate to confirm that we’ve accepted and added the documents to your file. Your delegate can then apply to the CDCP on your behalf.

  #### How to submit your proof of delegate documents

  ##### By mail

  If you or your delegate are sending us the documents by mail, please **include a cover letter** with:

  + your full name
  + your Social Insurance Number (SIN)
  + a statement that the documents are being submitted for the CDCP
  + your delegate’s phone number and
  + a return address, so we can return your documents for us to send the original documents or certified copies back to once we’ve processed them

  Mailing addresses by region

  | Province or region | Mailing address |
  | --- | --- |
  | Atlantic Canada | Service Canada  Canadian Dental Care Plan  PO Box 250 Station A  Fredericton, NB E3B 4Z6 |
  | Quebec | Service Canada  Canadian Dental Care Plan  PO Box 60  Boucherville, QC J4B 5E6 |
  | Ontario | Service Canada  Canadian Dental Care Plan  PO Box 5100 Station D  Scarborough, ON M1R 5C8 |
  | Western Canada and Territories | Service Canada  Canadian Dental Care Plan  PO Box 2710 Station Main  Edmonton, AB T5J 2G4 |

  ##### In person

  If you or your delegate brings the documents to a Service Canada office in person, please provide:

  + your full name, and
  + your Social Insurance Number (SIN)

  [Find a Service Canada office near you](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp)

## Check the status of your application

You can check the status of your and your dependant’s CDCP application using the status checker tool.

You will need to provide the following information for each person you are checking the status for:

* application code or client number:
  + the number you received after applying, or the number in the right-hand corner of the CDCP letter (determination letter or renewal letter) you received from Service Canada
* Social Insurance Number (SIN):
  + for children’s application that do not have a SIN, you will need to enter their full name and date of birth

To check the application status, you can use the online tool.

[Check the status of your application](https://srv024.service.canada.ca/en/status)

## You can also call us

### By automated phone service

You can use the automated phone service to check your application. This service is available 24 hours a day, 7 days a week.

Call 1-833-537-4342, select your preferred language, then press 3.

### By speaking to a representative

Representatives are also available 8:30 am to 4:30 pm local time, Monday to Friday, to answer any questions you may have. They do not answer calls on statutory holidays.

**Note:** If your child does not have a SIN, you are not able to use the automated phone service to check their application status. You must speak to a representative to check their status or use the online tool.

### By TTY (teletypewriter) service

If you’re hearing impaired, use our TTY (teletypewriter) service: 1-833-677-6262.

The hours of operation are 7:00 am to 7:30 pm Eastern time, Monday to Friday.

### Requesting alternate formats

If you need information from the CDCP in a different format such as large print, Braille, or DAISY, you can request alternate versions of letters and publications.

Please note that CDCP application and renewal forms are not available in paper or alternate formats.

To request an alternate format, please call 1-833-537-4342.

If you’re hearing impaired, use our TTY (teletypewriter) service: 1-833-677-6262.

## Related link

* [Canadian Dental Care Plan statistics](/en/services/benefits/dental/dental-care-plan/statistics.html)

## Document navigation

* [Previous - Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html)
* [Next - Renew your coverage](/en/services/benefits/dental/dental-care-plan/renew.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finance](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
