---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan/providers.html
scraped_at: 2025-08-24 14:03:33
filename: en/services/benefits/dental/dental-care-plan/providers_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires/fournisseurs.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan.html)

# Canadian Dental Care Plan

* [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html) [Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html#wb-cont)
* [Apply](/en/services/benefits/dental/dental-care-plan/apply.html) [Apply](/en/services/benefits/dental/dental-care-plan/apply.html#wb-cont)
* [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html) [When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html#wb-cont)
* [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html) [What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html#wb-cont)
* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html) [Information for oral health professionals](#wb-cont)
* [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html) [Contact us](/en/services/benefits/dental/dental-care-plan/contact.html#wb-cont)

# Information for oral health professionals

Oral health professionals play a vital role in oral health care. The Canadian Dental Care Plan (CDCP) allows more people to benefit from their care.

## On this page

* [Participation in the CDCP](#h2.1)
* [CDCP established fees](#establishedfees)
* [Coordination of benefits](#h2.3)
* [Preauthorization](#h2.4)

## Participation in the CDCP

Participation in the CDCP is voluntary. Eligible providers who can bill for their services include:

* dentists
* denturists
* dental hygienists
* dental specialists
* dental schools and educational institutions for oral health professions

There are 2 ways for oral health providers to provide care to CDCP clients; either by:

1. signing up formally through Sun Life
2. submitting claims directly to Sun Life for payment, on a claim-by-claim basis

[How to sign-up through Sun Life](https://www.sunlife.ca/sl/cdcp/en/provider/)

In both options, by submitting a claim, oral health providers agree to bill Sun Life directly for payment of services covered under the CDCP per the [CDCP Billing Agreement](https://www.sunlife.ca/sl/cdcp/en/provider/claims-processing-and-payment-terms/) and limit out-of-pocket costs for CDCP clients.

**Note:** There is no option for CDCP clients to get a reimbursement from Sun Life. CDCP clients should not be asked to pay the full cost upfront. CDCP clients should only pay any outstanding amount not covered by the plan, if applicable.

Both Electronic Data Interchange (EDI) and paper claims are accepted and processed.

When submitting paper claims to Sun Life, providers **must** ensure the form is signed by the CDCP client or their parent/guardian, as applicable in the Assignment of Benefits section of the claim form. Paper claims received with a missing signature will not be processed and will be returned for signature.

Before providing care to CDCP clients, providers need to:

* confirm that the client is eligible for the CDCP through their existing patient intake process
* confirm that the client is covered for select services
* submit a claim with assignment of benefits (non-assigned claims will be rejected)

## CDCP established fees

We’ll reimburse providers according to the CDCP established fees for each service covered under the plan, and in consideration of the applicable client’s co-pay. CDCP fees are set independently from the fees suggested by provincial and territorial associations and outlined in their fee guides, and which are often charged by providers.

The [CDCP dental benefit grids](https://www.sunlife.ca/sl/cdcp/en/provider/dental-benefit-grids/) for each province and territory are available on the Sun Life website.

Fees are reassessed annually to account for new scientific evidence, inflation, and changes in costs over time.

## Coordination of benefits

### Provincial and territorial social dental programs

We’ve developed a set of factsheets based on guidance from each provincial or territorial government. These province/territory-specific factsheets can assist providers and their staff with the billing process when their patient asks to coordinate their benefits.

Consult the relevant provincial or territorial factsheet:

* [Alberta](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-ab.html) Updated December 2024
* [British Columbia](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-bc.html) Updated February 2025
* [Manitoba](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-mb.html) Updated January 2025
* [New Brunswick](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nb.html) Updated December 2024
* [Newfoundland and Labrador](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nl.html) Updated November 2024
* [Northwest Territories](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nt.html) Updated December 2024
* [Nova Scotia](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-ns.html) Updated June 2025
* [Nunavut](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-nu.html) Updated June 2025
* [Ontario](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-on.html) Updated January 2025
* [Prince Edward Island](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-pei.html) Updated December 2024
* [Quebec](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-qc.html) Updated June 2025
* [Saskatchewan](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-sk.html) Updated January 2025
* [Yukon](/en/services/benefits/dental/dental-care-plan/providers/fact-sheet-yk.html) Updated June 2025

### Other federal social dental programs

The following federal social dental programs offer dental coverage to specific populations. They will be billed first, before the CDCP:

* Non-Insured Health Benefits Program
* Veterans Affairs Canada Dental Services Program
* Interim Federal Health Program
* Correctional Services Canada Dental Care for Inmates

The CDCP will be billed after these plans, but given the similarities of the coverage and the established fees paid by these programs, we expect they’ll need either no coordination or only limited coordination. If a service is covered by the CDCP but isn’t covered by these plans, it could be submitted to the CDCP for coordination.

### Private dental coverage

People aren’t eligible for the CDCP if they already have access to coverage beyond a federal, provincial or territorial social dental program.

There will be no coordination with private, employer or other such plans.

## Preauthorization

Since November 1, 2024, providers have been able to submit CDCP preauthorization requests for additional services and treatments. The preauthorization process is not to determine if the proposed treatment is the right treatment. Those decisions remain between the provider and their patient. This is a process to confirm whether the procedure will be covered by the CDCP or not based on CDCP established clinical criteria.

In addition to the criteria, guidelines and requirements included in the [CDCP Dental Benefits Guide](/en/services/benefits/dental/dental-care-plan/guide.html), we have created some [resources](/en/services/benefits/dental/dental-care-plan/providers/preauthorization.html) to assist with the preauthorization process.

## Related links

* [Canadian Dental Care Plan: Promotional toolkit](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)
* [Canadian Dental Care Plan: Updates for oral health providers](/en/services/benefits/dental/dental-care-plan/providers/article.html)

## Document navigation

* [Previous - What is covered](/en/services/benefits/dental/dental-care-plan/coverage.html)
* [Next - Contact us](/en/services/benefits/dental/dental-care-plan/contact.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
