---
source_url: https://www.canada.ca/en/services/benefits/dental/dental-care-plan.html
scraped_at: 2025-08-24 13:27:37
filename: en/services/benefits/dental/dental-care-plan_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/dentaire/regime-soins-dentaires.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Canadian Dental Care Plan

The Canadian Dental Care Plan (CDCP) is helping make the cost of dental care more affordable for eligible Canadian residents.

## Applications are open

Eligible Canadians of all ages can now apply for the CDCP.

## Renewal period

The renewal process for the 2025 to 2026 benefit coverage period has ended. If you haven’t renewed and your CDCP coverage ended on June 30, 2025, you can [submit a new application](/en/services/benefits/dental/dental-care-plan/apply.html#apply-online).

## Sections

[Do you qualify](/en/services/benefits/dental/dental-care-plan/qualify.html)
:   Find out if you're eligible for the CDCP.

[Apply](/en/services/benefits/dental/dental-care-plan/apply.html)
:   Find out how to complete an application and how to check its status.

[When can you visit an oral health provider](/en/services/benefits/dental/dental-care-plan/visit-provider.html)
:   Find out about your CDCP benefit start date, and find an oral health care provider.

[What services are covered](/en/services/benefits/dental/dental-care-plan/coverage.html)
:   Find out which oral health care services are covered and how much the CDCP will pay toward those services.

## For oral health providers and stakeholders

Information is available for oral health professionals, including information on how to participate, CDCP fees and coordination of benefits.

* [Information for oral health professionals](/en/services/benefits/dental/dental-care-plan/providers.html)
  + [Preauthorization resources](/en/services/benefits/dental/dental-care-plan/providers/preauthorization.html)
* [CDCP promotional toolkit](/en/services/benefits/dental/dental-care-plan/providers/toolkit.html)

## Contact us

If you have questions about the CDCP, please [contact us](/en/services/benefits/dental/dental-care-plan/contact.html).

### Important

Watch out for email, mail and telephone (including text messages) scams where you may be asked to provide personal information.

If you are concerned about the legitimacy of any Canadian Dental Care Plan (CDCP) communication, you can contact us at 1-833-537-4342 (TTY: 1-833-677-6262).

## Related links

* [Canadian Dental Care Plan statistics](/en/services/benefits/dental/dental-care-plan/statistics.html)
* [Privacy protection in the Canadian Dental Care Plan](/en/services/benefits/dental/dental-care-plan/privacy.html)

## Page details

Date modified:
:   2025-08-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
