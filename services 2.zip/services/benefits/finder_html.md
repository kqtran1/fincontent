---
source_url: https://www.canada.ca/en/services/benefits/finder.html
scraped_at: 2025-08-24 15:19:54
filename: en/services/benefits/finder_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/chercheur.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Benefits Finder

Discover benefits that can help lower your living costs, find affordable housing and improve your quality of life. If you need financial help, healthcare support, housing options, or special programs for seniors, students, or people with disabilities, the Benefits Finder can help.

* [Go to Benefits Finder](https://benefitsfinder.services.gc.ca/)
* Test the new Benefits Finder
* [Test the new Benefits Finder - No Javascript](/en/services/benefits/finder/tool.html)

## Answer a few questions

The new Benefits Finder is a work in progress. Help improve it by giving your [feedback](https://forms-formulaires.alpha.canada.ca/en/id/clwzf86mr03i2x8831c5r9zk6).

I am looking for benefits for…

* Everyone
* Seniors and retirees
* Youth
* Students
* Parents and legal guardians
* Caregivers
* Military and Veterans
* Indigenous Peoples
* Newcomer to Canada
* Canadians living abroad
* Victims of crime

I am looking for benefits about…

* Health and well-being
* Disability
* Starting a family/raising children
* Retirement
* Going to school
* Jobs, volunteering and training
* Losing your job or unable to work
* Starting or owning a business
* Renting or home ownership
* Marriage or common-law
* Divorce or separation
* Grants and funding for projects
* Taxes
* What to do when someone dies

Find benefits

Looking for benefits from your province or territory?

* [Alberta](https://www.alberta.ca/all-services)
* [British Columbia](https://www2.gov.bc.ca/gov/content/home/benefits)
* [New Brunswick](https://socialsupportsnb.ca/en/)
* [Manitoba](https://residents.gov.mb.ca/reference.html?filter_category=226&d=howdoi)
* [Newfoundland and Labrador](http://www.gov.nl.ca)
* [Nunavut](https://www.tunngavik.com/programs-and-benefits/)
* [Northwest Territories](https://www.gov.nt.ca/)
* [Nova Scotia](https://beta.novascotia.ca/topic/money-tax-and-benefits)
* [Ontario](https://www.ontario.ca/page/find-benefits-and-programs)
* [Prince Edward Island](https://www.princeedwardisland.ca/en/residents)
* [Quebec](https://www.quebec.ca/en)
* [Saskatchewan](https://www.saskatchewan.ca/residents)
* [Yukon](https://yukon.ca/en)

## Manage your benefits

* [Payment dates](/en/services/benefits/calendar.html)
* [Direct deposit](https://www.tpsgc-pwgsc.gc.ca/recgen/txt/depot-deposit-eng.html)
* [Sign in to a Government of Canada online account](/en/government/sign-in-online-account.html)

## Other tools and resources

* [Financial support to help my business](https://innovation.ised-isde.canada.ca/s/?language=en_CA)
* [Personal income tax deductions, credits and expenses](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/deductions-credits-expenses.html)
* [Grants and funding programs to fund my project](/en/government/grants-funding.html)

## Page details

Date modified:
:   2024-08-12

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
