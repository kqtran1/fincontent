---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html
scraped_at: 2025-08-24 18:11:12
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

# Guaranteed Income Supplement

* [Do you qualify](#gc-document-nav)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html) [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html)
* [While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html) [While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Do you qualify

## On this page

* [Do you qualify for the Guaranteed Income Supplement](#h2.1)
* [Allowance benefit for your spouse or common-law partner](#h2.2)
* [Benefit for a surviving spouse or common-law partner](#h2.3)
* [Retirement hub](#h2.4)

The information provided below should be used as a guideline. We encourage you to allow a Service Canada representative to determine if you are eligible.

## Do you qualify for the Guaranteed Income Supplement

You may be able to get this benefit if:

* you are 65 or older
* you live in Canada
* you receive the [Old Age Security (OAS) pension](/en/services/benefits/publicpensions/old-age-security.html)
* your income is below $22,272 if you are single, widowed, or divorced
* your income plus the income of your spouse/common-law partner is below:
  + $29,424 if your spouse/common-law partner receives the full OAS pension
  + $53,376 if your spouse/common-law partner does not receive an OAS pension
  + $41,184 if your spouse/common-law partner receives the Allowance

### If you moved to Canada as an immigrant

#### If you are an immigrant who is sponsored

If you are a **sponsored** immigrant and have **lived in Canada for less than 10 years after age 18**, you cannot receive the Guaranteed Income Supplement while you are sponsored unless your sponsor:

* suffers personal bankruptcy
* is imprisoned for more than 6 months
* is convicted of abusing you
* dies

#### If you are an immigrant who is not sponsored

If you are an immigrant who is **not sponsored**, you could receive the Guaranteed Income Supplement if you receive the Old Age Security pension.

## Benefit for your spouse or common-law partner

### Allowance

If you are eligible to receive the Guaranteed Income Supplement, your spouse or common-law partner may be able to receive the [Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html) benefit if your spouse or common-law partner:

* is **60 to 64 years of age**
* is a Canadian citizen or a legal resident
* resides in Canada and has resided in Canada for at least 10 years since the age of 18
* your combined annual income is less than [the maximum annual income threshold for the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html)

## Benefit for a surviving spouse or common-law partner

### Allowance for the Survivor

You could receive the [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html) if:

* you are **60 to 64 years of age**
* your spouse or common-law partner has died and you have not remarried or entered into a common-law relationship
* your annual income is less than the [maximum annual income threshold for the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html)

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

## Document navigation

* [Previous : Overview](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
* [Next : How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)

## Page details

Date modified:
:   2025-05-20

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
