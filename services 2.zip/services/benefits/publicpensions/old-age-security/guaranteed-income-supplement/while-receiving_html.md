---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html
scraped_at: 2025-08-24 13:11:29
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/pendant-que-vous-recevez.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

# Guaranteed Income Supplement

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html) [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html)
* [While receiving GIS](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# While receiving GIS

## File your taxes to continue receiving your GIS payments

If you haven’t filed your 2024 taxes with the CRA, your Guaranteed Income Supplement (GIS) payments may stop or be reduced.

To avoid interruptions, [file your taxes](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes.html) as soon as possible.

You can also report your income directly to us to renew or confirm your eligibility.

If you have questions or concerns about your GIS payments, [contact us](/en/employment-social-development/corporate/contact/oas.html).

## On this page

* [Your first payment](#h2.1)
* [We review your benefit amount each year](#h2.2)
* [You must file your taxes on time](#h2.3)
* [If your income changes](#h2.4)
* [If your situation changes](#h2.5)
* [When your benefit could stop](#h2.6)

## Your first payment

Your Guaranteed Income Supplement will be added to your Old Age Security pension each month as one payment.

You will receive your first payment either:

* the same month you start your Old Age Security pension
* the date on your decision letter

You can receive your benefit payment by cheque or direct deposit to your banking account in Canada. You will have to [sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html).

## We review your benefit amount each year

Using your income information from your federal Income tax return, we will review whether you will continue to receive the Guaranteed Income Supplement for the next year.

Every July, you will receive a letter telling you one of the following:

* your benefit will be renewed and the amount for the next 12 months
* your benefit will be stopped
* your benefit will start or resume
* we need your income information

### If you did not receive your payment in July 2023

You should [contact us](/en/employment-social-development/corporate/contact/oas.html) by phone as soon as possible. Be prepared to provide:

* your Social Insurance Number
* your 2022 income information
* your spouse or common-law partner’s 2022 income

## You must file your taxes on time

You do not have to pay taxes on your Guaranteed Income Supplement payment. You must **file your taxes by April 30 every year** to avoid any disruption of payments.

### SimpleFile by Phone

Did you receive a [SimpleFile by Phone](/en/revenue-agency/campaigns/simplefile-by-phone.html) invitation from the CRA? You can complete and submit your tax return from the comfort of your home using this free and secure automated phone service.

## If your income changes

Your income may change due to several factors. [Determine your income](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html#h2.2-3.1).

[Contact us](/en/employment-social-development/corporate/contact/oas.html) if you or your spouse or common-law partner has a lower annual income due to retirement or if other pension benefits are reduced or stopped.

In these cases, we can set your benefit payment by estimating your income for the current year instead of using last year’s income.

## If your situation changes

Some changes in your life may affect your future benefits.

### If you leave Canada for more than 6 months

You cannot collect the Guaranteed Income Supplement if you are outside of Canada for more than 6 months.

If you plan to leave Canada for more than 6 months, you must [contact us to avoid an overpayment](/en/employment-social-development/corporate/contact/oas.html).

Service Canada compares information with the Canada Border Services Agency. If you leave Canada for more than 6 months while collecting the Guaranteed Income Supplement, we’ll determine if you’re eligible to those payments. If not, we’ll calculate how much we overpaid you, and you will then have to repay that amount.

**Note:** You could be fined for giving false, misleading, or purposely omitted information.

You can also come forward to correct wrong or incomplete information or to give important information that you haven’t already shared with Service Canada. [Learn about Penalties, Interest and Disclosure Policy](/en/services/benefits/publicpensions/cpp/penalties.html).

When you return to Canada, [contact us to restart your payments](/en/employment-social-development/corporate/contact/oas.html).

### If your marital status changes

You must [contact us](/en/employment-social-development/corporate/contact/oas.html) if you:

* marry
* enter into a common-law union
* divorce or separate
* your spouse or common-law partner dies

### If you and your partner have to live apart

If you and your spouse or common-law partner live apart for reasons beyond your control, such as long-term care for one or both of you, you may be able to receive a higher benefit payment amount.

Download the Statement - [Spouses or Common-law Partners Living Apart for Reasons beyond their Control (ISP-3040) form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3040.pdf).

Mail the completed form to the [nearest Service Canada office](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html).

### If you are in jail

Your Guaranteed Income Supplement payments will stop if you are in a federal prison serving a sentence of 2 years or more. You must notify Service Canada in writing of your release and your payments will start again the month you are released.

### If your spouse or common-law partner is in jail

You must [contact us](/en/employment-social-development/corporate/contact/oas.html) if your spouse or common-law partner is in a federal prison.

## When your benefit could stop

Your Guaranteed Income Supplement payment can stop for any of the following reasons:

* you did not file a tax return by April 30
* by the end of June, you did not give us the information about your income (or in the case of a couple, your income plus the income of your spouse/common-law partner) for the previous year
* you leave Canada for more than 6 consecutive months
* your income (or in the case of a couple, your income plus the income of your spouse/common-law partner) is higher than what is allowed to receive the benefit
* you are in a federal prison for a sentence of 2 years or longer
* you die (it is important that someone notify us about your death to avoid overpayment)

### When someone dies

If you're reading this following the loss of a loved one, please accept our condolences.

When someone dies, please inform us as soon as possible to avoid overpayment. Find out how to [cancel Guaranteed Income Supplement benefits](/en/services/benefits/publicpensions/cpp/cancel-cpp.html) on behalf of a deceased person.

## Document navigation

* [Previous : Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html)

## Page details

Date modified:
:   2025-07-15

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
