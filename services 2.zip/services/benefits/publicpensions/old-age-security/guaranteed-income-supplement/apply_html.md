---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html
scraped_at: 2025-08-24 18:11:17
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

# Guaranteed Income Supplement

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Your application](#gc-document-nav)
* [While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html) [While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Your application

* ## System maintenance: Online services

  All online services will be closed for maintenance from 6 am August 23 to 12 pm (ET) August 23, 2025.
* ## Get timely benefit payments: Sign up for Direct Deposit today!

  [Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

**You need to do the following:**

* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/documents.png)Step 1: Determine if you need to apply](#h2.1)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/personal.png)Step 2: Gather your information](#h2.2)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/submit.png)Step 3: Submit your application](#h2.3)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/old-age-security/Step4_Letter.png)Step 4: Receive a response from us](#h2.4)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/screen.png)Step 5: Review your application status](#h2.5)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/old-age-security/exclamation.png)Step 6: If you disagree with the decision](#h2.6)

## Step 1: Determine if you need to apply

We may send you a letter to let you know that you will receive the Guaranteed Income Supplement.

You will need to apply for the Guaranteed Income Supplement if:

* you get a letter from us asking you to apply
* the information in the letter we send you is incorrect
* you are already receiving an Old Age Security pension and have never received the Guaranteed Income Supplement

If you did not receive any letter about the Guaranteed Income Supplement the month after you turned 64, [contact us](/en/employment-social-development/corporate/contact/oas.html) to find out if you need to apply.

## Step 2: Gather your information

Before you begin, please ensure you have:

* your Social Insurance Number (SIN)
* information about your spouse or common-law partner if you have one (Social Insurance Number, date of birth)
* information about the countries where you have lived since age 18
* your banking information to sign up for [direct deposit](/en/employment-social-development/programs/direct-deposit.html)
* the date you would like your payments to start
* your reduction in employment or pension income, if applicable

### How to determine your income

When applying for the Guaranteed Income Supplement and the Allowance, you, or in the case of a couple you and your spouse or common-law partner, must report your income and deductions.

Do not include Old Age Security, Guaranteed Income Supplement, Allowance, or Allowance for the Survivor payments as income.

#### What you must include as income

* [Canada Pension Plan (CPP)](/en/services/benefits/publicpensions/cpp.html) or [Quebec Pension Plan (QPP)](https://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/regime_rentes.aspx) benefits
* Other pension income, such as private pensions, superannuation and foreign pension income
* Registered Retirement Savings Plans (RRSPs) that you cashed during the year
* Employment Insurance benefits
* Worker's compensation benefits
* Interest and other investment income, including foreign dividends
* Taxable capital gains and dividends
* Net income from any rental properties
* Net employment or self-employment income (consult exemptions below)
* Other income from sources such as alimony and First Home Savings Account (FHSA) withdrawals

#### Less deductions such as

* Canada Pension Plan or Quebec Pension Plan contributions and your Employment Insurance premiums
* Canada Pension Plan or Quebec Pension Plan contributions and your Employment Insurance premiums of net self-employment income
* Union dues, RRSP deductions, FHSA contributions, moving expenses and other employment expenses

#### What is exempted as income

* Old Age Security, Guaranteed Income Supplement, Allowance or Allowance for the Survivor payments
* If you are employed or self-employed and receive the Guaranteed Income Supplement, you can earn up to $5,000 with no reduction to your benefit amount. For earnings between $5,000 and $15,000,  only 50% of the income you receive will reduce your Guaranteed Income Supplement benefit amount
* Death benefit and Children's benefits from CPP or QPP
* Inheritances
* Lottery winnings
* The goods and services tax (GST) credit

## Step 3: Submit your application

Decide how to apply:

### Apply online for GIS

To apply online, you must:

* be at least 1 month past your 64th birthday
* not have a legal representative on your account

If you are applying online, you’ll need a My Service Canada Account (MSCA).

If you don’t have a My Service Canada Account (MSCA), you can register for one. You’ll receive a personal access code to complete your registration.

[Apply or register through My Service Canada Account](/en/employment-social-development/services/my-account.html)

**Note:** It's important to gather the information you need before you begin, because once you start the application, you cannot save it and continue later. Your session will expire after 20 minutes of inactivity (this time starts when your computer mouse stops moving and resets when your mouse is moved).

### Apply using a paper application

**If you are applying for both the Old Age Security and Guaranteed Income Supplement**

* Complete the form included with your letter or download a new [Application for the Old Age Security Pension and the Guaranteed Income Supplement (ISP-3550)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3550.pdf)
* Include certified true copies of the required documents
* [Mail the application](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) to Service Canada or bring it in person to a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

See the [Reference Guide (ISP-3550A)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3550A.pdf) for information on filling in your application form.

**If you are applying for just the Guaranteed Income Supplement**

* Complete the form included with your letter or download a new [Application for the Guaranteed Income Supplement or Statement of Income (ISP-3025)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3025.pdf)
* Include certified true copies of the required documents
* [Mail the application](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) to Service Canada or bring it in person to a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

#### If someone is helping you with your application

You must provide consent for someone to help you with your application. You can do this 2 ways:

1. through your [My Service Canada Account](/en/employment-social-development/services/my-account.html)

**or**

2. complete the [Consent to Communicate Information to an Authorized Person form (ISP-1603)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-1603_OAS.pdf) and [mail it to us](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true), or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

This **does not** give the person helping you authority to:

* submit your application
* apply for benefits on your behalf
* change your payment address
* request or change the withholding of tax for you

**If you need to apply or act on someone’s behalf**

If someone cannot manage their own affairs, another person or agency may act on their behalf.

To apply to administer benefits on someone’s behalf you need to:

* have a medical professional complete the [Certificate of Incapability form (ISP-3505)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3505_OAS.pdf)
* complete one of the following forms that applies to you:
  + [Agreement to administer benefits under the *Old Age Security Act* and/or the Canada Pension Plan by a Private Trustee form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3506_OAS.pdf) (for administration by an individual)
  + [Agreement to administer benefits under the *Old Age Security Act* and/or the Canada Pension Plan by an Agency or Institution form](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3507_OAS.pdf) (for administration by an agency, charitable organization or municipality)

You will need to [mail it to us](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true), or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng).

These forms do not give the person applying on someone’s behalf authority to submit an application through My Service Canada Account (MSCA). You must submit a paper application.

### Providing Service Canada with your email address

**Note:** When you apply, you can provide your email address. We may send you an email to provide you with information or ask you to call us if we can’t reach you by phone. Please note that we won't ask you to send information such as SIN, banking, or other personal details by email.

### Protecting your information

Learn how we [protect your privacy](/en/transparency/privacy.html).

## Step 4: Receive a response from us

We will mail you a letter with either:

* a decision on your application
* a request for more information

### Your decision letter

Your letter with a decision will include:

* the amount you will receive each month
* the date of your first payment
* any past payments that may be owed to you

## Step 5: Review your application status

To view your application status, you can:

* [sign in to My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)
* [contact Service Canada](/en/employment-social-development/corporate/contact/oas.html)

If you don’t have an MSCA account, you can register for one.

## Step 6: If you disagree with the decision

If you disagree with the decision, you may ask to have the decision reviewed. You must request this review in writing **within 90 days** of receiving your decision letter.

Your application will be reviewed by Service Canada staff who were not involved in making the original decision on your application.

### Submit a request for reconsideration of a decision

There are 3 ways you can make your request for reconsideration:

#### Online

Submit your request online using [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)

#### Printable form

Complete and submit the [Request for Reconsideration of a Old Age Security Decision form (ISP-3134)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3134)

##### If you complete your request on paper

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

#### Writing

Prepare and submit a written request to review the decision and include:

* your name
* your address
* your telephone number
* your Social Insurance Number or Client Identification Number
* a detailed explanation of why you do not agree with the decision
* any new information that could affect the decision
* your signature and the date

##### If you complete your request on paper

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

Reconsiderations can take several months to complete, depending on the case. Service Canada will review your application and any new information you submit in support of your request and send you a (new) decision by mail.

### Submit an appeal to the Social Security Tribunal of Canada

If you disagree with the new decision, you can contact the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) (SST). The Social Security Tribunal is an independent administrative tribunal. It’s separate from Service Canada.

There are 2 ways to start an appeal with the Social Security Tribunal:

#### Social Security Tribunal Website

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/en/your-appeal/notice-appeal-income-security)

#### Using My Service Canada Account (MSCA)

Start the appeal process online in [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html).

1. sign in or register to MSCA
2. navigate to the "Canada Pension Plan / Old Age Security" section
3. navigate to the "If you disagree with a decision" section
4. select "Appeal to the SST" under "Step 2"

#### Help to communicate with the Social Security Tribunal

If you would like a representative to help you communicate with the Social Security Tribunal about your appeal, you will need to either:

##### Complete a form

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf)

##### Call a representative

Call the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) and provide your representative’s information

You must contact the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) directly to change or cancel your representative.

**Note:** If you would like your representative to communicate with both Service Canada and the Social Security Tribunal, fill out [section 9 of the Notice of Appeal form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf) **and** complete the [Consent to Communicate Information to an Authorized Person form](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ISP-1603.pdf) for Service Canada.

## Document navigation

* [Previous : How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)
* [Next : While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html)

## Page details

Date modified:
:   2025-08-22

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
