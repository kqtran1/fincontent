---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/while-receiving.html
scraped_at: 2025-08-24 17:17:51
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/while-receiving_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/allocation-survivant/pendant-que-vous-recevez.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
6. [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

# Allowance for the Survivor

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/eligibility.html)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply.html) [Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply.html)
* [While receiving the Allowance for the Survivor](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# While receiving the Allowance for the Survivor

## On this page

* [Your first payment](#h2.1)
* [We review your benefit amount each year](#h2.2)
* [You must file your taxes on time](#h2.3)
* [If your situation changes](#h2.4)
* [How to avoid being overpaid](#h2.5)
* [When your benefit could stop](#h2.6)

## Your first payment

You will receive your first payment either:

* the month after the death of your spouse or common-law partner
* up to 11 months before the date we received or waived your application (if you applied after you turn 60)
* the month after you meet the eligibility requirements
* the month you turn 60
* the date that is indicated on your decision letter

You can receive your benefit payment by cheque or direct deposit to your banking account in Canada. You will have sign up for [direct deposit](/en/employment-social-development/programs/direct-deposit.html).

## We review your benefit amount each year

Using your income information from your federal Income tax return, we will review whether you will continue to receive the Allowance for the Survivor for the next year.

Every July, you will receive a letter telling you one of the following:

* your benefit will be renewed and the amount for the next 12 months
* your benefit will be stopped
* your benefit will start or resume
* we need your income information

## You must file your taxes on time

You do not have to pay taxes on your Allowance for the Survivor benefit payment. You must **file your taxes by April 30 every year** to avoid any disruption of payments.

## If your situation changes

### If your income changes

Your income may change due to several factors. [Find out how to determine your income](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply.html).

[Contact us](/en/employment-social-development/corporate/contact/oas.html) if you have a lower annual income due to retirement or if other pension benefits are reduced or stopped.

In these cases, we can set your benefit payment by estimating your income for the current year instead of using last year’s income.

### If you leave Canada for more than 6 months

You cannot collect the Allowance for the Survivor benefit if you are outside of Canada for more than 6 months.

If you plan to leave Canada for more than 6 months, you must [contact us](/en/employment-social-development/corporate/contact/oas.html) to avoid an overpayment.

Service Canada compares information with the Canada Border Services Agency. If you leave Canada for more than 6 months while collecting the Allowance for the Survivor benefit, we will determine if you are eligible to those payments. If not, we will calculate how much we overpaid you, and you will then have to repay that amount.

**Note:** You could be fined for giving false, misleading, or purposely omitted information.

You can also come forward to correct wrong or incomplete information or to give important information that you have not already shared with Service Canada. Learn about [Penalties, Interest and Disclosure Policy](/en/services/benefits/publicpensions/cpp/penalties.html).

When you return to Canada, [contact us](/en/employment-social-development/corporate/contact/oas.html) to restart your payments.

### If your marital status changes

You must [contact us](/en/employment-social-development/corporate/contact/oas.html) if you:

* marry
* enter into a common-law relationship

### If you are in jail

Your Allowance for the Survivor payments will stop if you are in a federal prison serving a sentence of 2 years or more. You must notify Service Canada in writing of your release and your payments will start again the month you are released.

## How to avoid being overpaid

You must notify Service Canada if there are any changes to your marital status. If you receive any monies to which you are not entitled, you will have to pay it back.

## How to avoid being overpaid

You must notify Service Canada if there are any changes to your marital status. If you receive any monies to which you are not entitled, you will have to pay it back.

## When your benefit could stop

Your Allowance for the Survivor payment can stop for any of the following reasons:

* you have not filed a tax return by April 30
* by the end of June, you did not give us the information about your income for the previous year
* you leave Canada for more than 6 consecutive months
* your income is higher than what is allowed to receive the benefit
* you are in a federal prison for a sentence of 2 years or longer
* you have reached the age of 65 (payments stop the month after you turn 65 when you may be eligible for the [Old Age Security pension](/en/services/benefits/publicpensions/old-age-security.html)
* you remarry or enter into a new common-law relationship
* you die (it is important that someone notify us about your death to avoid overpayment)

### When someone dies

If you are reading this following the loss of a loved one, please accept our condolences.

When someone dies, please inform us as soon as possible to avoid overpayment.

Find out how to [cancel the Allowance for the Survivor benefit](/en/services/benefits/publicpensions/cpp/cancel-cpp.html) on behalf of a deceased person.

## Document navigation

* [Previous - Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply.html)

## Page details

Date modified:
:   2025-04-10

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
