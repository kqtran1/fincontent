---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply.html
scraped_at: 2025-08-24 16:10:24
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/allocation-survivant/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
6. [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

# Allowance for the Survivor

* [Overview](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html) [Overview](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)
* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/eligibility.html)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Your application](#gc-document-nav)
* [While receiving the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/while-receiving.html) [While receiving the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Your application

## System maintenance: Online services

All online services will be closed for maintenance from 6 am August 23 to 12 pm (ET) August 23, 2025.

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

**You need to do the following:**

* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/documents.png)Step 1: Determine if you need to apply](#h2.1)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/personal.png)Step 2: Gather your information](#h2.2)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/submit.png)Step 3: Submit your application](#h2.3)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/old-age-security/Step4_Letter.png)Step 4: Receive a response from us](#h2.4)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/apply/screen.png)Step 5: Review your application status](#h2.5)
* [![](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/old-age-security/exclamation.png)Step 6: If you disagree with the decision](#h2.6)

## Step 1: Determine if you need to apply

You will need to apply for the Allowance for the Survivor benefits. You should apply for this benefit when your spouse or common-law partner has passed away and if you are 60 to 64 years of age.

You can apply 6 to 11 months before your 60th birthday if your spouse or common-law partner passed away before this.

## Step 2: Gather your information

* Information about your spouse or common-law partner:
  + Social Insurance Number
  + date of birth
  + date of death
  + foreign income information (types of income and annual amounts in CAD)
* Information about the countries where you have lived since age 18
* Your banking information to sign up for [direct deposit](https://www.tpsgc-pwgsc.gc.ca/recgen/txt/depot-deposit-eng.html)
* If your employment or pension income stopped or reduced you will need the date it reduced and stopped and the new monthly rate
* Your foreign income information (types of income and annual amounts in CAD)

### How to determine your income

When applying for the Allowance for the Survivor, you must report your income and deductions.

#### What you must include as income

* [Canada Pension Plan (CPP)](/en/services/benefits/publicpensions/cpp.html) or [Quebec Pension Plan (QPP)](https://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/regime_rentes.aspx) benefits
* Other pension income, such as private pensions, superannuation and foreign pension income
* Registered Retirement Savings Plans (RRSPs) that you cashed during the year
* Employment Insurance benefits
* Interest and other investment income
* Capital gains and taxable Canadian dividends
* Net income from any rental properties
* Net employment or self-employment income
* Other income from sources such as workers' compensation payments

#### What is exempted as income

* Old Age Security, Guaranteed Income Supplement, Allowance or Allowance for the Survivor payments
* Payments of retroactive CPP or QPP benefits for previous years
* Other benefit and assistance payments from municipal, territorial or federal government or universal child care benefits to name a few
* Grants, rebates, refunds programs and credits
* Some war service pensions, retribution payments and ex gratia payments
* Aboriginal people tax – exempt income
* Lottery winnings
* Inheritances
* Tax free savings accounts
* CPP death benefit or children’s benefits
* Wage loss replacement benefits paid under a private insurance plan

#### What can be deducted from your income

* Canada Pension Plan or Quebec Pension Plan contributions and your Employment Insurance premiums
* Elected pension split income deduction
* Union dues, professional or like dues
* RRSP, RPP or Saskatchewan pension plan contributions
* Moving expenses related to employment and other employment expenses
* Clergy residence deduction
* Deductions to reduce rental income
* Some child support payments
* Some spousal support payments
* Attendant care and other disability supports deduction
* Other deductions permitted by CRA

**Note:** If you are employed or self employed and receive the Guaranteed Income Supplement, Allowance or Allowance for the Survivor, you can earn up to $5,000 and still receive the full benefit amount. For earnings between $5,000 and $15,000, your Guaranteed Income Supplement, Allowance or Allowance for the Survivor will be reduced by 50 cents for every dollar of income you receive.

## Step 3: Submit your application

Decide how to apply:

### Apply online

To apply online, you must:

* be age of 60 to 65
* not have a legal representative on your account

If you are applying online, you will need a My Service Canada Account (MSCA). If you do not have an MSCA account, you can register for one. You will receive a personal access code to complete your registration.

[Apply or register through My Service Canada Account](/en/employment-social-development/services/my-account.html)

**Note:** It is important to gather the information you need before you begin, because once you start the application, you cannot save it and continue later. Your session will expire after 20 minutes of inactivity (this time starts when your computer mouse stops moving and resets when your mouse is moved).

### Apply using a paper application

* Print and complete the application for the [Application for the Allowance or Allowance for the Survivor (ISP3008)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3008)
* Print and complete the [Statement of income for the Renewal of the Guaranteed Income Supplement, the Allowance or the Allowance for the Survivor (ISP3026)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3026)
* Include certified true copies of the required documents
* [Mail the application](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) to Service Canada or bring it in person to a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

Consult the [Information Sheet for Allowance or Allowance for the Survivor (ISP3008A)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3008) for information on how to fill your application.

#### If someone is helping you with your application

You must provide consent for someone to help you with your application. You can do this in 2 ways:

1. through your [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)

   **or**
2. print and complete the [Consent to Communicate Information to an Authorized Person (ISP1603)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1603OAS) and [mail](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) it to us, or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

This **does not** give the person helping you authority to:

* submit your application
* apply for benefits on your behalf
* change your payment address
* request or change the withholding of tax for you

#### If you need to apply or act on someone’s behalf

If someone cannot manage their own affairs, another person or agency may act on their behalf.

To apply to administer benefits on someone’s behalf you need to:

* have a medical professional complete the [Certificate of Incapability (ISP3505)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3505OAS)
* print and complete one of the following forms that applies to you:
  + [Agreement to administer benefit under the *Old Age Security Act* and/or the Canada Pension Plan by a Private Trustee (ISP3506)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3506OAS) (for administration by an individual)
  + [Agreement to administer benefits under the *Old Age Security Act* and/or the Canada Pension Plan by an Agency or Institution (ISP3507)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3507OAS) (for administration by an agency, charitable organization or municipality)

You will need to [mail](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) it to us, or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng).

These forms do not give the person applying on someone’s behalf authority to submit an application through My Service Canada Account (MSCA). You must submit a paper application.

### Providing Service Canada with your email address

**Note:** When you apply, you can provide your email address. We may send you an email to provide you with information or ask you to call us if we can’t reach you by phone. Please note that we won't ask you to send information such as SIN, banking, or other personal details by email.

## Protect your information

Learn how we [protect your privacy](/en/transparency/privacy.html).

## Step 4: Receive a response from us

We will mail you a letter with either:

* a decision on your application
* a request for more information

### Your decision letter

If you are approved, your letter with a decision will include:

* the amount you will receive each month
* the date of your first payment
* any past payments that may be owed to you

## Step 5: Review your application status

To view your application status, you can:

* Sign in to [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)
* contact [Service Canada](/en/employment-social-development/corporate/contact/oas.html)

If you don’t have an MSCA account, you can register for one.

## Step 6: If you disagree with the decision

If you disagree with the decision, you may ask to have the decision reviewed. You must request this review in writing **within 90 days** of receiving your decision letter.

Your application will be reviewed by Service Canada staff who were not involved in making the original decision on your application.

### Submit a request for reconsideration of a decision

There are 3 ways you can make your request for reconsideration:

#### Online

Submit your request online using [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)

#### Printable form

Complete and submit the [Request for Reconsideration of a Old Age Security Decision form (ISP-3134)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3134)

#### If you complete your request on paper

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

#### Writing

Prepare and submit a written request to review the decision and include:

* your name
* your address
* your telephone number
* your Social Insurance Number or Client Identification Number
* a detailed explanation of why you do not agree with the decision
* any new information that could affect the decision
* your signature and the date

#### If you complete your request on paper

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

Reconsiderations can take several months to complete, depending on the case. Service Canada will review your application and any new information you submit in support of your request and send you a (new) decision by mail.

### Submit an appeal to the Social Security Tribunal of Canada

If you disagree with the new decision, you can contact the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) (SST). The Social Security Tribunal is an independent administrative tribunal. It’s separate from Service Canada.

There are 2 ways to start an appeal with the Social Security Tribunal:

#### Social Security Tribunal Website

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/en/your-appeal/notice-appeal-income-security)

#### Using My Service Canada Account (MSCA)

Start the appeal process online in [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html).

1. sign in or register to MSCA
2. navigate to the "Canada Pension Plan / Old Age Security" section
3. navigate to the "If you disagree with a decision" section
4. select "Appeal to the SST" under "Step 2"

#### Help to communicate with the Social Security Tribunal

If you would like a representative to help you communicate with the Social Security Tribunal about your appeal, you will need to either:

##### Complete a form

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf)

##### Call a representative

Call the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) and provide your representative’s information

You must contact the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) directly to change or cancel your representative.

**Note:** If you would like your representative to communicate with both Service Canada and the Social Security Tribunal, fill out [section 9 of the Notice of Appeal form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf) **and** complete the [Consent to Communicate Information to an Authorized Person form](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ISP-1603.pdf) for Service Canada.

## Document navigation

* [Previous - How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html)
* [Next - While receiving the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/while-receiving.html)

## Page details

Date modified:
:   2025-08-22

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
