---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/eligibility.html
scraped_at: 2025-08-24 20:03:31
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/allocation/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
6. [Guaranteed Income Supplement - Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)

# Guaranteed Income Supplement - Allowance

* [Do you qualify](#gc-document-nav)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Apply](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html) [Apply](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html)
* [While receiving the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/while-receiving.html) [While receiving the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Do you qualify

The information provided below should be used as a guideline. We encourage you to apply and allow a Service Canada representative to determine if you are eligible.

## Do you qualify for the Allowance

You may be able to get the Allowance benefit if:

* your spouse or common-law partner receives an Old Age Security pension (OAS) and is eligible and entitled to receive the Guaranteed Income Supplement (GIS)
* you are 60 to 64 years of age
* you are a Canadian citizen or a legal resident
* you have resided in Canada for at least 10 years since the age of 18
* you and your spouse or common-law partner’s annual combined income is less than $41,184

Check the [maximum annual income threshold](/en/services/benefits/publicpensions/old-age-security/payments.html#tbl2).

If you have not resided in Canada for at least 10 years since you turned 18, but you have resided or worked in a [country that has a social security agreement with Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html), you may still be eligible for a partial benefit.

## Other circumstances

### If you are an immigrant who is sponsored

If you are a sponsored immigrant and have lived in Canada for less than 10 years after age 18, you can apply and have your benefit approved however, you will not receive a payment for the Allowance while you are sponsored unless your sponsor:

* suffers personal bankruptcy
* is sentenced to a term of incarceration for more than 6 months
* is convicted of an offence against you under the *Criminal Code*
* dies

If you have lived in Canada for fewer than 10 years since you turned 18, but you have lived or worked in a [country that has a social security agreement with Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html), you may be eligible for a partial benefit.

If you become entitled to the Allowance it will gradually increase with every year that you continue to reside in Canada until you have reached 10 years of residence.

### If you are an immigrant who is not sponsored

If you are an immigrant who is not sponsored, you may be eligible to receive the Allowance based on the number of years you have resided in Canada after age 18.

If you have lived in Canada for fewer than 10 years since you turned 18, but you have lived or worked in a [country that has a social security agreement with Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html), you may be eligible for a partial benefit.

Your Allowance or the Allowance for the Survivor entitlement will gradually increase with every year that you continue to reside in Canada until you have reached 10 years of residence.

### If your spouse or common-law partner is in jail

You may be entitled to the Allowance if your spouse or common-law partner is in jail, provided that you meet all the eligibility requirements. The Allowance will be based on your own annual income.

If your spouse or common-law partner is in jail, he or she must be in receipt or apply for the Old Age Security or Guaranteed Income Supplement and be found eligible in order for you to be eligible to receive the Allowance.

### If you are in jail

If you are in jail in a Federal institution, you can apply for the Allowance however, you cannot receive a payment until you are released.

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

## Document navigation

* [Previous : Overview](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)
* [Next : How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html)

## Page details

Date modified:
:   2025-05-20

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
