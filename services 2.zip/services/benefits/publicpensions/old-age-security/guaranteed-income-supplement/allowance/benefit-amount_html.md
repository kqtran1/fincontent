---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html
scraped_at: 2025-08-24 16:02:26
filename: en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti/allocation/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)
5. [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
6. [Guaranteed Income Supplement - Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)

# Guaranteed Income Supplement - Allowance

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/eligibility.html)
* [How much you could receive](#gc-document-nav)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Apply](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html) [Apply](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html)
* [While receiving the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/while-receiving.html) [While receiving the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# How much you could receive

## On this page

* [Maximum payment and income threshold](#h2.1)
* [Your payment](#h2.2)
* [If your income this year is less than last year](#h2.3)
* [If you disagree with the amount you receive](#h2.4)

## Maximum payment and income threshold

The amount of the Allowance that you receive depends on your marital status and your previous year’s income (or in the case of a couple, your combined income).

Allowance – July to September 2025

| Your situation | Your annual net income must be | Maximum monthly payment amount |
| --- | --- | --- |
| I have a spouse/common-law partner who receives the GIS and the full OAS pension | less than $41,184 (combined annual income of couple) | up to $1,395.73 |

Find out more about [Allowance payment amounts](/en/services/benefits/publicpensions/old-age-security/payments.html).

The Allowance is reviewed in January, April, July and October to reflect increases in the cost of living as measured by the Consumer Price Index. Your monthly payment amount will not decrease if the cost of living goes down.

## Your payment

You can receive your benefit payment by cheque or [direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to your banking account in Canada. You will have to sign up for direct deposit.

## If your income this year is less than last year

Your income may change due to several factors. Find out how to [determine your income](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html#determine-income).

[Contact us](/en/employment-social-development/corporate/contact/oas.html) if you or your spouse or common-law partner has a lower annual income due to retirement or if other pension benefits are reduced or stopped.

In these cases, we can set your benefit payment by estimating your income for the current year instead of using last year’s income.

## If you disagree with the amount you receive

If your letter from us lists a payment amount you think is incorrect, you must write to us within 90 days after you receive your letter.

Find more information on [how to request a reconsideration](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html#h2.6).

## Document navigation

* [Previous : Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/eligibility.html)
* [Next : Apply](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/apply.html)

## Page details

Date modified:
:   2025-06-19

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
