---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/eligibility.html
scraped_at: 2025-08-24 19:59:20
filename: en/services/benefits/publicpensions/old-age-security/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)

# Old Age Security

* Do you qualify
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Apply, delay, or change your start date](/en/services/benefits/publicpensions/old-age-security/apply.html) [Apply, delay, or change your start date](/en/services/benefits/publicpensions/old-age-security/apply.html)
* [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html) [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Do you qualify

## On this page

* [Do you qualify for Old Age Security](#h2.1)
* [Extra payments based on your Income and Age](#h2.2)
  + [Other Old Age Security Benefits](#h2.2-h3.1)
  + [One-time payments](#h2.2-h3.2)

## Do you qualify for Old Age Security

Your employment history is not a factor in determining eligibility. You can receive the Old Age Security (OAS) pension even if you have never worked or are still working.

**If you are living in Canada, you must:**

* be 65 years old or older
* be a Canadian citizen or a legal resident at the time we approve your OAS pension application
* have resided in Canada for at least 10 years since the age of 18

**If you are living outside Canada, you must:**

* be 65 years old or older
* have been a Canadian citizen or a legal resident of Canada on the day before you left Canada
* have resided in Canada for at least 20 years since the age of 18

**Canadians working outside Canada for Canadian employers**

Canadians working outside Canada for Canadian employers, such as the Canadian Armed Forces and banks, may have their time working abroad counted as residence in Canada.

To qualify this time working abroad as residence, you must have either:

* returned to Canada within 6 months of ending employment
* turned 65 years old while still employed and maintained residence in Canada during your time outside of Canada

You must provide the following 2 documents:

* proof of employment from the employer
* proof of physically returning to Canada (unless you turned 65 while still employed outside Canada).

Under certain conditions, spouses, common-law partners, dependents, and Canadians working abroad for international organizations may also count time spent abroad as residence in Canada.

**If neither of the above scenarios applies to you, you may still qualify for the Old Age Security pension, a pension from another country, or from both countries if you have:**

* lived in one of the countries Canada has established a social security agreement
  or
* contributed to the social security system of one of the countries with which Canada has established a social security agreement.

For more information, see [lived or living outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html).

## Extra payments based on your income and your age

In addition to your Old Age Security pension, you and/or your spouse/common-law partner may be eligible for extra benefits and payments.

### Other Old Age Security benefits:

[Guaranteed Income Supplement (GIS)](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

You may be able to get this benefit if:

* you get the Old Age Security (OAS) pension
* you are **65 or older**
* you are a Canadian citizen or a legal resident
* you live in Canada
* your income is below the [maximum annual income threshold for the GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html) based on your marital status

[Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)

You may be able to get this benefit if:

* your spouse or common-law partner receives the Guaranteed Income Supplement (GIS)
* you are **60 to 64 years of age**
* you are a Canadian citizen or a legal resident
* you have lived in Canada for at least 10 years since the age of 18
* you and your spouse or common-law partner’s combined income is below the [maximum annual income threshold for the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance/benefit-amount.html)

[Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

You may be able to get this benefit if:

* your spouse or common-law partner has died and you have not remarried or entered into a common-law relationship
* you are **60 to 64 years of age**
* you are a Canadian Citizen or legal resident
* you have lived in Canada for at least 10 years since the age of 18
* your annual income is less than the [maximum annual income threshold for the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor/benefit-amount.html)

### One-time payments:

* [One-time payment for older seniors](/en/services/benefits/publicpensions/old-age-security/one-time-payment-older-seniors.html) born before June 30, 1947

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

### Document navigation

* [Previous: Overview](/en/services/benefits/publicpensions/old-age-security.html)
* [Next: How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html)

## Page details

Date modified:
:   2025-08-12

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
