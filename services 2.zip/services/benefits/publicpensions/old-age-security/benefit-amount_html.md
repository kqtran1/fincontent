---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/benefit-amount.html
scraped_at: 2025-08-24 19:25:27
filename: en/services/benefits/publicpensions/old-age-security/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)

# Old Age Security

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html)
* How much you could receive
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* [Apply, delay, or change your start date](/en/services/benefits/publicpensions/old-age-security/apply.html) [Apply, delay, or change your start date](/en/services/benefits/publicpensions/old-age-security/apply.html)
* [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html) [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# How much you could receive

## On this page

* [Maximum payments and income thresholds](#h2.1)
* [Increased Old Age Security pension at age 75](#h2.2)
* [Your payment](#h2.3)
* [Should you wait to start collecting Old Age Security](#h2.4)
* [Partial Old Age Security for less than 40 years of residency (after age 18)](#h2.5)

## Maximum payments and income thresholds

**Old Age Security (OAS) pension amounts – July to September 2025**

| Age | Maximum monthly payment amount | To receive the OAS your annual net world income in 2024 must be |
| --- | --- | --- |
| 65 to 74 | $734.95 | Less than $148,541 |
| 75 and over | $808.45 | Less than $154,196 |

Find out more about [Old Age Security (OAS) payment amounts](/en/services/benefits/publicpensions/old-age-security/payments.html).

The Old Age Security pension is reviewed in January, April, July and October to reflect increases in the cost of living as measured by the Consumer Price Index. Your monthly payment amount will not decrease if the cost of living goes down.

## Increased Old Age Security pension at age 75

If you are or will be 75 years old or older in June 2022, you will get an automatic 10% increase of your Old Age Security pension starting in July 2022.

If you are turning 75 after July 1, 2022, you will receive the increase in the month following your 75th birthday.

The 10% increase in the maximum OAS pension rate will not affect the calculation of your Guaranteed Income Supplement (GIS).

## Your payment

If your income is higher than $90,997 (2024), you will have to repay part or your entire Old Age Security pension. Find out more about [Old Age Security pension recovery tax](/en/services/benefits/publicpensions/old-age-security/recovery-tax.html).

You can receive your benefit payment by cheque or direct deposit to your banking account in Canada, the United States, or to some [specific countries](https://www.tpsgc-pwgsc.gc.ca/recgen/dd/etranger-abroad-eng.html#a4). You will have to [sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html).

### Retroactive payments

If you are already over 65, we may be able to give you a retroactive payment for up to a maximum of 11 months from the date we receive your application. If you delayed receiving your Old Age Security pension you will not be able to receive retroactive payment during the deferral period.

You might also be eligible to receive extra payments based on your income such as:

* [the Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)
* [the Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)
* [the Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

### Payment dates

You will receive your first Old Age Security payment either:

* the month after you turn 65
* the specific date that you have chosen

## Should you wait to start collecting Old Age Security

You can receive your first Old Age Security pension payment the month after you turn 65.

You can receive a higher amount for each month you decide to delay your first payment.

You can delay payment of the Old Age Security pension for up to 60 months (5 years) after you are 65. The longer you delay, the larger your pension payment will be each month.

After age 70, there is no advantage in delaying your first payment. In fact, you risk losing benefits. If you are over the age of 70 and are not receiving an Old Age Security pension, [apply now](/en/services/benefits/publicpensions/old-age-security/apply.html).

If you are eligible for the Guaranteed Income Supplement, there is also no advantage in delaying your first payment.

### Consider your personal circumstances

There are many factors you should consider when deciding when to start receiving your Old Age Security pension. These include your health, your financial situation, and your plans for retirement.

You should think about:

* whether you plan to keep working
* if your spouse or common-law partner wants to apply for the [Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)
* your health
* your retirement plans

### If you are still working and receiving Old Age Security payments

If you are still working and your income is higher than **$90,997** (2024), you will have to repay part of your Old Age Security pension payment. Delaying your first payment can let you keep more of your pension.

If you are planning on receiving the Guaranteed Income Supplement and your income is less than what you reported on your tax form last year, [contact us](/en/employment-social-development/corporate/contact/oas.html).

### Other benefits will be delayed if you delay your Old Age Security payment

If you are not in receipt of the Old Age Security pension:

* you cannot get the Guaranteed Income Supplement
* your spouse cannot apply for the Allowance

**Note:** The Guaranteed Income Supplement and Allowance amounts don’t increase when you delay receiving Old Age Security pension payments. You cannot receive the Guaranteed Income Supplement and your partner cannot receive the Allowance when you are not receiving the Old Age Security pension.

**When monthly increases are not applied**

If you decide to delay receiving the Old Age Security pension, you will not receive monthly increases during any month where you are:

* in federal prison as a result of a sentence of 2 years or longer (except for the first month of incarceration)
* outside Canada, have less than 20 years of residence in Canada and do not qualify under an international social security agreement

### Applying to delay your first payment

If you received a letter from us and want to delay your first payment:

* Sign in to your [My Service Canada Account](https://www.canada.ca/en/employment-social-development/services/my-account.html) and follow the directions
* complete, sign, and return the enrolment letter by mail

**Guide for calculating OAS amounts for each year the pension is delayed**

| Age | Percentage increase | How much you could get for your OAS pension (July to September 2025) |
| --- | --- | --- |
| 65 | n/a | $734.95 |
| 66 | 12 months X 0.6% = 7.2% | $787.87 |
| 67 | 24 months X 0.6% = 14.4% | $840.78 |
| 68 | 36 months X 0.6% = 21.6% | $893.70 |
| 69 | 48 months X 0.6% = 28.8% | $946.62 |
| 70 | 60 months X 0.6% = 36% | $999.53 |

**Examples of delaying Old Age Security**

 **Delaying 1 year**

Michael turned 65 in July. If he decides to delay receiving the Old Age Security pension for 1 year, his monthly amount will increase by 7.2% (0.6% x 12 months) to account for the 12-month deferral period.

**Delaying 5 years**

Rita will be turning 65 in December. If she decides to delay receiving the Old Age Security pension for the maximum deferral period of 60 months, her monthly amount will increase by 36% at age 70 (0.6% x 60 months).

**Delaying with an earlier start date than the date of application**

John could receive his Old Age Security pension in August and he decided to delay receiving it. In December of the next year, John applied for Old Age Security. He writes on his application that he would like his benefit to be effective as of October, 3 months earlier than his application date. His monthly benefit amount will then increase by 8.4% (0.6% x 14 months) to account for the 14-month deferral period. The monthly increase does not apply to the period from October to December of the year he applied.

## Partial Old Age Security pension for less than 40 years of residence (after age 18)

Not everyone receives the full Old Age Security pension. To receive a partial Old Age Security pension, you must have lived in Canada for 10 years, but less than 40 years (after age 18). To determine your payments, use the [Old Age Security (OAS) estimator](/en/services/benefits/publicpensions/old-age-security/payments.html#estimate-benefits).

To receive a partial Old Age Security pension, you must have lived in Canada for at least 10 years (after age 18). The amount of the partial Old Age Security pension you receive depends on the number of years you have lived in Canada.

Your partial payment amount is based on the number of years in Canada divided by 40.

You can delay your first payment up to 5 years to get a higher amount.

**Example**

**If you lived in Canada for 20 years**

If you lived in Canada for 20 years after age 18, you would receive a payment equal to 20 divided by 40, or 50%, of the full Old Age Security pension.

### Document navigation

* [Previous: Do you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html)
* [Next: Your application](/en/services/benefits/publicpensions/old-age-security/apply.html)

## Page details

Date modified:
:   2025-08-12

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
