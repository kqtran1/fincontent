---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/old-age-security/apply.html
scraped_at: 2025-08-24 20:01:39
filename: en/services/benefits/publicpensions/old-age-security/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)

# Old Age Security (OAS) pension

* [Do you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html)
* [How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html) [How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html)
  + [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) [Old Age Security Benefits Estimator](https://estimateursv-oasestimator.service.canada.ca/en) New!
* Apply, delay, or change your start date
* [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html) [While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/oas.html) [Contact us](/en/employment-social-development/corporate/contact/oas.html)

# Apply, delay, or change your start date

## System maintenance: Online services

All online services will be closed for maintenance from 6 am August 23 to 12 pm (ET) August 23, 2025.

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

## Most people don’t need to apply

If Service Canada has your eligibility information, you will get an enrollment letter around your 64th birthday. This means that you are **automatically enrolled**—no need to apply.

### Didn’t get a letter?

If it’s been one month since your 64th birthday and you still have not received an enrollment letter, [contact us](/en/employment-social-development/corporate/contact/oas.html) to find out if you need to apply.

### You will need to take action if

* The letter you received has **wrong information**
* You get a letter from Service Canada **asking you to apply**
* You want to **delay** or **change** your start date
* You have already had your 65th birthday and you have not started your pension or delayed your start date

## What to know before you start

[Check that you qualify](/en/services/benefits/publicpensions/old-age-security/eligibility.html) and choose your start date before you begin.

* I qualify
* I've chosen my Old Age Security (OAS) start date

### Gather your information

Before you begin, please ensure you have the following:

* information about your spouse or common-law partner if you are married or in a common-law relationship (Social Insurance Number, date of birth)
* information about where you have lived since age 18
* the date you would like your pension to start
* for you and your spouse or common-law partner (if applicable):
  + details about your residence history for the last 2 years
  + income information for the last 2 years if you have not filed taxes with the Canada Revenue Agency (CRA)
  + information about a reduction in employment or pension income in the last 2 years
  + any income earned from another country
  + your banking information to sign up for [direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit.html)

### If you lived or are living outside of Canada

If you are applying from outside of Canada, you must use a paper application. Send your application to the [Service Canada office](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html) in your last province or territory of residence. Learn more about pensions and benefits if you have [lived or are living outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html).

## Apply or delay

To apply or delay your OAS pension, [apply or delay online](#h3.1) or [apply or delay with a paper form](#paper-form).

### Apply or delay online

#### Check that you qualify to apply or delay using the online process

You can only apply or delay online if all the following statements are true.

* You are at least 1 month past your 64th birthday
* You live in Canada
* You are not currently receiving an Old Age Security pension
* You have not already applied, or your application is still being assessed by Service Canada
* You don't have a third party (like a power of attorney or a trustee) managing your OAS account

If you cannot apply or delay online, you will need to use a [paper form](#paper-form).

1. **1. Register or sign into your My Service Canada Account (MSCA) to:**
   [Apply](/en/employment-social-development/services/my-account.html)
2. **2. Complete this option (if required):**

#### If someone is helping you communicate with Service Canada

You can authorize someone to communicate with Service Canada on your behalf by signing in to your My Service Canada Account and selecting the "Give consent to communicate on my behalf" link.

**This does not give someone consent to:**

* apply for benefits on your behalf
* change your payment address
* request or change the withholding of tax

1. **3. Choose how to apply or delay**

* #### Option 1: Apply or delay with an application (with a start date)

  + Select "Manage my benefits" from the Old Age Security section
  + Select “Your benefit(s)” on the top left, then select “Apply for benefits”
  + Choose your start date in the application
* #### Option 2: Delay (without a start date)

  + Select “Manage my benefits” from the Old Age Security section
  + Select “Profile,” then “Delay Receiving OAS/GIS pension” under the “Tell us if anything has changed” heading

### Apply or delay with a paper form

1. **1. Complete the form:**
   * [Application for the OAS and the GIS (ISP-3550)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3550.pdf)
     + If you download the form, check your “Downloads” folder, even if the page indicates the form is loading
2. **2. Choose and complete an option (if required):**

#### If someone is helping you communicate with Service Canada

You can authorize someone to communicate with Service Canada on your behalf by:

* Completing the [Consent to Communicate Information to an Authorized Person form (ISP-1603)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-1603_CPP.pdf)

**This does not give someone consent to:**

* apply for benefits on your behalf
* change your payment address
* request or change the withholding of tax

#### If you are applying on someone's behalf

To act as an administrator for someone who cannot manage their own pension and benefits, you must:

1. Have a medical professional complete the [Certificate of Incapability OAS/CPP form (ISP-3505)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3505_CPP.pdf)
2. Choose and complete the form that applies to you:

* ##### Individual administration: Option 1

  [Agreement to administer benefits under the Old Age Security Act and/or the Canada Pension Plan by a Private Trustee (ISP-3506)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3506_OAS.pdf)
* ##### Agencies, charitable organizations, or municipalities: Option 2

  [Agreement to administer benefits under the Old Age Security Act and/or the Canada Pension Plan by an Agency or Institution (ISP-3507)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3507_OAS.pdf)

1. **3. Submit the forms**
   * [Mail the forms](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/isp.html?wbdisable=true) or [drop off the forms at a Service Canada office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## Change your start date

* **If you delayed your OAS, but did not complete an application:**
  + You need to apply to start receiving your payments
* **If you already applied and chose a start date, but want to change it:**
  + You need to [call us](/en/employment-social-development/corporate/contact/oas.html#details-panel2), [write to us](/en/employment-social-development/corporate/contact/oas.html#details-panel3), or [visit a Service Canada Office](/en/employment-social-development/corporate/contact/oas.html#details-panel4) to ask for a new date

## Receive a response from us

If you filled in an application, you’ll get a letter from us in the mail. It will tell you one of these things:

* A decision on your application
* If we need more information from you

### If you get a decision letter

#### Your letter with a decision will include

* The amount you will receive each month
* The date of your first payment
* Any past payments that may be owed to you

## Check your application status

Use one of the following methods to check your application status:

* [Sign in to your MSCA](/en/employment-social-development/services/my-account.html)
  + Select "Manage my benefits" link from the Old Age Security section
* [Call Service Canada](/en/employment-social-development/corporate/contact/oas.html#details-panel2)

### Document navigation

* [Previous: How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html)[Previous: How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html#wb-cont)
* [Next: While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html)[Next: While receiving OAS](/en/services/benefits/publicpensions/old-age-security/while-receiving.html#wb-cont)

## Page details

Date modified:
:   2025-08-22

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
