---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp.html
scraped_at: 2025-08-24 12:52:12
filename: en/services/benefits/publicpensions/cpp_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)

# Canada Pension Plan retirement pension

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

## Description of Canada Pension Plan retirement pension

The Canada Pension Plan (CPP) retirement pension is a monthly, taxable benefit that replaces part of your income when you retire. If you qualify, you’ll receive the CPP retirement pension for the rest of your life.

## Sections

[**Do you qualify**](/en/services/benefits/publicpensions/cpp/eligibility.html)
:   Eligibility for CPP is determined by your contributions to the plan and your age. Consult the eligibility criteria for CPP.

[**When to start your retirement pension**](/en/services/benefits/publicpensions/cpp/when-start.html)
:   When should you start receiving your pension and are there advantages to waiting.

[**How much you could receive**](/en/services/benefits/publicpensions/cpp/amount.html)
:   How we calculate your CPP retirement pension and situations that affect the amount.

[**Apply**](/en/services/benefits/publicpensions/cpp/apply.html)
:   You may have to apply. Find out how to apply.

[**After you apply**](/en/services/benefits/publicpensions/cpp/after-apply.html)
:   How and when you will receive payments, tax information, and how to cancel a CPP retirement pension.

![](/content/dam/canada/employment-social-development/services/pension/cpp/sack-dollar-solid.png)

##### Payment amounts

Maximum CPP pension at age 65 (January 2025): **$1,433.00/month**

Average CPP pension at age 65 (October 2024): **$899.67/month**

[**CPP pensions and benefits monthly amounts**](/en/services/benefits/publicpensions/cpp/payment-amounts.html)

![](/content/dam/canada/employment-social-development/services/pension/cpp/calendar-solid.png)

##### Next payment date

August 27, 2025

[**Payment dates**](/en/services/benefits/calendar.html)

## Explore top tasks

If you’re already familiar with CPP, explore these quick links to help you take action now:

### Top tasks for CPP

* [Statement of Contributions](/en/services/benefits/publicpensions/cpp/statement-contributions.html): access your CPP statement of Contributions to see your contribution history
* [Apply online (MSCA)](/en/employment-social-development/services/my-account.html): register or sign in to My Service Canada Account (MSCA) to apply online
* [Apply with a paper form](/en/services/benefits/publicpensions/cpp/apply.html#h2.2): find what you need to download and submit a paper application form
* [Check your application status](/en/services/benefits/publicpensions/cpp/apply.html#h2.5): track the status of your CPP application
* [Change your personal information](/en/employment-social-development/services/my-account/personal-information.html): update your personal details like your address and banking information
* [Taxes](/en/services/benefits/publicpensions/cpp/after-apply.html#h2.2): find out how to deduct federal taxes from your CPP and access your tax slips
* [Disagree with a decision](/en/services/benefits/publicpensions/cpp/after-apply.html#h2.3): request a review or submit an appeal with the Social Security Tribunal of Canada

## Contact us

If you have general questions about the Canada pension retirement plan or specific questions about your application, [contact us](/en/employment-social-development/corporate/contact/cpp.html).

## Related links

If you’re applying for CPP, check if you’re eligible for these other pensions and benefits:

### Other pensions and benefits

#### [Old Age Security (OAS) pension](/en/services/benefits/publicpensions/old-age-security.html)

Apply for OAS if you are 65 and older even if you have never worked or are still working.

#### [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html)

Apply for this benefit if you are an Old Age Security recipient with low income.

#### [CPP Post-Retirement Benefit (PRB)](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)

If you're under 70 and working while receiving your CPP, you can still contribute to increase your pension.

#### [CPP Post-Retirement Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit.html)

Apply if you are under 65, receiving a CPP retirement pension, and now have a severe and prolonged disability.

#### [Guaranteed Income Supplement – Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html)

Canada Pension Plan, Old Age Security, Guaranteed Income Supplement, Retirement planning.

#### [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

Apply for a monthly benefit if you are low-income, widowed, age 60 to 64 and not yet eligible for OAS.

#### [Receive public pensions outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html)

Receiving OAS and CPP pensions and benefits, if living outside Canada.

Find Survivor and CPP disability benefits:

### Survivor and CPP disability benefits

#### [CPP survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)

Apply for a monthly payment paid to the legal spouse or common-law partner of a deceased CPP contributor.

#### [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)

Apply for a one-time payment on behalf of a deceased CPP contributor.

### [What to do when someone dies](/en/services/death.html)

What to do following the loss of a loved one. Documents you need, who to notify, how to cancel benefits and avoid overpayment.

#### [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

Apply for a monthly benefit if you are low-income, widowed, age 60 to 64 and not yet eligible for OAS.

#### [CPP children’s benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

Apply for a monthly benefit for a dependent child of a deceased CPP contributor.

#### [CPP disability benefits](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

Apply if you are unable to work due to a severe and prolonged disability.

#### [CPP Post-Retirement Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit.html)

Apply if you are under 65, receiving a CPP retirement pension, and now have a severe and prolonged disability.

## Page details

Date modified:
:   2025-08-13

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
