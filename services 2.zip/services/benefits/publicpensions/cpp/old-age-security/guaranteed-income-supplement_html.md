---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/old-age-security/guaranteed-income-supplement.html
scraped_at: 2025-08-24 18:25:51
filename: en/services/benefits/publicpensions/cpp/old-age-security/guaranteed-income-supplement_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/securite-vieillesse/supplement-revenu-garanti.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html)

# Guaranteed Income Supplement

* ## System maintenance: Online services

  All online services will be closed for maintenance from 6 am August 23 to 12 pm (ET) August 23, 2025.
* ## Get timely benefit payments: Sign up for Direct Deposit today!

  [Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.
* ## File your taxes to continue receiving your GIS payments

  If you haven’t filed your 2024 taxes with the CRA, your Guaranteed Income Supplement (GIS) payments may stop or be reduced.

  To avoid interruptions, [file your taxes](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes.html) as soon as possible.

  You can also report your income directly to us to renew or confirm your eligibility.

  If you have questions or concerns about your GIS payments, [contact us](/en/employment-social-development/corporate/contact/oas.html).

## Description of the Guaranteed Income Supplement

The Guaranteed Income Supplement (GIS) is a **monthly payment** you can get if you are **65 or older.**

The Supplement is based on income and is available to Old Age Security pensioners with low income. It is not taxable.

In many cases, we will let you know by letter when you could start receiving the first payment. We will send you this letter the month after you turn 64. In other cases, you may have to apply.

## You may have to apply for the Guaranteed Income Supplement if

* We do not have enough information to enroll you automatically
* You are already receiving your Old Age Security pension and never applied for the Guaranteed Income Supplement

## Sections

[Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html)
:   Guaranteed Income Supplement eligibility is based on income and is available to low-income Old Age Security pensioners. Consult the detailed eligibility criteria, including benefits for spouses and common-law partners.

[How much you could receive](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/benefit-amount.html)
:   Estimate how much money you could get from Guaranteed Income Supplement.

[Your application](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/apply.html)
:   You may have to apply. Consult detailed information on how to apply.

[While receiving GIS](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/while-receiving.html)
:   Guaranteed Income Supplement payments are added to Old Age Security pension payments each month. Find out what you need to know while receiving Guaranteed Income Supplement.

## Contact us

If you have general questions about the Guaranteed Income Supplement or specific questions about your application, [contact us](/en/employment-social-development/corporate/contact/oas.html).

## Document navigation

* [Next : Do you qualify](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/eligibility.html)

## Page details

Date modified:
:   2025-08-22

## About this site

### Old Age Security (OAS) pension

* [Contact us](/en/employment-social-development/corporate/contact/oas.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
