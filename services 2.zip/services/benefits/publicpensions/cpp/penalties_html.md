---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/penalties.html
scraped_at: 2025-08-24 16:25:11
filename: en/services/benefits/publicpensions/cpp/penalties_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/penalites.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Penalties, Interest, and Disclosure Policy

## *Canada Pension Plan* (CPP) and *Old Age Security Act* (OAS) Administrative Penalties, Interest, and Disclosure Policy

Administrative penalities under the *Canada Pension Plan* and the *Old Age Security Act* came into force on April 1, 2010. The penalty provision imposes financial sanctions in cases of misrepresentation. A misrepresentation is made when an applicant, beneficiary or third party knowingly provides false or misleading information, or omits information. The interest provision imposes interest on penalties and on overpayments that are subject to a penalty.

Service Canada’s disclosure policy allows individuals to come forward and correct inaccurate or incomplete information or to disclose information they did not divulge during previous dealings with Service Canada. A valid disclosure must be voluntary, complete and accurate, and must be given before an investigation has been started by Service Canada. Making a disclosure may exempt an individual from penalty or from having the case referred by the Minister to the RCMP for investigation and potential prosecution.

Individuals who would like to disclose a misrepresentation should contact the CPP/OAS information line 1-800-277-9914 or (TTY: 1-800-255-4786), or go in person at a [Service Canada Centre](http://www.servicecanada.gc.ca/cgi-bin/hr-search.cgi?app=hme&ln=eng), for help to begin the process.

## Guides and help

* [Getting Retirement Ready](http://www.fcac-acfc.gc.ca/Eng/forConsumers/lifeEvents/planningRetirement/Pages/home-accueil.aspx)
* [Retirement Planning](http://www.fcac-acfc.gc.ca/Eng/forConsumers/lifeEvents/planningRetirement/Pages/home-accueil.aspx)

## Related services and info

* [Old Age Security payment amounts](/en/services/benefits/publicpensions/old-age-security/payments.html)
* [Payment calendar](/en/services/benefits/calendar.html)
* [My Service Canada Acccount](http://www.servicecanada.gc.ca/eng/online/cpp_info_msca.shtml)
* [Canadian retirement income calculator](http://www.servicecanada.gc.ca/eng/services/pensions/cric.shtml)

## Page details

Date modified:
:   2025-01-22

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
