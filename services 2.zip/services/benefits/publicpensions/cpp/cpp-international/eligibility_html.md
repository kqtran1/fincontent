---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html
scraped_at: 2025-08-24 15:40:52
filename: en/services/benefits/publicpensions/cpp/cpp-international/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-internationales/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [Lived or living outside Canada - Pensions and benefits - Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html)

# Lived or living outside Canada- Pension and benefits - Eligibility

# Lived or living outside Canada - Pensions and benefits

* [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html) [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html#gc-document-nav)
* [Eligibility](#gc-document-nav)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html#gc-document-nav)
* [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html) [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/issa.html) [Contact us](/en/employment-social-development/corporate/contact/issa.html#gc-document-nav)

# Eligibility

## How can a social security agreement help me qualify for benefits?

A social security agreement can help you qualify for benefits by allowing you to combine your periods of contribution or periods of residency in Canada with your periods of contribution or periods of residency in the other country to meet the minimum eligibility criteria. It can also reduce or eliminate restrictions based on citizenship or on payment of pensions abroad.

### Note: Possible eligibility for more than one benefit

You may be eligible for a foreign pension, a Canadian pension, or both.

### Canadian benefits

If you have lived and/or worked in Canada and in another country, and do not meet the contributory

or residence requirement for a Canada Pension Plan or Old Age Security benefit, a social security agreement may help you qualify. It might also provide benefits to your surviving spouse, common law partner or children.

The Canadian benefits included in Canada’s international social security agreements are those paid under the [Old Age Security program](/en/services/benefits/publicpensions/old-age-security.html) and the [Canada Pension Plan program](/en/services/benefits/publicpensions/cpp.html).

A social security agreement may help you qualify for a Canadian or foreign benefit, or both, if you **lived or worked abroad and in Canada**.

#### To help you qualify for a Canadian pension or benefit:

* your periods of contribution under the legislation of another country may be considered as periods of contribution to the [Canada Pension Plan](/en/services/benefits/publicpensions/cpp.html) (CPP).
* your periods of residency and contribution under the legislation of another country, also known as creditable periods, may be considered as periods of residency in Canada for the [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html) (OAS) program depending on the agreement.

##### Example 1

Thomas, 65, lived in Austria for much of his life. He lived in Canada for 16 years after the age of 18. This year, he moved back to Austria to be nearer his aging parents. Normally 20 years of residence in Canada is needed to receive an OAS pension outside Canada, so Thomas would normally **not have qualified**. However, the social security agreement with Austria allows him to count the time he lived in Austria after age 18 towards meeting the 20 -year residence-in-Canada requirement. Thomas **will** receive a partial OAS pension outside Canada for the rest of his life.

Note that while the social security agreement helped qualify Thomas to receive an OAS pension, the payment amount is determined by the numbers of years of residence in Canada after age 18. Having lived in Canada for 16 years, Thomas will receive 16/40ths of the full OAS pension.

##### Example 2

Liam was born in Ireland and worked there for 20 years before moving to Canada at the age of 40. Liam worked in Canada and contributed to the CPP for 5 years prior to his death at age 46. For Liam’s spouse and child to be eligible for CPP death and survivor benefits, Liam needed to have contributed to the CPP for 10 years. (You have to contribute to the CPP for at least one-third of all the years of your “[contributory period](/en/services/benefits/publicpensions/cpp/contributions.html#used)”.) Because Liam contributed to the CPP for only 5 years, his survivors would normally **not be entitled** to death or survivor benefits. However, the social security agreement with Ireland allows his periods of contribution to the Irish pension program to be considered as periods of contribution to the CPP in order to satisfy the minimum qualifying period of 10 years. Since Liam’s spouse and child meet the age requirements, they **will be entitled** to CPP death and survivor benefits.

Note that, while the social security agreement helped Liam’s spouse and child to qualify for CPP benefits, the payment amounts will be based on the actual contributions Liam made to the CPP.

### Foreign benefits

The foreign benefits covered by Canada’s international social security agreements vary from agreement to agreement. It is important to check the details of the agreement that relates to you.

#### To help you qualify for a foreign pension or benefit:

* your periods of contribution to the Canada Pension Plan or periods of residence in Canada may be considered as periods of contribution or residence under a foreign social security program.

##### Example 3

Christine, from Winnipeg, lived in Canada until she was 30 when she accepted a job at an international engineering firm in Barbados. She worked there for 7 years and then decided to return to Canada. Because she did not contribute to the Barbadian social security scheme for the minimum period of time, she would normally **not qualify** for a Barbadian retirement pension. So her contributions to the Barbadian pension plan would have been lost. However, Canada’s social security agreement with Barbados allows her to combine her periods of contribution to the Canada Pension Plan with her periods of contribution to the Barbadian social security scheme in order to meet the minimum requirement. Later, when she is ready to apply for her Barbadian pension, it will be based on those 7 years of contributions to the Barbadian social security scheme.

(And, when she is ready to apply for her Canada Pension Plan retirement pension, it will be based on her years of contributions to the CPP. Her Canadian Old Age Security pension will be based on her years of residence in Canada after the age of 18.)

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

## Document navigation

* [Previous - Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html)
* [Next - How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html)

## Page details

Date modified:
:   2025-06-10

## About this site

### Contact International Social Security Agreements

* [Contact us](/en/employment-social-development/corporate/contact/issa.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
