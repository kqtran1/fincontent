---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html
scraped_at: 2025-08-24 19:35:39
filename: en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-internationales/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [Lived or living outside Canada - Pensions and benefits - Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html)

# Lived or living outside Canada - Pensions and benefits – How much could you receive

# Lived or living outside Canada - Pensions and benefits

* [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html) [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html#gc-document-nav)
* [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html) [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html#gc-document-nav)
* [How much could you receive](#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html#gc-document-nav)
* [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html) [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/issa.html) [Contact us](/en/employment-social-development/corporate/contact/issa.html#gc-document-nav)

# How much could you receive

## Receiving payment of Old Age Security and Canada Pension Plan pensions and benefits outside Canada

Receiving your Old Age Security (OAS) and Canada Pension Plan (CPP) payments in the local currency can save you money.

Because your payments will have already been converted into the local currency of the country where you live, you should get a better [exchange rate](https://www.bankofcanada.ca/rates/exchange/), and you might also pay lower banking fees for cashing your cheques.

To receive your payments directly in your local bank account, see if you live in a [country that offers the service of direct deposit](http://www.tpsgc-pwgsc.gc.ca/recgen/dd/etranger-abroad-eng.html).

### Note: Payment dates

Your OAS or CPP payments will be issued on the same day as the OAS and CPP payments are issued in Canada, which is usually during the last three banking days of the month. See our page [Old Age Security and Canada Pension Plan Payment Dates](/en/services/benefits/calendar.html).

### How can I receive my payments in the local currency?

Check the [list of countries where direct deposit is offered](http://www.tpsgc-pwgsc.gc.ca/recgen/dd/etranger-abroad-eng.html) to see in which countries the Receiver General of Canada can issue payments by [Direct Deposit](http://www.servicecanada.gc.ca/eng/sc/direct-deposit/cpp-oas.shtml) in local currency.

Check the list of countries where OAS and CPP payments are made in foreign currency to see in which countries the Receiver General of Canada issue payments by cheque in local currency.

### Countries where Old Age Security and Canada Pension Plan Payments are Made in Foreign Currency

If you live outside Canada, your pension payment cheques are made in local currency in the following countries.

| Country | Official Currency |
| --- | --- |
| Australia | AUD AUSTRALIAN DOLLAR |
| Austria | EUR EURO CURRENCY |
| Belgium | EUR EURO CURRENCY |
| Cyprus | EUR EURO CURRENCY |
| Czech Republic | CZK CZECH KORUNA |
| Denmark | DKK DANISH KRONE |
| Ecuador | USD US DOLLAR |
| Estonia | EUR EURO CURRENCY |
| Fiji | FJD FIJI DOLLAR |
| Finland | EUR EURO CURRENCY |
| France | EUR EURO CURRENCY |
| French Polynesia | XPF CFP FRANC |
| Germany | EUR EURO CURRENCY |
| Greece | EUR EURO CURRENCY |
| Greenland | DKK DANISH KRONE |
| Hong Kong | HKD HONGKONG DOLLAR |
| Groenland | DKK COURONNE DANOISE |
| Hong Kong | HKD DOLLAR DE HONG KONG |
| India | INR INDIAN RUPEE |
| Ireland | EUR EURO CURRENCY |
| Italy | EUR EURO CURRENCY |
| Japan | JPY JAPANESE YEN |
| Kuwait | KWD KUWAITI DINAR |
| Luxembourg | EUR EURO CURRENCY |
| Malta | EUR EURO CURRENCY |
| Micronesia | USD US DOLLAR |
| Morocco | MAD MOROCCO DIRHAM |
| Netherlands | EUR EURO CURRENCY |
| New Caledonia | XPF CFP FRANC |
| New Zealand | NZD NEW ZEALAND DOLLAR |
| Norway | NOK NORWEGIAN KRONE |
| Oman | OMR OMANI RIAL |
| Pakistan | PKR PAKISTANI RUPEE |
| Panama | USD US DOLLAR |
| Papua New Guinea | PGK PAP NEW G KINA |
| Philippines | PHP PHILIPPINE PESO |
| Portugal | EUR EURO CURRENCY |
| Puerto Rico | USD US DOLLAR |
| Samoa | WST WESTERN SAMOA, TALA |
| Saudi Arabia | SAR SAUDI RIYAL |
| Singapore | SGD SINGAPORE DOLLAR |
| Solomon Islands | SBD SOLOMON ISLANDS DOLLAR |
| South Africa | ZAR S.AFRICAN RAND |
| Spain | EUR EURO CURRENCY |
| Sri Lanka | LKR SRI LANKAN RUPEE |
| Sweden | SEK SWEDISH KRONA |
| Switzerland | CHF SWISS FRANC |
| Thailand | THB THAILAND BAHT |
| United Arab Emirates | AED U.A.E. DIRHAM |
| United Kingdom | GBP POUND STERLING |
| United States | USD US DOLLAR |
| Vanuatu | VUV VANUATU VATU |
| Wallis and Futuna | XPF CFP FRANC |

This list is subject to change depending on the foreign banking arrangements made by the Receiver General of Canada and the Bank of America conversion service.

If you are currently having your benefits delivered to a Canadian address, your payments will continue to be issued in Canadian dollars. To receive your benefits in your local currency, you must [contact International Social Security Agreements](/en/employment-social-development/corporate/contact/issa.html) to change your cheque delivery address to the country where you live.

### Note: Payment in wrong currency

If your payment is in the wrong currency, [contact International Social Security Agreements](/en/employment-social-development/corporate/contact/issa.html) as soon as possible.

### Why is the amount on my cheque different from the amount on my cheque stub?

The amount on the cheque itself is the amount in the local currency that you will receive when you cash the cheque.

The amount on the cheque stub reflects the Canadian dollar value of the OAS or CPP payment before it was [converted into your local currency](https://www.bankofcanada.ca/rates/exchange/). The Canadian dollar amount shown on the stub will appear on the taxation slip you receive for the year.

### Note: The payment amount may fluctuate

Daily currency market fluctuations may cause your cheque amount to differ each month, even though your entitlement amount in Canadian dollars has not changed.

## Document navigation

* [Previous - Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html)
* [Next - What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html)

## Page details

Date modified:
:   2025-06-10

## About this site

### Contact International Social Security Agreements

* [Contact us](/en/employment-social-development/corporate/contact/issa.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
