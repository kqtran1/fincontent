---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html
scraped_at: 2025-08-24 20:08:59
filename: en/services/benefits/publicpensions/cpp/cpp-international/while-receiving_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-internationales/pendant-que-vous-recevez.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [Lived or living outside Canada - Pensions and benefits - Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html)

# Lived or living outside Canada – While on pensions and benefits

# Lived or living outside Canada - Pensions and benefits

* [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html) [Overview](/en/services/benefits/publicpensions/cpp/cpp-international.html#gc-document-nav)
* [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html) [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html#gc-document-nav)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html#gc-document-nav)
* [While on pension and benefits](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/issa.html) [Contact us](/en/employment-social-development/corporate/contact/issa.html#gc-document-nav)

# While on pension and benefits

## Receiving Benefits

See [Already receiving a pension or benefits](http://www.servicecanada.gc.ca/eng/services/pensions/receiving.shtml) for information on such things as payment dates and rates, income tax, and when to notify Service Canada.

Non-residents also see [Receiving payment outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html).

### Note: Canadian pensions and benefits are taxable

See [Taxes on pensions and benefits for those outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html).

### If I move, how do I ensure that I receive my future cheques in the correct currency?

OAS and CPP cheques are issued in the currency of the country where your cheques are mailed. Once you [change your address for correspondence](http://www.servicecanada.gc.ca/eng/online/cpp_info_msca.shtml#a3), future payments will automatically be in the currency of your new country if it is a country supported by the Bank of America conversion service and this country appears on the [list of countries where OAS and CPP payments are made in foreign currency](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html). If the country is not on the list, the Receiver General of Canada can only issue your payments in Canadian currency.

### How long will it take before I receive my payments at a new address?

If you are currently living in Canada or in the U.S. and staying in either country but moving to another address, you will normally receive your payments at the new address the month after we have received your request. Moves to all other countries can take up to an additional month to process.

### Contact Us

If you need more information on Canada's international social security agreements, or want to send in your application form, please contact us:

**By mail:**
International Operations Service Canada Ottawa ON K1A 0L4
CANADA

**By phone:**
**1-800-454-8731** (TTY: 1-800-255-4786)
(from Canada and the United States)
**1-613-957-1954**  (from all other countries, collect calls accepted)

**Hours of Operation:**
Our agents are ready to answer your questions
Monday to Friday, 8:30 a.m. to 4:30 p.m. Eastern Time.

Please have your Canadian social insurance number ready.

## Document navigation

* [Previous - Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html)

## Page details

Date modified:
:   2025-06-10

## About this site

### Contact International Social Security Agreements

* [Contact us](/en/employment-social-development/corporate/contact/issa.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
