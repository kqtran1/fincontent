---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cancel-cpp.html
scraped_at: 2025-08-24 19:46:18
filename: en/services/benefits/publicpensions/cpp/cancel-cpp_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-annuler.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Cancel Canada Pension Plan and Old Age Security benefits after a death

## On this page

* [Benefits must be cancelled after a death](#benefits)
* [How to cancel benefits](#cancel)
* [Returning benefit payments](#return)

## Benefits must be cancelled after a death

When an Old Age Security (OAS) and Canada Pension Plan (CPP) beneficiary dies, their benefits must be cancelled. Benefits are payable for the month in which the death occurs; benefits received after that will have to be repaid. This includes the following benefits:

* OAS pension, including:
  + Guaranteed Income Supplement
  + Allowance
  + Allowance for the Survivor
* CPP retirement pension
* CPP disability benefits
* CPP children's benefits
* CPP survivor benefits

## How to cancel benefits

Please notify us of the date of death of the beneficiary as soon as possible.

You can notify Service Canada:

By phone

Make sure you have the person's Social Insurance Number (SIN) on hand when you call.

**Canada and the United States Toll-free:** 1-800-277-9914
**Canada and the United States TTY:** 1-800-255-4786
The hours of operation are 8:30 am to 4:30 pm local time, Monday to Friday.

**Outside Canada and the United States:** 1-613-957-1954 (Call collect)
The hours of operation are 8:30 am to 4:30 pm Eastern time, Monday to Friday.

By mail

Send the following information to your nearest [Service Canada Office](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html).

Information about the deceased beneficiary:

* full name
* date of birth
* date of death
* place of death
* marital status at time of death
* Social Insurance Number (if known)
* address at the time of death

Information about the estate and person reporting the death:

* name and address and phone number of the estate, the person responsible for handling the deceased's affairs, and/or next of kin
* Your name, address, phone number and relationship to the deceased

**Note:** If the deceased was receiving a benefit from the Quebec Pension Plan (QPP), also contact [Retraite Québec](http://www.retraitequebec.gouv.qc.ca/en/Pages/accueil.aspx).

### If we ask you to provide proof of date of death

You do not need to provide proof of date of death unless we request it.

 The following are common documents that will be accepted as proof of the date of death:

* official death certificate issued under the authority of some level of government (domestic or foreign) where the death occurred
* a document issued by a level of domestic or foreign government (federal, provincial, state, territorial, municipal, etc.) indicating the date of death (for example, Japanese Family Register, Portuguese Cédula Pessoal, etc.)
* funeral home burial or death certificate issued:
  + in accordance with the custom of any religious denomination by an ordained religious leader; or
  + by the funeral director; or
  + by any person who is authorized to issue such documents through the funeral home (this may vary from province to province)
* medical certificate of death issued by the attending doctor or coroner
* statement by a doctor last in attendance, a coroner or a funeral director using stationery with the appropriate identifying letterhead
* registration of death under a provincial or territorial authority
* certification of death by social security authorities in another country where an [international agreement](/en/services/benefits/publicpensions/cpp/cpp-international.html) on social security exists with that country
* memorandum of Notification of Death issued by the Chief of National Defence Staff, Department of National Defence Canada, where the death of a member of the Canadian Forces occurs outside Canada
* statement of Verification of Death from the Department of Veterans Affairs Canada written on the letterhead of the Department
* official notification from the Administrator of the Estate appointed by a court
* Letters of Probate
* life or group insurance claim provided it includes a statement signed by a medical doctor
* an official notification written on the letterhead of a Provincial Public Trustee or Administrator of Estates

The Canada Pension Plan program reserves the right to request supporting documents. When documents are requested, copies are acceptable; however, Service Canada may ask for an original or certified copy at any time. To be acceptable as a proof of death, a document must:

* be on official letterhead or contain a seal
* be dated, readable and not altered
* contain the following information:
  + the name of the deceased individual
  + the date and place of death
  + the name and signature of a person authorized to issue the document

Please [contact us](#byPhone) if you need to verify that a document is acceptable as proof of the date of death.

## Returning benefit payments

The estate is entitled to the beneficiary's OAS and CPP payments for the month of death. All payments issued after the month of death must be returned. If the payments have been redeemed, they must be repaid.

### Repayment method for payments received by direct deposit

If the beneficiary received payments by direct deposit, please have the bank return any payments deposited after the date of death to the originator, or send a cheque in Canadian funds made payable to the Receiver General for Canada to the [office responsible](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng) for paying the deceased's OAS and CPP benefits.

### Repayment method for payments received by cheque

If the beneficiary received payments by cheque, please return any cheques received after the month of death to:

* Imaging and Receiver General Operations Directorate
  Returned Cheques
  PO Box 2000
  Matane QC  G4W 4N5

Please make sure to include the name and address of the estate or the person responsible for handling the deceased's affairs (if known).

## Related links

* [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)
* [Retraite Québec](http://www.retraitequebec.gouv.qc.ca/en/Pages/accueil.aspx)
* [Payment calendar](/en/services/benefits/calendar.html)
* [My Service Canada Account](/en/employment-social-development/services/my-account.html)
* [Notify the federal government of a death](/en/services/death.html)

## Contact us

[Contact Employment and Social Development Canada (ESDC)](/en/employment-social-development/corporate/contact.html)

## Page details

Date modified:
:   2025-06-18

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
