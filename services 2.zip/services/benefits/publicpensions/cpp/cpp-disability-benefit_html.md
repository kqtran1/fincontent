---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html
scraped_at: 2025-08-24 14:54:35
filename: en/services/benefits/publicpensions/cpp/cpp-disability-benefit_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/prestation-invalidite-rpc.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canada Pension Plan disability benefits: Overview

# Canada Pension Plan disability benefits

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

The Canada Pension Plan (CPP) disability benefit is a **monthly payment** that you could receive if you are unable to work because of a disability.

## Sections

[Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)
:   Eligibility criteria for CPP disability.

[How much you could receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html)
:   Estimate how much money you could receive from CPP disability.

[Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html)
:   You must apply. Consult detailed information on how to apply.

[After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html)
:   How and when you will receive payments, tax information, and what to do if you disagree with the decision.

[Information for health professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html)
:   Medical Report, billing, return to work, returning to CPP disability benefits.

## Definitions

### Substantially gainful occupation

A substantially gainful occupation is a job that pays wages equal to or greater than the maximum annual amount a person could receive as a disability pension. **In 2025, this amount is $20,153.09** (before tax).

Once you have earned **$7,100** (before tax) in **2025**, you must contact Service Canada. Your disability benefits may be impacted by your gross earnings (before tax).

* If you earn less than **$7,100** (before tax), this should not affect your disability benefits.
* If you earn between **$7,100** and **$20,153.09** (before tax), this may demonstrate that you are regularly capable of working and it may affect your disability benefits.
* If you earn **$20,153.09** or more (before tax), this demonstrates that you are regularly capable of working and you will likely no longer qualify for disability benefits.

You need to advise Service Canada when you reach any of these amounts and you should call when you start working. This does not necessarily mean that your benefits will stop. When reviewing your file, we will consider factors such as hours worked and regularity of work. By contacting us, we can provide you with information about our work-related supports and services.

### Terminal illness

A “terminal illness” is a disease that cannot be cured or adequately treated and is likely to result in death within 6 months.

### Grave condition

A “grave condition” is a rapidly progressive medical condition. A list of grave conditions was developed based on extensive research by ESDC. These medical conditions have a high probability of meeting the CPP disability eligibility criteria.

**Grave conditions include:**

1. Acute Lymphoblastic Leukemia
2. Acute Myeloid Leukemia
3. Adrenocortical Cancer
4. Alzheimer's Disease (early onset, less than age 60)
5. Amyloidosis
6. Amyotrophic Lateral Sclerosis (ALS)
7. Anal Cancer
8. Appendiceal Cancer
9. Bladder Cancer (Metastatic, Stage IV)
10. Brain Cancer
11. Breast Cancer (Metastatic/recurrent)
12. Cervical Carcinoma
13. Chronic Kidney Disease (CKD)
14. Chronic Liver Disease
15. Colorectal Cancer
16. Endometrial Cancer
17. Esophagus Cancer
18. Follicular Lymphoma
19. Frontotemporal Dementia (FTD)
20. Gallbladder Cancer
21. Huntington Disease
22. Idiopathic Pulmonary Fibrosis (IPF)
23. Kidney Cancer
24. Liver Cancer
25. Lung Cancer
26. Malignant Melanoma
27. Malignant Tumours of Small Intestine
28. Multiple Myeloma
29. Muscular Dystrophy (Adult onset)
30. Ovarian Cancer
31. Pancreatic Cancer
32. Parkinson's Disease
33. Post-inflammatory Pulmonary Fibrosis
34. Primary Cerebellar Degeneration
35. Progressive Polyneuropathy
36. Quadriplegia and Quadriparesis
37. Schizophrenia
38. Stomach Cancer
39. Thymus Cancer
40. Uterine Sarcoma
41. Vascular Dementia

## Contact us

If you have general questions about the disability benefits or specific questions about your application, [contact us](/en/employment-social-development/corporate/contact/cpp.html).

## Other disability resources

* [Canada Pension Plan disability benefit toolkit](/en/employment-social-development/programs/pension-plan-disability-benefits/reports/toolkit.html)
* [Other resources for people with disabilities](/en/services/benefits/disability.html)

## Document navigation

* [Next - Eligibility](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)

## Page details

Date modified:
:   2025-07-15

## About this site

### Canada Pension Plan Disability benefits (CPPD)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
