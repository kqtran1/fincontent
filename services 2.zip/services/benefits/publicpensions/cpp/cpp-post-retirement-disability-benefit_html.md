---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit.html
scraped_at: 2025-08-24 13:03:42
filename: en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-prestation-invalidite-apres-retraite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canada Pension Plan Post-Retirement Disability Benefit

# Canada Pension Plan Post-Retirement Disability Benefit

**From: [Employment and Social Development Canada](/en/employment-social-development.html)**

## Step 1 What the Post-Retirement Disability Benefit offers

The Post-Retirement Disability Benefit is a new benefit that is available as of January 1, 2019. It is intended for Canada Pension Plan (CPP) retirement pension beneficiaries found to be disabled but not eligible for a disability pension due to being CPP retirement pension beneficiaries for more than 15 months. Applicants who have made sufficient contributions may be eligible for this benefit in addition to their retirement pension.

## Step 2 Eligibility

The eligibility criteria are the same as for the Canada Pension Plan disability pension. You must:

1. be under the age of 65
2. have a severe and prolonged mental or physical medical condition, according to the definition in the Canada Pension Plan legislation
3. meet the minimum contributory requirements

To meet the minimum contributory requirements, you must:

* have made valid contributions to the CPP in 4 of the last 6 years
* have contributed for at least 25 years, including 3 of the last 6 years
* meet the requirements for the late applicant provision

If you apply for CPP disability benefits but are not eligible because you have received the CPP retirement pension for more than 15 months, we will automatically consider your eligibility for the post-retirement disability benefit.

## Step 3 How to apply

There is no separate application for this benefit. You will have to complete a [CPP disability benefits application](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html).

## Step 4 How much you could receive

The amount of the Post-Retirement Disability Benefit is the flat rate component of the disability pension. For the current year the amount is $598.49 (2025).

This amount will be paid until age 65, at which point the PRDB payment stops and the person continues to receive the retirement pension.

## Step 5 How does the Post-Retirement Disability Benefit interact with your other benefits

The Post-Retirement Disability Benefit is paid in addition to the CPP retirement pension you are receiving, until the age of 65.

If you have any dependent children, a [disabled contributor's child benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) is payable.

CPP benefits may affect the income you receive from other programs. Some income-tested benefits take your CPP income into account, such as the War Veterans Allowance, Employment Insurance, the Guaranteed Income Supplement, the Allowance and the Allowance for the Survivor, as well as provincial and territorial social assistance ("welfare") and disability benefits and most workers' compensation programs. CPP benefits may also affect how much you get from your employer pension or private-sector disability insurance.

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

## Page details

Date modified:
:   2025-05-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
