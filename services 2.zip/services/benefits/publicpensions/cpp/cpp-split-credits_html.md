---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-split-credits.html
scraped_at: 2025-08-24 16:13:44
filename: en/services/benefits/publicpensions/cpp/cpp-split-credits_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-partage-credits.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Divorced or separated: Splitting Canada Pension Plan credits

# Divorced or separated: Splitting Canada Pension Plan credits

The [Canada Pension Plan (CPP) contributions](/en/services/benefits/publicpensions/cpp/contributions.html) you and your spouse or common-law partner made during the time you lived together can be equally divided after a divorce or separation. This is called credit splitting.

Credits can be divided even if 1 spouse or common-law partner did not make contributions to the CPP. Credit splitting may help you qualify for benefits and can affect the amount of any current or future benefits under the [CPP program](/en/services/benefits/publicpensions/cpp.html) for both you and your former spouse or common-law partner. **The division of these credits is permanent**.

## On this page

* [Do you qualify](#h2.1)
* [How much you could receive](#h2.2)
* [When to apply](#h2.3)
* [Who should complete the application](#h2.4)
* [Apply](#h2.5)
* [After you apply](#h2.6)

## Step 1 Do you qualify

Eligibility for CPP credit splitting varies depending on when you divorced or separated, and whether you were married or living in a common-law relationship. You are **not permitted** to credit split when:

1. the total pensionable earnings of the spouses, former spouses or former common-law partners, in a year, was not more than twice [the Year’s Basic Exemption](/en/services/benefits/publicpensions/cpp/statement-contributions.html)
2. the period of time is before 1 of the spouses, former spouses, or former common-law partners reached age 18
3. the period of time is after a spouse, former spouse or former common-law partner reached age 70
4. the period of time that 1 of the spouses, former spouses, or former common-law partners was a beneficiary of a retirement pension under the CPP or Quebec Pension Plan (QPP), or
5. the period of time that 1 of the spouses, former spouses, or former common-law partners was considered to be disabled for the purpose of the CPP or QPP disability benefit

### The following are basic eligibility factors relating to credit splitting:

**If your marriage ended in divorce or annulment**

If your marriage ended in divorce or annulment **on or after January 1, 1987**, you may qualify for a credit split if:

* you lived with your former spouse for at least 12 consecutive months, and
* you or your former spouse notifies Service Canada and provides the necessary information (there is no time limit)

**Note: Spousal agreement**

Generally, a spousal agreement does not prevent a credit split. However, the following agreements can prevent a credit split:

* spousal agreements entered into before June 4, 1986
* spousal agreements in Quebec, Saskatchewan, British Columbia and Alberta that have a provincial law allowing couples to agree not to split CPP pension credits

If your marriage ended in divorce or annulment **between January 1, 1978 and December 31, 1986**, you may qualify for a credit split if:

* you lived with your spouse for at least 36 consecutive months
* the divorce or annulment was recognized by Canadian law, and
* you or your former spouse applied in writing and sent us the necessary documents within 36 months after your marriage ended

If your marriage ended in divorce or annulment **before January 1, 1978,** you do not qualify for a credit split. The Canada Pension Plan credit split did not exist before January 1, 1978.

**Note: Late application**

If you did not apply within 36 months after the end of your marriage, your pension credits can be divided only if your former spouse is still alive and agrees in writing to waive the 36-month time limit.

**If you are separated**

If you are still married and your separation occurred **on or after January 1, 1987**, you may qualify for a credit split if:

* you lived with your spouse for at least 12 consecutive months
* you have been living apart for at least 12 consecutive months, and
* you or your spouse applies in writing and sends us the necessary documents

**Note: Deadline to apply**

There is no time limit to apply, **unless your spouse dies**, in which case you must apply within 36 months of the date of death.

**If your common-law union ended**

If your common-law union ended **on or after January 1, 1987**, you may qualify for a credit split if:

* you lived with your former common-law partner for at least 12 consecutive months
* you have been living apart for at least 12 consecutive months (except in the case where your former common-law partner died during this period, in which case you may still qualify), and
* you or your former common-law partner applies in writing and sends us the necessary documents **within 48 months of the date you began living apart** (unless your former common-law spouse is still alive and agrees in writing to waive the 48-month time limit)

**Note: Common-law unions**

Common-law unions were not recognized for the purposes of credit splitting prior to January 1, 1987.

**If you worked or lived in Quebec**

If you and your spouse or common-law partner have contributed **only** to the Quebec Pension Plan (in other words, neither you, nor your spouse, has ever worked outside Quebec), contact [Retraite Québec](https://www.rrq.gouv.qc.ca/en/retraite/retraite_a_deux/rupture/Pages/partage_gains.aspx) to find out about the eligibility rules under the QPP.

If you or your spouse or common-law partner worked in **both** Quebec and other provinces over the years and therefore paid into **both** plans, credit splitting will be more complex. Both laws must be checked to see if credits can be split in your case and to establish the period of the split.

* If you are living in a province or territory other than Quebec and have contributed to both the CPP and QPP, [contact the Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html) for advice
* If you are living in Quebec and you want to request a credit split, contact [Retraite Québec](https://www.retraitequebec.gouv.qc.ca/en/nous-joindre/Pages/nous-joindre.aspx), which administers the QPP

## Step 2 How much you could receive

The impact of a credit split can vary considerably, depending on your circumstances. In some cases, a credit split can have a major impact on future CPP benefit amounts.

In other cases, the impact of a credit split may be small. For instance, there are features of the CPP that protect your benefits from being reduced if you have some low earning years. These features are called the [general drop-out provision](/en/services/benefits/publicpensions/cpp/eligibility.html#a1) and the [child-rearing provision](/en/services/benefits/publicpensions/cpp/child-rearing.html). If the time that you and your spouse or common-law partner cohabited overlaps with 1 of your "drop-out" periods, then there may be very little impact from the credit split. But the "drop-out" period would still work to your advantage.

### Example

Maria and John started living together in 1985 when she was 24 and he was 22. John was working a construction job that was paying him a good salary. Maria was working in a day care centre.

They were married in 1987. A year after they were married, Maria decided to go back to school to study nursing. She graduated in 1992 and began working in the local children's hospital.

In 1993, John lost his job and was out of work for almost 3 years. He found work in 1996 but by then the marriage was not working, and Maria and John decided to separate.

Following their separation in 1997, John contacted the CPP to apply for a division of pension credits for the time he and Maria lived together. Their earnings from 1985 to 1996 were added together and divided equally between them, as illustrated in Tables 1 and 2 below.

Table 1 shows John's and Maria's records of earnings during the time they lived together. Table 2 shows their earnings after their CPP pension credits were split between them. The last calendar year a couple is together is always excluded from the division.

This "credit split" is a permanent change to both John and Maria's records of earnings. The amount of any CPP benefit that either of them may be eligible for in the future will be based on the revised earnings in Table 2.

**Table 1: John and Maria's records of earnings before the credits were divided**

| Year | John's earnings | Maria's earnings | Years eligible for credit splitting |
| --- | --- | --- | --- |
| 1982 | $16,500 | $14,000 | No |
| 1983 | $18,500 | $14,000 | No |
| 1984 | $20,800 | $14,000 | No |
| 1985 | $23,400\* | $14,200 | Yes |
| 1986 | $25,800\* | $14,600 | Yes |
| 1987 | $25,900\* | $14,700 | Yes |
| 1988 | $26,500\* | $9,600 | Yes |
| 1989 | $27,700\* | $0 | Yes |
| 1990 | $28,900\* | $0 | Yes |
| 1991 | $30,500\* | $0 | Yes |
| 1992 | $32,200\* | $23,500 | Yes |
| 1993 | $22,500 | $33,400\* | Yes |
| 1994 | $0 | $34,400\* | Yes |
| 1995 | $0 | $34,900\* | Yes |
| 1996 | $18,300 | $35,400\* | Yes |
| 1997 | $22,500 | $35,800 | No |
| 1998 | $22,900 | $36,300 | No |
| 1999 | $23,500 | $36,800 | No |

\* Maximum earnings for the year.

**Table 2: John and Maria's records of earnings after the credits were divided**

| Year | John's earnings | Maria's earnings | Years eligible for credit splitting |
| --- | --- | --- | --- |
| 1982 | $16,500 | $14,000 | No |
| 1983 | $18,500 | $14,000 | No |
| 1984 | $20,800 | $14,000 | No |
| 1985 | $18,800 | $18,800 | Yes |
| 1986 | $20,200 | $20,200 | Yes |
| 1987 | $20,300 | $20,300 | Yes |
| 1988 | $18,050 | $18,050 | Yes |
| 1989 | $13,850 | $13,850 | Yes |
| 1990 | $14,450 | $14,450 | Yes |
| 1991 | $15,250 | $15,250 | Yes |
| 1992 | $27,850 | $27,850 | Yes |
| 1993 | $27,950 | $27,950 | Yes |
| 1994 | $17,200 | $17,200 | Yes |
| 1995 | $17,450 | $17,450 | Yes |
| 1996 | $26,850 | $26,850 | Yes |
| 1997 | $22,500 | $35,800 | No |
| 1998 | $22,900 | $36,300 | No |
| 1999 | $23,500 | $36,800 | No |

**Case study summary: Credit splitting**

* 1985 – Maria and John begin living together
* 1987 – Maria and John marry
* 1988 – Maria left work to go to university
* 1992 – Maria goes back to work
* 1993 – John loses his job
* 1996 – John goes back to work
* 1997 – Maria and John separate
* 1998 – CPP pension credits earned during their years together are added and divided equally between both Maria and John

## Step 3 When to apply

The division of the CPP credits that you or your spouse or common-law partner accumulated during the time you lived together can only take place after a divorce, legal annulment, separation from a legal marriage or common-law union.

You should apply for a credit split and submit the required documentation as soon as possible.

## Step 4 Who should complete the application

Either you or your former spouse or common-law partner can request the CPP credit split. A representative (such as a lawyer) may act on a client’s behalf in person, by mail or by phone, but not online. In the case of a separation, the signature of 1 of the spouses or common-law partners is required.

### Former spouses or common-law partners

The information you give us (for example, the length of time you lived together) affects the credit split. That information will therefore be provided to your former spouse or common-law partner. Both you and your former spouse or common-law partner have the right to challenge the information and to appeal any decision about a division of credits.

You are **not eligible** to receive a survivor’s pension if:

* you are a separated legal spouse who had a CPP credit split received and approved in January 2025 or later, with the same deceased contributor

However, you **may still be eligible** for the survivor’s pension if:

* you reunited with your separated legal spouse, **and**
* lived together for a period of 12 months or more immediately before their death

**Applying for credit splitting if you have remarried or are living in a new common-law relationship**

You can still ask for CPP credits to be split with your former spouse or common-law partner, even if you have remarried or are living in a new common-law relationship.

## Step 5 Apply

The Canada Pension Plan program reserves the right to request supporting documents. When documents are requested, copies are acceptable; however, Service Canada may ask for an original or [certified copy](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1730CPP) at any time.

### Apply online

To apply for your benefit online:

* [sign in to your MSCA](/en/employment-social-development/services/my-account.html) and complete the online CPP Credit Split form, and
* mail copies of the required documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

### Apply using a paper application

To apply for your benefit using a paper application:

* complete the [CPP Credit Split form (ISP1901)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1901)
* include copies of required documents
* [mail](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) the form and documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng), and
* indicate your Social Insurance Number on all documents before sending them to Service Canada

## Step 6 After you apply

Once we receive your application and supporting documents, we will review your application and contact you if we need more information. We will send you and your spouse, former spouse or former common-law partner a decision letter once we have completed our review.

### If you disagree with a decision

You may [request a reconsideration](/en/services/benefits/publicpensions/cpp/after-apply.html#disagree) of any decision that affects your eligibility or the amount of your Canada Pension Plan benefit.

## Related links

* [Canada Pension Plan retirement- What will you get](/en/services/benefits/publicpensions/cpp/amount.html)
* [Apply for an OAS pension](/en/services/benefits/publicpensions/old-age-security/apply.html)
* [Canada Retirement Income Calculator](/en/services/benefits/publicpensions/cpp/retirement-income-calculator.html)
* [My Service Canada Account](/en/employment-social-development/services/my-account.html)
* [Apply for direct deposit](/en/employment-social-development/programs/direct-deposit.html)
* [Update your personal information](/en/employment-social-development/services/my-account.html)

### From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

## Page details

Date modified:
:   2025-06-18

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
