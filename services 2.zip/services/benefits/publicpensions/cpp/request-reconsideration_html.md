---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/request-reconsideration.html
scraped_at: 2025-08-24 14:01:00
filename: en/services/benefits/publicpensions/cpp/request-reconsideration_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/demande-reexamen.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# CPP retirement pension - Request a reconsideration

If you disagree with a decision about your application, you can ask Service Canada to reconsider. A Service Canada employee who did not make the original decision will review your application.

**You must request this reconsideration within 90 days of receiving your decision letter.**

Use this process to request a reconsideration for any of the following:

 **List of CPP pensions, benefits, and provisions**

* [CPP retirement pension](/en/services/benefits/publicpensions/cpp.html)
* [CPP Post-Retirement Benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)
* [CPP Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)
* [CPP Survivor's Pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)
* [CPP Children's Benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)
* [Credit-splitting provision](/en/services/benefits/publicpensions/cpp/cpp-split-credits.html)
* [Pension-sharing provision](/en/services/benefits/publicpensions/cpp/share-cpp.html)

## Step 1 Submit a request for reconsideration of a decision

There are 3 ways you can make your request for reconsideration:

 **Online**

Submit your request online using My Service Canada Account (MSCA)

* [Sign in to My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)
  + Click on the “Request a review of a decision” link from the Canada Pension Plan section, then select “Ask Service Canada to reconsider” under “Step 1”

 **Printable form**

Complete and submit the [Request for Reconsideration of a Canada Pension Plan Decision (ISP-1238)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1238).

**If you complete your request on paper**

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

 **Writing**

Prepare and submit a written request to review the decision and include:

* your name
* your address
* your telephone number
* your Social Insurance Number or Client Identification Number
* a detailed explanation of why you do not agree with the decision
* any new information that could affect the decision
* your signature and the date

**If you complete your request on paper**

Sign and date your written request and submit it:

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

Reconsiderations can take several months to complete, depending on the case. Service Canada will review your application and any new information you submit in support of your request and send you a **new decision** by mail.

## Step 2 Submit an appeal to the Social Security Tribunal of Canada

**If you disagree with the new decision**, you can contact the [Social Security Tribunal (SST).](https://www.sst-tss.gc.ca/en)

The SST is an independent administrative tribunal. It is separate from Service Canada.

There are 2 ways to start an appeal with the SST:

 **Social Security Tribunal website**

Complete and submit the form: [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf)

 **My Service Canada Account (MSCA)**

Start the appeal process online in My Service Canada Account (MSCA)

* [Sign in to My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)
  + Select “Request a review of a decision” link from the Canada Pension Plan section, then select “Appeal to the Social Security Tribunal” under “Step 2”

### Appointing a representative

If you plan to have another individual represent you in your appeal, you must provide details about your representative to the [Social Security Tribunal](https://www.sst-tss.gc.ca/en). You will need to either:

* **Complete a form**

  To appoint a representative complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf)
* **Call the Social Security Tribunal**

  [Call the Social Security Tribunal](https://www.sst-tss.gc.ca/en/contact-us/ways-contact-social-security-tribunal) and provide your representative’s information.

If you would like your representative to also be an authorized person to communicate with Service Canada:

* you must also complete the [Consent to Communicate Information to an Authorized Person form](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ISP-1603.pdf).

You must contact Service Canada to change or cancel your authorized representative.

## Page details

Date modified:
:   2025-08-13

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
