---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/eligibility.html
scraped_at: 2025-08-24 18:07:35
filename: en/services/benefits/publicpensions/cpp/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# CPP retirement pension

* [Do you qualify](#gc-document-nav)
* [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html) [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html)
* [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html) [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Apply](/en/services/benefits/publicpensions/cpp/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/apply.html)
* [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html) [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# Do you qualify

## Who can receive a CPP retirement pension

To qualify for a Canada Pension Plan (CPP) retirement pension, you must:

* be at least 60 years old
* have made at least one valid contribution to the CPP

Valid contributions can be either from work you did in Canada or from credits received from a spouse/common-law partner after a divorce or separation.

## Working while receiving CPP

Your CPP retirement pension will not be reduced if you work while receiving it. In fact, you may also qualify for the CPP Post-Retirement Benefit.

### More information about the CPP Post-Retirement Benefit

You qualify for a [CPP Post-Retirement Benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html) if you're:

* under age 70
* working while receiving your CPP pension, and
* still making contributions

#### How the CPP Post-Retirement Benefit works

* Each year you contribute to the CPP will result in an additional post-retirement benefit which will increase your retirement income
* We'll automatically pay you this benefit the following year
* You'll receive it for the rest of your life

You can choose to stop your post-retirement contributions when you reach age 65. Your contributions will stop when you reach age 70, even if you're still working. We will contact you if we need more information for you to qualify.

## Other eligibility criteria

### If you lived and worked in Quebec

The CPP and Québec Pension Plan (QPP) work together to make sure that all contributors receive a retirement pension. [Contact Retraite Québec](http://www.retraitequebec.gouv.qc.ca/en/Pages/accueil.aspx) if one of the following applies to you:

* you've only worked in Quebec
* you worked in Quebec and in at least one other province/territory, and are living in Quebec
* you've worked in Quebec, currently live outside Canada and your last province of residence was Quebec

### If you lived and worked in another country

If you [lived and/or worked in Canada and in another country](/en/services/benefits/publicpensions/cpp/cpp-international.html), you may qualify to receive both a CPP retirement pension and a pension from the other country. Canada has international social security agreements with a number of countries.

### If you die before starting CPP retirement pension

* If you die in the month of or before your 70th birthday, and you have not applied for your CPP retirement pension, it can't be paid to anyone else
* If you're over age 70 and you die before applying for your CPP retirement pension, [your estate can submit an application](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html) for your CPP retirement pension
  + The application from your estate must be received no later than one year after your death
  + Your estate may receive payment for the month of death and the 11 months preceding the death
  + There is no payment made to your estate for the months of and before your 70th birthday

Your family may also qualify for [other CPP benefits](/en/services/benefits/publicpensions.html).

## Watch videos on this topic

[![ ](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/cpp1-en.jpg)](/en/services/benefits/publicpensions/cpp/eligibility/video-how-works.html)

[The CPP retirement pension: How it works](/en/services/benefits/publicpensions/cpp/eligibility/video-how-works.html)

[![ ](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/cpp2-en.jpg)](/en/services/benefits/publicpensions/cpp/eligibility/video-when-start.html)

[The CPP retirement pension: When is the best time to start your pension](/en/services/benefits/publicpensions/cpp/eligibility/video-when-start.html)

## Retirement hub

Explore our [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

### Document navigation

* [Previous: Overview](/en/services/benefits/publicpensions/cpp.html)
* [Next: When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html)

## Page details

Date modified:
:   2025-08-13

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
