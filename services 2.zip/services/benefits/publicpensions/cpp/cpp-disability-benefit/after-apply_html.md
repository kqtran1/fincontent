---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html
scraped_at: 2025-08-24 19:38:23
filename: en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/prestation-invalidite-rpc/apres-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [CPP Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

# Canada Pension Plan disability benefits

* [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html)
* [After you apply](#gc-document-nav)
* [Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html) [Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# After you apply

## If you disagree with the decision

If you disagree with the decision, you may ask to have it reviewed. You must request this reconsideration in writing **within 90 days** of receiving your decision.

Your application will be reviewed by Service Canada staff who were not involved in the original decision.

### Request for reconsideration of a decision

There are 3 ways you can request a reconsideration:

Online

Submit the request online through your [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html)

Printable form

Complete and submit the [Request for Reconsideration of a Canada Pension Plan Disability Decision form (ISP-1145)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1145)

In writing

Prepare and submit a written request for reconsideration of the decision and include:

* your name
* your address
* your telephone number
* your Social Insurance Number (SIN) or Client Identification Number
* a detailed explanation of why you do not agree with the decision
* any new information that could affect the decision
* date on the decision letter that you received from Service Canada (in the top right corner of the letter)
* your signature and the date

**If you complete your request on paper, you can provide it:**

By mail
To the return address on the decision letter

In person
At a [Service Canada Office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

Note: Reconsiderations can take several months to complete, depending on the case. Service Canada will review your application and any new information you submit in support of your request and send you a (new) decision by mail.

### Submit an appeal to the Social Security Tribunal of Canada

If you disagree with the new decision, you can [contact the Social Security Tribunal](https://www.sst-tss.gc.ca/en/contact-us/ways-contact-social-security-tribunal) (SST). The SST is an independent administrative tribunal. It is separate from Service Canada.

There are 2 ways to submit an appeal with the SST:

Through the SST’s website

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/en/your-appeal/notice-appeal-income-security)

Using your My Service Canada Account (MSCA)

Start the appeal process online in [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html).

1. Sign in to MSCA or register for an account
2. Navigate to the "Canada Pension Plan / Old Age Security" section
3. Navigate to the "If you disagree with a decision" section
4. Select "Appeal to the SST" under "Step 2"

#### Need help communicating with the Social Security Tribunal

If you would like a representative to help you communicate with the [Social Security Tribunal](https://www.sst-tss.gc.ca/en) about your appeal, you need to

Complete section 9 of the [Notice of Appeal – Income Security – General Division form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf)

When you need to speak to your representative, [call the Social Security Tribunal](https://www.sst-tss.gc.ca/en/contact-us/ways-contact-social-security-tribunal) and provide your representative’s information

You must [contact the Social Security Tribunal](https://www.sst-tss.gc.ca/en/contact-us/ways-contact-social-security-tribunal) directly to change or cancel your representative.

**Note:** If you would like your representative to communicate with both Service Canada and the Social Security Tribunal, fill out [section 9 of the Notice of Appeal form](https://www.sst-tss.gc.ca/sites/default/files/2021-11/noa-gd-is-en-v6_0.pdf) **and** complete the [Consent to Communicate Information to an Authorized Person form](http://forms-formulaires.prv/lc/apps/EForms/pdf/en/ISP-1603.pdf) for Service Canada.

## Your payments

Your decision letter will give you the date and amount of your first payment.

### Payment dates

If you are eligible for the Canada Pension Plan Disability benefit, you will receive a payment every month.

[View CPP payment dates](/en/services/benefits/calendar.html#cpp-payments)

### Deduct taxes from your CPP disability benefits

Taxes are not automatically deducted. You can ask to deduct federal income tax from your monthly payments through one of the following methods:

* by signing into your [My Service Canada Account](/en/employment-social-development/services/my-account.html) select ‘Change my tax deductions’ from the Canada Pension Plan section to start
  + or
* by completing the [Request for voluntary Federal Income tax Deductions CPP/OAS (ISP-3520) form](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3520CPP) and [mailing it to us](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) or dropping it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

If you do not ask for monthly tax deductions, you could owe income tax when you file your tax return.

### T4 and NR4 tax information slips

Early each year, you will receive a **T4 or NR4 tax slip** showing the amount you received during the previous year. You must include this slip when filing your annual income tax return electronically or on paper.

T4 tax information slips are for residents of Canada, while NR4 tax information slips are for those living outside Canada.

### How to get copies of your tax slips

#### With My Service Canada Account

You can view and print official copies of your tax information slips online through [My Service Canada Account](/en/employment-social-development/services/my-account.html). Once you sign in, select ‘View tax slips’ from the Canada Pensions Plan section.

#### With the Canada Revenue Agency

You can access your T4 tax information slips online with the Canada Revenue Agency through the following services:

* [My Account for individuals](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html)
  View and print your tax information online.
* [Represent a Client](/en/revenue-agency/services/e-services/represent-a-client.html)
  Access tax information on behalf of someone else.
* [Auto-fill my Return](/en/revenue-agency/services/e-services/about-auto-fill-return.html)
  Certified software that automatically fills in parts of your electronic tax return.

If you have not registered to view them online, we will send your tax slip by mail in February of each year.

## While on CPP disability benefits

### Reviewing your case

From time to time, we review cases to ensure that only eligible people receive disability benefits.

If your case is being reviewed, we may ask you to provide current medical and other information. Since everyone's medical condition and capacity to work is unique, each case is assessed individually.

Once we have assessed all the necessary information, we will decide to continue or stop paying your disability benefits. We will inform you of this decision in writing.

### Volunteer and educational activities

If you are attending school or if you are volunteering, you must inform Service Canada if you:

* are doing any of these activities for a combined total of 15 hours a week or more, and
* have been doing these activities on a regular basis for 4 months or longer

School can include college, university, a trade or a technical training program, which can be attended in person or online.

The time you spend at school or in training includes all related activities like studying, researching, writing papers, and completing assignments.

You must also notify Service Canada if you complete a school, university, trade, technical training or rehabilitation program.

Service Canada recognizes the importance of volunteer work, education and training. Many of our beneficiaries can participate in volunteer work and education/training and continue to receive their CPP disability benefits. In some cases, these activities could demonstrate your capacity to work and could impact your eligibility for CPP disability benefits.

#### Examples

Volunteering over 15 hours a week for more than 4 months

John has been receiving CPP disability benefits since November 2015. John has started volunteering as a cashier at a cafeteria and selling clothing. He volunteers 5 days a week, for 5 hours a day since January 2019. His duties include pricing, handling money, cooking and cleaning.

John must report this activity to Service Canada. His benefits may be impacted if this activity demonstrates a capacity to work.

Combination of volunteering and educational activity totaling more than 15 hours a week for more than 4 months

Michael has been receiving CPP disability benefits since 2015. 6 months ago, he started providing free business advice to the business community. He offers his services online for 3 to 4 hours a day, 5 days a week. Sometimes Michael takes mini virtual courses to improve his service offerings.

Michael must report this activity to Service Canada. His benefits may be impacted if this activity demonstrates a capacity to work.

Volunteering less than 15 hours a week for more than 4 months

Margo has been receiving CPP disability benefits since June 2019. Since then, she sometimes volunteers at a nearby community centre . Her duties include shredding old documents, photocopying pamphlets and putting them out for display. She spends anywhere from 5 to 10 hours per week at the centre, whenever she can.

Margo does not need to report this activity to Service Canada. Although she has participated in volunteer activity for over 4 months, it is under the reporting threshold of 15 hours per week.

### Working and earning money

You must contact Service Canada when you return to work, and once you have earned **$7,100** (before tax) in **2025**. Your disability benefits may be impacted by your gross (before tax) earnings.

* If you earn below **$7,100** (before tax), this alone should not affect your disability benefits.
* If you earn between **$7,100** and **$20,153.09** (before tax), this may show that you are regularly capable of working and it may affect your disability benefits.
* If you earn **$20,153.09** (before tax) or more, this demonstrates you are regularly capable of working and you will likely no longer qualify for disability benefits.

If you delay in contacting Service Canada when you earn more than the allowed amount, you may have to repay some of the CPP disability benefits.

**Vocational rehabilitation program**

If you are thinking of returning to work, a variety of services such as guidance, training, and job placement may be available.

[Learn more about the vocational rehabilitation program](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/vocational-rehabilitation.html).

**Three-month work trial**

If you return to work on a regular basis, you may be able to continue to receive your disability benefits for 3 months. This gives you and the CPP time to evaluate your ability to work regularly.

If you are still capable of working after 3 months, your CPP disability benefits will likely stop.

#### Reinstating disability benefits for the same disability

If you are no longer able to work after your benefits stop, you may qualify for [Automatic Reinstatement or the Fast Track Re-application](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/reinstatement.html) process. These are designed to reinstate your benefits as quickly as possible when you are unable to continue working due to a reoccurrence of the same or related disability.

This also applies if your benefit stopped because of your self reported volunteer or educational activities.

#### Examples

##### Reporting a Return to Work

Tara plans to return to work. Tara's benefits can continue while she tries working. She must contact Service Canada once she earns $7,100 (before tax), at which time she is eligible for a 3-month work trial. This provides Tara and Service Canada time to evaluate her ability to work on a regular basis. If Tara is still working after the end of the work trial, this may show that she is regularly capable of working and it may affect her disability benefits.

##### Not Reporting a Return to Work

Robert returned to the workforce but did not contact Service Canada. He is no longer able to do his job as a roofer, but his company offered him light work as an estimator. He returned to work in March working 30 hours a week. Since Robert did not report his return to work, he may no longer be eligible for the CPP disability benefit and may be required to repay any benefits he was not entitled to receive.

##### Self-Employment

Cynthia started her own company. She designs and sells clothing when she feels well enough. Cynthia has the same responsibilities as other beneficiaries who return to work and must contact Service Canada once she earns $7,100 (before tax). The gross business earnings of Cynthia's company and her involvement in the day-to-day activities will be considered in the review of her file.

##### Work Trial

Amina contacted Service Canada to report that she had returned to work. She was provided a three-month work trial to test her ability to work. At the end of the work trial, Amina had earned $8,200, despite missing many days of work due to her medical condition. She was unable to continue working due to her medical condition. Service Canada determined that Amina's condition remained severe and prolonged, and she remained eligible to receive CPP disability benefits.

##### Automatic Reinstatement

Raj contacted Service Canada when he returned to work. His benefits were stopped after a successful 3-month work trial. Less than 2 years later, his disability worsened and he could no longer continue working. Since Raj had reported his return to work and his disability reoccurred within 2 years, he was eligible for the automatic reinstatement of his benefits. This means that his benefits could be reinstated without having to go through the usual application process.

## When your benefit(s) could stop

The disability benefit is meant to replace some of your employment income for as long as your disability stops you from working at any job on a regular basis.

Your disability benefit will stop if you:

* you are capable of working on a regular basis
* you are no longer disabled
* you turn 65
* you die

When a disability benefit is cancelled, any related [children's benefits](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) are also cancelled.

#### When you turn 65

When you turn 65 the disability benefit will automatically change Canada Pension Plan (CPP) retirement pension. If you are receiving the post-retirement disability benefit, it will stop.

Your retirement pension will be less than your disability benefit. However, you can also apply for [Old Age Security](/en/services/benefits/publicpensions/old-age-security.html) and the [Guaranteed Income Supplement](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html). Your spouse or common-law partner may also be eligible for the [Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html) if they are 60 to 64 years old (up to and including the month of their 65th birthday).

#### When someone dies

If you're reading this following the loss of a loved one, please accept our condolences.

When someone dies, please inform us as soon as possible to avoid overpayment. Find out how to [cancel CPP benefits](/en/services/benefits/publicpensions/cpp/cancel-cpp.html) on behalf of a deceased person.

The estate and survivors may be eligible for other CPP benefits:

* [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)
* [Survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)
* [Surviving Child’s benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

## Document navigation

* [Previous - 4. Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html)
* [Next - 6. Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html)

## Page details

Date modified:
:   2025-06-20

## About this site

### Canada Pension Plan Disability benefits (CPPD)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
