---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html
scraped_at: 2025-08-24 13:55:05
filename: en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/prestation-invalidite-rpc/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [CPP Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

# Canada Pension Plan disability benefits

* [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html)
* [Apply](#gc-document-nav)
* [After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html) [After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html)
* [Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html) [Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# Apply

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

## What to know before you apply

### Apply as soon as you develop a severe and prolonged disability

You should apply for CPP disability benefits if you have a severe and prolonged disability that prevents you from working regularly.

The date Service Canada receives your application could affect when your benefit starts.

### If you're a parent or guardian

You can request the [child-rearing provision](/en/services/benefits/publicpensions/cpp/child-rearing.html) and the [children's benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) (both are included in the application form).

### Keep track of your documents and correspondence

Keep photocopies of everything you submit. If you call us, write down the name of the person you speak to and the date and time of your conversation.

## How to apply

To apply for Canada Pension Plan disability benefits, **follow these 2 steps**:

**[Step 1: Apply](#h2.1)**

**[Step 2: Submit your medical form](#h2.2)** (after you have submitted your application)

## Step 1: Apply

To apply for CPP disability benefits [apply with a paper form](#h3.1) or [apply online](#h3.2).

### If you download a form

Check your downloads folder, even if the page indicates the form is loading.

### Apply with a paper form

**1. Choose and complete the form that applies to you:**

* #### Terminal illness: Option 1

  [Terminal Illness Application for Disability Benefits under the Canada Pension Plan form (ISP-2530A)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-2530A.pdf)
* #### [Severe](#centred-popup1) and [prolonged](#centred-popup2) disability (non-terminal illness): Option 2

  [Application for Canada Pension Plan Disability Benefits (ISP-1151)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-1151.pdf)

**2. Choose and complete an option (if required):**

### If someone is helping you communicate with Service Canada

You can authorize someone to communicate with Service Canada on your behalf by completing the:

* [Consent to Communicate Information to an Authorized Person form (ISP-1603)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1603CPP)

**This does not give someone consent to:**

* apply for benefits on your behalf
* change your payment address
* request or change the withholding of tax

### If you are applying on someone's behalf

To act as an administrator for someone who cannot manage their own pension and benefits, you must:

1. Have a medical professional complete the [Certificate of Incapability form (ISP-3505)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3505CPP)
2. Choose and complete the form that applies to you:
   * #### Individual administration: Option 1

     [Agreement to administer benefits under the *Old Age Security Act* and/or the Canada Pension Plan by a Private Trustee form (ISP-3506)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3506_OAS.pdf)
   * #### Agencies, charitable organizations, or municipalities: Option 2

     [Agreement to administer benefits under the *Old Age Security Act* and/or the Canada Pension Plan by an Agency or Institution form (ISP-3507)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3507_OAS.pdf)

**3. Submit the form(s):**

* [Mail the form](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) or [drop the form off at a Service Canada office](https://offices.service.canada.ca/en)

### Tips for applying with a paper form

* Download and save a fillable form to your computer
* Write your Social Insurance Number at the top of each page
* Sign every section that requires your signature using a pen
* If you need more space, use extra blank paper, attach it to your application, and include your Social Insurance Number on each additional page

### Apply online

Please note that the online process is the same if you have a severe and prolonged illness that is both terminal and non-terminal.

1. **1. To apply, register or sign into your My Service Canada Account (MSCA):**
   Apply
2. **2. Complete this option (if required):**

   #### If someone is helping you communicate with Service Canada

   You can authorize someone to communicate with Service Canada on your behalf by signing in to your My Service Canada Account and selecting the "Give consent to communicate on my behalf" link.

   * apply for benefits on your behalf
   * change your payment address
   * request or change the withholding of tax
3. **3. Start your application:**
   * Once you're in MSCA, select "Apply for Canada Pension Plan disability benefits" from the Canada Pension Plan section to start a new application or recover an application already in progress
4. **4. Complete the paper consent form:**
   * Print and sign the [Consent for Service Canada to Collect Personal Information form (ISP-2502)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP2502)
5. **5. Submit the consent form:**
   * [Upload the form online (MSCA)](/en/employment-social-development/services/my-account.html), [mail the form](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html), or [drop the form off at a Service Canada office](https://offices.service.canada.ca/en)
6. **6. After submitting your forms:**
   * Sign in to MSCA anytime to upload additional documents

## Step 2: Submit your medical form

Once your application is submitted, work with your doctor or nurse practitioner to complete the medical form.

1. **1. Choose the form that applies to you:**
   * #### Terminal illness: Option 1

     [Terminal Illness Medical Attestation form (ISP-2530B)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-2530B.pdf)
   * #### [Severe](#centred-popup1) and [prolonged](#centred-popup2) disability (non-terminal illness): Option 2

     [Medical report (ISP-2519)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-2519.pdf)
2. **2. Before giving the form to your doctor:**
   * Complete Sections 1 and 2 of the form
3. **3. If your doctor or nurse practitioner returns the form to you, submit the form:**
   * [Upload it online (MSCA)](/en/employment-social-development/services/my-account.html), [mail it](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html), or [drop it off at a Service Canada office](https://offices.service.canada.ca/en)

### If you are receiving disability benefits from insurance or an agency

If you're already getting disability benefits from an insurance company or a provincial/territorial agency, you can ask them to send us your most recent medical records instead of filling out the medical report form.

### Healthcare Professional Reimbursement

Service Canada will pay up to $85 to your healthcare professional for filling out the medical form. If your healthcare professional charges more than $85, you will need to pay the extra amount.

Consult the [amounts that Service Canada will reimburse your health care professional](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html#h2.02).

## Receive a response from us

We aim to make a decision on your eligibility within 120 calendar days (4 months).

### Priority processing time for terminal illnesses

If we confirm you have a **terminal illness**, we aim to process your application within 5 business days.

A "terminal illness" is a disease that cannot be cured or adequately treated and is likely to result in death within 6 months.

### Priority processing time for grave conditions

If we confirm your **condition is grave**, we aim to process your application within 30 calendar days.

A "grave condition" is a rapidly progressive medical condition. A list of grave conditions was developed based on extensive research by ESDC. These medical conditions have a high probability of meeting the CPP disability eligibility criteria.

**Grave conditions include:**

1. Acute Lymphoblastic Leukemia
2. Acute Myeloid Leukemia
3. Adrenocortical Cancer
4. Alzheimer's Disease (early onset, less than age 60)
5. Amyloidosis
6. Amyotrophic Lateral Sclerosis (ALS)
7. Anal Cancer
8. Appendiceal Cancer
9. Bladder Cancer (Metastatic, Stage IV)
10. Brain Cancer
11. Breast Cancer (Metastatic/recurrent)
12. Cervical Carcinoma
13. Chronic Kidney Disease (CKD)
14. Chronic Liver Disease
15. Colorectal Cancer
16. Endometrial Cancer
17. Esophagus Cancer
18. Follicular Lymphoma
19. Frontotemporal Dementia (FTD)
20. Gallbladder Cancer
21. Huntington Disease
22. Idiopathic Pulmonary Fibrosis (IPF)
23. Kidney Cancer
24. Liver Cancer
25. Lung Cancer
26. Malignant Melanoma
27. Malignant Tumours of Small Intestine
28. Multiple Myeloma
29. Muscular Dystrophy (Adult onset)
30. Ovarian Cancer
31. Pancreatic Cancer
32. Parkinson's Disease
33. Post-inflammatory Pulmonary Fibrosis
34. Primary Cerebellar Degeneration
35. Progressive Polyneuropathy
36. Quadriplegia and Quadriparesis
37. Schizophrenia
38. Stomach Cancer
39. Thymus Cancer
40. Uterine Sarcoma
41. Vascular Dementia

## Check your application status

To check your application status:

* [Sign in to your MSCA](/en/employment-social-development/services/my-account.html) and select the "View my status updates" link
* [Contact Service Canada](/en/employment-social-development/corporate/contact/cpp.html) (if it's been more than 120 days, reach out to us for an update)

## Application updates

What to expect while you wait for a decision on your submitted application:

* **Confirmation:** You will receive a letter in the mail confirming we received your application
* **Follow-up:** We may contact you if we need more information
* **Decision:** You'll receive a letter in the mail with a decision

## Other pensions and benefits

There are several other pensions and benefits that you or your spouse or common-law partner may be eligible for, depending on your situation:

### List of other pensions and benefits

* [Canada Pension Plan (CPP) retirement pension](/en/services/benefits/publicpensions/cpp.html): If you are **60 and older**, and ready to apply for your retirement pension
* [Old Age Security (OAS) pension](/en/services/benefits/publicpensions/old-age-security.html): If you are 65 and older, even if you have never worked or are still working
* [Guaranteed Income Supplement (GIS)](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement.html): If you are **65 and older**, receive Old Age Security, and your income is low
* [Allowance](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance.html): If you are **60 to 64** and your spouse or common-law partner receives Guaranteed Income Supplement
* [Allowance for the Survivor](/en/services/benefits/publicpensions/old-age-security/guaranteed-income-supplement/allowance-survivor.html): If you are **60 to 64**, your spouse or common-law partner has died, and your income is low
* [CPP survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html): If you are the legal **spouse or common-law partner** of a deceased CPP contributor
* [CPP children's benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html): If you are a **dependent child** of a deceased CPP contributor
* [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html): A **one-time payment** on behalf of a deceased CPP contributor

## Document navigation

* [Previous - 3. How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html)
* [Next - 5. After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html)

## Severe

A disability is considered severe only if the CPP determines that it usually or always prevents you from doing any substantially gainful work.

## Prolonged

A disability is considered prolonged only if the CPP determines that it is likely to be long-term and of indefinite duration or is likely to result in death.

## Page details

Date modified:
:   2025-08-13

## About this site

### Canada Pension Plan Disability benefits (CPPD)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
