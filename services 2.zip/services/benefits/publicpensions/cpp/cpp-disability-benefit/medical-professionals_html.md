---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html
scraped_at: 2025-08-24 17:55:04
filename: en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/prestation-invalidite-rpc/professionnels-sante.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [CPP Disability Benefit](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

# Canada Pension Plan disability benefits

* [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/benefit-amount.html)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/apply.html)
* [After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html) [After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html)
* [Information for health care professionals](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# Information for health care professionals

## On this page

* [Medical Report](#h2.01)
* [Billing](#h2.02)
* [Patient is returning to work or participating in volunteer or educational activities](#h2.03)
* [Reinstating a patient’s CPP disability benefits](#h2.04)

Health care professionals may need to provide medical details for individuals applying for Canada Pension Plan (CPP) disability benefits. This essential information allows Service Canada to assess a patient's eligibility or continued eligibility for benefits.

A patient's eligibility is based on multiple factors, in addition to the medical diagnosis. Our medical adjudicators holistically review a number of factors, including:

* the nature and severity of their medical condition
* the impact of the medical condition and treatment on their capacity to work
* the prognosis
* their age, education and work history
* their earnings, the number of hours worked and the ability to regularly attend work
* volunteer and educational activities

If required, we may also seek information from specialists or obtain a second opinion from an independent medical examiner.

## Medical Report

As a medical professional, you are responsible for completing and submitting the Medical Report or the Terminal Illness Medical Attestation on behalf of your patient. We cannot make a decision without your medical report.

[Medical Report for a Canada Pension Plan disability benefit (ISP-2519)](https://catalogue.servicecanada.gc.ca/apps/EForms/pdf/en/ISP-2519.pdf) (to be completed by the applicant's physician or nurse practitioner).

### Submit the report

#### Please promptly submit the Medical Report to the closest Service Canada office listed on the form

If you are unable to provide the required medical information, [contact the CPP Program](/en/employment-social-development/corporate/contact/cpp.html). This will help prevent delays in determining your patient's eligibility.

### If your patient has a terminal illness

For the purposes of the CPP, a terminal illness is a disease that cannot be cured or adequately treated and is likely to result in death within 6 months.

If your patient has a terminal illness, please complete a Terminal Illness Medical Attestation. Applications for terminal illness benefits. Applications from patients with terminal illnesses receive priority handling.

[Terminal Illness Medical Attestation for a Disability Benefit Under the Canada Pension Plan (ISP-2530B)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-2530B.pdf) (to be completed by the applicant’s physician or nurse practitioner).

### Type of medical information needed

We need you to provide a clear and comprehensive medical assessment of your patient's disabling condition, with information about any limitations on their capacity to function. It is not necessary to include any particular statements or phrases to ensure that your patient qualifies for benefits.

The medical assessment must contain the following information related to an applicant's medical history:

* the medical conditions, impairments, functional limitations, prognosis and treatment
* the impact of current and future restrictions on the applicant's ability to work
* planned investigations and specialist consultations
* supporting documents (for example, a clinical note, a medical investigation report, a specialist's report or a hospital discharge report)

We ask that you assess the psychosocial impacts of the disability on your patient's capacity to work. Please provide supporting documents for your comments as this will greatly assist us in making a decision.

We do not need your patient's entire medical file. Provide only the medical information relevant to their capacity to work, including supporting documents such as:

* consultants' reports
* diagnostic test results
* investigative reports
* hospital notes

#### Can I submit clinical notes

If your clinical notes address **all the questions in the Medical Report**, you may submit them instead of completing the entire Medical Report. However, you must also complete the following 2 sections of the Medical Report:

* **Section 5** – Medical conditions, impairments, functional limitations and treatment
* **Section 9** – Declaration

You can only submit your clinical notes for patients who you are following closely and for whom you are keeping detailed clinical notes.

#### Late CPP disability applications

In the case of a [late application](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html#h2.02), we may ask you for information going back a number of years. With the appropriate information, we can treat an application as if it was submitted at an earlier date, when the applicant met the eligibility requirements. We need to determine if your patient was continuously medically eligible from that date until now.

#### Additional requirements of medical professional

The medical information you submit on your patient's capacity to work is essential for the initial application, but also during appeals, follow-up reviews, reassessments or vocational rehabilitation.

We periodically review a client's case to ensure continuing eligibility, and we may ask you for up-to-date medical information on your patient's condition. If so, you may be asked to complete a short medical report. To avoid delays in your patient’s payment of benefits, please answer all the questions on any forms you are asked to fill out.

Our periodic reviews give us an opportunity to contact clients and identify what services would suit them best. If your patient's case is reviewed, your patient will also be asked to provide medical and non-medical information. Since everyone's medical condition is unique, each case is reviewed individually. Once we have reviewed all the necessary information, we will decide to continue or stop paying disability benefits.

### Privacy

The personal information of patients is administered in accordance with [CPP legislation](/en/employment-social-development/programs/laws-regulations/pensions.html) as well as the [*Access to Information Act*](http://laws-lois.justice.gc.ca/eng/acts/P-21/) and the [*Privacy Act*](http://laws-lois.justice.gc.ca/eng/acts/A-1/index.html), under which applicants have the right to formally request a copy of their CPP disability file, including any medical reports and supporting documents.

Appropriate exemption to the release of information may be applied if the release of medical information is considered to be against the patient’s best interests ([section 28 of the *Privacy Act*](https://laws-lois.justice.gc.ca/eng/acts/P-21/page-5.html#s-28)).

If you feel it would be detrimental to your patient to be given particular information about their medical condition, indicate it in your report. We will contact you directly to determine if this information can be withheld.

## Billing

You must mail your invoice to the Service Canada office address noted on the medical form. Payment will be made by cheque and mailed to the address indicated on the invoice.
Your invoice must include:

* your patient's name
* their address, date of birth and Social Insurance Number (SIN)
* your full name or the full name of the medical centre and one of the following:
  + business number, or
  + GST/HST number, or
  + your SIN

Service Canada will pay you up to:

* $85 for the initial [Medical Report](https://catalogue.servicecanada.gc.ca/apps/EForms/pdf/en/ISP-2519.pdf) (ISP-2519)
* $85 for the [Terminal Illness Medical Attestation for a Disability Benefit Under the Canada Pension Plan](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-2530B.pdf) (ISP-2530B)
* $25 for the Reassessment Medical Report (ISP-2509)
* $50 for the Scannable Impairment Evaluation (IMPAIR)
* $25 for the Medical Report - Recurrence of the Same Medical Problem (ISP-2525)
* $150 if we ask you to provide other information in the form of a narrative report (depending on the complexity and the time required for completion)

Your patient is responsible for covering any extra costs.

### Payment for consultations or functional capacity evaluations

Occasionally, Service Canada may request independent medical consultations or functional capacity evaluations during the initial application process, or when determining the patient’s continued eligibility. If so, Service Canada will directly pay the specialist or the functional capacity evaluation facility for these examinations.

### T1204 tax slips for service providers

[Employment and Social Development Canada](/en/employment-social-development.html)  (ESDC) no longer provides copies of T1204 tax slips to service providers. However, ESDC will continue to submit all T1204 information to the Canada Revenue Agency (CRA) as required. Refer to the [CRA’s website](/en/revenue-agency.html) for additional information.

## If a patient is returning to work or participating in volunteer or educational activities

The CPP disability program encourages beneficiaries to work to their potential and offers the following return to work support:

* if a beneficiary self reports a return to work but is unable to continue working because of the same or a related disability, they can ask to have the benefit [automatically reinstated](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/reinstatement.html) or fast tracked without going through the usual reapplication process.
* the same is true if a beneficiary stopped receiving benefits after a self reported return to their volunteer and/or educational activities, but is unable to continue the activities because of the same or a related disability.
* the CPP disability program offers [vocational rehabilitation](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/vocational-rehabilitation.html) to help eligible CPP disability beneficiaries return to work.

### Unpaid work activities while receiving CPP disability benefits

In some cases, unpaid work activities, such as [volunteering and educational activities](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html#h2.03-h3.02), could signal a beneficiary's ability to work and could affect their eligibility for CPP disability benefits.

### Work-related income while receiving CPP disability benefits

Beneficiaries must contact Service Canada once they have earned **$7,100** (before tax) in 2025, and before returning to work (including self-employment). This level of earnings does not necessarily result in benefits stopping. It is, however, a point at which support and services are offered to help the beneficiary’s return to work.

## Reinstating a patient’s CPP disability benefits

To help a patient have their CPP disability benefits reinstated, you must complete the *Reinstatement of CPP Disability Benefits Physician Confirmation Form*. The billing method for the service is explained on the form.

If a patient no longer has the customized form provided when they left CPP disability benefits, they can obtain another one by [contacting CPP](/en/employment-social-development/corporate/contact/cpp.html). The form is not available online.

## Document navigation

* [Previous - 5. After you apply](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/after-apply.html)
* [Next - 6. Information for health care professionals](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/medical-professionals.html)

## Page details

Date modified:
:   2025-06-16

## About this site

### Canada Pension Plan Disability benefits (CPPD)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
