---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-enhancement.html
scraped_at: 2025-08-24 18:27:50
filename: en/services/benefits/publicpensions/cpp/cpp-enhancement_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/bonification-rpc.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canada Pension Plan enhancement

As of 2019, the Canada Pension Plan (CPP) is gradually being enhanced. This means that today’s workers, the seniors of tomorrow, will have higher benefits and greater financial stability through a small increase in the amount they contribute to the CPP.

The CPP enhancement only affects those who work and contribute to the CPP in 2019 or after.

The enhancement adds 2 additional components to the CPP. These components are not a separate benefit, but a ‘top-up’ to the base CPP.

The CPP now consists of:

* the **base** (or original CPP)
* the **first additional component**, which was phased in between 2019 and 2023, and
* the **second additional component**, which was phased in over 2024 and 2025

The CPP enhancement increases the amount working Canadians receive from their CPP retirement pension, post-retirement benefit, disability pension and survivor's pension. It does not affect eligibility for CPP benefits.

To find out if you qualify for CPP benefits, visit:

* [CPP retirement pension](/en/services/benefits/publicpensions/cpp/eligibility.html)
* [CPP post-retirement benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)
* [CPP disability benefits](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/eligibility.html)
* [CPP survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)

If you only work in Quebec, you contribute to the [Québec Pension Plan](http://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/regime_rentes.aspx) (QPP). You can find out more about the enhancement to the QPP by visiting the [Retraite Québec](https://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/bonification-du-rrq.aspx) website.

## Payment increase

We determine the higher benefit payment based on how much and for how long you have contributed to the CPP enhancement.

If you applied after January 1, 2019, you can expect to have the enhanced amount included as part of your monthly CPP benefit. If you are eligible, this may also include a small amount from the [disability drop-in provision](/en/services/benefits/publicpensions/cpp/amount.html#disability-provision) and/or the [child-rearing drop-in provision](/en/services/benefits/publicpensions/cpp/child-rearing.html).

If you have questions once you receive your payment, you can:

* view your payment information on your [My Service Canada Account](/en/employment-social-development/services/my-account.html), or
* contact [Service Canada](/en/employment-social-development/corporate/contact/cpp.html)

## Effects on the CPP retirement pension and post-retirement benefit

Up until 2019, the [CPP retirement pension](/en/services/benefits/publicpensions/cpp.html) replaced **one quarter** (25%) of your average work earnings. We determine this average based on your earnings from employment or self-employment up to the maximum earnings limit in each year. Other sources of income are not included in this calculation.

Under the enhancement, the CPP will grow to replace **one third** (33.33%) of the covered average work earnings you receive after 2019. The maximum level of earnings protected by the CPP was also increased by 14% over 2024 and 2025.

Your pension will increase based on how much and for how long you contribute to the enhanced CPP. The CPP enhancement will increase the maximum CPP retirement pension by more than 50% for those who make enhanced contributions for 40 years.

The enhancement also applies to the [CPP post-retirement benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html). This benefit will be higher if you:

* are receiving the CPP (or QPP) retirement pension, and
* continue to work and make CPP contributions in 2019 or later

## Effects on the CPP disability pension

The enhancement also increased the [CPP disability pension](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html) starting in 2019. The increase you receive depends on how much and for how long you contribute to the enhanced CPP. If you began receiving your CPP disability pension before 2019, the enhancement will not affect it.

## Effects on the CPP survivor's pension

The enhancement also increased the [CPP survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html), starting in 2019. The increase you receive depends on how much and for how long your deceased spouse or common-law partner contributed to the enhanced CPP. If your spouse or partner did not make any contributions in 2019 or later, the enhancement will not affect your pension amount.

## Changes to CPP contributions

You contribute to the CPP if you:

* are over the age of 18
* work in Canada (outside of Quebec), and
* earn more than $3,500 a year

You only contribute on employment earnings between $3,500 and an [annual earnings limit](/en/services/benefits/publicpensions/cpp/contributions.html). This is adjusted each year based on changes in the average wage in Canada. For the current year, this limit is $71,300 (2025).

Before January 1, 2019, employees contributed 4.95% on these earnings to the CPP. Employers contributed an equal amount. If you are self-employed, you contributed both the employee and employer portions, which was equal to 9.9%.

The contribution rates for the enhancement were phased in over the last 7 years. They consist of two changes:

The first additional component covers the same range of earnings as the base, or original, CPP. The contribution rate for the first additional component on earnings from $3,500 and the annual limit, is 1.0% (for a total contribution rate of 5.95%).

The second additional component protects your earnings above the original CPP's limit, up to a new, higher limit ($81,200 in 2025). This new limit, known as the **year's additional maximum pensionable earnings**, does not replace the original limit, known as the **year's maximum pensionable earnings**. Rather, it creates a new range of earnings between these two limits (between $71,300 and $81,200 in 2025), that are now covered under the CPP enhancement. Contributions on this range of earnings are 4.0% for employers and employees (with self-employed paying both halves).

**Note:** This additional range will only affect your CPP contributions in years when your annual earnings are **above the original earnings limit** (for example: for any earnings between $71,301 and $81,200 in 2025).

So, if you earn more, the CPP will protect those earnings. By making a higher contribution, you will get a higher future benefit amount.

Employers will pay the same increase in contributions as their employees.

If you are self-employed, you will contribute both the employee and employer portions. This means self-employed individuals will pay:

* a total contribution rate of 11.9% on earnings in the **original earnings limit**, and
* 8.0% on the **new earnings range**

This will in turn increase your benefit amounts.

If you are an employee, your employer will continue to deduct CPP contributions. If you are an employer or self-employed, you can find out more about CPP enhancement contributions by visiting the [Canada Revenue Agency](/en/revenue-agency/services/tax/businesses/topics/payroll/payroll-deductions-contributions/canada-pension-plan-cpp/cpp-enhancement.html) website.

## Related links

* [Backgrounder: Canada Pension Plan (CPP) Enhancement](/en/department-finance/news/2016/09/backgrounder-canada-pension-plan-cpp-enhancement.html)
* [Retraite Québec Changes to the Québec Pension Plan](https://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/regime_rentes.aspx)

## Page details

Date modified:
:   2025-05-09

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
