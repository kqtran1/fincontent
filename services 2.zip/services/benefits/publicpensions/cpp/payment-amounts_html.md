---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/payment-amounts.html
scraped_at: 2025-08-24 12:56:56
filename: en/services/benefits/publicpensions/cpp/payment-amounts_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/montants-paiement.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canada Pension Plan: Pensions and benefits monthly amounts

This is the average and maximum monthly payment amounts for Canada Pension Plan (CPP) pensions and benefits, except for the death benefit, which is a one-time payment, not a monthly payment.

Canada Pension Plan pensions and benefits - Monthly and maximum payment amounts

| Type of pension or benefit | Average amount for new beneficiaries (April 2025) | Maximum payment amount (2025) |
| --- | --- | --- |
| [Retirement pension](/en/services/benefits/publicpensions/cpp.html) (at age 65) | $844.53 | $1,433.00 |
| [Post-retirement benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html) (at age 65) | $22.59 | $49.39 |
| [Disability benefit](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html) | $1,198.66 | $1,673.24 |
| [Post-retirement disability benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement-disability-benefit.html) | $598.49 | $598.49 |
| [Survivor's pension – younger than 65](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html) | $534.64 | $770.88 |
| [Survivor's pension – 65 and older](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html) | $335.68 | $859.80 |
| [Children of disabled or deceased contributor benefit – under age 18](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) | $301.77 | $301.77 |
| [Children of disabled or deceased contributor benefit – full-time student](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) | $301.77 | $301.77 |
| [Children of disabled or deceased contributor benefit – part-time student](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html) | $150.89 | $150.89 |
| [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html) (one-time payment)**1** | $2,544.53 | $2,500.00 |
| [Combined survivor's and retirement pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html) (at age 65) | $1,042.14 | $1,449.53 |
| [Combined survivor's pension and disability benefit](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html) | $1,175.89 | $1,683.57 |

* **1** The estate of a contributor who dies before collecting a retirement or disability pension and does not leave behind a survivor is entitled to an additional $2,500.

Note: Maximum benefit amounts reflect the CPP/QPP enhancement. CPP maximum amounts in this table are for benefits beginning in January 2025. Maximum CPP benefit amounts increase every month as a result of the enhancement.

For a more detailed report on CPP amounts and figures, see the OAS and CPP Program [Information Card (Rate Card)](/en/employment-social-development/programs/pensions/pension.html).

[Consult CPP payment dates](/en/services/benefits/calendar.html)

**Can I get retroactive payments**

If you apply after you turn 65, Service Canada can only pay retroactive payments of the CPP retirement pension for up to 12 months (11 months plus the month you apply) but no earlier than the month following your 65th birthday. There are no retroactive payments for a retirement pension taken before age 65.

## Page details

Date modified:
:   2025-07-02

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
