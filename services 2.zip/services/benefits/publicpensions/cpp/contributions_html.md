---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/contributions.html
scraped_at: 2025-08-24 13:21:09
filename: en/services/benefits/publicpensions/cpp/contributions_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/cotisations.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Contributions to the Canada Pension Plan

**From: [Employment and Social Development Canada](/en/employment-social-development.html)**

With very few exceptions, every person over the age of 18 who works in Canada outside of Quebec and earns more than a minimum amount ($3,500 per year) must contribute to the Canada Pension Plan (CPP). If you have an employer, you pay half the required contributions and your employer pays the other half. If you are self-employed, you make the whole contribution.

No matter how often you change jobs or where you work in Canada, your contributions may help you or your family become eligible for:

* [Retirement pension](/en/services/benefits/publicpensions/cpp.html)
* [Post-retirement benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)
* [Disability benefits](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)
* [Survivor benefits](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)

At the age of 70, you no longer contribute to the CPP, even if you are still working.

### Note: Quebec Pension Plan

The CPP operates throughout Canada, except in Quebec, where the [Quebec Pension Plan (QPP)](http://www.rrq.gouv.qc.ca/en/accueil/Pages/accueil.aspx) provides similar pensions and benefits.

## How much do I contribute

The amount you contribute is based on your employment income. Starting in 2019, the amount you contribute will be affected by the CPP enhancement.

You make contributions only on your annual earnings between **minimum** and **maximum** amounts. These are called your pensionable earnings. The **minimum amount** is frozen at $3,500.

The **earnings ceiling in the CPP** is set each January, based on increases in the average wage in Canada. **In 2025**, the CPP **earnings ceiling is $71,300**. The contribution rate on these pensionable earnings is 11.9% (9.9% for the base, or original CPP, and 2% for the CPP enhancement, first additional component, which began to be phased in on January 1, 2019), the contribution rate is split equally between you and your employer.

If you are self-employed, you pay the full 11.9%. Your contributions are based on your net business income (after expenses). You do not contribute on any other type of income, such as investment earnings. If, during a year, you contributed too much or earned less than the set minimum amount, your contributions will be refunded when you file your income taxes.

The maximum contribution to the base CPP for employers and employees in 2025 is **$4,034.10**.

If you are self-employed, the maximum contribution is **$8,068.20**.

Starting in 2024, a second additional component was introduced to allow for contributions on higher earnings.

For 2025, pensionable earnings between $71,300.00 and $81,200.00 are subject to additional contributions.

The employee and employer second additional contribution rate for 2025 is 4.00%, and the maximum contribution will be $396.00 each. The self-employed rate is 8.00%, and the maximum contribution is be $792.00.

Second additional component will only affect years when your annual earnings are above the original earnings limit.

For more information on contribution rates in the base CPP, visit [CPP contribution rates, maximums and exemptions](http://www.cra-arc.gc.ca/tx/bsnss/tpcs/pyrll/clcltng/cpp-rpc/cnt-chrt-pf-eng.html).

## Why are my contributions important

Your contributions to the base, or original, CPP determine whether you and/or your family are eligible for a CPP benefit and, if so, both base and enhanced contributions determine what the amount of the benefit will be. Important factors include both how long and how much you contribute. Usually, the more you earn and contribute to the CPP in the years before you take your retirement pension, the higher the benefit will be when you become eligible. That is because you have built up more CPP pension credits.

## How do I know that all of my contributions are accounted for

The Canada Revenue Agency and Revenu Québec (for those working in Quebec) provide Service Canada with details on your earnings and the contributions you have made. Service Canada then keeps a record using a [Statement of Contributions](/en/services/benefits/publicpensions/cpp/statement-contributions.html). You can check this statement for accuracy and contact us if you disagree with any of the figures.

You do not contribute while you are receiving a [CPP Disability benefit](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html), or during periods when you have no earnings or when your earnings are below the $3,500 minimum amount.

### Note: Post-retirement benefit

If you work and make contributions while receiving your CPP retirement pension, these contributions will go toward the [post-retirement benefit](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html).

## What if I lived or worked in another country

Canada has international [social security agreements](/en/services/benefits/publicpensions/cpp/cpp-international.html) with many countries. These agreements may help you qualify for pensions or benefits from Canada and/or from the other country if:

* you have worked in Canada and made at least one valid contribution to the CPP, and
* you have valid periods in a partner country that are creditable under the legislation of that country

For example, if you did not live or work long enough in another country to qualify for benefits under its rules, your periods of contribution to the CPP or periods of residence in Canada under the *Old Age Security Act* may be combined with your periods that are creditable in the partner country. The combination may help you meet the minimum eligibility requirements for pensions or benefits from the other country.

Similarly, if you do not meet the minimum contributory requirements to qualify for children’s, disability or survivors’ benefits under the CPP, a social security agreement can help you qualify. The social security agreement will allow you to combine your periods of contribution to the CPP with your periods that are creditable under the legislation of a partner country. Note that, while a social security agreement can help you to qualify for certain CPP benefits, the payment amounts will be based on your actual contributions to the CPP.

The requirements under the social security agreements vary from agreement to agreement. It is important to check the details of the agreement that relates to you.

## What are my contributory periods and how are they used

Your contributory period for the base CPP **begins** when you reach age 18 (or January 1, 1966, whichever is later).

Your **2** contributory periods for the CPP enhancement **also begin** when you reach age 18 or January 1 of the appropriate year (2019 for the first part of the enhancement, 2024 for the second part of the enhancement), whichever is later.

Each of your contributory periods **end** when you either start receiving your CPP retirement pension, turn 70 or die (whichever happens earliest).

We use the contributory periods to calculate the amount of CPP benefits that you may become eligible to receive.

The amount you get considers periods where you had 0 or low earnings.

A certain number of your lowest earnings years may be automatically dropped from the calculation of the base portion of a CPP benefit. This falls under the "general drop-out provision".

The CPP’s "child-rearing provisions" take into account periods of 0 or low earnings because you were the primary caregiver for your children.

Periods of disability are also taken into account in the calculation of your contributory period.

## Related links

* [Apply for OAS pension](/en/services/benefits/publicpensions/old-age-security/apply.html)
* [Canada Retirement Income Calculator](/en/services/benefits/publicpensions/cpp/retirement-income-calculator.html)
* [My Service Canada Account](/en/employment-social-development/services/my-account.html)
* [Apply for Direct Deposit](/en/employment-social-development/programs/direct-deposit.html)
* [Update your personal information](/en/employment-social-development/services/my-account/cpp-oas.html)
* [Canada Pension Plan retirement- What will you get](/en/services/benefits/publicpensions/cpp/amount.html)

## Page details

Date modified:
:   2025-05-09

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
