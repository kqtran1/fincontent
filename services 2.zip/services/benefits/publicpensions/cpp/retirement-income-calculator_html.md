---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/retirement-income-calculator.html
scraped_at: 2025-08-24 16:28:28
filename: en/services/benefits/publicpensions/cpp/retirement-income-calculator_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/calculatrice-revenu-retraite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canadian Retirement Income Calculator

The Canadian Retirement Income Calculator helps you estimate how much money you might have when you retire.

## Before you begin

To get the most accurate insights from the tool, consider gathering the following resources based on the income sources you want to include:

| Income sources to examine | Resources to gather |
| --- | --- |
| Canada Pension Plan (CPP) retirement benefits | [CPP Statement of Contributions](/en/services/benefits/publicpensions/cpp/statement-contributions.html) or [QPP Statement of Participation](http://www.rrq.gouv.qc.ca/en/accueil/Pages/accueil.aspx) |
| Old Age Security (OAS) pension | Your residence history in Canada |
| Employer pension (if applicable) | Financial information about your employer pension |
| Retirement savings like RRSPs and TFSAs (if applicable) | Statements for your RRSPs and TFSAs |
| Other income (if applicable) | Statements for other savings that will provide ongoing monthly retirement income (annuities, foreign pensions, survivor pensions, etc.) |

### How the Canadian Income Calculator Works

1. **Set a retirement income goal**: input how much income you want to have each year when you retire
2. **Enter your information**: answer questions about your income and savings
3. **Check your results**: check income estimates from OAS, CPP, and other sources
4. **Adjust and compare**: adjust the information you have entered, such as planned RRSP contributions or the date you plan to start your pension, to understand how those changes affect your retirement income
5. **Take your time**: it will take you about **30 minutes** to complete

### If you are married or have a common-law partner

If you are married or have a common-law partner, you should use the calculator separately. Then, review both of your results to understand your overall situation.

**The results provide estimates only.** Do not use the results for financial planning. It's best to consult with a financial expert for more detailed advice.

[Start](https://srv111.services.gc.ca/GeneralInformation/Index)

## Privacy and browser requirements

The calculator does not collect any personal information or identifiers.

### Web browser requirements

Ensure your browser is up to date. The calculator works with:

* Microsoft Edge (version 85 or newer)
* Mozilla Firefox (version 68 or newer)
* Safari (version 13.1.2 or newer)
* Google Chrome (version 84 or newer)

You also need to have JavaScript enabled in your browser settings.

## Related links

* [Canada Pension Plan - How much could you receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Old Age Security - How much you could receive](/en/services/benefits/publicpensions/old-age-security/benefit-amount.html)
* [Canada Pension Plan payment amounts](/en/services/benefits/publicpensions/cpp/amount.html)
* [Old Age Security payment amounts](/en/services/benefits/publicpensions/old-age-security/payments.html)
* [Payment dates for OAS and CPP](/en/services/benefits/calendar.html)
* [My Service Canada Account](http://www.servicecanada.gc.ca/eng/online/mysca.shtml)

## Page details

Date modified:
:   2025-05-09

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
