---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-international.html
scraped_at: 2025-08-24 15:00:47
filename: en/services/benefits/publicpensions/cpp/cpp-international_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-internationales.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Lived or living outside Canada - Pensions and benefits - Overview

# Lived or living outside Canada - Pensions and benefits

* [Overview](#gc-document-nav)
* [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html) [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html#gc-document-nav)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-international/apply.html#gc-document-nav)
* [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html) [While on pension and benefits](/en/services/benefits/publicpensions/cpp/cpp-international/while-receiving.html#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/issa.html) [Contact us](/en/employment-social-development/corporate/contact/issa.html#gc-document-nav)

# Overview

**If you have lived or worked in Canada and in another country**, or you are the survivor of someone who has lived or worked in Canada and in another country, you may be eligible for pensions and benefits from Canada and/or from the other country because of a social security agreement.

## What is a social security agreement?

A social security agreement is an international agreement between Canada and another country that is designed to coordinate the pension programs of the two countries for people who have lived or worked in both countries.

Canada has signed social security agreements with a number of other countries that offer comparable pension programs.

The requirements under the social security agreements vary from agreement to agreement. It is important to check the details of the agreement that relates to you.

## Guides and help

* [Benefits finder](http://www.canadabenefits.gc.ca/f.1.2ch.4m.2%40.jsp?lang=eng)
* [Retirement planning](/en/services/retirement.html)

## Related services and info

* [Apply for a CPP retirement pension](http://www.servicecanada.gc.ca/eng/services/pensions/cpp/retirement/index.shtml#ch)
* [Apply for an OAS pension](http://www.servicecanada.gc.ca/eng/services/pensions/oas/pension/index.shtml#how)
* [My Service Canada Account](http://www.servicecanada.gc.ca/eng/online/mysca.shtml)
* [Apply for direct deposit](http://www.servicecanada.gc.ca/eng/sc/direct-deposit/index.shtml)
* [Update your personal information](http://www.servicecanada.gc.ca/eng/services/pensions/vupi.shtml)

## Contact us

If you need more information on Canada's international social security agreements, [contact us](/en/employment-social-development/corporate/contact/issa.html).

### Document navigation

* [Next - Eligibility](/en/services/benefits/publicpensions/cpp/cpp-international/eligibility.html)

## Page details

Date modified:
:   2025-06-10

## About this site

### Contact International Social Security Agreements

* [Contact us](/en/employment-social-development/corporate/contact/issa.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
