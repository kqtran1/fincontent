---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/apply.html
scraped_at: 2025-08-24 14:07:53
filename: en/services/benefits/publicpensions/cpp/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# CPP retirement pension

* [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html)
* [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html) [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html)
* [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html) [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Apply](#gc-document-nav)
* [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html) [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# Apply

## Potential delays in Canada Post delivery services

Mail delivery for some programs and services may be delayed. Consult the measures in place during the [potential disruption of Canada Post services](/en/employment-social-development/corporate/portfolio/service-canada/postal-disruption.html).

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

## Are you ready to apply

You need to apply to receive the Canada Pension Plan (CPP) retirement pension. [Check that you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html) and [choose your start date](/en/services/benefits/publicpensions/cpp/when-start.html) before you begin your application.

* I qualify
* I've chosen my pension start date

## What to know before you apply

### Plan to apply early

Apply in advance to ensure your CPP retirement pension starts on your chosen date. You can apply up to 12 months before your chosen start date.

### Gather your information

Before you begin your application, please ensure you have the following:

* Social Insurance Number (SIN)
* Direct Deposit information
  + Name of your financial institution
  + Branch (transit) number
  + Account number
* If you have lived or worked in a country other than Canada
  + Country name
  + Insurance number
  + Start and end date
* If applying for Child Rearing Provision
  + Child's full name
  + Child's Social Insurance Number
  + Child's date of birth
  + Documentation showing the child's date of entry into Canada (if born outside Canada)
    - Canadian immigration records (IMM 1000)
    - Complete passport
    - Customs declaration
    - Airline ticket
    - Bus ticket
    - Ship ticket
  + Dates when you did not receive Family Allowance or were not eligible for the Canada Child Benefit
  + Dates that you were not the primary caregiver for the child(ren)

### If you are receiving a CPP disability benefit

When you turn 65, your CPP disability benefit will **automatically** change to a CPP retirement pension.

### If you lived or are living outside of Canada

If you are applying from outside of Canada, you must use a paper application. Send your application to the [Service Canada office](/en/employment-social-development/corporate/contact/cpp.html) in your last province or territory of residence. Learn more about pensions and benefits if you have [lived or are living outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html).

## Apply

To start, you can either [Apply online](#h2.1) or [Apply with a paper form](#h2.2).

### Apply online

#### Before proceeding, check if you’re eligible to use the online option to apply

You need to fill out a paper application instead of applying online if any of the following apply to you:

* You live outside of Canada
* You have a third party (like a power of attorney or a trustee) managing your CPP account
* Your CPP disability benefit ended before you turned 65
* You were denied a CPP disability benefit in the past
* You received a CPP children's benefit between the ages of 18 to 25, but it was not paid directly to you
* You either received or were denied a CPP children's benefit before the age of 18, and you did not receive it after the age of 25
* You are receiving a CPP survivor's pension under an International Social Security Agreement

If you cannot apply online, you will need to [apply with a paper form](#h2.2).

1. **1. Register or sign into your My Service Canada Account (MSCA) to:**
   [Apply](/en/employment-social-development/services/my-account.html)
2. **2. Complete this option (if required):**

   #### If someone is helping you communicate with Service Canada

   You can authorize someone to communicate with Service Canada on your behalf by signing in to your My Service Canada Account and selecting the "Give consent to communicate on my behalf" link.

   **This does not give someone consent to:**

   * apply for benefits on your behalf
   * change your payment address
   * request or change the withholding of tax
3. **3. Start your application:**
   * Select "Apply for Canada Pension Plan retirement pension" link from the Canada Pension Plan section

#### How long will it take to process your application

Expect a decision by mail **within 28 days** from when we receive the application.

### Apply with a paper form

1. **1. Complete the form:**
   * [Application for a Canada Pension Plan Retirement Pension (ISP-1000)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-1000.pdf)
     + If you download the form, check your Downloads folder, even if the page indicates the form is loading
2. **2. Choose and complete an option (if required):**

   #### If someone is helping you communicate with Service Canada

   You can authorize someone to communicate with Service Canada on your behalf by:

   * Completing the [Consent to Communicate Information to an Authorized Person form (ISP-1603)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-1603_CPP.pdf)

     **This does not give someone consent to:**

     + apply for benefits on your behalf
     + change your payment address
     + request or change the withholding of tax

   #### If you are applying on someone's behalf

   To act as an administrator for someone who cannot manage their own pension and benefits, you must:

   1. Have a medical professional complete the [Certificate of Incapability form (ISP-3505)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3505_CPP.pdf)
   2. Choose and complete the form that applies to you:
      * #### Individual administration: Option 1

        [Agreement to administer benefits under the Old Age Security Act and/or the Canada Pension Plan by a Private Trustee form (ISP-3506)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3506_OAS.pdf)
      * #### Agencies, charitable organizations, or municipalities: Option 2

        [Agreement to administer benefits under the Old Age Security Act and/or the Canada Pension Plan by an Agency or Institution form (ISP-3507)](https://catalogue.servicecanada.gc.ca/content/EForms/en/CallForm.html?Lang=en&PDF=ISP-3507_OAS.pdf)
3. **3. Submit the form(s)**
   * [Mail the form(s)](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) or [drop off the form(s) at a Service Canada office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

#### How long will it take to process your application

Expect a decision by mail **within 120 days** from when we receive the application

## Check your application status

Use one of the following methods to check your application status:

* [Sign in to your MSCA](/en/employment-social-development/services/my-account.html) and select the "View my status updates" link
* [Call Service Canada](/en/employment-social-development/corporate/contact/cpp.html)

## Updating and correcting your application

**To update your direct deposit, mailing address or telephone number use one of the following methods:**

* Complete the [eServiceCanada form](https://eservices.canada.ca/en/service/)
* Visit a [Service Canada Office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)
* [Call us](/en/employment-social-development/corporate/contact/cpp.html)

## Make sure your application is accurate

Make sure your application is accurate. If you notice any errors or missing information, [contact us](/en/employment-social-development/corporate/contact/cpp.html) immediately to correct them.

You could be fined if there is false, misleading, or omitted information on your CPP retirement pension application. Interest is also charged on penalties and overpayments that are subject to a penalty.

[Learn about Penalties, Interest and Disclosure Policy](/en/services/benefits/publicpensions/cpp/penalties.html)

### Document navigation

* [Previous: How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Next: After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html)

## Page details

Date modified:
:   2025-08-14

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
