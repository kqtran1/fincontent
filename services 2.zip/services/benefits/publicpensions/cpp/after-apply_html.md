---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/after-apply.html
scraped_at: 2025-08-24 13:26:49
filename: en/services/benefits/publicpensions/cpp/after-apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/apres-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# CPP retirement pension

* [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html)
* [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html) [When to start your retirement pension](/en/services/benefits/publicpensions/cpp/when-start.html)
* [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html) [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Apply](/en/services/benefits/publicpensions/cpp/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/apply.html)
* [After you apply](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# After you apply

## On this page

* [If you disagree with the decision](#h2.1)
* [Payments](#h2.2)
* [Taxes](#h2.3)
* [Cancel your CPP retirement pension after starting](#h2.4)
* [What to do after the death of a CPP recipient](#h2.5)

## If you disagree with the decision

If you disagree with the decision on your application, you may ask to have the decision reviewed. You must request this review in writing **within 90 days** of receiving your decision letter.

[Request a reconsideration of your CPP application](/en/services/benefits/publicpensions/cpp/request-reconsideration.html).

## Payments

Once you start your CPP retirement pension, you'll receive monthly payments for the rest of your life. View [payment dates](/en/services/benefits/calendar.html) for direct deposit.

* **Direct deposit:** Your payment will be directly deposited to your bank account every month if you chose direct deposit. You can sign up for [direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit.html) at any time.
* **Cheque:** If you didn't choose direct deposit, a cheque will be mailed to you during the last 3 business days of each month.

### Cost of living increases

Your monthly payment will increase every January if the cost of living goes up. This increase is based on the [Consumer Price Index](/en/services/benefits/publicpensions/cpp/cpp-benefit/after-apply/consumer-price-index.html). If your cost of living goes down, your payments will not decrease.

## Taxes

Your CPP retirement pension counts as income and is taxable.

### How to deduct federal income tax from your CPP payments

Taxes aren't automatically deducted. To have federal income tax deducted from your monthly payments, you can:

* [Sign in to your My Service Canada Account](/en/employment-social-development/services/my-account.html)
  + Select “Change my tax deductions” link from the Canada Pension Plan section
* Complete the [Request for voluntary Federal Income tax Deductions CPP/OAS (ISP3520CPP) form](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP3520CPP) and [mail it to us](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)
* [Call Service Canada](/en/employment-social-development/corporate/contact/cpp.html)

If you do not ask for monthly tax deductions, you may have to pay your income tax each quarter. For more information, contact the [Canada Revenue Agency (CRA) Tax Services Office](http://www.cra-arc.gc.ca/cntct/tso-bsf-eng.html).

#### If you live outside of Canada

We will automatically deduct the non-resident tax from your payments at a rate of 25% or less, depending on whether Canada has a International Social Security Agreement with the country you live in. You can ask the Canada Revenue Agency (CRA) for a lower amount to be deducted using the [NR5 Application by a Non-Resident of Canada for a Reduction in the Amount of Non-Resident Tax Required to be Withheld for Tax Year](/en/revenue-agency/services/forms-publications/forms/nr5.html) form.

### How to get copies of your tax slips

Early each year, you will receive a **T4 or NR4 tax slip** showing the amount you received during the previous year. You must include this slip when you file your annual income tax return by mail or in person.

* **T4 tax information slips** are for residents of Canada
* **NR4 tax information slips** are for those living outside Canada

#### Access your tax slips:

#### Online (My Service Canada Account)

View and print official copies of your tax information slips online with My Service Canada Account

* [Sign in to your My Service Canada Account](/en/employment-social-development/services/my-account.html)
  + Select “View my tax slips” link from the Canada Pension Plan section

#### Online (Canada Revenue Agency My Account)

You can access your T4 tax information online with the Canada Revenue Agency through the following services:

* [My Account](/en/revenue-agency/services/e-services/cra-login-services.html)
  + View and print your tax information online
* [Represent a Client (My Account)](/en/revenue-agency/services/e-services/represent-a-client.html)
  + Access tax information on behalf of someone else
* [Auto-fill my Return](/en/revenue-agency/services/e-services/about-auto-fill-return.html)
  + Certified software that automatically fills in parts of your electronic tax return

#### By mail

If you have not signed up to view them online, we will send your tax slip by mail in February of each year.

## Cancel your CPP retirement pension after starting

You can cancel your CPP retirement pension up to 12 months after you start receiving it. You must request the cancellation in writing. You must also pay back all the CPP income you've received. To cancel your benefit, contact [Service Canada](/en/employment-social-development/corporate/contact/cpp.html).

## What to do after the death of a CPP recipient

If you're reading this following the loss of a loved one, please accept our condolences.

When someone dies, please inform us as soon as possible to avoid overpayment. Find out how to [cancel CPP benefits](/en/services/benefits/publicpensions/cpp/cancel-cpp.html) on behalf of a deceased person.

The estate and survivors may be eligible to receive other CPP benefits:

* [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html): A one-time payment on behalf of the deceased contributor
* [Survivor's pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html): A monthly payment to the surviving spouse or common-law partner
* [CPP children's benefit](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html): A monthly benefit for a dependent child of a deceased CPP contributor

## Page details

Date modified:
:   2025-08-13

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
