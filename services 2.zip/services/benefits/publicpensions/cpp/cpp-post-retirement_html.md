---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html
scraped_at: 2025-08-24 15:57:02
filename: en/services/benefits/publicpensions/cpp/cpp-post-retirement_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-apres-retraite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Canada Pension Plan Post-Retirement Benefit (PRB) - Overview

# Canada Pension Plan Post-Retirement Benefit (PRB)

* [Overview](#gc-document-nav)
* [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility.html) [Eligibility](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility.html#gc-document-nav)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/benefit-amount.html#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/apply.html#gc-document-nav)
* [After you've applied](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/after-apply.html) [After you've applied](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/after-apply.html#gc-document-nav)

# Overview

If you continue to work while receiving your CPP retirement pension, and are under age 70, you can continue to participate in the CPP. Your CPP contributions will go toward post-retirement benefits (PRB), which will increase your retirement income.

## Guides and help

* [Canada Pension Plan](/en/services/benefits/publicpensions/cpp.html)
* [Canadian Retirement Income Calculator](http://www.servicecanada.gc.ca/eng/services/pensions/cric.shtml)

## Related services and info

* [PRB-Information for the employer](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility.html#selfemp)

### Document navigation

* [Next: Eligibility](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility.html)

## Page details

Date modified:
:   2025-01-22

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
