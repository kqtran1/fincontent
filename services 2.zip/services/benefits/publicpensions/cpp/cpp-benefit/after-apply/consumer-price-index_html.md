---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-benefit/after-apply/consumer-price-index.html
scraped_at: 2025-08-24 13:44:38
filename: en/services/benefits/publicpensions/cpp/cpp-benefit/after-apply/consumer-price-index_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/apres-demande/indice-prix-consommation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html)

# Canada Pension Plan amounts and the Consumer price index

Canada Pension Plan (CPP) rate increases are calculated once a year using the Consumer price index (CPI) **All-Items Index**. They come into effect each January. These increases are legislated under the [*Canada Pension Plan*](http://laws-lois.justice.gc.ca/eng/acts/C-8/page-1.html) act so that benefits keep up with the cost of living.

## Next payment adjustment – January to December 2025

Based on changes in the Consumer Price Index, CPP benefits paid in 2024 will increase by 2.6% for 2025.

## Consumer price index

Developed by Statistics Canada, the CPI is a measure of the rate of price change for goods and services bought by Canadian consumers. It is the most widely used indicator of price changes in Canada.

The CPI is obtained by comparing, through time, the cost of a fixed basket of commodities purchased by Canadian consumers. Since the basket contains commodities of unchanging or equivalent quantity and quality, the index reflects only pure price movements. This "basket" of goods consists of food, shelter, clothing, transportation, health care and other average household expenditures.

Statistics Canada is currently using 2002 as the base year. In 2002, the CPI was equal to 100. This means that the basket of goods in 2002 cost Canadians $100.00. The CPI in January 2023 was measured at 153.9, meaning that the same basket of goods that cost $100.00 in 2002 cost $153.90 in January 2023.

## CPP amounts

CPP amounts are adjusted once a year in January. The rate increase is the percentage change from one 12-month period to the previous 12-month period.

For example, these equations show how the CPI was used to calculate the CPP amounts for January 1, 2024:

### 2024 CPP rate increase

![These equations are described in the following paragraphs.](/content/dam/canada/employment-social-development/migration/images/assets/portfolio/docs/en/services/pensions/cpp/images/cpi-cpp2024-en.png)

Figure 1: text description

Line 1: To calculate the 2024 CPP rates increase, the average CPI for November 2022 to October 2023 is divided by the average CPI for November 2021 to October 2022.

Line 2: The average of 154.0, 153.1, 153.9, 154.5, 155.3, 156.4, 157.0, 157.2, 158.1, 158.7, 158.5 and 158.6 is divided by the average of 144.2, 144.0, 145.3, 146.8, 148.9, 149.8, 151.9, 152.9, 153.1, 152.6, 152.7 and 153.8.

Line 3: In numeric terms, the average CPI for November 2022 to October 2023 is 156.3. This amount is then divided by the average CPI for November 2021 to October 2022, which equals 149.7.

Line 4: 156.3 divided by 149.7 equals 1.044 minus 1 equals 0.044. Multiplying by 100 to obtain the percentage increase gives 4.4%.

If the cost of living decreased over the 12-month period, the calculation of the percentage increase would produce a negative amount. However, as prescribed under the *Canada Pension Plan* act benefit amounts do not decrease, they stay at the same level when there is a decrease in the cost of living.

## Page details

Date modified:
:   2025-05-07

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
