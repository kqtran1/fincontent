---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/share-cpp.html
scraped_at: 2025-08-24 14:09:41
filename: en/services/benefits/publicpensions/cpp/share-cpp_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-partage.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Pension Sharing

# Pension Sharing

You can share your Canada Pension Plan (CPP) retirement pension with your legal spouse or common-law partner. To do so, you must be receiving your pension, or be eligible to receive it, and be living with your legal spouse or common-law partner.

Sharing your pension may result in tax savings.

## Step 1 Do you qualify

To qualify for pension sharing of retirement pension(s), you must meet the following conditions:

* be living with your legal spouse or common-law partner, and
* either you or your legal spouse or common law partner must be receiving, or have applied for, a retirement pension

### Common-law partner

According to the CPP legislation, a common-law partner is a person of either sex who has lived with you in a conjugal relationship for at least 1 year.

### Spouses or common-law partners who are separated

Spouses or common-law partners cannot be approved for pension sharing if they are voluntarily separated at the time of application.

## Step 2 How much could you receive

There are 2 ways to share a pension:

* if only **1** of you contributed to the CPP and/or the Quebec Pension Plan (QPP), you can share the 1 pension
* if **both** of you contributed, you and your spouse or common-law partner may receive a share of both pensions. The combined total amount of the 2 pensions stays the same whether you decide to share your pensions or not

The portion of your pension that can be shared is based on the number of months you and your spouse or common-law partner lived together during your joint contributory period. This period is the time when either one of you could have contributed to the CPP and/or QPP. Your [Statement of Contributions](/en/services/benefits/publicpensions/cpp/statement-contributions.html) has all the details about your contributions.

**Note:**

* the CPP post-retirement benefit is **not** eligible for pension sharing
* pension sharing is not the same as [Canada Revenue Agency’s pension income splitting](/en/revenue-agency/services/tax/individuals/topics/pension-income-splitting.html)
* if you are receiving a retirement pension from the QPP, see the [Retraite Québec](https://www.rrq.gouv.qc.ca/en/retraite/retraite_a_deux/impact_fiscal/Pages/attenuer_impact_fiscal.aspx) website for more information on their pension sharing

## Step 3 When to apply

Pension sharing starts as soon as we approve your application. A pension-sharing arrangement cannot be backdated.

## Step 4 Who should complete the application

If you and your spouse or common-law partner meet the eligibility requirements and would like to share your CPP retirement pensions, either you or your legal spouse or common-law partner can apply.

## Step 5 Apply

If you are applying for or are already receiving a CPP retirement pension, you can apply for pension sharing.

The Canada Pension Plan program reserves the right to request supporting documents. When documents are requested, copies are acceptable; however, Service Canada may ask for an original or [certified copy](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1730CPP) at any time.

### Apply online

To apply online:

* [sign in to your My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) and complete the online CPP Pension Sharing form
* mail copies of the required documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng), and
* indicate both your and your spouse’s/common-law partner’s Social Insurance Numbers on all documents before sending them to Service Canada

### Apply using a paper application

To apply using a paper application:

* complete the [Application for CPP Pension Sharing of Retirement Pension(s) (ISP1002)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1002)
* include copies of the required documents
* [mail the form](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) and documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng), and
* indicate both your and your spouse’s/common-law partner’s Social Insurance Numbers on all documents before sending them to Service Canada

## Step 6 After you apply

Once we receive your application and any supporting documents, we will contact you if we need more information. We will send you a letter once we have completed our review to let you know if you are eligible.

### When pension sharing stops

Pension sharing stops in whichever month occurs first:

* the month following the month Service Canada approves a cancellation request submitted by both you and your spouse or common-law partner
* the month you divorce
* the month the spouse or common-law partner who has never paid into the CPP (or QPP) begins contributing
* the month one of you dies ([contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html) as soon as possible to notify us of the date of death of the CPP pensioner/beneficiary)
* when the pension sharing involves CPP-only retirement pensions, the pension sharing ceases the 12th month following the month in which the spouses or common-law partners start to live separate and apart, or
* when the pension sharing involves both CPP and QPP retirement pensions, the pension sharing ceases the earliest of:
  + the 12th month after the spouses or common-law partners separated, or
  + the month in which a legal separation took place

### To cancel pension sharing

To cancel a pension sharing arrangement:

* complete the [Cancellation of Pension Sharing form (ISP1014)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1014)
* print and sign the form
* [mail it to us](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html), or drop it off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

### What happens to my CPP retirement pension when pension sharing ends

We adjust your pension to the amount you were to receive before the pension-sharing arrangement.

If you contributed less to the CPP than your spouse or common-law partner or if you never worked, the amount of your retirement pension could decrease.

If you contributed more to the CPP than your spouse or common-law partner, your retirement pension amount could increase.

### Review your application status

If you have not heard from us by the time you expect your first payment and you would like to find out the status of your application, you can [contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html).

### If you disagree with a decision

You may [request a reconsideration](/en/services/benefits/publicpensions/cpp/after-apply.html#disagree) of any decision that affects your eligibility or the amount of your Canada Pension Plan benefit.

## Related links

* [Apply for OAS pension](/en/services/benefits/publicpensions/old-age-security/apply.html)
* [Canada Retirement Income Calculator](/en/services/benefits/publicpensions/cpp/retirement-income-calculator.html)
* [My Service Canada Account](/en/employment-social-development/services/my-account.html)
* [Apply for Direct Deposit](https://www.tpsgc-pwgsc.gc.ca/recgen/txt/depot-deposit-eng.html)
* [Update your personal information](/en/employment-social-development/services/my-account.html)

### From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

## Page details

Date modified:
:   2025-06-18

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
