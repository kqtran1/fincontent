---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html
scraped_at: 2025-08-24 12:59:55
filename: en/services/benefits/publicpensions/cpp/cpp-death-benefit_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/prestation-rpc-deces.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Death benefit

# Death benefit

The Canada Pension Plan (CPP) death benefit is a one-time payment, payable to the estate or other eligible individuals, on behalf of a deceased CPP contributor.

## Step 1 Do you qualify

To qualify for the death benefit, the deceased must have made contributions to the [Canada Pension Plan (CPP)](/en/services/benefits/publicpensions/cpp/contributions.html) for at least:

* one-third of the calendar years in their contributory period for the base CPP, but no less than 3 calendar years, or
* 10 calendar years

For deaths occurring on or after January 1, 2025, the death benefit includes a top-up. To qualify for the top-up amount, the deceased must qualify for the death benefit and:

* have never received a disability benefit, post-retirement disability benefit or retirement pension under the CPP or Quebec Pension Plan (QPP), and
* not have a surviving spouse or common-law partner who is eligible to receive a survivor’s pension

### If the deceased contributor lived outside Canada

The international social security agreements that Canada has with other countries may be used to satisfy these requirements.

Consult [lived or living outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international.html).

### If the deceased contributor worked or lived in Quebec

A person may contribute to both the CPP and the Quebec Pension Plan.

The contributions made under both plans are combined when a death benefit is calculated.

Contact [Retraite Québec](http://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/Pages/regime_rentes.aspx) if at the time of death, one of these conditions also applies:

* the deceased contributor only contributed to the Quebec Pension Plan
* the deceased contributor lived outside Canada and the last province of residence was Quebec, or
* the deceased contributor lived in Quebec at the time of death.

### You may also qualify for other CPP benefits

In addition to the CPP death benefit, you may be eligible to receive:

* [Survivor’s pension](/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)
* [Benefits for children under 25](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

## Step 2 How much could you receive

Effective January 1, 2025, the amount of the death benefit for eligible CPP, or CPP and QPP, contributors consist of:

* a basic amount of $2,500, and
* a possible top-up of $2,500

The maximum benefit is $5,000.

These amounts can be less if a social security agreement is needed to meet eligibility.

## Step 3 When to apply

You should apply as soon as possible after the contributor’s death.

## Step 4 Who should complete the application

**If an estate exists**, the executor named in the will or the administrator named by the Court to administer the estate applies for the death benefit.

The executor should apply for the benefit within 60 days of the date of death.

**If no estate exists** or if the executor has not applied for the death benefit, payment may be made to other persons who apply for the benefit in the following order of priority:

* the person or institution that has paid for or that is responsible for paying for the funeral expenses of the deceased
* the surviving spouse or common-law partner of the deceased, or
* the next-of-kin of the deceased

A registered trustee, guardian, or other legal representative, may act on a client’s behalf in person, by mail or by phone, but not online.

For more information, you can [contact the Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html).

## Step 5 Apply

The Canada Pension Plan program reserves the right to request supporting documents. When documents are requested, copies are acceptable; however, Service Canada may ask for an original or [certified copy](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1730CPP) at any time.

### Apply online

To apply for your benefit online:

* [sign in to your MSCA](/en/employment-social-development/services/my-account.html) and complete the online CPP Death Benefit form
* upload supporting documents, if any

### Apply using a paper application

To apply for your benefit using a paper application:

* complete the [Application for a Canada Pension Plan Death Benefit (ISP1200)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1200)
* include copies of documents, if any
* [mail](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) the form and documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng), and
* indicate both the deceased contributor’s Social Insurance Number and your own on all documents before sending them to Service Canada

## Step 6 After you apply

It takes approximately 6 to 12 weeks to receive your payment from the date Service Canada receives your completed application.

### Review your application status

If more than 12 weeks have passed and you would like to find out the status of your application, you can [contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html).

### If you disagree with a decision

You may [request a reconsideration](/en/services/benefits/publicpensions/cpp/after-apply.html#disagree) of any decision that affects your eligibility or the amount of your Canada Pension Plan benefit.

### How to report the benefit on a tax return

To find out how to report the death benefit on the tax return of the individual who receives it, refer to [Death benefits - Prepare tax returns for someone who died](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died/prepare-returns/report-income/death-benefits.html).

### From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

## Page details

Date modified:
:   2025-06-18

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
