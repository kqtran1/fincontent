---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility.html
scraped_at: 2025-08-24 16:26:06
filename: en/services/benefits/publicpensions/cpp/cpp-post-retirement/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-apres-retraite/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)
5. [Working and aged 60 and over](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)

# Canada Pension Plan Post-Retirement Benefit (PRB) - Eligibility

# Canada Pension Plan Post-Retirement Benefit (PRB)

* [Overview](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html) [Overview](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html#gc-document-nav)
* [Eligibility](#gc-document-nav)
* [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/benefit-amount.html) [How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/benefit-amount.html#gc-document-nav)
* [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/before-apply.html) [What you need before you start](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/before-apply.html#gc-document-nav)
* [Apply](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/apply.html#gc-document-nav)
* [After you've applied](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/after-apply.html) [After you've applied](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/after-apply.html#gc-document-nav)

# Eligibility

## Working and aged 60 and over

If you work while receiving your Canada Pension Plan (CPP) retirement pension, you may increase your retirement income with a lifetime benefit. This is called the **Post-Retirement Benefit (PRB)**. You might be eligible if you are:

* 60 to 70 years of age
* working and contributing to the CPP
* receiving a retirement pension from the CPP or the Quebec Pension Plan (QPP)

To get this benefit, you and your [employer](#selfemp) have to make CPP contributions. If you are **self-employed**, you have to pay both the employee and the employer portions of the CPP contributions.

Once you reach 70, you will stop making CPP contributions.

## Note: Working in Quebec

If you work in Quebec after you started receiving your CPP retirement pension, you could receive a [retirement pension supplement from the QPP](http://www.rrq.gouv.qc.ca/en/accueil/Pages/accueil.aspx) .

## 60 to 65 years of age and working

CPP contributions are **mandatory** for working CPP retirement pension recipients under age 65.

## 65 to 70 years of age and working

Starting at age 65, you can **choose** not to contribute to the CPP.

To **stop** contributing, you must fill out form [CPT30 Election to stop contributing to the Canada Pension Plan, or revocation of a prior election](/en/revenue-agency/services/forms-publications/forms/cpt30.html). Give a copy of the form to your employer, and send the original to the Canada Revenue Agency (CRA).

If you have more than one employer, you must give a copy of the form to each of your employers. You cannot choose to contribute to the CPP with one employer and not contribute with another.

If you are self-employed, you must complete the applicable section of the CRA's Schedule 8  [CPP contributions on Self-Employment and Other Earnings](/en/revenue-agency/services/forms-publications/tax-packages-years/general-income-tax-benefit-package/5000-s8.html) and file it with your Income Tax and Benefit Return.

You can **start** contributing once again but only one change can be made per calendar year. Submit section D of a new CRA form [CPT30 Election to stop contributing to the Canada Pension Plan, or revocation of a prior election](/en/revenue-agency/services/forms-publications/forms/cpt30.htm). Give a copy of the form to your employer, and send the original to CRA. If you are self-employed, [contact CRA](http://www.cra-arc.gc.ca/cntct/menu-eng.html) .

## Post-Retirement Benefit - Information for employers

The Post-Retirement Benefit (PRB) is a lifetime monthly benefit for employees **who work in Canada outside Quebec** while receiving a Canada Pension Plan (CPP) or Quebec Pension Plan (QPP) retirement pension.

If your employee is **60 to 65** years of age and works while receiving a CPP retirement pension, you and your employee have to make CPP contributions.

If your employee is **65 to 70** years of age and works while receiving a CPP retirement pension, he or she can **choose** whether or not they want to contribute to the CPP.

To **stop** contributing, your employee must provide you with the completed Canada Revenue Agency (CRA) form [CPT30 Election to stop contributing to the Canada Pension Plan, or revocation of a prior election](/en/revenue-agency/services/forms-publications/forms/cpt30.html). Your employee is responsible to send it to the CRA as soon as possible.

An **employee** may later change this decision and start contributing again. However, only one change can be made per calendar year. Your employee must complete section D of a new CRA form [CPT30 Election to stop contributing to the Canada Pension Plan, or revocation of a prior election](/en/revenue-agency/services/forms-publications/forms/cpt30.html). Your employee is responsible to send it to the CRA as soon as possible.

## Retirement hub

Explore our new [retirement planning tool](/en/services/retirement.html) to find out about public pensions, when to collect them and tips to consider for your retirement income.

### Document navigation

* [Previous: Overview](/en/services/benefits/publicpensions/cpp/cpp-post-retirement.html)
* [Next: How much could you receive](/en/services/benefits/publicpensions/cpp/cpp-post-retirement/benefit-amount.html)

## Page details

Date modified:
:   2025-05-20

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
