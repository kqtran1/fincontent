---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html
scraped_at: 2025-08-24 14:20:19
filename: en/services/benefits/publicpensions/cpp/cpp-survivor-pension_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/rpc-pension-survivant.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# Survivor's pension

# Survivor's pension

## Get timely benefit payments: Sign up for Direct Deposit today!

[Sign up for direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit/individuals-canada.html) to avoid delays in your benefit payments. It's fast, secure, and convenient.

The Canada Pension Plan (CPP) survivor's pension is a monthly payment paid to the legal spouse or common-law partner of the deceased contributor.

## Step 1 Do you qualify

To qualify for the survivor’s pension, you must:

* be legally married to a deceased CPP contributor
* be the common-law partner of a deceased CPP contributor

### Common-law partner

According to the Canada Pension Plan (CPP) legislation, a common-law partner is a person of either sex who has lived with you in a conjugal relationship for at least 1 year.

If you are a separated legal spouse and the deceased had no common-law partner, you may qualify for this benefit.

### If you received a CPP credit split

You are **not eligible** to receive a survivor’s pension if:

* you are a separated legal spouse who’s CPP credit split request was received and approved in January 2025 or later, for the same deceased contributor

However, you **may still be eligible** for the survivor’s pension if:

* you reunited with your separated legal spouse, **and**
* lived together for a period of 12 months or more immediately before their death

### If you previously remarried

The rule was changed in 1987. If you previously lost a Canada Pension Plan survivor’s benefit because you remarried, [contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html) to find out if you are now eligible.

### If you are widowed more than once

If you are widowed more than once, only one survivor's pension - the larger - will be paid.

### If you remarry

Your pension will continue even if you remarry.

### Other CPP benefits

In addition to the CPP survivor’s pension, there may be eligiblity to the CPP:

* [Death benefit](/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)
* [Benefits for children under 25](/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

## Step 2 How much could you receive

The amount you receive as a surviving spouse or common-law partner will depend on:

* whether you are younger or older than age 65
* how much, and for how long, the deceased contributor has paid into the CPP

We first calculate the amount that the CPP [retirement pension](/en/services/benefits/publicpensions/cpp.html) of the deceased is, or would have been, if the deceased had been age 65 at the time of death. Then, a further calculation is done based on the survivor's age at the time of the contributor's death.

### If you are age 65 or older

You will receive 60% of the contributor's retirement pension, if you are not receiving other CPP benefits.

### If you are under age 65

You will receive a flat rate portion **and** 37.5% of the contributor's retirement pension, if you are not receiving other CPP benefits.

### Combining the survivor's pension with other CPP benefits

If you already receive a Canada Pension Plan (CPP) [retirement pension](/en/services/benefits/publicpensions/cpp.html) or [disability pension](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html), the survivor's pension will be combined into a single monthly payment.

However, you cannot receive a full survivor's pension while also receiving a full retirement pension or disability pension. The combined benefit is not necessarily the sum of the 2 separate benefits.

The following restrictions relate to benefit amounts if you are eligible for more than 1 CPP benefit.

**Combining the disability pension and the survivor's pension**

The most that can be paid to a person eligible for both the disability pension and the survivor's pension is the maximum disability pension (which is more than the maximum survivor's pension).

**Combining the CPP retirement pension and survivor’s pension**

The most that can be paid to a person who is eligible for the retirement pension and the survivor's pension is the maximum retirement pension (which is more than the maximum survivor's pension).

**Combining multiple benefits**

When combining multiple benefits with a flat-rate component, only 1 flat-rate (the largest) is provided (for example, the post-retirement disability benefit rather than the smaller flat-rate for a survivor under age 65).

When combining multiple benefits, the total amount of combined CPP benefits paid is adjusted based on the survivor's age and other benefits received.

### CPP enhancement

The [CPP enhancement](/en/services/benefits/publicpensions/cpp/cpp-enhancement.html) component of your survivor’s, retirement and/or disability pensions will be added to the amount of the base component of your combined benefit. The enhanced component of a combined benefit is not subject to the above maximums.

Consult the table of current [Canada Pension Plan (CPP) payment amounts](/en/services/benefits/publicpensions/cpp/payment-amounts.html).

## Step 3 When to apply

You should apply as soon as possible after the contributor's death. If you delay, you may lose benefits.

The Canada Pension Plan can only make back payments for up to 12 months (11 months plus the month you apply).

## Step 4 Who should complete the application

As the survivor, you are responsible for applying for your monthly pension. If you are incapable of applying, you may have a representative (such as a trustee) apply for you.

A registered trustee, guardian, or other legal representative, may act on a client’s behalf in person, by mail or by phone, but not online. For more information, you can [contact the Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html).

## Step 5 Apply

The Canada Pension Plan program reserves the right to request supporting documents . When documents are requested, copies are acceptable; however, Service Canada may ask for an original or [certified copy](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1730CPP) at any time.

### Apply online

To apply for your benefit online:

* [sign in to your MSCA](/en/employment-social-development/services/my-account.html) and complete the online CPP Survivor’s Pension form
* upload supporting documents, if any

### Apply using a paper application

To apply for your benefit using a paper application:

* complete the [Canada Pension Plan survivor's pension and children's benefits application form (ISP1300)](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=ISP1300)
* include copies of the documents, if any
* [mail the form](https://catalogue.servicecanada.gc.ca/content/EForms/en/ReturningtheForm/IspCpp.html) and documents or drop them off at a [Service Canada office](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng), and
* indicate both the deceased contributor’s Social Insurance Number and your own on all documents before sending them to Service Canada

### Providing Service Canada with your email address

**Note:** When you apply, you can provide your email address. We may send you an email to provide you with information or ask you to call us if we can’t reach you by phone. Please note that we won't ask you to send information such as SIN, banking, or other personal details by email.

## Step 6 After you apply

### Your first payment

The survivor's pension starts at the earliest the month after the contributor's death.
It takes approximately 6 to 12 weeks to receive your first payment from the date Service Canada receives your completed application.

### Review your application status

If more than 12 weeks have passed and you would like to find out the status of your application, you can [contact Canada Pension Plan](/en/employment-social-development/corporate/contact/cpp.html).

### If you disagree with a decision

You may [request a reconsideration](/en/services/benefits/publicpensions/cpp/after-apply.html) of any decision that affects your eligibility or the amount of your Canada Pension Plan benefit.

### From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

## Page details

Date modified:
:   2025-06-30

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
