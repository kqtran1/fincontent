---
source_url: https://www.canada.ca/en/services/benefits/publicpensions/cpp/when-start.html
scraped_at: 2025-08-24 14:43:58
filename: en/services/benefits/publicpensions/cpp/when-start_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/pensionspubliques/rpc/quand-debut.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inMSCA sign in](/en/employment-social-development/services/my-account.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Public pensions](/en/services/benefits/publicpensions.html)
4. [Canada Pension Plan retirement pension](/en/services/benefits/publicpensions/cpp.html)

# CPP retirement pension: When to start your pension

# CPP retirement pension

* [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html) [Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html)
* [When to start your retirement pension](#gc-document-nav)
* [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html) [How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)
* [Apply](/en/services/benefits/publicpensions/cpp/apply.html) [Apply](/en/services/benefits/publicpensions/cpp/apply.html)
* [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html) [After you apply](/en/services/benefits/publicpensions/cpp/after-apply.html)
* [Contact us](/en/employment-social-development/corporate/contact/cpp.html) [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

# When to start your retirement pension

## When to start your pension

* The standard age to start CPP is at age 65
* You can start as early as age 60 or as late as age 70
  + Starting earlier means smaller monthly payments
  + Starting later means bigger monthly payments
* There's no benefit to wait after age 70 - the maximum monthly amount is reached when you turn 70

## How age affects your pension

**If you start your CPP pension before age 65**

Payments decrease by 0.6% each month (7.2% per year), up to a maximum reduction of 36% if you start at age 60.

**If you start your CPP pension after age 65**

Payments increase by 0.7% each month (8.4% per year), up to 42% at age 70.

### Consider your personal circumstances

There are many factors you should consider when deciding when to start receiving your CPP retirement pension. Make your choice based on your health, financial situation, and your plans for retirement.

### Examples of when you might choose to start your CPP pension earlier

If you need to work less, or you need the money now to pay off debts or to fund your retirement plans, you may choose to start receiving your CPP retirement pension earlier. This will result in a smaller monthly pension which can help meet immediate needs, especially if you have little or no other income.

### Examples of when you might choose to start your CPP pension later

If you're healthy and expect to live long, and have other sources of income, you may choose to start receiving your CPP retirement pension later. This will result in a larger monthly pension.

## Request retroactive start date

* If you apply after you reach age 65, you can request a retroactive start date which may be as early as 11 months before the month we received your application, but no earlier than the month after your 65th birthday
* If you apply the month of your 65th birthday or earlier, there is no retroactivity

## Watch a video on this topic

[![ ](/content/dam/esdc-edsc/images/services/benefits/publicpensions/cpp/cpp-benefits/cpp4-en.jpg)](/en/services/benefits/publicpensions/cpp/after-apply/video-work.html)

[The CPP retirement pension: Working and the Canada Pension Plan](/en/services/benefits/publicpensions/cpp/after-apply/video-work.html)

### Document navigation

* [Previous: Do you qualify](/en/services/benefits/publicpensions/cpp/eligibility.html)
* [Next: How much you could receive](/en/services/benefits/publicpensions/cpp/amount.html)

## Page details

Date modified:
:   2025-08-14

## About this site

### Canada Pension Plan (CPP)

* [Contact us](/en/employment-social-development/corporate/contact/cpp.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
