---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-self-employed-workers.html
scraped_at: 2025-08-24 18:36:23
filename: en/services/benefits/ei/ei-self-employed-workers_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-sb-autonomes.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# Benefits for self-employed people

Employment Insurance (EI) has a program for self-employed people that provides special benefits when they need time away from their business to care for themselves, their children or other family members.

If you qualify, you could receive financial support of up to 55% of your earnings, to a maximum amount of $695 per week in 2025.

## Are you considered self-employed?

If you run your own business, or control more than 40% of the corporation’s voting shares, you’re considered self-employed.

## If you’re self-employed and an employee

If you’re self-employed and also receive insurable earnings from an employer, both employment and self-employment may be combined to increase your benefit rate.

Insurable earnings include most of the different types of compensation from employment, such as wages, tips, bonuses and commissions. The Canada Revenue Agency (CRA) determines what [types of earnings](/en/revenue-agency/services/tax/canada-pension-plan-cpp-employment-insurance-ei-rulings/cpp-ei-explained/canada-pension-plan-employment-insurance-explained-10.html) are insurable.

## Types of special benefits for self-employed people

If you’re participating in the EI program as a self-employed person, there are 6 types of special benefits available to you.

### Maternity benefits

Maternity benefits are only available to the person who is away from work because they're pregnant or have recently given birth. These benefits can't be shared between parents.

The person receiving maternity benefits may also be entitled to parental benefits.

#### If you live in Quebec

The Province of Quebec is responsible for providing maternity, paternity, parental and adoption benefits to its residents. Visit the [Québec Parental Insurance Plan](https://www.rqap.gouv.qc.ca/en/home) for more information.

### Parental benefits

Parental benefits are available to the parents of a newborn or newly adopted child. These benefits can be shared between parents.

#### If you live in Quebec

The Province of Quebec is responsible for providing maternity, paternity, parental and adoption benefits to its residents. Visit the [Québec Parental Insurance Plan](https://www.rqap.gouv.qc.ca/en/home) for more information.

### Sickness benefits

Sickness benefits can provide you with up to 26 weeks of financial assistance if you can't work for medical reasons.

### Family caregiver benefits for children

Family caregiver benefits for children provide financial assistance while you're away from work to provide care for or support a critically ill or injured child under the age of 18. These benefits can be shared between family members.

### Family caregiver benefits for adults

Family caregiver benefits for adults provide financial assistance while you're away from work to provide care for or support a critically ill or injured person 18 years or older. These benefits can be shared between family members.

### Compassionate care benefits

Compassionate care benefits are available while you're away from work to provide end‑of‑life care. End-of-life-care is defined as providing care or support to a person who has a serious medical condition with a significant risk of death within 26 weeks (6 months). These benefits can be shared between family members.

## Sections

[Who can qualify](/en/services/benefits/ei/ei-self-employed-workers/eligibility.html)
:   Requirements to receive EI special benefits as a self-employed person.

[Premiums](/en/services/benefits/ei/ei-self-employed-workers/premiums.html)
:   About payment of premiums.

[Withdrawal from the program](/en/services/benefits/ei/ei-self-employed-workers/withdraw.html)
:   How to withdraw from the program for self-employed people.

## Page details

Date modified:
:   2025-05-02

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
