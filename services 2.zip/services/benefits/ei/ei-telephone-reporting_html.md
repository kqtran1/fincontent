---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-telephone-reporting.html
scraped_at: 2025-08-24 18:54:49
filename: en/services/benefits/ei/ei-telephone-reporting_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/declarations-assurance-emploi.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# Employment Insurance reporting

## On this page

* [What you need to report](#About-reporting)
* [How to submit your report](#How-submit)
* [When to submit your next report](#When-submit)
* [Ask for an exemption from reporting](#Reporting-exemption)
* [My Service Canada Account](#MSCA)
* [Find a job](#Job-search)

## What you need to report

While receiving Employment Insurance (EI) benefits, you have to complete a report every 2 weeks to show that you’re eligible and to continue receiving benefits.

For each week of the report, you need to:

* indicate dates and hours worked and earnings before deductions, even if you’ll be paid later
* provide the contact information of any employers
* enter hours spent at school or in a training course and any training allowance received
* indicate whether you were available for work
* report other money, even if you’ll receive it later

For information on earnings and other money, visit [Employment Insurance (EI) earnings chart](/en/services/benefits/ei/earnings-chart.html).

### Track your hours and earnings

A reporting calendar is available to help you track your hours and earnings. This will make it easier to fill your report.

You need to report hours and earnings from each job, including self-employment.

### Use the reporting calendar

**How to fill in the reporting calendar**

1. At the top of the calendar, enter the dates for the weeks you’re reporting. Use Sunday as the first day and Saturday as the last day of the week. For example, Sunday, September 6 to Saturday, September 12
2. In the “Hours” column, enter the total number of full and partial hours worked each day. For example, 8.25 hours
3. In the “Earnings” column, enter the total earnings before deductions for each day of the week you worked. Include all [earnings](/en/services/benefits/ei/earnings-chart.html), such as tips, commissions or vacation pay
4. Add up the “Hours” column and enter the total in the “Total to report for this week” box. Report only full hours. Round down to the nearest hour; do not round up. For example, if you worked 38.5 hours, you would enter 38 hours
5. Add up the “Earnings” column and enter the total in the “Total to report for this week” box. Round your total earnings to the nearest dollar. For example, if your earnings were $125.49, enter $125. If your earnings were $125.50, enter $126
6. When it comes time to complete your report, enter the total amounts from your calendar where required
7. Once you complete and submit your report, the due date of your next report will be displayed. Note this date at the bottom of your reporting calendar as a reminder

**Hours and earnings for the week of: Insert work week 1**

Sunday

* Hours: Insert number of hours worked on Sunday
* Earnings: Insert earnings amount on Sunday

Monday

* Hours: Insert number of hours worked on Monday
* Earnings: Insert earnings amount on Monday

Tuesday

* Hours: Insert number of hours worked on Tuesday
* Earnings: Insert earnings amount on Tuesday

Wednesday

* Hours: Insert number of hours worked on Wednesday
* Earnings: Insert earnings amount on Wednesday

Thursday

* Hours: Insert number of hours worked on Thursday
* Earnings: Insert earnings amount on Thursday

Friday

* Hours: Insert number of hours worked on Friday
* Earnings: Insert earnings amount on Friday

Saturday

* Hours: Insert number of hours worked on Saturday
* Earnings: Insert earnings amount on Saturday

Total to report for this week:

* Hours: Insert total hours for work week 1
* Earnings: Insert total earnings for work week 1

**Hours and earnings for the week of: Insert work week 2**

Sunday

* Hours: Insert number of hours worked on Sunday
* Earnings: Insert earnings amount on Sunday

Monday

* Hours: Insert number of hours worked on Monday
* Earnings: Insert earnings amount on Monday

Tuesday

* Hours: Insert number of hours worked on Tuesday
* Earnings: Insert earnings amount on Tuesday

Wednesday

* Hours: Insert number of hours worked on Wednesday
* Earnings: Insert earnings amount on Wednesday

Thursday

* Hours: Insert number of hours worked on Thursday
* Earnings: Insert earnings amount on Thursday

Friday

* Hours: Insert number of hours worked on Friday
* Earnings: Insert earnings amount on Friday

Saturday

* Hours: Insert number of hours worked on Saturday
* Earnings: Insert earnings amount on Saturday

Total to report for this week:

* Hours: Insert total hours for work week 2
* Earnings: Insert total earnings for work week 2

Next report due on: Insert date

#### Download the Employment Insurance reporting calendar

[![](/content/dam/canada/doc.png)

Reporting calendar  [PDF - 80 KB]](/content/dam/canada/employment-social-development/services/benefits/ei/employment-insurance-reporting/EmploymentInsurance_TimeReportingCalenda_EN_Final.pdf)

## How to submit your report

When you applied for benefits, Service Canada mailed you a benefit statement. This statement included a **4-digit access code**. You need this code and your social insurance number (SIN) to submit your reports.

You can submit your reports by Internet or by telephone.

### By Internet

The Internet Reporting Service is simple, fast, convenient and secure.

[Submit your report by Internet](https://srv265.hrdc-drhc.gc.ca/interdec/ouverturedesession-login/ouverturedesession-login.aspx?lang=eng)

If you stay on a page for more than 10 minutes, you’ll be disconnected.

If we need more information to process your report, you’ll receive a message at the end of your report asking you to [call us](/en/employment-social-development/corporate/contact/ei-individual.html).

#### Privacy notice statement

The information you provide is collected under the authority of the *Employment Insurance Act* (1996) to determine your eligibility for Unemployment Benefits (including Family Supplement) Employment Benefits, employment services and training. Completion is voluntary; however failure to complete this form will result in you not being considered for the aforementioned benefits. The information will be retained in "Personal Information Bank(s) "ESDC-PPU-150", "Insurance Claim File-Local Office" and/or "ESDC-PPU-293", "Employment Benefits and Support Measures" and will be used and disclosed in accordance with the conditions listed therein. For Employment Benefits, services and training, this may include the provision of information to your province/territory for the administration of the Labour Market Development Agreements or to third party service providers.

Under the provisions of the *Privacy Act*, individuals have the right to protection of, and access to, their personal information. Instructions for obtaining your personal information are outlined in the government publication entitled Info Source, a copy of which is located in all Employment and Social Development Canada (ESDC).

We use software to monitor network traffic in order to identify cyber threats, unauthorized attempts to upload information, change information, or otherwise cause damage. This software receives and records network, environmental, and behavioral metadata. We make no attempt to link this metadata with the identity of individuals visiting our pages, unless an attempt to undertake inappropriate activity has been detected.

Questions or comments regarding this policy or the administration of the *Privacy Act* in Employment and Social Development Canada (ESDC) may be directed to the Coordinator (nc-fas-sfa-atip-aiprp@hrdc-drhc.gc.ca), Access to Information and Privacy.

Please note that by providing and submitting your **SIN and Access Code**, you will be deemed to have signed your online report. Keep your Access Code safe and store it separately from your SIN.

#### If you receive an error 404 message

If you receive an error 404 message when you try to log in:

* clear your browser’s cache
* delete cookies, or
* use another browser

#### Internet Explorer compatibility view

Make sure the Internet Reporting Service website hasn’t been added to your browser’s compatibility view list:

* click on the Tools menu and then Compatibility View settings
* remove the website if it appears on the list

### By telephone

If you don’t have Internet access, you can use the Telephone Reporting Service by calling 1-800-531-7555.

If we need more information to process your report, we’ll transfer your call to an agent or you’ll receive a message to call back during business hours.

The service standard and the average wait time to speak to an agent are the same as for the [Telephone Information Service](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel2).

### Paper reports

If you can’t submit your report online or by phone, you must mail a [paper report](/en/services/benefits/ei/ei-paper-reports.html).

### Mistakes can happen

You can modify your report before submitting it when you send it by Internet or by telephone.

If you think you made a mistake on report you already submitted, [call us](/en/employment-social-development/corporate/contact/ei-individual.html) as soon as possible. If you don’t, you risk being [overpaid](/en/employment-social-development/programs/ei/ei-list/overpayments.html) and having to repay benefits.

## When to submit your next report

After you submit a report, you’ll be given the date that your next report is due. Mark this date on your calendar. You won’t be able to submit your report before this date, but you have 3 weeks from this date to submit it.

## Ask for an exemption from reporting

For some types of EI benefits, you can choose to be exempted from reporting. If you’re eligible, you can request a reporting exemption, or cancel it, any time during your claim.

You can agree to this exemption when you submit your EI benefits application. You can also [call us](/en/employment-social-development/corporate/contact/ei-individual.html) to be exempted.

You can choose to be exempted if:

* you’re receiving maternity, parental or caregiving benefits
* you’re participating in an apprenticeship program
* you’re part of a Work-Sharing agreement

### If you’re receiving maternity, parental or caregiving benefits or you’re participating in an apprenticeship program

If you’re exempted, you must contact Service Canada if:

* you work
* you receive money
* any situation arises that affects your EI benefits

### If you’re part of a Work-Sharing agreement

If you’re exempted, you must contact Service Canada if:

* you work for an employer other than the employer participating in the Work-Sharing agreement
* you receive money from any employer other than the employer participating in the Work-Sharing agreement
* you receive any money as a result of self-employment, including farming
* any situation arises that affects your EI benefits

## My Service Canada Account

Sign in to [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) at any time, and:

* check that your banking information, address and telephone number are up-to-date
* review your claim status and messages

To sign up for direct deposit or to update your banking information, address or telephone number, you can:

* complete the [eServiceCanada](https://eservices.canada.ca/en/service/) service request form
* contact the [Service Canada call centre](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel2)
* visit a [Service Canada Office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

With direct deposit, your payment is deposited to your bank account 2 to 3 business days after you complete your report.

## Find a job

Search for jobs and connect with employers looking for your skills and experience at [Job Bank](https://www.jobbank.gc.ca/home).

## Page details

Date modified:
:   2025-07-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
