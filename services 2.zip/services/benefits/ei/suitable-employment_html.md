---
source_url: https://www.canada.ca/en/services/benefits/ei/suitable-employment.html
scraped_at: 2025-08-24 18:28:34
filename: en/services/benefits/ei/suitable-employment_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/emploi-convenable.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# Suitable employment and reasonable job search efforts

## On this page

* [Suitable employment](#h2.01)
* [Seasonal employment](#h2.02)
* [Fishers](#h2.03)
* [Living in a community with no suitable employment opportunities](#h2.04)
* [Support available to help you with your job search activities](#h2.05)

As an Employment Insurance (EI) claimant, you have always been responsible for conducting reasonable job searches, documenting your job search activities and accepting any offer of suitable employment while receiving EI regular and fishing benefits. The definitions of **suitable employment** and **reasonable job search are below**.

## Suitable employment

Several factors determine what will be considered **suitable employment**, including:

### Personal circumstances

For example, job opportunities may **not be considered suitable employment** if:

* your health and physical capabilities do not allow you to commute to the workplace or perform the work required
* the hours you are required to work are not compatible with your family obligations (for example, you are a single parent working evenings or nights)
* the nature of the work is contrary to your moral convictions or religious beliefs

### Working conditions/wages

For example, job opportunities may **not be considered suitable employment** if:

* the position offered is vacant due directly to a strike, lockout or other labour dispute
* the working conditions are unsafe
* the wage is lower than the minimum wage in the province or territory where you are looking for work
* the wage would place you in a less favourable financial situation than you are currently experiencing

### Commuting time

For example, job opportunities may be **considered to be suitable employment** if:

* the workplace is within an acceptable commuting time when taking into account your previous commutes and the average commuting time in the area where you live

Commuting time is assessed by taking into account the availability of public transportation, access to a vehicle and the commonly used mode of commute in your community.

### Hours of work

All hours of work, including part-time and shift work, hours per day and hours available outside your previous work schedule, may be **considered to be suitable employment**.

### Reasonable job search

Reasonable job search activities include:

* assessing employment opportunities
* preparing a résumé or cover letter
* registering for job search tools or with electronic job banks or employment agencies
* attending job search workshops or job fairs
* networking[Footnote 1](#fn1)
* contacting prospective employers
* submitting job applications
* attending interviews
* evaluating your skills and competencies[Footnote 2](#fn2)

You must be looking for a job every day that you are receiving regular or fishing benefits. Document all of these job search efforts for the **entire duration of your claim**. This includes the dates, names of employers you have contacted and their contact information, the type of work you were looking for and the results. **Keep this information in a safe place**.

Employers do not need to sign your job search form or provide you with a letter confirming that you have applied for a job. You should never pay for proof of your job search and, if asked, you should refuse.

You are required to make reasonable and ongoing job search efforts while receiving EI regular or fishing benefits. We will take into account the availability of jobs in your community and your personal circumstances when we assess whether you have conducted a reasonable job search.

### Note: Working part time while receiving EI regular benefits

If you are working part time and receiving EI benefits, you must continue to be actively seeking other full- or part-time work and documenting the details of your job search efforts.

Claimants receiving EI regular, fishing, parental, compassionate care and family caregiver benefits can benefit from the [Working While on Claim](/en/employment-social-development/programs/ei/ei-list/working-while-claim.html).

## Seasonal employment

If you are an individual who works in seasonal employment, you will benefit from the same support and resources available to all unemployed people looking for work.

All EI regular and fishing benefits recipients are required to look for a job and document their job search efforts on a continuous basis.

## Important note:

If you are a worker in a seasonal industry and have established an Employment Insurance claim on or between August 5, 2018, and October 30, 2021, in 1 of 13 targeted economic regions, you may be eligible to receive 5 additional weeks of benefits.

For more information, and to find out if you are eligible, visit the [Additional support for seasonal workers](/en/employment-social-development/corporate/portfolio/service-canada/ei-seasonal-workers.html) page.

**What if I have a job to return to in the spring/summer?**

Even if you have a job to return to in the spring/summer, you are still required to be willing to seek and accept temporary employment, conduct [reasonable job search](#job-search) activities and document those activities for the **duration of your claim**.

**If I accept a job during off-season and quit once my seasonal employment begins again, how will my off-season employment be used to establish a future EI claim?**

You will not be penalized for accepting work in your off-season if, within reason, you switch from an off-season job to go back to your regular seasonal employment.

All the hours you work in the 52 weeks before the beginning of your claim are used to determine whether you meet the qualifying conditions to receive EI, as well as the number of weeks of benefits you may receive.

If you accept a short-term seasonal job, then return to your previous seasonal job, you may have the hours from both jobs to determine your eligibility, as long as you meet the other qualifying conditions.

**If I take a short-term seasonal job, how can I qualify for EI once the season is over? Will I qualify for fewer weeks at a lower wage?**

Accepting a short-term or lower-paying job doesn’t prevent you from searching for more stable or higher-paying jobs.

Normally, all the hours you work in the 52-week period before the beginning of your claim are used to determine whether you meet the qualifying conditions to receive EI regular or fishing benefits, as well as the number of weeks of benefits you may receive. The new [Variable Best Weeks](/en/services/benefits/ei/ei-variable-best-weeks.html) approach to calculate your benefit amount, effective April 2013, will also ensure that your benefit rate will be calculated with your highest-paying weeks, when applicable.

### Note:

We assess each situation on a case-by-case basis when we are processing your [online applications for Employment Insurance benefits](/en/services/benefits/ei.html).

## Fishers

As a **fisher** receiving EI benefits, you have always been responsible for conducting a [reasonable job search](#job-search) documenting your job search activities and accepting any offer of suitable employment, including those outside of fishing.

If you are a **self-employed fisher**, you are exempt from proving you are unemployed and available for work while collecting benefits if you are engaged in activities related to fishing. These activities can include, but are not limited to:

* working on your fishing vessel
* making or maintaining fishing gear
* curing a catch
* constructing a vessel to be used by you to make a catch

When not engaged in fishing-related activities, you must **be available for** and [looking for work](#job-search) in the same way as other EI regular benefits claimants.

## Living in a community with no suitable employment opportunities

You have always been responsible for conducting a reasonable job search and accepting any offer of suitable employment while receiving EI regular or fishing benefits. Your efforts must be ongoing; however, you will not be denied EI benefits as long as you are making a reasonable effort to look for work. The requirement of what will constitute a reasonable job search will take into account local employment conditions.

If you are receiving EI regular or fishing benefits and live in a community where there are limited or no employment opportunities, minimum job search requirements would include:

* talking with former colleagues, friends and community centres about potential opportunities
* looking for potential job opportunities in the newspaper and/or on the Internet
* applying for any suitable employment opportunities, should there be any

If you are living in a community where there are employment opportunities, the degree and intensity of your job search would increase and could include additional activities beyond the minimal requirement.

**Will I be expected to move if there are no suitable employment opportunities where I live?**

You are only obligated to look for suitable employment where you live or where you would normally travel for work. You will not be required to move to remain eligible for EI benefits.

**How far will I be required to commute?**

Your daily commute time to and from work should be within what is considered normal for your community. If it is more than what is normal for your community, it should not be more than what you used to commute for your previous job or should not be uncommon in your community. In all cases, commuting time will be assessed by taking into consideration the different methods of transportation that are available to you in your community.

## Support available to help you with your job search activities

### Job Alerts

The new [Job Alerts](http://www.jobbank.gc.ca/job_alert.do?lang=eng) system, found on the [Job Bank](http://www.jobbank.gc.ca/home-eng.do?lang=eng) website, allows you to subscribe and receive job postings from a variety of sources, including Job Bank and other recruitment systems, to better make you aware of local jobs that match your skills. Sign up for new job postings emailed twice daily so you can pursue job opportunities as they become available.

The new Job Alerts will provide emails to Canadian subscribers twice a day that contain job postings from a variety of sources, including Job Bank and other recruitment systems. Job Alerts will continue to be refined and improved over time to ensure it works effectively and efficiently for users.

### Job Bank

Job Bank has thousands of job listings in more than 500 occupational categories. It also provides you with:

* information on how to market yourself
* information on how to locate unadvertised jobs
* information on how to find subsidized jobs to gain work experience
* information on other ways of working, such as telework
* sample résumés to help get you started
* an online tool to create and save your résumé

You can also [register for Job Bank](http://www.jobbank.gc.ca/home-eng.do?lang=eng) to subscribe to job alerts and receive job postings in your email or RSS feed twice a day. Registering is fast, easy and free.

### Additional supports

* [Finding a job](/en/services/jobs.html)
* [Job Bank](http://www.jobbank.gc.ca/home-eng.do?lang=eng)
* [Provincial/Territorial Employment Services and Training Assistance](https://www.jobbank.gc.ca/findajob/employment-centres)

### No Internet access - No problem

You will not be penalized for not having access to the Internet. You can access the Internet by visiting your local [Service Canada Centre](http://www.servicecanada.gc.ca/cgi-bin/sc-srch.cgi?app=hme&ln=eng) to use a Citizen Access Workstation to get information on job opportunities. You can also visit a public library with Internet access in your community. Using newspapers and other means to find out about job opportunities is also considered a reasonable job search activity.

## Footnotes

Footnote 1
:   **Networking** – Engaging with others in a manner that can directly and reasonably help you improve your chances of finding suitable employment. For example, contacting former colleagues, associates and friends for information on expected hiring needs in their organizations.

    [Return to footnote 1 referrer](#fn1-rf)

Footnote 2
:   **Evaluation of competencies** – In your efforts to search for suitable employment, you may undertake an evaluation of your skills. In some cases, an evaluation of your skills may be required by a potential employer. You may also want to evaluate your own skills to assess potential employment opportunities.

    [Return to footnote 2 referrer](#fn2-rf)

## Page details

Date modified:
:   2025-07-17

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
