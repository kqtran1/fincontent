---
source_url: https://www.canada.ca/en/services/benefits/ei/cerb-application/return-or-repay.html
scraped_at: 2025-08-24 15:18:55
filename: en/services/benefits/ei/cerb-application/return-or-repay_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/pcusc-application/retour-ou-remboursement.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canada Emergency Response Benefit (CERB)](/en/services/benefits/ei/cerb-application.html)

# Return or repay the Canada Emergency Response Benefit (CERB)

## Self-employment income (net vs. gross)

Self-employed individuals who applied for the CERB based on their gross self-employment income may be able to keep their payments. Those who have already repaid, may be able to get it reimbursed.

Find out if you meet the [conditions for using gross self-employment income](/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/self-employment-income.html).

## When to return or repay the CERB

You may want to return or be required to repay the CERB to the department (CRA or Service Canada) that issued you the CERB payment.

If you applied for CERB through the Canada Revenue Agency

* returned to work earlier than expected, or were paid retroactively by your employer
* applied for CERB but later realized you were not eligible
* applied for and received the CERB from CRA and Service Canada for the same eligibility period

For more information, visit [Repay COVID-19 benefits – Why you may need to repay](/en/revenue-agency/services/payments/payments-cra/individual-payments/repay-covid-benefits/why-may-need-repay.html).

If you applied for CERB through Service Canada (Employment Insurance (EI) payment):

* returned to work earlier than expected, or were paid retroactively by your employer
* applied for and received the CERB from CRA and Service Canada for the same eligibility period

## How to return a CERB Payment

If you applied for and received the CERB from CRA and Service Canada for the same eligibility period, **please return or repay the CERB to the CRA**.

If you applied for CERB through the Canada Revenue Agency

Visit [Repay COVID-19 benefits – How to make a repayment](/en/revenue-agency/services/payments/payments-cra/individual-payments/repay-covid-benefits/how-make-payment.html) for repayment options.

If you applied for CERB through Service Canada (Employment Insurance (EI) payment)

For anyone who became eligible for EI regular or sickness benefits on March 15, 2020 or later, their Employment Insurance (EI) claim was automatically processed as a CERB payment through Service Canada. **Please note you only have to repay one organization not both.**

If you choose to repay to Service Canada the process to return the payment is as follows:

* if you still have the original cheque you can return the cheque by mail to the address below
* if you do not have the cheque, or have deposited the cheque, you can pay your account using one of the **methods** outlined below:
  Online banking
  + Select "Employment and Social Development Canada"
  + Enter your 9 digit Social Insurance Number (SIN). If your financial institution requires 11 characters **add the letters “YY” or the numbers “00”** to the end of the Client ID
    - Given that each financial institution is different, please try using your SIN with the letters YY after, if this is not accepted by the system, you should input your SIN and the numbers 00. Once the client ID is created the payment can be transferred to Employment and Social Development Canada

  By mail (cheque or money order)
  + Send your payment by cheque or money order (address below)
  + Make your payment payable to: "Receiver General for Canada"
  + Write your SIN on the front of your cheque or money order and indicate it is for “Repayment of CERB”

**Please do not send cash through the mail**

Mail your cheque or money order to the following payment office:

ESDC Remittances
PO Box 1122
Matane QC  G4W 4S7

## How to request reimbursement

Self-employed individuals who applied for the CERB based on their gross self-employment income may be able to keep their payments. Those who have already repaid, may be able to get it reimbursed.

Find out if you meet the [conditions for using gross self-employment income](/en/revenue-agency/services/benefits/apply-for-cerb-with-cra/self-employment-income.html).

To request a reimbursement for a CERB repayment, you must fill in and submit the reimbursement application form. Whether you repaid the CRA or Service Canada, you must submit the form to the CRA. You can only be reimbursed for periods that you repaid.

## How the CERB is taxed

CERB payment amounts are taxable. You must report the CERB amounts that you receive as income when you file your personal income tax return. How much tax you must pay will depend on how much income you earned.

For more information, go to [COVID-19 benefits and your taxes.](/en/services/taxes/income-tax/personal-income-tax/covid19-taxes.html)

## Verifying eligibility

The CRA provided convenient ways for individuals to get the CERB as quickly as possible. Most people were able to complete the application in under 2 minutes, and receive payments through direct deposit within 2 business days.

The CRA is still verifying that the CERB was paid to individuals who were eligible.

As a result, the CRA will be comparing the payroll records of employers with the information of CERB claimants to ensure individuals that returned to work and became ineligible for the CERB repay those amounts.

For more information, visit [COVID-19 benefits from the CRA – Validating your application](/en/revenue-agency/services/benefits/covid-validation.html).

## Page details

Date modified:
:   2025-06-19

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
