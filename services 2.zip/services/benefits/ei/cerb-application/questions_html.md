---
source_url: https://www.canada.ca/en/services/benefits/ei/cerb-application/questions.html
scraped_at: 2025-08-24 15:37:11
filename: en/services/benefits/ei/cerb-application/questions_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/pcusc-application/questions.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Canada Emergency Response Benefit (CERB)](/en/services/benefits/ei/cerb-application.html)

# Questions and Answers on the Canada Emergency Response Benefit

**The CERB has ended**

## On this page

* [Apply](#apply)
* [Eligibility](#eligibility)
* [Income Requirements](#income-requirements)
* [Payment](#payment)
* [Maternity/Parental benefits](#maternity-parental-benefits)
* [Students/Apprentices](#students-apprentices)
* [Retired persons](#retired-persons)
* [Persons with Disabilities](#persons-disabilities)
* [Part-time Workers](#part-time-workers)
* [Self-employed and Independent Workers](#self-employed-independent-workers)
* [Employment Insurance](#employment-insurance)

## Apply

Where can I apply for the CERB?

You can apply [here](/en/services/benefits/ei/cerb-application.html).

Can I apply for the CERB over the phone, or only online?  What if I don’t have access to a computer at my house and I must self-isolate?

The best way for you to apply for the Canada Emergency Response Benefit is [online](/en/services/benefits/ei/cerb-application.html). However, if you do not have online access, you can obtain further information on how to apply for the Benefit using the toll free number 1-833-966-2099.

 Under what circumstances can I apply for the CERB?

The Canada Emergency Response Benefit is available to those who stop working for reasons related to COVID-19, for example:

* you have lost your job
* you are in quarantine or sick due to COVID-19
* you are taking care of others because they are in quarantine or sick due to COVID-19, and/or
* you are taking care of children or other dependents because their care facility is closed due to COVID-19

There may be other reasons related to COVID-19 beyond these examples why you may have stopped working. However, you **cannot** voluntarily quit your job.

Alternatively, you can apply for the Canada Emergency Response Benefit if:

* you are eligible for Employment Insurance regular or sickness benefits, or
* you are a former Employment Insurance claimant who used up your entitlement to your Employment Insurance regular or fishing benefits between December 29, 2019 and October 3, 2020

To get the Canada Emergency Response Benefit, you may not earn more than $1,000 for a period of at least 14 consecutive days within the initial 4-week period of your claim or $1,000 in total for each subsequent claim.

How do I know whether to apply for EI benefits or the CERB?

If you have stopped working because of COVID-19, you should apply for the Canada Emergency Response Benefit.

A single portal is available to assist you with the application process. You will be asked to answer a few simple questions, which will help direct you to complete the application best suited to your situation.

For anyone who became eligible for EI regular or sickness benefits on March 15, 2020, or later, your Employment Insurance claim will be automatically processed through the Canada Emergency Response Benefit.

For other Employment Insurance benefits, including maternity, parental, caregiving, fishing and work-sharing, you should continue to [apply](/en/services/benefits/ei.html) as you normally would.

If I am already receiving EI regular benefits, should I reapply for the CERB?

No.

If you are already receiving Employment Insurance regular benefits, you will continue to receive these benefits until the end of your benefit period.

You cannot be paid Employment Insurance benefits and the Canada Emergency Response Benefit for the same period.

 I have applied for EI regular or sickness benefits, but my claim hasn’t been processed yet, do I need to reapply for the CERB?

No. You should not submit another application for the same benefit period.

Service Canada is processing all of these claims as quickly as possible.

What if I stopped working before March 15th but only applied for EI after March 15th – which benefit will I receive?

If you became eligible for Employment Insurance regular or sickness benefits before March 15th, your claim will be processed under the pre-existing Employment Insurance rules. You will not receive the Canada Emergency Response Benefit.

Do I need to provide any documentation when I apply for the CERB?

You will need to provide your personal contact information, your Social Insurance Number and confirm that you meet the eligibility requirements.

You may be asked to provide additional documentation to verify your eligibility at a future date.

Do I need a medical certificate to receive the CERB if I am in quarantine or sick from COVID-19?

No.

Is a Record of Employment required to apply for the CERB?

A Record of Employment is not required to apply for the Canada Emergency Response Benefit.

However, employers are encouraged to provide a Record of Employment in the event that any employee should subsequently apply for Employment Insurance benefits.

## Eligibility

What are the eligibility criteria for the CERB?

The Benefit is available to workers:

* residing in Canada, who are at least 15 years old
* who have stopped working because of reasons related to COVID-19 **or** are eligible for Employment Insurance regular or sickness benefits **or** have exhausted their Employment Insurance regular or fishing benefits between December 29, 2019 and October 3, 2020
* who had employment and/or self-employment income of at least $5,000 in 2019 or in the 12 months prior to the date of their application, and
* who have not quit their job voluntarily

When submitting your first claim, you cannot have earned more than $1,000 in employment and/or self-employment income for 14 or more consecutive days within the 4-week benefit period of your claim.

When submitting subsequent claims, you cannot have earned more than $1,000 in employment and/or self-employment income for the entire 4-week benefit period of your new claim.

Provided it is allowed in your province or territory, you may also receive provincial or territorial support payments at the same time you receive the Canada Emergency Response Benefit.

Does eligibility for the Canada Emergency Response Benefit (CERB) now include a requirement to seek and accept work opportunities or to return to work when requested by your employer?

Eligibility for the CERB is unchanged. CERB continues to support workers by providing $500 a week to eligible workers, including the self-employed, who have stopped working and lost income due to COVID-19. The CERB responds to a broad range of situations that may require a person to stop working. However, a person is not eligible if they quit their job voluntarily.

As the economy gradually opens, the Government of Canada encourages workers who are able to return to work to do so, provided it is reasonable based on their individual circumstances. Workers who are able to work are also encouraged to consult the tools available through Job Bank, Canada’s national employment service, to help with their job search.

Do I need to be laid off to access the CERB?

No.

Workers who remain attached to their company can receive the Canada Emergency Response Benefit if they meet the eligibility requirements.

 Can you receive the CERB if you are not a citizen or permanent resident?

Yes if you meet the eligibility requirements, which includes residing in Canada and having a valid Social Insurance Number.

 Am I eligible for the CERB even if my job is still there but I don’t feel comfortable going to work as a result of risk associated with COVID-19? For example, what if I have someone at home who has a compromised immune system and I cannot risk infecting them.

The Canada Emergency Response Benefit is available to those who stop working for reasons related to COVID-19, for example:

* you have lost your job
* you are in quarantine or sick due to COVID-19
* you are taking care of others because they are in quarantine or sick due to COVID-19, and/or
* you are taking care of children or other dependents because their care facility is closed due to COVID-19

There may be other reasons related to COVID-19 beyond these examples why you may have stopped working. **However, you cannot voluntarily quit your job**.

If you are concerned about the safety of your working conditions, you should discuss the situation with your employer.

* If you work in a federally-regulated workplace, you may wish to consult your workplace health and safety committee or health and safety representative as well as the document “[Right to refuse dangerous work](/en/employment-social-development/services/health-safety/reports/right-refuse.html)”
* Otherwise, you may wish to consult the website for the department of labour in your province or territory for further information on your rights and the process you should follow
* The [Canadian Centre for Occupational Health and Safety](https://www.ccohs.ca/) is another possible resource

Am I eligible to apply for the CERB if I volunteer to be temporarily laid off by my employer to help them manage the pressures on their business?

Yes. You are eligible for the Canada Emergency Response Benefit if you are laid off as a result of reasons related to COVID-19, even if you maintain your attachment with your employer.

If I lost my job prior to March 15th for reasons related to COVID-19 will I be able to receive the CERB?

If you became eligible for Employment Insurance regular or sickness benefits prior to March 15th, your claim will be processed under the pre-existing Employment Insurance rules.

If you are not eligible for Employment Insurance regular or sickness benefits and lost your job prior to March 15th you may be eligible for the Canada Emergency Response Benefit delivered by the Canada Revenue Agency. However, the Benefit is only available for periods between March 15 and October 3, 2020.

 Am I eligible to apply for the CERB if I have not declared that I earned any money in the last year?

While having filed income tax for 2019 is not an eligibility requirement, you will need to confirm when applying for the Canada Emergency Response Benefit that you had at least $5,000 in employment or self-employment income in 2019 or in the 12 months prior to the date of your application. You will also need to confirm that you have not earned more than $1,000 in employment and/or self-employment income in a period of at least 14 consecutive days within the first benefit period and for the entire 4-week benefit period of any subsequent claim. If you are deemed ineligible for the Benefit at a later date, you will be required to pay it back.

The income of at least $5,000 may be from employment and/or self-employment. For those who are not eligible for Employment Insurance you may also include maternity and parental benefits under the Employment Insurance program and/or similar benefits paid in Quebec under the Quebec Parental Insurance Plan as part of the calculation for income.

 Can employers send their employees off on furloughs to help cope with the decline in available work?

Employers can choose to ask their employees to take a furlough to help meet their business requirements.

In this case, the employee would be considered to have stopped working (unpaid leave) and eligible for the Canada Emergency Response Benefit provided they meet the other eligibility criteria.

There is no requirement for the employer-employee relationship to be severed and the employee can continue to receive other benefits such as medical benefits from the employer and still be eligible for the Benefit.

If an employee has stopped working but is still receiving benefits from their employer (for example, medical) are they eligible for the Canada Emergency Response Benefit?

Yes.

Stopping work does not mean that the employee has severed all ties with their employer. The employer can continue to provide non-cash benefits to the employee and these will not impact their eligibility for the Canada Emergency Response Benefit.

Does being in receipt of severance impact a person’s eligibility for the Canada Emergency Response Benefit?

A severance payment does not impact an individual’s eligibility for the Canada Emergency Response Benefit.

## Income Requirements

What counts towards the $1,000 in income I can earn?

The $1,000 includes employment and/or self-employment income. This includes among others: tips you may earn while working; non-eligible dividends; honoraria (for example, nominal amounts paid to emergency service volunteers); and royalties (for example, paid to artists).

However, royalty payments received from work that took place before the period for which a person applies for the Canada Emergency Response Benefit do not count as income during that specific benefit period.

Pensions, student loans and bursaries are not employment income and therefore, should not be included in the $1,000.

Applications will be verified against tax records to confirm income.

Does the $1,000 limit on income from employment and/or self-employment for each 4-week benefit period apply to when income is earned or when income is received?

For the purposes of CERB, the $1,000 limit relates to earnings from employment and/or self-employment. Income is considered to be earned at the time work is performed and not when payment is received. Self-employed workers need to assess their earnings to determine whether they earned more than $1,000 during that period, regardless of whether they received a payment.

What income types count towards the $5,000 in employment and/or self-employment income?

The $5,000 includes all employment and self-employment income. This includes among others: tips you have declared as income; non-eligible dividends; honoraria (for example, nominal amounts paid to emergency service volunteers); and royalties (for example, paid to artists). If you are not eligible for Employment Insurance, you may also include maternity and parental benefits you received from the Employment Insurance program and/or similar benefits paid in Quebec under the Quebec Parental Insurance Plan.

Pensions, student loans and bursaries are not considered employment income and should not be included.

 Does the minimum income of $5,000 have to be earned in Canada?

No.

The income does not have to be earned in Canada, but you need to reside in Canada.

If I am in receipt of dividends am I eligible for the CERB?

Yes as long as the dividends are non-eligible dividends (generally those paid out of corporate income taxed at the small business rate) and you meet the eligibility criteria.

Non-eligible dividends count towards the minimum $5,000 in income required for eligibility. Non-eligible dividends also count toward the $1,000 income threshold for a benefit period.

Do artists’ royalties count as employment or self-employment income with respect to the CERB?

Yes, in some cases. Artists’ royalties would be considered payments received as self-employment income if they were received as compensation for using or allowing the use of a copyright, patent, trademark, formula or secret process that is a result of their own work or invention. These royalties count towards the $5,000 income threshold, as well as towards the $1,000 that claimants can earn per month while receiving the Benefit. However, royalty payments received from work that took place before the period for which a person applies for the Canada Emergency Response Benefit do not count as income during that specific benefit period. Other royalties (for example, from investment activities) do not count with respect to the Benefit.

## Payment

How much could I receive through the CERB?

If you meet the eligibility requirements, you would receive $500 per week to a maximum of 28 weeks.

The Benefit is taxable, you will be expected to report it as income when you file your income tax for the 2020 tax year.

 When and how will I receive my CERB payment? Is there a waiting period?

There is no waiting period so you will receive your Benefit within 10 days of applying.

Payments will be made through direct deposit or by cheque; however direct deposit is faster.

Your payments will be retroactive to the date you became eligible.

 If I would be entitled to more than the $500 per week under EI, will I get the higher amount?

No.

You will receive $500 per week, regardless of what you may have been eligible to receive through Employment Insurance.

However, once you are finished receiving the Canada Emergency Response Benefit, you will still be eligible to receive Employment Insurance at the higher rate provided you cannot find a job. Getting the Canada Emergency Response Benefit does not affect your EI entitlement.

 If I would have been entitled to less than the $500 per week under EI, will I get the $500?

Yes.

You will receive $500 per week, regardless of what you may have been eligible to receive through Employment Insurance.

 What happens if I get a CERB payment I am not entitled to because I applied twice - once to the Canada Revenue Agency and once to Service Canada?

Canadians should only apply for the Canada Emergency Response Benefit from either Service Canada **OR** the Canada Revenue Agency, not both.  If you have already applied for Employment Insurance benefits but haven’t received your benefits yet, you should not submit another application.

While there will not be any penalty for Canadians if you have received a payment in error, you will have to repay the CERB benefits for which you are not entitled and will receive a letter from the CRA providing you with further information about the repayment process.

Specifically, if you have received the Canada Emergency Response Benefit twice for the same benefit period, you are requested to return one of the payments to the Canada Revenue Agency using the following procedure:

* if you still have the original Canada Emergency Response Benefit cheque, you can return the cheque by mail to the address below
* if you received the payment by direct deposit, or deposited the cheque, you can mail your repayment to the CRA. Be sure to:
  1. make payment out to “Receiver General for Canada”
  2. indicate it is for “Repayment of CERB”
  3. include your Social Insurance Number (SIN) or your Temporary Tax Number (TTN)

Please do not send cash through the mail.

Please mail your payment to:

Revenue Processing – Repayment of CERB
Sudbury Tax Centre
1050 Notre Dame Avenue
Sudbury ON  P3A 0C1

 Once I receive my first payment, can I assume I will receive my next payment 4 weeks later?

No, the renewal of payments will not be automatic. You must confirm your eligibility for each period for which you apply either [online](/en/services/benefits/ei/cerb-application.html) or by phone (1-833-966-2099).

If you are receiving your Benefit through Service Canada you must complete your EI Report Card to confirm your eligibility.

## Maternity/Parental benefits

If I am planning on going on maternity/parental leave shortly am I eligible for the Canada Emergency Response Benefit? Why was I put on EI regular benefits rather than the CERB? Will this impact my eligibility for Employment Insurance maternity and/or parental benefits?

* The Government of Canada is committed to addressing the situation experienced by some expectant mothers applying for the CERB and receiving regular EI benefits when they should have been receiving the CERB. Anyone entitled to the CERB should be getting the CERB
* We are also committed that being on the CERB will not affect an expectant mother’s ability to collect EI maternity and parental benefits. We have come up with a way that will not negatively impact any expectant mother who should have been receiving the CERB
* As way of background, Service Canada asks CERB applicants if they are pregnant and anticipating going on maternity/parental benefits to ensure that the claims are properly established with all the necessary information to allow the client to transition over to maternity/parental at the appropriate time without having to reapply
* There was a limitation with the CERB system when expectant mothers disclosed they were pregnant, and women were being immediately put on EI benefits rather than the CERB. This was happening regardless of whether the expectant mother became eligible for EI before or after March 15th
* March 15th is an important date as it determines whether a claim will be processed through the regular EI system or through the CERB system. The triggering date is not the date of application
* Expectant mothers who lost their job and are eligible for EI prior to March 15th, should have received EI regular benefits, and when eligible, transition to EI maternity and parental benefits following the birth of their child
  + The benefits will be paid at the rate established under EI rules
* Expectant mothers who lost their job and are eligible for EI after March 15th should receive the CERB (to a maximum of 28 weeks) and when eligible, transition to EI maternity and parental benefits following the birth of their child
  + CERB benefits will be paid out at the rate of $500/week
  + An expectant mother could potentially claim EI regular benefits in between the end of CERB and the beginning of EI maternity and parental benefits
* As of May 8th, women who should have been receiving the CERB had their claims converted retroactively to the CERB
  + Those who had been receiving less than the $500 per week will receive a payment to get them up to the $500
  + Those who had been receiving more than the $500 per week will not have any money clawed back, but will receive the $500 per week flat rate from the time their claim is converted going forward
  + The weeks for which they collect the CERB will not impact the number of weeks of maternity and parental benefits they may receive
* The maximum number of weeks of EI regular and maternity and standard parental benefits any claimant can receive is 50 weeks, or over a longer period for claimants who choose the extended parental benefits
  + Whereas EI regular benefits count towards this 50-week maximum, CERB benefits do not
  + In all cases, maternity and parental benefits will be paid at the rate established under EI rules

If I am on maternity/parental benefits, am I eligible to apply for the CERB?

You cannot receive maternity or parental benefits at the same time as the Canada Emergency Response Benefit.

If you cannot return to work due to COVID-19 following your maternity/parental leave, you would be considered to have stopped working due to COVID-19. If you meet the other eligibility requirements you may receive the Canada Emergency Response Benefit.

## Students/Apprentices

Am I eligible for the CERB if I am a student who was working part-time and lost my job for reasons related to COVID-19?

Yes, provided you lost your job as a result of reasons related to COVID-19 and meet the other eligibility criteria.

 I lost my job but I am receiving bursaries and/or scholarships. Can I get the CERB?

Yes, provided you stopped working for reasons related to COVID-19 and meet the other eligibility criteria.

Student loans and bursaries do not affect eligibility for the Canada Emergency Response Benefit.

 Does the money I receive through bursaries and/or scholarships count toward the requirement for $5,000 in income?

No. Student loans and bursaries do not count toward the $5,000 in income.

The income of at least $5,000 may be from employment and/or self-employment. For those who are not eligible for Employment Insurance you may also include maternity and parental benefits under the Employment Insurance program and/or similar benefits paid in Quebec under the Quebec Parental Insurance Plan as part of the calculation for income.

 Am I eligible for the CERB if I am in an apprenticeship program, receiving funding through the Employment Insurance Program, and lose my job as a result of COVID-19?

No, but you could be eligible to continue receiving your Employment Insurance benefits.

## Retired persons

Are people who lost their job but are receiving a pension eligible for the CERB?

Yes, provided you stopped working for reasons related to COVID-19 and meet the other eligibility criteria.

Pension income does not affect eligibility to the Canada Emergency Response Benefit.

 Does pension income count towards the $5,000 income requirement for the CERB?

No. Pension income does not count toward the $5,000 in income.

The income of at least $5,000 may be from employment and/or self-employment. For those who are not eligible for Employment Insurance you may also include maternity and parental benefits under the Employment Insurance program and/or similar benefits paid in Quebec under the Quebec Parental Insurance Plan as part of the calculation for income.

## Persons with Disabilities

Can I get the CERB if I am receiving disability benefits?

Yes, provided you stopped working for reasons related to COVID-19 and meet the other eligibility criteria.

Disability benefits do not affect eligibility to the Canada Emergency Response Benefit.

 Does the money I receive through my disability benefits count toward the requirement for $5,000 in income?

No. Funding received through disability benefits does not count toward the $5,000 in income.

The income of at least $5,000 may be from employment and/or self-employment. For those who are not eligible for Employment Insurance you may also include maternity and parental benefits under the Employment Insurance program and/or similar benefits paid in Quebec under the Quebec Parental Insurance Plan as part of the calculation for income.

## Part-time Workers

I am a part-time worker who has seen a reduction in my hours as a result of COVID-19. Am I eligible for the CERB?

You may be eligible if you have stopped working because of COVID-19.

When submitting your first claim, you cannot have earned more than $1,000 in employment and/or self-employment income for a period of at least 14 or more consecutive days within the 4-week benefit period of your claim.

When submitting subsequent claims, you cannot have earned more than $1,000 in employment and/or self-employment income for the entire 4-week benefit period of your new claim.

## Self-employed and Independent Workers

Are self-employed small business owners eligible for the CERB?

Yes provided they meet the eligibility criteria including that they stopped working due to COVID-19 and do not earn more than $1,000 in a period of at least 14 consecutive days in the first benefit period and for the entire 4-week benefit period of any subsequent claim.

Small Business owners can receive income from their business in different ways, including as salary, business income or dividends. In determining their eligibility for the Canada Emergency Response Benefit:

* owners who take a salary from their business should consider their pre-tax salary
* owners who rely on business income should consider their net pre-tax income (gross income less expenses)
* owners who rely on dividend income should consider this as self-employment income provided it comes from non –eligible dividends (generally, those paid out of corporate income taxed at the small business rate)

Can someone qualify for CERB if they still have a small amount of income coming into their business account as a sole proprietor to pay some of their business expenses (commercial rent, utility costs, etc.) as long as they are not paying themselves any income from the business?

Yes. To be eligible for the Canada Emergency Response Benefit, you must have stopped working as a result of reasons related to COVID-19 and receive less than $1,000 in employment or self-employment income for at least 14 consecutive days within the initial 4-week period for which you apply. For subsequent periods, you cannot receive more than $1,000 in employment or self-employment income for the entire 4-week period.

Are Self-Employed Fishers eligible for the CERB?

Self-employed fishers are encouraged to apply for Employment Insurance fishing benefits.

If a self-employed fisher does not meet the criteria to establish a new EI fishing benefits claim, or if they have exhausted their EI fishing benefits between December 29, 2019 and October 3, 2020, and are unable to work due to COVID-19, they may be eligible for the Canada Emergency Response Benefit, provided they meet the eligibility criteria.

You cannot be in receipt of Employment Insurance benefits (including fishing benefits) and the Canada Emergency Response Benefit for the same period.

## Employment Insurance

Do I need to complete my bi-weekly EI reports?

Yes.

While you are receiving the CERB through Service Canada and the Employment Insurance program, you must complete reports to show that you are eligible and to continue to be paid.

You can complete your reports online using the [Internet Reporting Service](/en/services/benefits/ei/employment-insurance-reporting.html#Internet-Reporting-Service) or by telephone at 1-800-531-7555.

You will need your 4-digit Access Code from Service Canada and your Social Insurance Number (SIN). Continue completing reports when they’re due to continue to be paid for the duration of your claim.

Where can I find my Access Code to allow me to apply for EI online through Service Canada?

You do not need an access code to apply for EI. The EI Access Code is required for you to complete your biweekly reporting required once you have submitted your EI application. Shortly after you submit your EI application, an EI benefit statement will be mailed to you. This does **not** mean that your application has been approved. Your Benefit statement will provide the information you need to complete your reports with our [Internet reporting service](/en/services/benefits/ei/ei-internet-reporting.html) or our [Telephone reporting service](/en/services/benefits/ei/ei-telephone-reporting.html).

Your access code is the 4-digit code printed in the shaded area of your benefit statement. Your access code is used to identify you and ensure confidentiality of the information you provide. Store your access code in a safe place, separately from your Social Insurance Number.

Do I get a choice between collecting the EI CERB and collecting EI regular Benefits?

There are 3 possible scenarios in terms of which benefit you may receive:

* if you became eligible for Employment Insurance regular or sickness benefits prior to March 15th, you will receive the Employment Insurance benefits. You do not get to choose to receive the Canada Emergency Response Benefit
* if you became eligible for Employment Insurance regular or sickness benefits March 15th onward, you will receive the Canada Emergency Response Benefit. You do not get to choose

The only case where you get a choice is if you started a new EI claim within the last 52 weeks and there are still weeks payable on that claim. If you are in this situation, you can choose to:

* automatically reactive (renew) your existing claim at the existing benefit rate, **or**
* request that Service Canada end your existing claim and open a new claim for the Canada Emergency Response Benefit, provided you meet the eligibility criteria

If you choose to end your existing claim, any remaining weeks payable on that existing claim will be lost and your decision is irreversible and not subject to reconsideration.

You cannot get Employment Insurance benefits and the Canada Emergency Response Benefit for the same period.

I am a seasonal worker who received EI regular benefits over the off-season and I have just exhausted my benefit entitlement, but I am unable to find work due to COVID-19—am I eligible for the CERB?

Yes. You are eligible for the Canada Emergency Response Benefit if you are a former Employment Insurance claimant who used up your entitlement to your Employment Insurance regular benefits between December 29, 2019 and October 3, 2020, and are unable to find work due to COVID-19.

The date for which you would potentially become eligible for the Canada Emergency Response Benefit would be the week following your last Employment Insurance benefit payment or March 15, 2020, whichever is most recent. You may not receive EI benefits and the Canada Emergency Response Benefit for the same period.

 I was laid-off from my work prior to March 15, 2020 for reasons not related to COVID-19 and I have exhausted my EI regular benefits, but I am unable to find work due to COVID-19—am I eligible for the CERB?

Yes. You are eligible for the Canada Emergency Response Benefit if you are a former Employment Insurance claimant who used up your entitlement to your Employment Insurance regular benefits between December 29, 2019 and October 3, 2020, and are unable to find work due to COVID-19.

The date for which you would potentially become eligible for the Canada Emergency Response Benefit would be the week following your last Employment Insurance benefit payment or March 15, 2020, whichever is most recent. You may not receive EI benefits and the Canada Emergency Response Benefit for the same period.

Are individuals who are part of work-sharing agreements eligible for the CERB?

No. Individuals who are part of work-sharing agreements are not eligible as you cannot be getting Employment Insurance Benefits and the Canada Emergency Response Benefit at the same time.

Employers and workers can continue to enter into Work-Sharing agreements. The Canada Emergency Response Benefit has no impact on claims subject to Work-Sharing agreements. These claims continue to be processed using the standard rules for calculating Work-Sharing benefits.

Are individuals who are working while on claim eligible for the CERB if they lose their jobs for reasons related to COVID-19?

You cannot be paid Employment Insurance benefits as part of working while on claim and the Canada Emergency Response Benefit for the same period.

However, if you lose your job for reasons related to COVID-19 you will no longer be eligible for working while on claim. You may be eligible for the Canada Emergency Response Benefit provided you meet the eligibility criteria.

I am a fisher who received Employment Insurance fishing benefits over the off-season and I have just exhausted my benefit entitlement, but I am unable to find work due to COVID-19—am I eligible for the Canada Emergency Response Benefit?

If a self-employed fisher does not meet the criteria to establish a new EI fishing benefits claim, or if they have exhausted their EI fishing benefits between December 29, 2019 and October 3, 2020, and are unable to work due to COVID-19, they may be eligible for the Canada Emergency Response Benefit, provided they meet the eligibility criteria.

You may not receive Employment Insurance benefits (including fishing benefits) and the Canada Emergency Response Benefit for the same period.

Can employers use a Supplemental Unemployment Benefit (SUB) plan to increase their employee’s weekly earnings while they are unemployed and collecting the Canada Emergency Response Benefit?

Given the simplified design of the Canada Emergency Response Benefit (CERB), the provisions that exist under the Employment Insurance (EI) system for employers to make additional payments to workers through SUB plans do not apply to employees who are receiving the CERB. However, eligible individuals collecting the CERB and receiving $2,000 for a 4-week period may earn up to $1,000 in employment and/or self-employment income in each of their benefit periods from March 15, 2020 to October 3, 2020 while continuing to receive the CERB. This represents 50% of the amount of the benefit. Employers who wish to increase their employees weekly earnings while they are unemployed have the flexibility to top-up CERB benefits up to this amount in lieu of a SUB plan. However, individuals who receive income from employment, including top-ups, in excess of $1,000 over each 4-week period for which they claim the CERB would have to repay CERB amounts they received for the same benefit period.

Employers that wish to do so may continue to submit a SUB plan to Service Canada. By registering a plan, employers can make payments to employees who are currently receiving EI regular or sickness benefits, and will also be prepared should employees need EI benefits at a future time.

Eligible employers may also choose to claim the Canada Emergency Wage Subsidy (CEWS) which provides a subsidy of 75% of employee wages, up to a maximum of $847. To the extent that they can, employers are encouraged to continue to pay employees their normal salaries if it is above the amount supported through the CEWS.

## Page details

Date modified:
:   2022-08-02

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
