---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html
scraped_at: 2025-08-24 20:14:58
filename: en/services/benefits/ei/ei-regular-benefit/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-reguliere/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Regular Benefits](/en/services/benefits/ei/ei-regular-benefit.html)

# EI regular benefits: How much you could receive

# EI regular benefits

* [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html)
* [How much you could receive](#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html) [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html)
* [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html) [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)
* [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html) [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html)

# How much you could receive

## On this page

* [You could get up to 55% of your earnings](#h2.01)
* [You can get benefits for up to a maximum of 45 weeks](#h2.02)
* [How we calculate your weekly benefit amount](#h2.03)
* [If your net family income is $25,921 or less](#h2.04)
* [Taxes are deducted from EI payments](#h2.05)
* [Estimate your benefits](#h2.06)

## You could get up to 55% of your earnings

We can't tell you exactly how much you'll receive before we process your application. For most people, the basic rate for calculating Employment Insurance (EI) benefits is 55% of their average **insurable weekly earnings**, up to a maximum amount. As of January 1, 2025, the maximum yearly insurable earnings amount is $65,700. This means that you can receive a maximum amount of $695 per week.

**Insurable earnings** include most of the different types of compensation from employment, such as wages, tips, bonuses and commissions. The Canada Revenue Agency (CRA) determines what [types of earnings](/en/revenue-agency/services/tax/canada-pension-plan-cpp-employment-insurance-ei-rulings/cpp-ei-explained/canada-pension-plan-employment-insurance-explained-10.html) are insurable.

## You can get benefits for up to a maximum of 45 weeks

You can receive EI from 14 weeks up to a maximum of 45 weeks, depending on the [rate of unemployment in your region](http://srv129.services.gc.ca/eiregions/eng/postalcode_search.aspx) at the time of filing your claim and the number of insurable hours you've accumulated in the last 52 weeks or since your last claim, whichever is shorter.

### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

**Seasonal workers**

If you’re a seasonal worker, you may be eligible for [additional weeks of regular benefits](/en/employment-social-development/corporate/portfolio/service-canada/ei-seasonal-workers.html), up to a maximum of 45 weeks.

**Number of weeks of EI regular benefits payable by regional rate of unemployment**

| Number of hours of insurable employment | 6% and less | 6.1%  to  7.0% | 7.1%  to  8.0% | 8.1%  to  9.0% | 9.1%  to  10.0% | 10.1%  to  11.0% | 11.1%  to  12.0% | 12.1%  to  13.0% | 13.1%  to  14.0% | 14.1%  to  15.0% | 15.1%  to  16.0% | 16% and more |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 420 to 454 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 26 | 28 | 30 | 32 |
| 455 to 489 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 24 | 26 | 28 | 30 | 32 |
| 490 to 524 | 0 | 0 | 0 | 0 | 0 | 0 | 23 | 25 | 27 | 29 | 31 | 33 |
| 525 to 559 | 0 | 0 | 0 | 0 | 0 | 21 | 23 | 25 | 27 | 29 | 31 | 33 |
| 560 to 594 | 0 | 0 | 0 | 0 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 |
| 595 to 629 | 0 | 0 | 0 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 |
| 630 to 664 | 0 | 0 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 |
| 665 to 699 | 0 | 15 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 |
| 700 to 734 | 14 | 16 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 |
| 735 to 769 | 14 | 16 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 |
| 770 to 804 | 15 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 |
| 805 to 839 | 15 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 |
| 840 to 874 | 16 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 |
| 875 to 909 | 16 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 |
| 910 to 944 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 |
| 945 to 979 | 17 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 |
| 980 to 1,014 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 |
| 1,015 to 1,049 | 18 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 |
| 1,050 to 1,084 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 |
| 1,085 to 1,119 | 19 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 |
| 1,120 to 1,154 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 |
| 1,155 to 1,189 | 20 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 |
| 1,190 to 1,224 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 |
| 1,225 to 1,259 | 21 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 |
| 1,260 to 1,294 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 |
| 1,295 to 1,329 | 22 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 |
| 1,330 to 1,364 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 |
| 1,365 to 1,399 | 23 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 |
| 1,400 to 1,434 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 | 45 |
| 1,435 to 1,469 | 25 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 | 45 |
| 1,470 to 1,504 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 | 45 | 45 |
| 1,505 to 1,539 | 27 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 | 45 | 45 |
| 1,540 to 1,574 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 | 45 | 45 | 45 |
| 1,575 to 1,609 | 29 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 | 45 | 45 | 45 |
| 1,610 to 1,644 | 30 | 32 | 34 | 36 | 38 | 40 | 42 | 44 | 45 | 45 | 45 | 45 |
| 1,645 to 1,679 | 31 | 33 | 35 | 37 | 39 | 41 | 43 | 45 | 45 | 45 | 45 | 45 |
| 1,680 to 1,714 | 32 | 34 | 36 | 38 | 40 | 42 | 44 | 45 | 45 | 45 | 45 | 45 |
| 1,715 to 1,749 | 33 | 35 | 37 | 39 | 41 | 43 | 45 | 45 | 45 | 45 | 45 | 45 |
| 1,750 to 1,784 | 34 | 36 | 38 | 40 | 42 | 44 | 45 | 45 | 45 | 45 | 45 | 45 |
| 1,785 to 1,819 | 35 | 37 | 39 | 41 | 43 | 45 | 45 | 45 | 45 | 45 | 45 | 45 |
| 1,820 and more | 36 | 38 | 40 | 42 | 44 | 45 | 45 | 45 | 45 | 45 | 45 | 45 |

The number of weeks for which you may receive benefits doesn’t change if you move to another region after your benefit period begins.

## How we calculate your weekly benefit amount

The amount of weekly benefits is calculated as follows:

* we calculate your total insurable earnings for the required number of best weeks (the weeks that you earned the most money, including insurable tips and commissions) based on the information you provide or your record of employment (ROE)
* we determine the divisor (number of best weeks) that corresponds to your regional rate of unemployment
* we divide your total insurable earnings for your best weeks by your required number of best weeks
* we then multiply the result by 55% to obtain the amount of your weekly benefits

In regions of Canada with the highest rates of unemployment, we’ll calculate using the best 14 weeks. In regions of Canada with the lowest rates of unemployment, we’ll use the best 22 weeks. In other regions, the number of weeks used to calculate benefits will be somewhere between 14 and 22, depending on the rate of unemployment in those regions.

### Calculation

* Total insurable earnings for the required number of best weeks
* divided by  required number of best weeks
* times by  55 %
* ---

  equals  weekly EI benefit rate (maximum $695)

**Required number of best weeks by regional rate of unemployment**

| Regional rate of unemployment | Required weeks |
| --- | --- |
| 6% or less | 22 |
| 6.1% to 7% | 21 |
| 7.1% to 8% | 20 |
| 8.1% to 9% | 19 |
| 9.1% to 10% | 18 |
| 10.1% to 11% | 17 |
| 11.1% to 12% | 16 |
| 12.1% to 13% | 15 |
| 13.1% or more | 14 |

To find out the rate of unemployment in your region, visit [EI Program Characteristics](http://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx).

Once the weekly benefit rate is established, it will remain unchanged over the life of your claim.

## If your net family income is $25,921 or less

If your net family income doesn’t exceed $25,921 per year, you have children and you or your spouse receive the Canada Child Benefit, you’re considered a member of a low-income family. Therefore, you may be eligible to receive the EI family supplement.

The family supplement rate is based on:

* your net family income up to a maximum of $25,921 per year
* the number of children in the family and their ages

The family supplement may increase your benefit rate up to 80% of your average insurable earnings. If you and your spouse claim EI benefits at the same time, only 1 of you can receive the family supplement. It is generally better for the spouse with the lower benefit rate to receive the supplement.

As your income level rises, the Family Supplement gradually decreases, so that when the maximum income of $25,921 is reached no supplement is payable.

## Taxes are deducted from EI payments

EI benefits are taxable, no matter what type of benefits you receive. Federal and provincial or territorial taxes, where applicable, will be deducted from your payment.

## Estimate your benefits

Try the [EI Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) before you apply to check if these benefits are right for you and how much you could receive.

## Document navigation

* [Previous - Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html)
* [Next - Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
