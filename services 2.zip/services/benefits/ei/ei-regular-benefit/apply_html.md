---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-regular-benefit/apply.html
scraped_at: 2025-08-24 19:37:31
filename: en/services/benefits/ei/ei-regular-benefit/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-reguliere/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Regular Benefits](/en/services/benefits/ei/ei-regular-benefit.html)

# EI regular benefits: Apply

# EI regular benefits

* [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html) [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)
* [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html) [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html)

# Apply

## On this page

* [Prepare to apply](#h2.01)
* [Sign up for direct deposit](#h2.02)
* [Apply online](#h2.03)

## Prepare to apply

**Complete and submit your online application right away.** If you apply for Employment Insurance (EI) more than 4 weeks after your last day of work, you may lose benefits.

When you apply, you'll need:

* your social insurance number (SIN)
* + if your SIN begins with a 9, you need to supply proof of your immigration status and work permit
* the last name at birth of one of your parents
* your mailing and residential addresses, **including the postal codes**
* your banking information to sign up for direct deposit, including:
* + financial institution name
  + bank branch (transit) number
  + account number
* details about all employment in the past 52 weeks or since the start of your last claim, whichever is shorter. This includes:
* + employer names
  + addresses
  + dates of employment
  + reason for separation (if you quit or were dismissed, you will need to provide your version of the facts)
* **Note:** We will need your [records of employment](/en/services/benefits/ei/ei-regular-benefit/after-applying.html#h2.03) (ROEs) from each employer to determine your eligibility.

### You are ready to apply

### Don't wait to apply

You can send required documents after you apply.

### If you applied for EI benefits in the past year

If you started a new EI claim within the last 52 weeks and there are still weeks payable on that claim, **we'll automatically reactivate (renew) your existing claim when you submit your application**.

If your claim is reactivated, and you work after the start of that claim, you may be able to establish a new claim when your existing claim runs out.

In some cases, it may be to your advantage to cancel or end your old claim and start a new claim, because this may increase the amount of your benefits or the length of your benefit period.

It is important to consider:

* in order to establish a new claim, you must meet the [qualifying conditions](/en/services/benefits/ei/ei-regular-benefit/eligibility.html)
* if a new claim is established instead of reactivating your existing claim, the remaining weeks payable on the existing claim will be lost
* additionally, a 1-week unpaid waiting period must be served on a new claim before you're entitled to receive payment

#### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

### If we reactivate your existing claim

You may also have to provide the following details:

* the salary amount you received, before deductions, for the last week you worked (from Sunday to your last day of work), including insurable tips and commissions
* any other amount you received or will receive, such as:
  + vacation pay
  + severance pay
  + pension payments
  + pay in lieu of notice
  + other money

## Sign up for direct deposit

When you apply for EI benefits, be sure to **sign up for** direct deposit to get your payments deposited automatically into your bank account 2 business days after we process your [EI report](/en/services/benefits/ei/employment-insurance-reporting.html).

## Apply online

To find out if you're eligible to receive EI regular benefits, you must submit an application. The online application takes about 1 hour to complete.

If you don't complete the application all at once, you can come back to it later using the temporary password that you receive when you start.

Your information is saved for 72 hours (3 days) from the time you start. If you don't submit the application within this time:

* it will be deleted, and
* you'll have to start a new application

When you apply for EI benefits, we’ll ask for your email address. We may send you an email to provide you with information or ask you to call us if we can't reach you by phone.

Please note that we won’t ask you to send us information by email.

[Apply](/en/services/benefits/apply-privacy.html)

## Document navigation

* [Previous - How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html)
* [Next - After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
