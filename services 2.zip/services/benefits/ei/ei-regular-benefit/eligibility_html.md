---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-regular-benefit/eligibility.html
scraped_at: 2025-08-24 17:28:15
filename: en/services/benefits/ei/ei-regular-benefit/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-reguliere/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Regular Benefits](/en/services/benefits/ei/ei-regular-benefit.html)

# EI regular benefits: Do you qualify

# EI regular benefits

* [Do you qualify](#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html) [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html)
* [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html) [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)
* [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html) [While on EI](/en/services/benefits/ei/ei-regular-benefit/while-receiving.html)
* [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html)

# Do you qualify

## On this page

* [Eligibility criteria](#h2.01)
* [Eligibility for specific work situations](#h2.02)
* [Situations where you may not be eligible](#h2.03)
* [You need to have worked enough hours to be eligible](#h2.04)
* [Find other types of benefits](#h2.05)

The information below should be used as a guideline. We encourage you to apply for Employment Insurance (EI) benefits as soon as possible and let us determine if you're eligible.

## Eligibility criteria

To receive EI regular benefits, you need to demonstrate that you:

* were employed in insurable employment
* lost your job through no fault of your own
  + are affected by [flooding or wildfires](/en/employment-social-development/corporate/notices/hazardous-weather.html)
* have been without work and without pay for at least 7 consecutive days in the last 52 weeks
* have worked for the required number of insurable employment hours in the last 52 weeks or since the start of your last EI claim, whichever is shorter
* are ready, willing and capable of working each day
* are actively looking for work (you must keep a written record of employers you contact, including when you contacted them)

To prove your eligibility and to receive payments you may be entitled to, you're required to complete bi-weekly reports by [internet](/en/services/benefits/ei/employment-insurance-reporting.html#Internet-Reporting-Service) or [telephone](/en/services/benefits/ei/employment-insurance-reporting.html#Telephone-Reporting-Service). Failure to do so can mean a loss of benefits.

## Eligibility for specific work situations

You may still qualify for benefits, even if you work for an employer who is related to you.

Refer to the following links for eligibility information for these specific situations:

* [EI benefits and farmers](/en/services/benefits/ei/ei-farmers.html)
* [EI benefits and fishers](/en/services/benefits/ei/ei-fishing.html)
* [EI benefits and teachers](/en/services/benefits/ei/ei-teachers.html)
* [EI benefits for apprentices](/en/services/jobs/training/support-skilled-trades-apprentices/ei-apprentices.html)
* [EI benefits and Canadian Force Members](/en/services/benefits/ei/ei-military-families.html)
* [Special benefits for self-employed people](/en/services/benefits/ei/ei-self-employed-workers.html)
* [EI benefits for workers and residents outside of Canada](/en/services/benefits/ei/ei-outside-canada.html)

## Situations where you may not be eligible

* if you [voluntarily left your job](/en/employment-social-development/programs/ei/ei-list/quit-job.html) without just cause
* if you were [dismissed for misconduct](/en/employment-social-development/programs/ei/ei-list/fired-misconduct.html)
* if you're unemployed because you're directly participating in a labour dispute (for example, a strike, lockout or other type of conflict)
* during a period of leave that compensates for a period in which you worked under an agreement with your employer, more hours than are normally worked in full-time employment

### COVID-19 vaccination

In most cases, if you lose or quit your job because you didn't comply with your employer's mandatory COVID-19 vaccination policy, you won't be eligible for EI regular benefits. To determine if you're eligible, we may contact you to obtain information such as:

* if your employer clearly communicated a mandatory COVID‑19 vaccination policy to you
* if you were informed that not complying with the policy would result in you losing your employment
* if applying the policy to you was reasonable within your workplace context
* if you have a valid reason for not complying with the policy and your employer didn't provide you an exemption

We'll use the facts provided by you and your employer to determine if you're entitled to benefits.

### If you're in jail

You're **not** entitled to receive EI benefits while you're confined to a jail, penitentiary or other similar institution.

If you've been incarcerated but are later **found not guilty** by a court of law on all counts in relation to the event that led to your incarceration, your qualifying period and benefit period may be extended upon providing necessary proof.

Once you've applied for EI benefits, you'll be asked to provide us with proof that you were confined to a jail, penitentiary or other similar institution and that you were not found guilty of the offence(s) from the event(s) for which you were being held.

For a qualifying period or benefit period to be extended, you'll be asked to submit the following documents:

* a letter from the institution where you were incarcerated, specifying the dates of your incarceration
* documentation showing that no other outstanding charge(s) in relation to the event(s) that originally led to the incarceration exist, to confirm the time served is not being credited to any other charge(s) in relation to the original event or any other subsequent event
* proof that you have not been found guilty of the charge(s) from the original event that led to your incarceration

Keep these documents in a safe place. We'll contact you and provide you with instructions on how to submit them.

## You need to have worked enough hours to be eligible

Based on the rate of unemployment in your region, you'll need between 420 and 700 hours of insurable employment during the qualifying period to qualify for regular benefits.

### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

### Qualifying period

The qualifying period is the shorter of:

* the 52-week period immediately before the start date of your claim, or
* the period from the start of a previous benefit period to the start of your new benefit period, if you applied for benefits earlier and your application was approved in the last 52 weeks

**Exception**: In some cases, the qualifying period may be extended to a maximum of 104 weeks if you weren’t employed in insurable employment or if you weren’t receiving EI benefits.

### Determine how many hours you need

The rate of unemployment in your region determines how many hours you need to qualify.

[Look up EI Economic Region by Postal Code](http://srv129.services.gc.ca/ei_regions/eng/postalcode_search.aspx) to find out the rate of unemployment in your region and the number of hours to qualify for regular benefits.

#### If you received a notice of violation

If you received a notice of violation regarding prior EI benefit periods, the number of insurable hours required to qualify is increased.

#### Number of insurable hours required to qualify for EI benefits

Number of insurable hours required to qualify for EI benefits

| Regional rate of unemployment | Without violation | Minor violation | Serious violation | Very serious violation | Subsequent violation |
| --- | --- | --- | --- | --- | --- |
| 6% and under | 700 | 875 | 1,050 | 1,225 | 1,400 |
| 6.1% to 7% | 665 | 831 | 998 | 1,164 | 1,330 |
| 7.1% to 8% | 630 | 788 | 945 | 1,103 | 1,260 |
| 8.1% to 9% | 595 | 744 | 893 | 1,041 | 1,190 |
| 9.1% to 10% | 560 | 700 | 840 | 980 | 1,120 |
| 10.1% to 11% | 525 | 656 | 788 | 919 | 1,050 |
| 11.1% to 12% | 490 | 613 | 735 | 858 | 980 |
| 12.1% to 13% | 455 | 569 | 683 | 796 | 910 |
| More than 13% | 420 | 525 | 630 | 735 | 840 |

## Find other types of benefits

Are EI regular benefits not applicable to you? Use the [Benefits Finder](http://www.canadabenefits.gc.ca/) to find other Government of Canada, provincial, or territorial benefits.

## Document navigation

* [Previous - What these benefits offer](/en/services/benefits/ei/ei-regular-benefit.html)
* [Next - How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html)

## Page details

Date modified:
:   2025-08-18

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
