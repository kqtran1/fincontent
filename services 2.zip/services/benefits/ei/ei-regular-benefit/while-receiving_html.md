---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-regular-benefit/while-receiving.html
scraped_at: 2025-08-24 17:56:48
filename: en/services/benefits/ei/ei-regular-benefit/while-receiving_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-reguliere/pendant-que-vous-recevez.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Regular Benefits](/en/services/benefits/ei/ei-regular-benefit.html)

# EI regular benefits: While on EI

# EI regular benefits

* [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-regular-benefit/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-regular-benefit/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html) [Apply](/en/services/benefits/ei/ei-regular-benefit/apply.html)
* [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html) [After you apply](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)
* [While on EI](#gc-document-nav)
* [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html)

# While on EI

## On this page

* [Continue to submit your biweekly reports](#h2.01)
* [Situations that may impact your benefits](#h2.02)
* [When payments stop](#h2.03)
* [You can receive different types of benefits one after the other](#h2.04)
* [If you’re not well, someone else can manage your benefits for you](#h2.05)
* [Requesting EI benefits on behalf of a deceased person](#h2.06)
* [Work-Sharing](#h2.07)
* [Situations where you may owe money](#h2.08)
* [Your rights and responsibilities while receiving EI benefits](#h2.09)
* [Your employer may be notified of our decision](#h2.10)
* [Service Canada's responsibilities](#h2.11)

## Continue to submit your biweekly reports

You must submit reports every 2 weeks for as long as you receive Employment Insurance (EI) benefits. They help show your ongoing eligibility and make sure you get the benefits to which you're entitled.

You'll need your social insurance number and the 4-digit access code we mailed you to submit your reports [by internet](/en/services/benefits/ei/employment-insurance-reporting.html#Internet-Reporting-Service) or [by phone](/en/services/benefits/ei/employment-insurance-reporting.html#Telephone-Reporting-Service).

Once you submit your report, we’ll tell you when to complete your next one. You have 3 weeks from that date to submit the report.

[Submit your report](https://srv265.hrdc-drhc.gc.ca/interdec/ouverturedesession-login/ouverturedesession-login.aspx?lang=en)

## Situations that may impact your benefits

### Earning money while receiving EI benefits

If you work or earn money, you must indicate it on your report. If you don't inform Service Canada, you risk being [overpaid](/en/employment-social-development/programs/ei/ei-list/overpayments.html) and having to repay benefits.

You'll be able to keep 50 cents of your EI benefits for every dollar you earn, up to 90% of the weekly insurable earnings used to calculate your EI benefit amount, if you work while receiving regular benefits and have served your waiting period.

### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

If you earn any money above this 90%, we'll deduct it dollar for dollar from your benefits.

For more information, visit the [Working While on Claim](/en/employment-social-development/programs/ei/ei-list/working-while-claim.html) page.

When you work and receive benefits at the same time, you must [report](/en/services/benefits/ei/employment-insurance-reporting.html) your work earnings and hours for each week you work, in the week in which the work occurred.

If you receive other payments while receiving EI, some [types of earnings](/en/services/benefits/ei/various-types-earnings.html) will be deducted from your EI benefits, while other types of income have no impact on your EI benefits. You can refer to the [earnings chart](/en/services/benefits/ei/earnings-chart.html) to find out if a payment constitutes earnings for benefit purposes and, if so, how those earnings are allocated.

### If you travel outside of Canada

You’re not usually eligible to receive regular benefits while you’re away from Canada. However, you may receive regular benefits if you show that you’re available for work in Canada while abroad. You must also notify us of your travel on [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) or through your biweekly report.

You can be outside Canada for a period of 7 consecutive days for the purpose of:

* attending the funeral of a member of your immediate family or a close relative
* accompanying a member of your immediate family to a medical facility, provided that the treatment sought is not readily available in the family member's area of residence in Canada
* visiting a member of your immediate family who is seriously ill or injured
* attending a bona fide job interview

You can be away from Canada for a period of 14 consecutive days for the purpose of conducting a bona fide job search.

If you indicate that you’ve taken measures to be reached if an employment opportunity presents itself during your absence and that you’re able to return to Canada within 48 hours, we’ll accept that you’ve proven your availability.

One measure we take to enforce this rule is to compare EI information with information from the Canada Border Services Agency. If we find you’ve been out of the country while collecting benefits, we’ll determine whether you were entitled to receive those benefits. If you weren’t entitled to receive them, we’ll calculate how much we overpaid you, and you’ll then have to repay the benefits.

We may also impose penalties of up to 3 times your weekly benefit rate or 3 times the amount of your overpayment. As well, you may have to work more hours or, in the case of fishing benefits, you may need more insurable earnings to qualify for benefits in the future.

## When payments stop

You stop receiving benefits if:

* you receive all the weeks of benefits to which you were entitled
* the payment timeframe during which you can receive benefits ends
* you stop filing your biweekly report
* you request a termination of your claim to file a new claim

If you start working before you finish your current EI claim, you must tell us when you complete your [EI report](/en/services/benefits/ei/employment-insurance-reporting.html) so we can adjust or stop your claim, depending on whether the work is full-time, part-time or by contract. If the work is short-term or a contract, you may re-activate your EI claim and continue to receive your biweekly payments when you’re laid off.

## You can receive different types of benefits one after the other

You can normally receive up to 50 weeks of benefits when regular benefits are combined with maternity, parental, sickness or caregiving benefits in the same benefit period (of 52 weeks).

The only exception is when EI regular benefits and extended parental benefits are paid during the 52-week period. As extended parental benefits are paid at a benefit rate of 33% of your average weekly insurable earnings, once 50 weeks of benefits have been paid, the weeks of extended parental benefits will be converted to an equivalent number of weeks that would have been paid at the 55% benefit rate. This conversion will determine how many more weeks of regular benefits and special benefits can be paid to reach the equivalent of 50 weeks paid at the 55% benefits rate. Any weeks where you return to work during this period will be considered weeks paid for the purposes of calculating the equivalent of 50 weeks paid at the 55% benefit rate. Once the number of additional weeks that can be paid is determined, the 52-week benefit period will be extended to allow for the additional weeks to be paid.

It's important to note that you can’t receive more than 1 type of benefit at the same time.

## If you’re not well, someone else can manage your benefits for you

If you’re unable to manage your own affairs due to health problems, a person other than an Employment and Social Development Canada employee may be appointed to act on your behalf. In that case, the form [Appointment of Representative](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS3280) must be completed and returned with your EI application.

If you’re eligible for EI, we’ll authorize the payment of benefits to the representative acting on your behalf.

## Requesting EI benefits on behalf of a deceased person

When a person dies, EI benefits payable to that person up to and including the day of the death may be paid to the legal representative  [Footnote 1](#fn1) , or to a person authorized to inherit property of the deceased person.

If the deceased person had not applied for EI benefits, the legal representative must do the following, **in the name of the deceased person**, before benefits can be paid:

* [apply for benefits](/en/services/benefits/ei/ei-regular-benefit/apply.html) in the name of the deceased person
* complete the form [Request for Payment of Benefit on Behalf of a Deceased Person](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS2882)
* provide a death certificate issued by the province or territory, a certificate from the director of a funeral home or an administrator of a hospital or clinic, or a letter from a physician, graduate nurse, or member of the clergy

If the deceased person was receiving EI benefits before death, the legal representative must complete the form [Request for Payment of Benefit on Behalf of a Deceased Person](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS2882) to cancel these benefits.

If EI benefits are paid after the death of someone in your family, the legal representative must repay the overpayment by making a cheque or money order to the Receiver General for Canada and sending it to the [nearest overpayment recovery office](/en/employment-social-development/programs/ei/ei-list/overpayments/repayments.html).

It is important to [notify the federal government of a death](/en/services/death/notify.html) as quickly as possible to avoid overpayment of other benefit types.

## Work-Sharing

The [EI Work-Sharing Program](/en/employment-social-development/services/work-sharing.html) assists employers and employees facing lay-offs due to a decline in production. With the Work-Sharing agreement, available work is redistributed through a voluntary reduction in hours worked by all employees within 1 or more work units. This enables the employer to retain a full work force on a reduced work week, rather than laying off part of his or her work force. Employees are able to remain on the job and maintain skills and working habits and avoid uncertainties and hardship associated with total unemployment

## Situations where you may owe money

Deductions can never be taken for money owed directly to a person or company. However, deductions can be taken from your EI benefits to repay money you owe, **if**:

* you received an [overpayment from EI](/en/employment-social-development/programs/ei/ei-list/overpayments.html)
* you received an advance or assistance from the Government of Canada or any of its agencies, a provincial or municipal government, or any other authority **and** an arrangement has been taken with EI for the deduction. Your consent must be given in writing to the deduction and payment by EI. Example: you received an [advance from a Social Services agency](/en/employment-social-development/programs/ei/ei-list/reports/social-assistance.html) while waiting for your EI benefits to start
* the Department of Justice issued a court order, according to the [*Family Orders and Agreements (FOA) Enforcement Assistance Act*](http://laws.justice.gc.ca/eng/acts/F-1.4/). Your EI benefits are garnished and forwarded to the Department of Justice that ensures payment to your spouse or dependents, according to the existing court order
* the Canada Revenue Agency (CRA) may collect taxes owing according to the [*Income Tax Act*](http://laws-lois.justice.gc.ca/eng/acts/I-3.3/), the [*Excise Tax Act*](http://laws-lois.justice.gc.ca/eng/acts/E-14/) or other provisions enforced by the CRA. Any taxes owing to federal or provincial governments may be garnished from your EI benefits

### A mistake on your EI report can affect your claim

We work to protect the EI program from misuse. One of the ways we do this is by working with employers and claimants to ensure the accuracy of the information we receive. With your help, we can reduce the amount of misuse and ensure that the EI program is used as it should be — as a program that provides temporary financial assistance to individuals who qualify.

A mistake is an unintentional act. We know claimants can make mistakes when filing their reports.

Common mistakes include:

* estimating weekly earnings instead of putting in the actual amount earned
* declaring net earnings instead of gross earnings
* forgetting to declare all the earnings received
* writing or entering the wrong number when reporting earnings, or
* adding the number of hours or amount of earnings incorrectly

Some mistakes can delay benefit payments, while others can affect the amount of benefits you receive — meaning you were paid more or less than you were entitled to receive.

Estimating your earnings can have the following effects:

* if you estimated your earnings for 1 week and your estimate was higher than the earnings you actually received, your benefit amount will be less than it should have been. If this happens, let us know and we’ll adjust your file to make sure you receive all the benefits to which you’re entitled
* if you estimated your earnings for 1 week and your estimate was lower than the earnings you actually received, your benefit amount will be higher than it should have been. Let us know if this happens. You’ll have to repay the excess amount, but we’ll ensure that repaying it causes no undue hardship. As well, we’ll adjust your file to reflect your accurate information

If you notice a mistake on a completed form or report, or if there is a change in your circumstances that could affect your EI claim, tell Service Canada immediately. This will help prevent any future problems with your claim.

### You may be penalized if you make a false statement related to your claim

A misrepresentation occurs when someone knowingly completes a statement without declaring, makes false or misleading representations or statements, or misrepresents facts to make a false claim for benefits. You could face severe monetary penalties or prosecution in these cases. However, if you disclose your actions to Service Canada before an investigation begins, we may waive any monetary penalties and prosecutions that might otherwise apply.

Here is an example of a situation where penalties may be imposed:

An EI benefit claimant goes on an ocean cruise for a month and arranges for a friend to conceal their absence by signing and returning 2 EI reports. As a result, the claimant illegally received $350 in benefits for each of the 4 weeks of the cruise. After investigation, we find that this was the first time the claimant and the friend had misused the EI system. As well, we find that they both knew that what they did was illegal but they did it anyway.

In this case, the claimant will have to repay $1,400 (4 weeks of benefits at $350 per week) and may have to pay a penalty of $700 ($350 for each of the 2 false reports filed during the holiday). The friend may also have to pay a penalty of $700 for the illegal act of filing 2 false reports on behalf of the claimant.

There are many situations when a penalty may apply, and the amount could become very high. Depending on the circumstances, the maximum penalty could be up to 3 times the amount of the overpayment, 3 times the weekly benefit rate for each incident of misrepresentation, or 3 times the maximum benefit rate. This could also affect your future benefits.

### If you receive more than you're entitled to, you’ll have a debt to repay

When EI claimants receive benefits to which they are not entitled, the amount of the overpayment counts as a debt that must be repaid.

We charge interest on this debt when it results from claimants who knowingly withhold information or make false or misleading representations or statements. However, we do not charge interest on debt that results when we make an error in the benefit payment.

The rate of interest is the Bank of Canada average rate plus 3%. Interest is calculated daily and compounded monthly.

## Misusing the EI program may affect your future claims

Claimants who misused the EI program and were assessed a violation may need more insurable earnings or hours to qualify for benefits in the future. The required amount rises based on the number and seriousness of misrepresentations that have been recorded in the 5-year period before the start of their claims.

## Your rights and responsibilities while receiving EI benefits

The EI program guarantees certain rights. There are also some basic responsibilities, for both you and Service Canada.

**You have the right to:**

* file a claim for EI benefits
* receive any benefits that are owing to you
* [request a reconsideration](/en/services/benefits/ei/ei-reconsideration.html) of any decisions we make about your benefits that you find unsatisfactory
* see any government record that contains your personal information, and
* be served in the official language of your choice

Your **responsibilities** include:

* be capable of and available for work and unable to obtain suitable employment
* actively search for and accept offers of suitable employment. For further information on what constitutes [suitable employment](/en/services/benefits/ei/suitable-employment.html), visit the Employment Insurance section of the Canada.ca website
* conduct job search activities that increase your opportunities to find suitable employment, such as:

+ assessing employment opportunities
+ preparing a résumé or cover letter
+ registering for job search tools or with electronic job banks or employment agencies
+ attending job search workshops or job fairs
+ networking
+ contacting prospective employers
+ submitting job applications
+ attending interviews
+ undergoing evaluations of competencies

* keep a detailed record as proof of your job search efforts to find suitable employment as we may ask you to provide that proof at any time. Therefore, you must keep your job search record for 6 years
* you **aren't** required to have employers sign your job search form or provide you with a letter confirming that you've applied for a job
* let us know when you refuse any offers of employment
* report all periods when you're not available for work
* keep your appointments with our office
* notify us of any separation from employment and the reasons for the separation
* accurately report all periods of incapacity
* obtain a medical certificate that confirms the duration of your incapacity
* provide all other required information and documents
* report any absences from your area of residence or any absence from Canada
* report all employment, whether you work for someone else or for yourself
* accurately report all employment earnings before deductions, in the week(s) in which they were earned, as well as any other monies you may receive

## Your employer may be notified of our decision

If we decide to pay you benefits even if you quit, were fired for misconduct, refused work, or are involved in a labour dispute, we'll notify your employer. If an employer believes that our decision is not justified, they can request a [reconsideration of that decision](/en/services/benefits/ei/ei-reconsideration.html).

## Service Canada's responsibilities

At Service Canada, we're responsible for:

* giving you prompt and courteous service
* advising you of the programs and services that are available to you
* serving you in the official language of your choice
* determining if you're eligible to receive benefits — that is, whether or not you meet the qualifying conditions specified in the *Employment Insurance Act* and Regulations — and determining how many weeks of benefits you can receive
* processing all claims within the same timeframe
* issuing your first payment no later than 28 days after the date we receive your application, if you've provided us with all the required information and if you're eligible for benefits
* giving you accurate information about your claim, including how you can share parental benefits with your EI-eligible spouse or partner, compassionate care or family caregiver benefits with other EI-eligible family members, and whether or not you will need to serve a one-week waiting period
* letting you know about decisions we've made about your claim and explaining the process to follow if you disagree with a decision

## Footnotes

Footnote 1
:   **Legal representative**

    * If the deceased person left a court-approved will (a testamentary estate), the executor appointed in the will is considered as the legal representative. In Quebec, a notarized will does not have to be court-approved
    * If the deceased person did not leave a will (an intestate estate), but the court appointed an administrator of the estate by way of letters of administration, the administrator is considered the legal representative
    * If the total value of the estate is not large enough to justify obtaining an order or probate of the will, one of the persons authorized to inherit property of the deceased person may ask for the payment of benefits in the name of the deceased person

    [Return to footnote 1 referrer](#fn1-ref)

### Document navigation

* [Previous - After you've applied](/en/services/benefits/ei/ei-regular-benefit/after-applying.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
