---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-fishing/apply.html
scraped_at: 2025-08-24 18:18:04
filename: en/services/benefits/ei/ei-fishing/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-pecheur/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Fishing benefits - Overview](/en/services/benefits/ei/ei-fishing.html)

# EI fishing benefits - Apply

# EI fishing benefits

* [What these benefits offer](/en/services/benefits/ei/ei-fishing.html)[What these benefits offer](/en/services/benefits/ei/ei-fishing.html)
* [Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)[Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)[After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)

# Apply

## What you need before you start

To receive fishing benefits, you must submit an Employment Insurance (EI) application **online**. You'll need the following information:

* your social insurance number (SIN)
  + if your SIN begins with a "9," you'll need to supply proof of your immigration status and work permit
* date of birth
* the last name at birth of 1 of your parents
* your mailing and residential addresses, **including the postal codes**
* the names and addresses of all buyers of your catch and employers
* dates for the periods you were engaged in self-employed fishing and other periods of employment
* reasons for separation from any employment, including self-employment in fishing, for the last 52 weeks
* your complete banking information, including:
  + your financial institution name
  + your branch number
  + your account number

## Apply

You should apply no later than 4 weeks after:

* your last day of work
* the end date of your fishing trip, or
* the date you sold your catch to a buyer

You may lose benefits if you are late applying for benefits.

To apply for EI fishing benefits, you must submit an application online.

The online application takes about 1 hour to complete.

If you don't complete the application all at once, you can come back to it later using the temporary password that you receive when you start.

Your information is saved for 72 hours (3 days) from the time you start. If you don't submit the application within this time:

* it will be deleted, and
* you'll have to start a new application

When you apply for EI benefits, we’ll ask for your email address. We may send you an email to provide you with information or ask you to call us if we can't reach you by phone.

Please note that we won’t ask you to send us information by email.

### Records of employment

Employers issue records of employment (ROEs) to provide information about your work history. We use the information to determine:

* whether you're eligible to receive EI benefits
* how much you'll receive

You can visit [My Service Canada Account](/en/employment-social-development/services/my-account.html) to view ROEs that have been issued for you by past and recent employers.

**Electronic ROEs**

Electronic ROEs are sent directly to us by your employer. You don't need to request copies from your employer and provide them to us.

**Paper ROEs**

If your employers issue paper ROEs, you must request copies of all ROEs issued for you during the past 52 weeks or since the start of your last claim, whichever is shorter. You'll need to provide them to us as soon as possible after you submit your application for EI benefits. You can [mail them](/en/employment-social-development/corporate/contact/ei-individual.html) or drop them off at a [Service Canada Centre](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng).

[Apply](/en/services/benefits/privacy-notice.html)

## Document navigation

* [Previous: How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)
* [Next: After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
