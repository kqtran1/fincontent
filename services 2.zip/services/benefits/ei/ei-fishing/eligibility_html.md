---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-fishing/eligibility.html
scraped_at: 2025-08-24 19:07:48
filename: en/services/benefits/ei/ei-fishing/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-pecheur/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Fishing benefits - Overview](/en/services/benefits/ei/ei-fishing.html)

# EI fishing benefits – Eligibility

# EI fishing benefits

* [What these benefits offer](/en/services/benefits/ei/ei-fishing.html)[What these benefits offer](/en/services/benefits/ei/ei-fishing.html)
* [Do you qualify](#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-fishing/apply.html)[Apply](/en/services/benefits/ei/ei-fishing/apply.html)
* [After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)[After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)

# Do you qualify

Your eligibility depends on how much you earned from self-employment in fishing during your **qualifying period**.

The **qualifying period** for summer fishing benefits can't start earlier than the week of March 1. For winter fishing benefits, it can't start earlier than the week of September 1. The qualifying period also can't start more than 31 weeks immediately before the start of a benefit period.

If you applied for benefits earlier and your application was approved in the last 31 weeks, the qualifying period is from the start of the previous benefit period to the start of your new benefit period.

To qualify for Employment Insurance (EI) fishing benefits, the amount you need to earn during your qualifying period varies depending on the rate of unemployment in the region where you live. As shown in the table [Earnings needed to qualify for EI fishing benefits](#table), you need to earn a minimum of between $2,500 and $4,200 during your qualifying period.

## Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

To qualify for EI special benefits (sickness, maternity, parental and caregiving), you must earn $3,760 or more from self-employment in fishing during the qualifying period.

**Earnings needed to qualify for EI fishing benefits**

| Regional rate of unemployment | Required earnings |
| --- | --- |
| 6% or less | $4,200 |
| 6.1% to 7% | $4,000 |
| 7.1% to 8% | $3,800 |
| 8.1% to 9% | $3,600 |
| 9.1% to 10% | $3,400 |
| 10.1% to 11% | $3,200 |
| 11.1% to 12% | $2,900 |
| 12.1% to 13% | $2,700 |
| 13.1% or more | $2,500 |

If you've been paid EI benefits in the past and received a written notice for making a false statement or misrepresentation, you may need to earn more from fishing to claim fishing benefits.

### Special benefits

Sickness benefits

If you can't work for medical reasons, you may be able to receive up to 26 weeks of sickness benefits. You must get a medical certificate showing that you're unable to work for medical reasons and for approximately how long. Medical reasons include illness, injury, quarantine or any medical condition that prevents you from working.

Maternity benefits

If you're away from work because you're pregnant or recently gave birth, you may be able to receive up to 15 weeks of maternity benefits.

Parental benefits

If you're a parent who is away from work to care for your newborn or newly adopted child, you may be able to receive parental benefits.

There are 2 options available for receiving parental benefits: standard or extended.

* Up to 40 weeks of **standard parental benefits** can be paid to parents sharing benefits, but 1 parent can't receive more than 35 weeks. If parents share benefits, they must choose the same option.
* Up to 69 weeks of **extended parental benefits** can be paid to parents sharing benefits, but 1 parent can't receive more than 61 weeks. If parents share benefits, they must choose the same option.

### Caregiving benefits

Compassionate care benefits

Compassionate care benefits can be paid for up to 26 weeks to fishers who have to be away from work to provide care or support to a person who has a serious medical condition with a significant risk of death within 26 weeks (6 months). Unemployed fishers receiving fishing benefits can also ask for this type of benefit. You must be able to provide medical proof that your family member has a serious medical condition with a risk of dying within 26 weeks and requires you to provide care and support to your family member who is seriously ill.

Family caregiver benefits

Family caregiver benefits for children can be paid for up to 35 weeks to family members who must be away from work to provide care or support[Footnote 1](#fn1) to a critically ill or injured child who is under the age of 18.

Family caregiver benefits for adults can be paid for up to 15 weeks to family members who must be away from work to provide care or support[Footnote 1](#fn1) to a critically ill or injured family member who is over the age of 18.

You must provide medical proof that the family member is critically ill or injured and requires you to provide care and support.

## Footnotes

Footnote 1
:   Care or support of a critically ill or injured child is defined as directly providing or participating in the care, or providing psychological and emotional support.

    [Return to footnote 1 referrer](#fn1-rf)

## Document navigation

* [Previous: What these benefits offer](/en/services/benefits/ei/ei-fishing.html)
* [Next: How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
