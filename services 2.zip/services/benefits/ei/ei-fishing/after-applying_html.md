---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-fishing/after-applying.html
scraped_at: 2025-08-24 19:35:31
filename: en/services/benefits/ei/ei-fishing/after-applying_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-pecheur/apres-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI Fishing benefits - Overview](/en/services/benefits/ei/ei-fishing.html)

# EI fishing benefits - After you've applied

# EI fishing benefits

* [What these benefits offer](/en/services/benefits/ei/ei-fishing.html)[What these benefits offer](/en/services/benefits/ei/ei-fishing.html)
* [Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)[Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-fishing/apply.html)[Apply](/en/services/benefits/ei/ei-fishing/apply.html)
* [After you apply](#gc-document-nav)

# After you apply

You’ll receive your first payment about 28 days after you apply if you’re eligible and have provided all required information. If you’re not eligible, we’ll notify you of the decision made about your application.

## Waiting period

Before you start receiving Employment Insurance (EI) benefits, there is 1 week for which you won’t be paid. This is called the waiting period. It’s like the deductible that you must pay for other types of insurance.

### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

Any money you earn during the 1-week waiting period will be deducted from your benefit payment during the first 3 weeks for which benefits are paid. Once these 3 weeks have passed, the waiting period has no further effect on your benefits.

To receive your payment, you must complete an EI report (online or by telephone) every 2 weeks. You can’t receive your payment unless you complete these reports.

## Access code

Once your application is received, we'll mail you a benefit statement with a 4-digit access code. You’ll need this code and your social insurance number (SIN) to follow up on your application. Receiving an EI benefit statement doesn't mean that we've made a decision about your claim.

To find out more about the fishing benefit, please read the [Fishers and Employment Insurance](/en/revenue-agency/services/forms-publications/publications/t4005/fishers-employment-insurance.html) guide, contact your nearest Service Canada office or call our EI Telephone Information Service at 1-800-206-7218 for service in English; 1-800-808-6352 for service in French (TTY: 1-800-529-3742).

## If you disagree with the decision about your application for EI benefits

You can request a [reconsideration of the decision](/en/services/benefits/ei/ei-reconsideration.html). You must submit a request for reconsideration within 30 days after the day the decision was communicated to you. You can [contact Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html) to help you with your reconsideration request.

## Review the status of your application

Sign in to [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) at any time, and:

* check that your banking information, address and telephone number are up-to-date
* review your claim status and messages

To sign up for direct deposit or to update your banking information, address or telephone number, you can:

* complete the [eServiceCanada](https://eservices.canada.ca/en/service/) service request form
* contact the [Service Canada call centre](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel2)
* visit a [Service Canada Office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## While on EI

You can’t work full time and receive EI benefits. However, you can work part time while receiving benefits.

You’ll be able to keep 50 cents of your EI benefits for every dollar you earn, up to 90% of the weekly insurable earnings used to calculate your EI benefit amount, if you work while receiving fishing benefits and have served your waiting period. If you earn any money above this 90%, we’ll deduct it dollar for dollar from your benefits.

For more information, visit the [Working While on Claim page](/en/employment-social-development/programs/ei/ei-list/working-while-claim.html).

You must report all gross earnings—that is, earnings before taxes and deductions—during the week you earn them, as well as any other money you receive while collecting fishing benefits.

### Receiving fishing and other types of EI benefits in the same claim period

Under certain conditions, you may receive fishing benefits **and** maternity, parental, sickness or family caregiver benefits during the same claim period. In this case, the benefit period would be extended to a maximum of 52 weeks, and you could receive up to 50 weeks of benefits.

The only exception is when EI fishing benefits and extended parental benefits are paid. As extended parental benefits are paid at a benefit rate of 33% of your weekly insurable earnings, up to a maximum amount, once 50 weeks of benefits have been paid, the weeks of extended parental benefits will be converted to an equivalent number of weeks that would have been paid at the 55% benefit rate. This conversion will determine how many more weeks of fishing benefits and special benefits can be paid to reach the equivalent of 50 weeks paid at the 55% benefits rate. Any weeks where you return to work during this period will be considered weeks paid for the purposes of calculating the equivalent of 50 weeks paid at the 55% benefit rate. Once the number of additional weeks that can be paid is determined, the benefit period will be extended to allow for the additional weeks to be paid.

It is important to note that if you haven’t been paid any fishing or regular benefits during your benefit period, you may be able to receive up to 102 weeks of maternity, parental, sickness or family caregiver benefits in the same benefit period.

To find out whether you’re eligible to receive other types of EI benefits in the same benefit period, please call our EI Telephone Information Service at **1-800-206-7218** (TTY: 1-800-529-3742) between 8:30 am and 4:30 pm, Monday to Friday. You can also write to us or go in person to your Service Canada Centre.

### Travelling outside Canada

Usually, you can’t receive EI benefits while outside Canada. One measure we take to enforce this rule is to compare EI information with information from the Canada Border Services Agency. If we find you’ve been out of the country while collecting fishing benefits, we’ll try to determine whether you’re entitled to those benefits. If not, we’ll calculate your overpayment, which you’ll then have to repay.

We may also impose penalties of up to 3 times your weekly benefit rate or 3 times the amount of your overpayment. As well, you may have to earn more to qualify for fishing benefits in the future.

### Repaying benefits at income tax time

When you file your income tax return, you may be required to repay some of the EI benefits you received. This will depend on your net income and whether you were paid EI regular non-fishing or regular fishing benefits during the tax year.

For more information, visit the [EI and overpayments](/en/employment-social-development/programs/ei/ei-list/overpayments.html) page or call our EI Telephone Information Service at **1-800-206-7218** (TTY: 1-800-529-3742). You can also write to us or visit us in person at a Service Canada Centre.

### Protecting Employment Insurance

We work to protect the EI program from misuse. One of the ways we do this is by working with employers and claimants to ensure the accuracy of the information we receive. With your help, we can reduce the amount of misuse and ensure that the EI program is used as it should be—as a program that provides temporary financial assistance to individuals who qualify.

A mistake is an unintentional act. We know claimants can make mistakes when filing their reports. Common mistakes include:

* estimating weekly earnings instead of putting in the actual amount earned
* forgetting to declare all the earnings received
* writing or entering the wrong number when reporting earnings, or
* adding the number of hours or amount of earnings incorrectly

Some mistakes can delay benefit payments, while others can affect the amount of benefits you receive—meaning you were paid more or less than you were entitled to receive.

For example, estimating your earnings can have the following effects:

* If you estimated your earnings for 1 week and your estimate was higher than the earnings you actually received, your benefit amount will be less than it should have been. If this happens, let us know and we'll adjust your file to make sure you receive all the benefits to which you are entitled
* If you estimated your earnings for 1 week and your estimate was lower than the earnings you actually received, your benefit amount will be higher than it should have been. Let us know if this happens. You’ll have to repay the excess amount, but we’ll ensure that repaying it causes no undue hardship. As well, we’ll adjust your file to reflect your accurate information

If you notice a mistake on a completed form or report, or if there is a change in your circumstances that could affect your EI claim, **tell Service Canada immediately**. This will help prevent any future problems with your claim.

### Misrepresentation

If you knowingly withhold information, make misleading statements, or misrepresent the facts to make a false claim for benefits, this is considered misrepresentation. You could face severe monetary penalties or prosecution. This could also affect your future benefits. However, if you disclose your actions to Service Canada before an investigation begins, we may waive any monetary penalties and prosecutions that might otherwise apply.

### Consequences of misrepresentation: Interest and penalties

#### Interest on debt

When EI claimants receive benefits to which they’re not entitled, the amount of the overpayment counts as a debt that must be repaid.

We charge interest on this debt when it results from claimants who knowingly withhold information or make false or misleading representations or statements. However, we do not charge interest on debt that results when we make an error in the benefit payment.

The rate of interest is the Bank of Canada average rate plus 3%. Interest is calculated daily and compounded monthly.

#### Penalties

A penalty may be imposed on a claimant, an employer, or an individual acting on their behalf in relation to a claim for benefits when he or she has:

* knowingly made false or misleading representations or statements, or
* completed a statement without declaring essential information

Here is an example of a situation where penalties may be imposed:

An EI benefit claimant goes on an ocean cruise for a month and arranges for a friend to conceal their absence by signing and returning 2 EI claimant reports. As a result, the claimant illegally received $350 in benefits for each of the 4 weeks of the cruise. After investigation, we find that this was the first time the claimant and the friend had misused the EI system. As well, we find that they both knew that what they did was illegal but they did it anyway.

In this case, the claimant will have to repay $1,400 (4 weeks of benefits at $350 per week) and may have to pay a penalty of $700 ($350 for each of the 2 false reports filed during the holiday). The friend may also have to pay a penalty of $700 for the illegal act of filing 2 false reports on behalf of the claimant.

There are many situations when a penalty may apply, and the amount could become very high. Depending on the circumstances, the maximum penalty could be up to 3 times the amount of the overpayment, 3 times the weekly benefit rate for each incident of misrepresentation, or 3 times the maximum benefit rate.

### Violations

Claimants who misuse the EI program and were assessed a violation may need more insurable earnings or hours to qualify for benefits in the future. The required amount rises based on the number and seriousness of misrepresentations that have been recorded in the 5-year period before the start of their claims.

### Rights and responsibilities

The EI program guarantees certain rights. There are also some basic responsibilities, for both you and Service Canada.

When you apply for EI benefits, you must:

* be capable of and available for work and unable to obtain suitable employment
* actively search for and accept offers of [suitable employment](/en/services/benefits/ei/suitable-employment.html)
* conduct job search activities that increase your opportunities to find suitable employment, such as:
  + assessing employment opportunities
  + preparing a résumé or cover letter
  + registering for job search tools or with electronic job banks or employment agencies
  + attending job search workshops or job fairs
  + networking
  + contacting prospective employers
  + submitting job applications
  + attending interviews
  + undergoing evaluations of competencies
* keep a detailed record as proof of your job search efforts to find suitable employment as we may ask you to provide that proof at any time. Therefore you must keep your job search record for 6 years
* let us know when you refuse any offers of employment
* report all periods when you’re not available for work
* keep your appointments with our office
* notify us of any separation from employment and the reasons for the separation
* report all periods of incapacity
* obtain a medical certificate that confirms the duration of your incapacity
* provide all other required information and documents
* report any absences from your area of residence or any absence from Canada
* report all employment, whether you work for someone else or for yourself
* accurately report all employment earnings before deductions, in the week(s) in which they were earned, as well as any other monies you may receive

### Service Canada's responsibilities

At Service Canada, we're responsible for:

* giving you prompt and courteous service
* advising you of the programs and services that are available to you
* serving you in the official language of your choice
* determining if you’re eligible to receive benefits (that is, whether or not you meet the qualifying conditions specified in the *Employment Insurance Act* and Regulations) and determining how many weeks of benefits you can receive
* processing all claims within the same timeframe
* issuing your first payment no later than 28 days after the date we receive your application, if you’ve provided us with all the required information and if you’re eligible for benefits
* giving you accurate information about your claim, including how you can share parental benefits with your EI -eligible spouse or partner and caregiver benefits with other EI -eligible family members, and whether or not you’ll need to serve a 1-week waiting period
* letting you know about decisions we've made about your claim and explaining the process to follow if you disagree with a decision

For more information on rights and responsibilities, see the publication called [Employment Insurance – Rights and Responsibilities](/en/employment-social-development/programs/ei/ei-list/reports/rights-responsbilities.html).

### Contacts and other useful information

#### EI Telephone Information Service

The EI Telephone Information Service is an automated telephone service that is available 24 hours a day, 7 days a week. If you would prefer to speak to a representative, call this number between 8:30 am and 4:30 pm, Monday to Friday, and press "0." You can get general information about the EI program, the SIN, and your specific EI claim.

Information about your claim is updated every morning from Monday to Friday. To access information about your EI claim, you’ll need your SIN and access code, which you’ll find on the benefit statement that is mailed to you after you apply for EI benefits.

## Document navigation

* [Previous: Apply](/en/services/benefits/ei/ei-fishing/apply.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
