---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-sickness.html
scraped_at: 2025-08-24 14:19:24
filename: en/services/benefits/ei/ei-sickness_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maladie.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# EI sickness benefits

* [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
* [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html) [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-sickness/apply.html) [Apply](/en/services/benefits/ei/ei-sickness/apply.html#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html) [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html#gc-document-nav)

# What these benefits offer

EI sickness benefits can provide you with up to 26 weeks of financial assistance if you can't work for medical reasons. You could receive 55% of your earnings up to a maximum of $695 a week.

You must get a medical certificate showing that you’re unable to work for medical reasons and for approximately how long. Medical reasons include illness, injury, quarantine or any medical condition that prevents you from working.

**Find out if you have employer-paid sick leave**

Some employers provide their own paid sick leave or short-term disability plan. Before you apply for EI sickness benefits, check with your employer to find out if they have a plan in place.

**If you have a long-term or permanent disability**

If your medical condition is expected to be long-term or permanent, you may be eligible for other benefits, such as:

* [Canada Pension Plan disability benefits](/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)
* [Disability benefits under the Québec Pension Plan](https://www.rrq.gouv.qc.ca/en/programmes/regime_rentes/prestations_invalidite/Pages/prestations_invalidite.aspx)

**If you get sick or require bed rest during pregnancy**

If you have health complications during pregnancy, you could be eligible for sickness benefits or [maternity benefits](/en/services/benefits/ei/ei-maternity-parental.html). You must meet the conditions for each benefit.

### Document navigation

* [Next: Next](/en/services/benefits/ei/ei-sickness/qualify.html#wb-cont)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
