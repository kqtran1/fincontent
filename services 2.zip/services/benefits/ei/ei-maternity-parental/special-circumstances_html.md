---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html
scraped_at: 2025-08-24 15:23:09
filename: en/services/benefits/ei/ei-maternity-parental/special-circumstances_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maternite-parentales/circonstances-particulieres.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI maternity and parental benefits: What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)

# EI maternity and parental benefits: Special circumstances

# EI maternity and parental benefits

* [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html) [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)
* [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)[How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html) [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html)
* [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html) [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)
* [Special circumstances](#gc-document-nav)

# Special circumstances

Below are some special circumstances that may impact you. Contact [Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html) for advice on your specific situation.

Changing your planned number of weeks

You can change the number of weeks you request as long as you don't go over the maximum for the option you chose.

## Note:

You can't change between standard and extended parental benefit options once a week of parental benefits has been paid to you, or if a payment has been made to the other parent when benefits are shared.

Non-consecutive parental leave

If you're taking parental leave at different times during the eligibility period, you must submit an application each time you plan to receive parental benefits. If you have an existing claim, we'll reactivate it or you could start a new claim.

Health complications during pregnancy

You could be eligible for [sickness benefits](/en/services/benefits/ei/ei-sickness.html) or for maternity benefits earlier. You must meet the conditions for each benefit.

Health complications for your child

If your child is hospitalized, your eligibility period for maternity or parental benefits could be extended. You may be eligible for [other benefits](/en/services/benefits/ei.html). This could include caregiving benefits if your child becomes critically ill or injured. You must meet the conditions for each benefit.

Miscarriage, termination or stillbirth

If you're reading this following a loss, please accept our condolences.

If your pregnancy ends before week 20, you could receive [sickness benefits](/en/services/benefits/ei/ei-sickness.html).

If your pregnancy ends in week 20 or later, you could receive maternity benefits.

Parental benefits are not available.

Death of a child

If you're reading this following the loss of your child, please accept our condolences.

You should know that you're still entitled to up to 15 weeks of maternity benefits. However, parental benefits are not available. If the loss occurs while parental benefits are being paid, parents are no longer eligible as of the week following the loss. You may be eligible for [other benefits](/en/services/benefits/ei.html).

Please inform us as soon as possible so we can update your file and make any necessary adjustments.

Your child is not legally adoptable

If your child is not legally adoptable at the time they're placed with you, benefits can be paid from the date you demonstrate that:

* you consider the placement to be permanent, and
* your intent is to adopt

Multiple birth

The number of weeks of maternity and parental benefits you can get doesn't change if you have a multiple birth (twins, triplets, etc.). This is also the case if you adopt more than 1 child at the same time.

Surrogacy

Maternity benefits are available to people who are away from work because they're pregnant or have recently given birth, including surrogates. Parental benefits are not available to surrogates.

Canadian Forces member

If you're a Canadian Forces member (regular or reservist) who must defer or interrupt your parental leave because of an imperative military requirement, your eligibility period for parental benefits [could be extended](/en/services/benefits/ei/ei-military-families.html).

### Document navigation

* [Previous After you've applied](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)

## Page details

Date modified:
:   2024-10-24

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
