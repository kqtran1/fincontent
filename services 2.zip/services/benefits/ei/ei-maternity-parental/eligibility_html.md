---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental/eligibility.html
scraped_at: 2025-08-24 17:47:48
filename: en/services/benefits/ei/ei-maternity-parental/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maternite-parentales/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI maternity and parental benefits: What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)

# EI maternity and parental benefits: Eligibility

# EI maternity and parental benefits

* [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html) [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)
* [Do you qualify](#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)[How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html) [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html)
* [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html) [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)
* [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html) [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html)

# Do you qualify

The information below should be used as a guideline. We encourage you to apply for benefits as soon as possible and let us determine if you're eligible.

You need to demonstrate that:

* you're pregnant or have recently given birth when requesting maternity benefits
* you're a parent caring for your newborn or newly adopted child when requesting parental benefits
* your regular weekly earnings from work have decreased by more than 40% for at least 1 week
* you accumulated 600 insured hours of work in the 52 weeks before the start of your claim or since the start of your last claim, whichever is shorter

If you had a recent claim

If you received Employment Insurance benefits in the past 52 weeks, you may not be eligible to receive the maximum number of weeks of maternity or parental benefits.

However, if you've worked enough hours since your last claim, you may be able to start a new claim. [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) to find out what's best for your situation.

If you get sick or require bedrest during pregnancy

If you have health complications during pregnancy, you could be eligible for [sickness benefits](/en/services/benefits/ei/ei-sickness.html) or for maternity benefits earlier. You must meet the conditions for each benefit.

If you're not a Canadian citizen

If you have a valid social insurance number, you may be eligible for maternity and parental benefits.

If you plan to travel outside of Canada, contact [Immigration, Refugees and Citizenship Canada](/en/immigration-refugees-citizenship.html) to find out how this may impact your situation.

Maternity benefits and gender identity

Maternity benefits are available to eligible individuals, regardless of gender identity.

## Eligibility period

### Maternity benefits

You can start receiving maternity benefits as early as 12 weeks before your due date or the date you give birth. You can't receive these benefits more than 17 weeks after your due date or the date you gave birth, whichever is later.

### Parental benefits

You must take parental benefits within specific periods starting the week of your child's date of birth or the week your child is placed with you for the purpose of adoption.

These periods are:

* **Standard parental:** within 52 weeks (12 months)
* **Extended parental:** within 78 weeks (18 months)

### Document navigation

* [Previous What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)
* [Next How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)

## Page details

Date modified:
:   2024-10-24

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
