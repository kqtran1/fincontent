---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html
scraped_at: 2025-08-24 17:16:48
filename: en/services/benefits/ei/ei-maternity-parental/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About this site"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maternite-parentales/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](http://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI maternity and parental benefits: What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)

# EI maternity and parental benefits

* [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html) [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)
* [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)
* [How much you could receive](#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html) [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html)
* [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html) [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)
* [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html) [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html)

# How much you could receive

The exact amount you receive will be determined once your application is processed.

The number of weeks of benefits you get depends on the benefit type you choose and if you decide to share the benefits with other parents. The amount you receive depends on your insurable earnings\* before taxes in the past 52 weeks or since the start of your last claim, whichever is shorter.

\* Insurable earnings include most of the different types of compensation from employment, such as wages, tips, bonuses and commissions. The Canada Revenue Agency (CRA) determines what [types of earnings](https://www.canada.ca/en/revenue-agency/services/tax/canada-pension-plan-cpp-employment-insurance-ei-rulings/cpp-ei-explained/canada-pension-plan-employment-insurance-explained-10.html) are insurable.

Some employers provide additional money to employees on maternity or parental leave. This is called a top-up. Check with your employer to find out if they offer a top-up.

## If your weekly earnings vary or your income changes

To calculate your benefit amount, we use a specific number of your highest paid weeks of employment. We call these your best weeks. The number of best weeks we use is based on the unemployment rate where you live. It could be between 14 and 22 weeks.

If your weekly earnings vary or your income changes, your best weeks can impact your benefit amount.

## Estimate your benefits

The estimator below provides the most accurate estimate for maternity and parental benefits. A new [EI Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) is also available but still under development. After using this estimator, please try the new tool and share your [feedback](https://srv217.services.gc.ca/ihst4/Intro.aspx?cid=28cf11f7-56d8-4395-b76c-3e3d1e16dba1&lc=eng) to help us improve it.

Answer the questions below to estimate your benefits, or find out [what we use to calculate your benefits](#formula).

[Find your economic region](https://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx) to learn how many best weeks are used to calculate your benefit amount. To complete your estimate, you need to know your average insurable earnings (before taxes) for those weeks. The Province of Quebec is responsible for providing maternity, paternity, parental and adoption benefits to its residents. Visit the [Québec Parental Insurance Plan](https://www.rqap.gouv.qc.ca/en) for more information.

Enter your annual salary or your average weekly earnings. **(required)**

Earnings frequency

Select one
Annually
Weekly

Earnings (before taxes)

$

Which benefits are you applying for? **(required)**

If you're pregnant or gave birth, you could take both.

Maternity (for the person giving birth)

Parental (for parents)

What parental benefits option do you want? **(required)**

Once a parental benefits payment has been made for the birth or adoption, the option (standard or extended) can't be changed.

Standard (higher payments over fewer weeks)

Extended (lower payments over more weeks)

How many weeks of parental benefits do you want for yourself? **(required)**

You can take up to 35 weeks of standard or up to 61 weeks of extended parental benefits.

Are you planning to share parental benefits? **(required)**

If you share parental benefits, extra weeks are available: 5 for standard or 8 for extended parental benefits. You can split the total weeks however you want, but one parent can't receive more than 35 (standard) or 61 (extended) weeks.

Yes

No

When do you plan to stop working? (YYYY-MM-DD) **(required)**

Apply as soon as possible after you stop working. If you wait more than 4 weeks after your last day of work to apply, you may lose benefits.

You can only start receiving parental benefits on or after your child's date of birth or the date your child is placed with you for the purpose of adoption.

Get estimate

#### Estimated results:

**This is just an estimate.** It's based on the information you entered above. We can't tell exactly how much you'll receive until your application is processed.

Your **maternity benefits**:

* are estimated at **$** a week
* will end after **15** weeks, around

Your  **parental benefits**:

* will begin around , after your **15** weeks of maternity benefits end
* are estimated at **$** a week
* will end after  weeks, around

Because you indicated you want to share parental benefits, up to  weeks are available for other parents, for a total of  weeks of  parental benefits. One parent cannot receive more than  weeks of  parental benefits.

**If you took  parental benefits instead of  parental benefits**

Your  **parental benefits** would:

* begin around , after your **15** weeks of maternity benefits end
* be estimated at **$** a week

Once a parental benefits payment has been made for the birth or adoption, **the option (standard or extended) can't be changed.**

**Note:** You can change your answers and recalculate to get updated results.

## What's included in benefit calculations

* Basic rates

  The basic rate used to calculate maternity and standard parental benefits is 55% of average insurable weekly earnings, up to a maximum amount. In 2025, the maximum amount is $695 a week.

  For extended parental benefits, this rate is 33% of average insurable weekly earnings, up to a maximum amount. In 2025, the maximum amount is $417 a week.
* Benefit calculation

  This is how we calculate your weekly benefit amount:

  1. we add your insurable weekly earnings from your best weeks based on information provided by you and your record of employment
  2. we divide that amount by the number of best weeks based on where you live
  3. we then multiply the result by 55% for maternity and standard parental benefits or by 33% for extended parental benefits
* If your family income is $25,921 or less

  You may be eligible to receive the family supplement if:

  + your annual net family income is $25,921 or less
  + you have at least 1 child under 18
  + you or your spouse receive the Canada Child Benefit

  We automatically add your family supplement to your weekly benefit payments. You don't need to take any action. Your total weekly amount cannot exceed $695.

### Document navigation

* [Previous Eligibility](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)
* [Next Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html)

## Page details

Date modified:
:   2024-07-29

## About government

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)
* [Departments and agencies](/en/government/dept.html)
* [Public service and military](/en/government/publicservice.html)
* [News](/en/news.html)
* [Treaties, laws and regulations](/en/government/system/laws.html)
* [Government-wide reporting](/en/transparency/reporting.html)
* [Prime Minister](http://pm.gc.ca/en)
* [About government](/en/government/system.html)
* [Open government](http://open.canada.ca/en)

## About this site

* [Social media](/en/social.html)
* [Mobile applications](/en/mobile.html)
* [About Canada.ca](/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

[Top of page](#wb-cont)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
