---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental/apply.html
scraped_at: 2025-08-24 14:44:11
filename: en/services/benefits/ei/ei-maternity-parental/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maternite-parentales/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI maternity and parental benefits: What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)

# EI maternity and parental benefits: Apply

# EI maternity and parental benefits

* [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html) [What these benefits offer](/en/services/benefits/ei/ei-maternity-parental.html)
* [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)[How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html) [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)
* [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html) [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html)

# Apply

Apply as soon as possible after you stop working. If you apply more than 4 weeks after your last day of work, you may lose benefits.

**Follow these steps to apply:**

* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/hand.png)Step 1: Choose benefits](#h2.1-h3.1)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/baby.png)Step 2: Gather required information](#h2.1-h3.2)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/computer.png)Step 3: Complete the online application](#h2.1-h3.3)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/submit.png)Step 4: Provide required documents](#h2.1-h3.4)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/letter.png)Step 5: A benefit statement and access code will arrive by mail](#h2.1-h3.5)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/screen.png)Step 6: Check the status of your application](#h2.1-h3.6)

Service Canada collects the personal information you put in an Employment Insurance (EI) benefit application to decide if you qualify for EI benefits. By starting this application, you consent to the terms of the privacy notice statement. Please read the [privacy notice statement](/en/services/benefits/apply-privacy.html).

If you're already familiar with the program:

[Apply](/en/services/benefits/apply-privacy.html)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/hand.png)Step 1: Choose benefits

* ### Maternity benefits

  You can start receiving maternity benefits as early as 12 weeks before your due date or the date you give birth. You can't receive these benefits more than 17 weeks after your due date or the date you gave birth, whichever is later. A maximum of 15 weeks of benefits is available.

  When you apply for maternity benefits, you can also apply for parental benefits. This will save you time later.
* ### Parental benefits

  You can start receiving parental benefits the week your child is born or placed with you for the purpose of adoption.

  When applying for parental benefits, you need to choose between 2 options:

  1. standard parental (up to 35 weeks, up to $695 a week)
  2. extended parental (up to 61 weeks, up to $417 a week)

  If you applied for parental benefits at the same time as maternity benefits, you don't need to apply again.

  **You can't change between standard and extended parental benefit options** once a week of parental benefits has been paid to you, or if a payment has been made to the other parent when benefits are shared.

  #### Sharing parental benefits

  If sharing benefits, each parent must choose the same option, standard or extended. Each parent must submit their own application. If parents don't choose the same option, the choice on the first application received is used to determine the parental benefit option for all parents.

  When sharing, the maximum number of weeks available increases to:

  + 40 weeks for standard parental
  + 69 weeks for extended parental

  One parent can't receive more than 35 weeks of standard or 61 weeks of extended parental benefits. The remaining 5 weeks of standard or 8 weeks of extended parental benefits are available on a use-it-or-lose-it basis: if taken, they can only be taken by the other parent(s).

  Parents can receive their weeks of benefits at the same time or one after another.
* ### Examples

  #### Maternity plus standard parental benefits

  Julie and David are having a baby. Julie takes the full 15 weeks of maternity benefits she is entitled to. She and David each decide to take 20 weeks of standard parental benefits at the same time to care for their child.

  #### Extended parental benefits

  Sami and Alex are adopting a child. Sami decides to take 39 weeks of extended parental benefits. This means Alex can take up to 30 weeks of extended parental benefits to care for their child.

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/baby.png)Step 2: Gather required information

As part of the application process, you’ll need to provide information and documents to us.

**Don't wait until you have the documents to apply.** Complete and submit your online application right away. You can send the required documents after you apply.

* ### Personal information

  Make sure you have the following information to complete your application:

  + the names and addresses of your employers in the past 52 weeks
  + the dates you were employed with each employer and the reasons you're no longer employed with them
  + your detailed explanation of the facts if you quit or were dismissed from any job in the past 52 weeks
  + your full mailing address and your home address, if they are different
  + your social insurance number (SIN)
  + the SIN of any other parent if you plan to share benefits
  + the last name at birth of 1 of your parents
  + your banking information to sign up for direct deposit, including:
    - the name of your financial institution
    - your branch (transit) number
    - your account number
  + your child’s expected or actual date of birth
  + the date your child was placed with you for the purpose of adoption, and the full name and address of the agency handling the adoption
* ### Date of birth

  If your child's actual date of birth is different from the expected date of birth entered on your application, you must let us know as soon as possible. You can:

  + call 1-800-206-7218 (TTY: 1-800-529-3742)
  + [visit a Service Canada Centre](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)
* ### Records of employment

  Employers issue records of employment (ROEs) to provide information about your work history. We use the information to determine:

  + whether you're eligible to receive EI benefits
  + how much you'll receive

  You can visit [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) to view ROEs issued for you by past and recent employers.

  #### Electronic ROEs

  Electronic ROEs are sent directly to Service Canada by employers. You don't need to request copies from your employer to provide to us.

  #### Paper ROEs

  If your employer issues paper ROEs, you must request copies of all ROEs issued for you in the past 52 weeks or since the start of your last claim, whichever is shorter. You'll need to provide them to us as soon as possible after you submit your EI application. You can [mail them](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel3) or drop them off at a [Service Canada Centre](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng).

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/computer.png)Step 3: Complete the online application

The online application takes about 1 hour to complete. If you don't complete the application all at once, you can come back to it later using the temporary password that you receive when you start.

Your information is saved for 72 hours (3 days) from the time you start. If you don't submit the application within this time:

* it will be deleted, and
* you'll have to start a new application

When you apply for EI benefits, we’ll ask for your email address. We may send you an email to provide you with information or ask you to call us if we can't reach you by phone.

Please note that we won’t ask you to send us information by email.

[Apply](/en/services/benefits/apply-privacy.html)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/submit.png)Step 4: Provide required documents

After you complete your online application, submit the required documents to us.

You can:

* [mail them to us](/en/employment-social-development/corporate/contact/ei-individual.html)
* [drop them off at a Service Canada Centre](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/letter.png)Step 5: A benefit statement and access code will arrive by mail

Once your application is received, we’ll mail you a benefit statement with a 4-digit access code. You’ll need this code and your SIN to follow up on your application. Receiving an EI benefit statement doesn't mean that we’ve made a decision about your claim.

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/screen.png)Step 6: Check the status of your application

To check the status of your application, you can:

* register or [sign into MSCA](/en/employment-social-development/services/my-account.html)
* [contact Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html)

### Document navigation

* [Previous: How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)
* [Next: After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
