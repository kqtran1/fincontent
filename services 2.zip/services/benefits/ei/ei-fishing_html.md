---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-fishing.html
scraped_at: 2025-08-24 16:26:16
filename: en/services/benefits/ei/ei-fishing_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-pecheur.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# EI fishing benefits - Overview

# EI fishing benefits

* [What these benefits offer](#gc-document-nav)
* [Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)[Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-fishing/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-fishing/apply.html)[Apply](/en/services/benefits/ei/ei-fishing/apply.html)
* [After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)[After you apply](/en/services/benefits/ei/ei-fishing/after-applying.html)

# What these benefits offer

Employment Insurance (EI) provides fishing benefits to qualifying, self-employed fishers[Footnote 1](#fn1) who are actively seeking work. Unlike regular EI benefits, eligibility for EI fishing benefits is based on earnings, not insurable hours of employment.

Fishers may be eligible to receive regular fishing benefits as well as sickness, maternity, parental, compassionate care and/or family caregiver benefits.

### Guides and help

* [Fishers and Employment Insurance](/en/revenue-agency/services/forms-publications/publications/t4005/fishers-employment-insurance.html)

### Related services and info

* [EI contact information – Individuals](/en/employment-social-development/corporate/contact/ei-individual.html)
* [Employment Insurance and fraud](/en/employment-social-development/programs/ei/ei-list/reports/fraud-serious.html)
* [Benefits Finder](http://www.canadabenefits.gc.ca/f.1.2c.6.3zardq.5esti.4ns%40.jsp?lang=eng)
* [Direct deposit for Service Canada](/en/employment-social-development/programs/direct-deposit.html)

## Footnotes

Footnote 1
:   A fisher is a self-employed person engaged in fishing.

    [Return to footnote 1 referrer](#fn1-rf)

## Document navigation

* [Next: Do you qualify](/en/services/benefits/ei/ei-fishing/eligibility.html)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
