---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-outside-canada.html
scraped_at: 2025-08-24 20:06:57
filename: en/services/benefits/ei/ei-outside-canada_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-horscanada.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# EI – Workers and residents outside of Canada - Overview

* [1. Overview](/en/services/benefits/ei/ei-outside-canada.html)
* [2. Eligibility](/en/services/benefits/ei/ei-outside-canada/eligibility.html)
* [3. How much you could receive](/en/services/benefits/ei/ei-outside-canada/benefit-amount.html)
* [4. What you need before you start](/en/services/benefits/ei/ei-outside-canada/before-applying.html)
* [5. Apply](/en/services/benefits/ei/ei-outside-canada/apply.html)
* [6. After you've applied](/en/services/benefits/ei/ei-outside-canada/after-applying.html)

## 1. Overview

People who work outside Canada may be entitled to benefits under Canada's Employment Insurance (EI) program.

If you work outside Canada for a Canadian company or the Canadian government, you're usually covered by EI. You're not insured by the EI program if your job is covered by the country in which you're working.

If you're not sure whether your job is insured under Canada's EI program, ask your employer or call the [Canada Revenue Agency](/en/revenue-agency/corporate/contact-information.html) at 1-800-959-5525.

## Document navigation

* [Next - Eligibility](/en/services/benefits/ei/ei-outside-canada/eligibility.html)

## Guides and help

* [EI regular benefits](http://www.servicecanada.gc.ca/eng/ei/publications/process.shtml)
* [EI reporting](/en/services/benefits/ei/employment-insurance-reporting.html#About-reporting)

## Related services and information

* [Job Bank](https://www.jobbank.gc.ca/home-eng.do?lang=eng)
* [MSCA](/en/employment-social-development/services/my-account.html)
* [Benefits finder](http://www.canadabenefits.gc.ca/f.1.2c.6.3zardq.5esti.4ns%40.jsp?lang=eng)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
