---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental.html
scraped_at: 2025-08-24 13:58:14
filename: en/services/benefits/ei/ei-maternity-parental_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maternite-parentales.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# EI maternity and parental benefits: What these benefits offer

# EI maternity and parental benefits

* [What these benefits offer](#gc-document-nav)
* [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html) [Do you qualify](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)
* [How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)[How much you could receive](/en/services/benefits/ei/ei-maternity-parental/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html) [Apply](/en/services/benefits/ei/ei-maternity-parental/apply.html)
* [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html) [After you apply](/en/services/benefits/ei/ei-maternity-parental/after-applying.html)
* [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html) [Special circumstances](/en/services/benefits/ei/ei-maternity-parental/special-circumstances.html)

# What these benefits offer

Employment Insurance maternity and parental benefits provide financial assistance to:

* people who are away from work because they're pregnant or have recently given birth
* parents who are away from work to care for their newborn or newly adopted child

You could receive 55% of your earnings, up to a maximum of $695 a week.

Residents of Quebec

The Province of Quebec is responsible for providing maternity, paternity, parental and adoption benefits to its residents. Visit [Québec Parental Insurance Plan](https://www.rqap.gouv.qc.ca/en/home) for more information.

## Maternity benefits

Maternity benefits are only available to the person who is away from work because they're pregnant or have recently given birth. They can't be shared between parents.

The person receiving maternity benefits may also be entitled to parental benefits.

## Parental benefits

Parental benefits are available to the parents of a newborn or newly adopted child.

You must choose between 2 options:

1. standard parental benefits
2. extended parental benefits

Your choice determines the number of weeks and the weekly amount you'll receive.

If sharing, each parent must choose the same option and submit their own application. Parents can receive their weeks of benefits at the same time or one after another.

Although you don't have to take weeks of parental benefits consecutively, **you must take them within specific periods** starting the week of your child's date of birth or the week your child is placed with you for the purpose of adoption.

These periods are:

* standard parental: within 52 weeks (12 months)
* extended parental: within 78 weeks (18 months)

Before you apply, consider carefully whether standard or extended parental benefits are better for you. **You can't change between standard and extended parental benefit options** once a week of parental benefits has been paid to you, or if a payment has been made to the other parent when benefits are shared.

## Maternity and parental benefits overview

| Benefit name | Maximum weeks | Benefit rate | Weekly max |
| --- | --- | --- | --- |
| Maternity\* (for the person giving birth) | up to 15 weeks | 55% | up to $695 |
| Standard parental | up to 40 weeks can be shared between parents, but one parent cannot receive more than 35 weeks of standard benefits | 55% | up to $695 |
| Extended parental | up to 69 weeks can be shared between parents, but one parent cannot receive more than 61 weeks of extended benefits | 33% | up to $417 |

\*Maternity benefits can be followed by parental benefits. You can apply for both at once.

### Examples of maternity and parental benefits

Maternity plus standard parental benefits

Natalie is taking time off work to recover from childbirth. She is sharing parental benefits with her partner to care for their newborn. She takes the maximum:

15 weeks of **maternity**

+35 weeks of **standard parental**

=50 weeks total for Natalie

Her partner can apply for up to 5 weeks of standard parental benefits to care for the baby.

If Natalie chooses to take fewer weeks of parental benefits, her partner can apply for more.

Maternity plus extended parental benefits

Kelsey is taking time off work to recover from childbirth. She is sharing extended parental benefits with her partner to care for their newborn. She takes the maximum:

15 weeks of **maternity**

+61 weeks of **extended parental**

=76 weeks total for Kelsey

Her partner can apply for up to 8 weeks of extended parental benefits to care for the baby.

If Kelsey chooses to take fewer weeks of parental benefits, her partner can apply for more.

### Document navigation

* [Next Eligibility](/en/services/benefits/ei/ei-maternity-parental/eligibility.html)

## Page details

Date modified:
:   2025-02-04

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
