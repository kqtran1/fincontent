---
source_url: https://www.canada.ca/en/services/benefits/ei/caregiving.html
scraped_at: 2025-08-24 13:45:19
filename: en/services/benefits/ei/caregiving_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/proches-aidants.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)

# EI caregiving benefits

Sometimes in life, you might need to take time away from work to provide care or support for a family member who is:

* critically ill
* critically injured
* in need of end-of-life care

If this happens, Employment Insurance (EI) has a caregiver benefit available for you.

As a caregiver, you don’t have to live with the person you care for or support. You don’t even have to be related, but you must be considered to be like a family member.

The weeks of benefits can be shared by eligible caregivers, either at the same time or one after another.

The EI program offers 3 types of caregiving benefits:

## Family caregiver benefits for children

If you're away from work to provide care or support for a **critically ill or injured child under 18**.

## Family caregiver benefits for adults

If you're away from work to provide care or support to a **critically ill or injured person 18 or older**.

## Compassionate care benefits

If you're away from work to provide care or support to a **person who requires end‑of‑life care, whether they're a child or an adult**.

## Definitions

Caregiver

A caregiver is a family member or someone who is considered to be like family providing care or support to the person who is critically ill or injured or needing end-of-life care.

Care or support

Care is defined as participating in the care of a critically ill or injured person or someone needing end-of-life care.

Support is defined as providing psychological or emotional support to a critically ill or injured person or someone needing end-of-life care.

Critically ill or injured person

A critically ill or injured person is someone whose baseline state of health has changed significantly because of illness or injury. As a result, their life is at risk as a direct or indirect result of illness or injury and care or support is needed from at least 1 caregiver. Their condition must be certified by a medical doctor or nurse practitioner.

If the person is already living with a chronic medical condition, caregivers aren't eligible for benefits unless the person’s health changes significantly because of a new and acute life-threatening event.

End-of-life care

End-of-life care is defined as providing care or support to a person who has a serious medical condition with a significant risk of death within 26 weeks (6 months).

The person also requires the care or support of at least 1 caregiver. Their condition must be certified by a medical doctor or nurse practitioner.

Family member

A family member includes immediate family as well as other relatives and individuals considered to be like family, whether or not related by marriage, common-law partnership, or any legal parent-child relationship.

## Sections

[Who can qualify](/en/services/benefits/ei/caregiving/eligibility.html)
:   Requirements to get EI caregiving benefits as an insurable employee, a self-employed person or a fisher, or for those providing care outside of Canada.

[How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)
:   Information about maximum benefit rates, and an estimator tool to help you see how much you could receive.

[After you apply](/en/services/benefits/ei/caregiving/after-applying.html)
:   How we protect your personal information, waiting period, when payments start and biweekly reporting.

[How to apply](/en/services/benefits/ei/caregiving/apply.html)
:   When to apply for insurable employees and people who are self-employed, what you’ll need for the application, required documents and how to submit them.

[Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html)
:   Information you can provide to a medical practitioner to support your application for benefits as a caregiver.

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
