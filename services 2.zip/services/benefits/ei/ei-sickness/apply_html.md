---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-sickness/apply.html
scraped_at: 2025-08-24 16:27:19
filename: en/services/benefits/ei/ei-sickness/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maladie/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI sickness benefits: What these benefits offer](/en/services/benefits/ei/ei-sickness.html)

# EI sickness benefits: Apply

# EI sickness benefits

* [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
  [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
* [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html)
  [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html)
  [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-sickness/apply.html)
* [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html)
  [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html#gc-document-nav)

# Apply

**Apply as soon as possible after you stop working**. If you apply more than 4 weeks after your last day of work, you may lose benefits.

**Follow these steps to complete your application:**

* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/documents.png)Step 1: Gather required information](#h2.1)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/computer.png)Step 2: Complete the online application](#h2.2)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/submit.png)Step 3: Provide required documents](#h2.3)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/letter.png)Step 4: A benefit statement and access code will arrive by mail](#h2.4)
* [![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/screen.png)Step 5: Check the status of your application](#h2.5)

Service Canada collects the personal information you put in an Employment Insurance (EI) benefit application to decide if you qualify for EI benefits. By starting this application, you consent to the terms of the privacy notice statement. Please read the [privacy notice](/en/services/benefits/privacy-notice.html) statement.

If you're already familiar with the program:

[Apply](/en/services/benefits/privacy-notice.html)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/documents.png)Step 1: Gather required information

As part of the application process, you’ll need to provide information and documents to us.

**Don't wait until you have the documents to apply**. Complete and submit your online application right away. You can send the required documents after you apply.

* ### Personal information

  Make sure you have the following information to complete your application:

  + the names and addresses of your employers in the past 52 weeks
  + the dates you were employed with each employer and the reasons you're no longer employed with them
  + your detailed explanation of the facts if you quit or were dismissed from any job in the past 52 weeks
  + your full mailing address and your home address, if they're different
  + your social insurance number (SIN)
  + the last name at birth of 1 of your parents
  + your banking information to sign up for direct deposit, including:
    - the name of your financial institution
    - your branch (transit) number
    - your account number
* ### Medical certificate

  You'll need to get a medical certificate signed by a medical practitioner.

  There are 2 options. You can ask your medical practitioner to complete and sign either:

  + Service Canada's [Medical certificate for Employment Insurance sickness benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5140), or
  + their own medical certificate form

  Once you have your medical certificate, keep it for 6 years in case we require it later. We'll contact you to let you know if you need to submit your medical certificate after you apply.

  The medical practitioner may charge a fee to provide you with a medical certificate. We don't reimburse this fee.

  For more information on medical certificates, such as who can sign them, visit:

  + [information on medical certificates and practitioners](/en/services/benefits/ei/ei-sickness/qualify.html#medical)
* ### Records of employment

  Employers issue records of employment (ROEs) to provide information about your work history. We use this information to determine:

  + whether you're eligible to receive EI benefits
  + how much you'll receive

  You can visit [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) to view ROEs that have been issued for you by past and recent employers.

  #### Electronic ROEs

  Electronic ROEs are sent directly to Service Canada by employers. You don't need to request copies from your employer to provide to us.

  #### Paper ROEs

  If your employer issues paper ROEs, you must request copies of all ROEs issued for you in the past 52 weeks or since the start of your last claim, whichever is shorter. You'll need to provide them to us as soon as possible after you submit your EI application. You can [mail them](/en/employment-social-development/corporate/contact/ei-individual.html) or drop them off at a [Service Canada Centre](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng).

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/computer.png)Step 2: Complete the online application

The online application takes about 1 hour to complete. If you don’t complete the application all at once, you can come back to it later using the temporary password that you receive when you start.

Your information is saved for 72 hours (3 days) from the time you start. If you don't submit the application within this time:

* it will be deleted, and
* you'll have to start a new application

When you apply for EI benefits, we’ll ask for your email address. We may send you an email to provide you with information or ask you to call us if we can't reach you by phone.

Please note that we won’t ask you to send us information by email.

[Apply](/en/services/benefits/privacy-notice.html)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/submit.png)Step 3: Provide required documents

After you complete your online application, submit the required documents to us.

You can:

* [mail them to us](/en/employment-social-development/corporate/contact/ei-individual.html)
* [drop them off at a Service Canada Centre](http://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/letter.png)Step 4: A benefit statement and access code will arrive by mail

Once your application is received, we’ll mail you a benefit statement with a 4-digit access code. You’ll need this code and your SIN to follow up on your application. Receiving an EI benefit statement doesn't mean that we’ve made a decision about your claim.

## ![](/content/dam/esdc-edsc/images/services/benefits/ei/icons/screen.png)Step 5: Check the status of your application

To check the status of your application, you can:

* register or [sign into MSCA](/en/employment-social-development/services/my-account.html)
* [contact Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html)

### Document navigation

* [Previous: Previous](/en/services/benefits/ei/ei-sickness/benefit-amount.html)
* [Next: Next](/en/services/benefits/ei/ei-sickness/after-applying.html)

## Page details

Date modified:
:   2025-01-10

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
