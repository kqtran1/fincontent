---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-sickness/qualify.html
scraped_at: 2025-08-24 16:21:14
filename: en/services/benefits/ei/ei-sickness/qualify_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maladie/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI sickness benefits: What these benefits offer](/en/services/benefits/ei/ei-sickness.html)

# EI sickness benefits: Do you qualify

# EI sickness benefits

* [What these benefits offer](/en/services/benefits/ei/ei-sickness.html) [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
* [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html)
* [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-sickness/apply.html) [Apply](/en/services/benefits/ei/ei-sickness/apply.html#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html) [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html#gc-document-nav)

# Do you qualify

The information below should be used as a guideline. We encourage you to apply for benefits as soon as possible and let us determine if you're eligible.

You need to demonstrate that:

* you're unable to work for medical reasons
* your regular weekly earnings from work have decreased by more than 40% for at least 1 week
* you accumulated 600 insured hours of work in the 52 weeks before the start of your claim or since the start of your last claim, whichever is shorter

While you’re receiving sickness benefits, you must remain otherwise available for work, if it weren’t for your medical condition.

**If you had a recent claim**

If you received Employment Insurance benefits in the past 52 weeks, you may not be eligible to receive the maximum number of weeks of sickness benefits.

However, if you've worked enough hours since your last claim, you may be able to start a new claim. [Contact us](/en/employment-social-development/corporate/contact/ei-individual.html) to find out what's best for your situation.

## Get a medical certificate

You need to get a medical certificate signed by a medical practitioner when you apply for sickness benefits.

You have 2 options. You can ask your medical practitioner to complete and sign one of the following:

* Service Canada’s [Medical certificate for Employment Insurance sickness benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5140) **or**
* their own medical certificate form. This certificate must:
  + be readable
  + contain your medical practitioner’s letterhead or official stamp
  + indicate your name
  + contain the start date and expected duration (if known) of your incapacity due to illness, injury or quarantine
  + contain your medical practitioner’s handwritten, electronic or stamped signature

### Who can complete and sign your medical certificate

Here is a list of medical practitioners who can complete and sign your medical certificate. They must practise in Canada or the United States and the illness they’re treating must be in their field.

* medical doctor
* chiropractor
* podiatrist
* optometrist
* psychologist
* dentist
* midwife
* nurse practitioner
* registered nurse (in isolated areas when a doctor is unavailable)

Once you have your medical certificate, keep it in a safe place. We’ll let you know if you need to submit it to Service Canada. Keep it for 6 years in case we require it later.

### Document navigation

* [Previous: Previous](/en/services/benefits/ei/ei-sickness.html)
* [Next:Next](/en/services/benefits/ei/ei-sickness/benefit-amount.html)

## Page details

Date modified:
:   2024-10-24

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
