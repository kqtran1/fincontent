---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-sickness/after-applying.html
scraped_at: 2025-08-24 15:56:26
filename: en/services/benefits/ei/ei-sickness/after-applying_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maladie/apres-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI sickness benefits: What these benefits offer](/en/services/benefits/ei/ei-sickness.html)

# EI sickness benefits: After you apply

# EI sickness benefits

* [What these benefits offer](/en/services/benefits/ei/ei-sickness.html) [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
* [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html) [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html) [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html#gc-document-nav)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-sickness/apply.html) [Apply](/en/services/benefits/ei/ei-sickness/apply.html#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html)

# After you apply

## Submit your biweekly reports

After you apply for Employment Insurance (EI) benefits, you'll have to submit reports to us every 2 weeks for as long as you receive benefits. They show your ongoing eligibility and make sure you get the benefits to which you're entitled.

You'll need your social insurance number (SIN) and the 4-digit access code we mailed you to submit your reports [online](/en/services/benefits/ei/employment-insurance-reporting.html#Internet-Reporting-Service) or by [phone](/en/services/benefits/ei/employment-insurance-reporting.html#Telephone-Reporting-Service). Once you submit your report, you'll get the date to submit your next one. You have 3 weeks from that date to complete the next report.

If you work or earn money, you must indicate it on your report. If you don't inform us, you risk being [overpaid](/en/employment-social-development/programs/ei/ei-list/overpayments.html) and having to repay benefits.

For more information on how earnings impact your benefits, visit [Working while on claim](/en/employment-social-development/programs/ei/ei-list/working-while-claim.html).

## When payments start

You'll receive your first payment about 28 days after you apply if you're eligible and have provided all required information. If you're not eligible, we'll notify you of the decision made about your application.

### Waiting period

Before you start receiving benefits, there is 1 week for which you won't be paid. This is called the waiting period. It's like the deductible that you pay for other types of insurance.

#### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

## If your situation changes

Please [contact us](/en/employment-social-development/corporate/contact/ei-individual.html) if you:

* recover earlier than expected
* need more time off work than expected

You may be eligible for [other types of EI benefits](/en/services/benefits/ei.html). You must meet the conditions for each benefit.

## If you travel outside of Canada

If you travel, let us know by filling out the online form Absence from Canada in [My Service Canada Account](/en/employment-social-development/services/my-account.html) (MSCA), or when you complete your biweekly report.

You’re not usually eligible to receive sickness benefits while outside Canada. However, you could be eligible if you're obtaining medical treatment that isn't readily or immediately available in your area of residence.

We encourage you to [contact Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html) for advice on your specific circumstances.

## Review the status of your application

Sign in to [My Service Canada Account (MSCA)](/en/employment-social-development/services/my-account.html) at any time, and:

* check that your banking information, address and telephone number are up-to-date
* review your claim status and messages

To sign up for direct deposit or to update your banking information, address or telephone number, you can:

* complete the [eServiceCanada](https://eservices.canada.ca/en/service/) service request form
* contact the [Service Canada call centre](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel2)
* visit a [Service Canada Office](https://www.servicecanada.gc.ca/tbsc-fsco/sc-hme.jsp?lang=eng)

## When payments end

You'll stop receiving benefits if:

* you no longer need to be away from work because of your medical condition
* you've received the maximum number of weeks of sickness benefits
* you've received the maximum weeks of benefits payable to you when combining EI benefit types or
* you've reached the end of your claim period
  + when you start a claim for any type of EI benefit, your claim is open for a certain period of time. This is usually 52 weeks. In some situations, the claim period may be extended up to a maximum of 2 years

## If you disagree with the decision about your application for EI benefits

You can request a [reconsideration of the decision](/en/services/benefits/ei/ei-reconsideration.html). You must submit a request for reconsideration within 30 days after the day the decision was communicated to you. You can [contact Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html) to help you with your reconsideration request

### Document navigation

* [Previous: Previous](/en/services/benefits/ei/ei-sickness/apply.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
