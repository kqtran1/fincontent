---
source_url: https://www.canada.ca/en/services/benefits/ei/ei-sickness/benefit-amount.html
scraped_at: 2025-08-24 15:58:44
filename: en/services/benefits/ei/ei-sickness/benefit-amount_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/assurance-emploi-maladie/montant-prestation.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI sickness benefits: What these benefits offer](/en/services/benefits/ei/ei-sickness.html)

# EI sickness benefit: How much could you receive

# EI sickness benefits

* [What these benefits offer](/en/services/benefits/ei/ei-sickness.html) [What these benefits offer](/en/services/benefits/ei/ei-sickness.html)
* [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html) [Do you qualify](/en/services/benefits/ei/ei-sickness/qualify.html#gc-document-nav)
* [How much you could receive](/en/services/benefits/ei/ei-sickness/benefit-amount.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [Apply](/en/services/benefits/ei/ei-sickness/apply.html) [Apply](/en/services/benefits/ei/ei-sickness/apply.html#gc-document-nav)
* [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html) [After you apply](/en/services/benefits/ei/ei-sickness/after-applying.html#gc-document-nav)

# How much you could receive

Up to 26 weeks of sickness benefits are available. The number of weeks of benefits you get depends on how long you're unable to work for medical reasons.

The exact amount you receive will be determined once your application is processed. You could receive 55% of your insurable earnings\* up to a maximum of $695 a week. The amount you receive depends on your insurable earnings\* before taxes in the past 52 weeks or since the start of your last claim, whichever is shorter.

Some employers provide additional money to employees on sick leave. This is called a top-up. Check with your employer to find out if they offer a top-up.

\*Insurable earnings include most of the different types of compensation from employment, such as wages, tips, bonuses and commissions. The Canada Revenue Agency (CRA) determines what [types of earnings](/en/revenue-agency/services/tax/canada-pension-plan-cpp-employment-insurance-ei-rulings/cpp-ei-explained/canada-pension-plan-employment-insurance-explained-10.html) are insurable.

## If your weekly earnings vary or your income changes

To calculate your benefit amount, we use a specific number of your highest paid weeks of employment. We call these your best weeks. The number of best weeks we use is based on the unemployment rate where you live. It could be between 14 and 22 weeks.

If your weekly earnings vary or your income changes, your best weeks can impact your benefit amount. [Find your economic region](https://srv129.services.gc.ca/eiregions/eng/rates_cur.aspx) to learn how many best weeks are used to calculate your benefit amount.

## What's included in benefit calculations

**Basic rates**

The basic rate used to calculate sickness benefits is 55% of average insurable weekly earnings, up to a maximum amount. In 2025, the maximum amount is $695 a week.

**Benefit calculation**

This is how we calculate your weekly benefit amount:

1. we add your insurable weekly earnings from your best weeks based on information provided by you and your record of employment
2. we divide that amount by the number of best weeks based on where you live
3. we then multiply the result by 55%

**If your family income is $25,921 or less**

You may be eligible to receive the family supplement if:

* your annual net family income is $25,921 or less
* you have at least one child under 18
* you or your spouse receive the Canada Child Benefit

We automatically add your family supplement to your weekly benefit payments. You don't need to take any action. Your total weekly amount can't exceed $695.

## Estimate your benefits

Try the [EI Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) before you apply to check if these benefits are right for you and how much you could receive.

### Document navigation

* [Previous: Previous](/en/services/benefits/ei/ei-sickness/qualify.html)
* [Next: Next](/en/services/benefits/ei/ei-sickness/apply.html)

## Page details

Date modified:
:   2024-12-31

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
