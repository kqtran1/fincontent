---
source_url: https://www.canada.ca/en/services/benefits/ei/caregiving/apply.html
scraped_at: 2025-08-24 15:08:00
filename: en/services/benefits/ei/caregiving/apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/proches-aidants/demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI caregiving benefits](/en/services/benefits/ei/caregiving.html)

# EI caregiving benefits – How to apply

# EI caregiving benefits

* [Who can qualify](/en/services/benefits/ei/caregiving/eligibility.html) [Who can qualify](/en/services/benefits/ei/caregiving/eligibility.html)
* [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)  [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [After you apply](/en/services/benefits/ei/caregiving/after-applying.html) [After you apply](/en/services/benefits/ei/caregiving/after-applying.html)
* [How to apply](#gc-document-nav)
* [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html) [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html)

# How to apply

**Complete and submit your online application right away**. You can provide the supporting documents after you apply.

You'll have the option to save your progress, so you can come back to it later. Any information you enter is saved for 72 hours (3 days) from the time you started the application.

If you don't submit the application within 72 hours, it will be deleted and you'll have to start a new one.

## When to apply

**Apply for EI as soon as possible** after you stop working or after your earnings are reduced. Otherwise, you may lose benefits. There may also be a waiting period depending on your situation.

## Gather required information

These will need to be filled out and signed by someone other than yourself. You can send these documents after submitting your request.

* ### Authorization to release medical information

  Medical doctors and nurse practitioners aren't allowed to release medical information about a patient without the patient's consent.

  #### For a critically ill or injured child or adult

  The critically ill or injured person or their legal representative must provide authorization to release medical information. In the case of a child, the parent or legal guardian of the child must complete the form.

  You must submit the form at the same time as the medical certificate.

  The medical doctor or nurse practitioner indicates on the medical certificate if the critically ill or injured person is capable of consenting to the release of their medical information. The critically ill or injured person must sign the form. If not capable of doing so, their legal representative must sign.

  Get the [Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5257) form.

  #### For a person needing end-of-life care

  The person requiring end-of-life care or their legal representative must provide authorization to release medical information.

  In the case of end-of-life care for a child, the parent or legal guardian of the child must complete the form.

  You must submit the form at the same time as the medical certificate. The medical doctor or nurse practitioner indicates on the medical certificate if the person needing end-of-life care is capable of consenting to the release of their medical information. The person needing end-of-life care must sign the form. If not capable of doing so, their legal representative must sign.

  Get the [Authorization to Release Medical Information for Employment Insurance Compassionate Care and Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5257) form.
* ### Medical certificate

  #### For a critically ill or injured child or adult

  A medical doctor or nurse practitioner must complete and sign the Medical Certificate for Employment Insurance Family Caregiver Benefits.

  This certificate:

  + confirms that the person is critically ill or injured
  + confirms that the person needs the care or support of 1 or more caregivers
  + provides the specific time period for which the critically ill or injured person is expected to need care or support

  The number of weeks you're entitled to receive benefits and the start date of benefits are based on the information provided on the medical certificate.

  If the critically ill or injured person needs care or support for a longer period of time than stated on the medical certificate, you'll need a second certificate from a medical doctor or nurse practitioner to extend the original time period. You or other caregivers can't receive benefits beyond the maximum number of weeks payable that each benefit type allows.

  Get the [Medical Certificate for Employment Insurance Family Caregiver Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5242B) form.

  #### For a person needing end-of-life care

  A medical doctor or nurse practitioner must complete and sign the Medical Certificate for Employment Insurance Compassionate Care Benefits.

  This certificate:

  + confirms that the person has a serious medical condition
  + confirms that the person is at significant risk of death within 26 weeks (6 months)
  + confirms that the person needs the care or support of 1 or more caregivers

  You can receive benefits during the 52 weeks following the date the person is certified to be in need of end-of-life care.

  Only one medical certificate is required. This applies if only one caregiver is claiming the 26 weeks of benefits, or if benefits are being shared. If more than one medical certificate is submitted, the first valid certificate determines the start and end dates of the 52-week timeframe.

  Get the [Medical Certificate for Employment Insurance Compassionate Care Benefits](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5216B) form.
* ### Attestation for non-family members

  You don't have to be related to or live with the person you care for or support. You can receive caregiving benefits to provide care or support to a person who considers you to be like family.

  If you're not related to the person needing care or support, the person or their legal representative must complete and sign the Family Member Attestation Form to confirm that you are considered to be like family.

  For a child, the parent or legal guardian must complete and sign the form.

  Get the [Family Member Attestation](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5223) form.

## What you'll need for the application

Make sure you have the following information to complete your application:

* your full mailing address and your home address, if they are different
* your social insurance number (SIN)
* the last name of 1 of your parents at their birth
* information about the person requiring care or support, including:
  + your relationship
  + their full name
  + their date of birth
  + their home address
* your banking information in order to set up direct deposit
* the names and addresses of your employers in the past 52 weeks
* the dates you were employed with each employer and the reasons you’re no longer employed with them
* your detailed explanation of the facts if you quit or were dismissed from any job in the past 52 weeks

* ### Records of employment if you’re an insurable employee

  Employers issue records of employment (ROEs) to provide information about your work history. We use this information to determine:

  + whether you're eligible to receive EI benefits
  + how much you'll receive

  You can view ROEs that have been issued for you by past and recent employers by signing in to My Service Canada Account (MSCA).

  #### Electronic records of employment

  Electronic ROEs are sent directly to Service Canada by employers. You don't need to request copies from your employer to provide to us.

  #### Paper records of employment

  If your employer issues paper ROEs, you must request copies of all ROEs issued for you in the past 52 weeks or since the start of your last claim, whichever is shorter. You'll need to provide them to us as soon as possible after you submit your application for EI benefits.
* ### Declared or estimated earnings if you're self-employed

  If you’ve filed your taxes for the previous tax year, you’ll need to provide your net self-employment income amount from line 4 of Schedule 13.

  If you haven’t yet filed your taxes for the previous tax year, you’ll need to provide an estimate of the net self-employment income for that taxation year.
* ### Records of employment if you're a self-employed fisher

  A record of employment (ROE) for self-employed fishers must be completed and submitted. We use this information to determine:

  + whether you're eligible to receive EI benefits
  + how much you'll receive

  #### Electronic records of employment

  Electronic ROEs are sent directly to Service Canada by employers (buyer). You don't need to request copies to provide to us.

  #### Paper records of employment

  If your employer (buyer) issues paper ROEs, you must request copies of all ROEs issued for you in the past 52 weeks or since the start of your last claim, whichever is shorter. You'll need to provide them to us as soon as possible after you submit your application for EI benefits.

## Submit the information and documents

After you finish your online application, a list of the required documents will be provided to you.

When those documents are ready to submit to us, you can:

* visit [My Service Canada Account](/en/employment-social-development/services/my-account.html) and upload your documents
* send them via [mail](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel3)
* drop them off at a [Service Canada location](/en/employment-social-development/corporate/contact/ei-individual.html#details-panel4)

[Apply for EI caregiving benefits](/en/services/benefits/apply-privacy.html)

## Document navigation

* [Previous: After you apply](/en/services/benefits/ei/caregiving/after-applying.html)
* [Next: Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html)

## Page details

Date modified:
:   2025-01-17

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
