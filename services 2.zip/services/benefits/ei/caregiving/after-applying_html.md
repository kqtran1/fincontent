---
source_url: https://www.canada.ca/en/services/benefits/ei/caregiving/after-applying.html
scraped_at: 2025-08-24 18:42:49
filename: en/services/benefits/ei/caregiving/after-applying_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/proches-aidants/apres-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI caregiving benefits](/en/services/benefits/ei/caregiving.html)

# EI caregiving benefits – After you apply

# EI caregiving benefits

* [Who can qualify](/en/services/benefits/ei/caregiving/eligibility.html) [Who can qualify](/en/services/benefits/ei/caregiving/eligibility.html)
* [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)  [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [After you apply](#gc-document-nav)
* [How to apply](/en/services/benefits/ei/caregiving/apply.html) [How to apply](/en/services/benefits/ei/caregiving/apply.html)
* [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html) [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html)

# After you apply

You can receive up to:

* 35 weeks with the family caregiver benefit for children who are under 18 years of age
* 15 weeks with the family caregiver benefit for adults
* 26 weeks with the compassionate care benefit

You would have 52 weeks to use these benefits, starting from the date a medical doctor or nurse practitioner certifies the person as critically ill or injured, or needing end-of-life care. You can take the benefits all at once or spread them out over separate periods.

Eligible caregivers can share the weeks of benefits, either at the same time or one after the other. Each caregiver must submit their own application for benefits.

## Waiting period

Before you start receiving benefits, there is 1 week for which you won't be paid. This is called the waiting period. It's like the deductible that you pay for other types of insurance.

### Temporary measures to support workers impacted by economic changes

Temporary measures will improve access to Employment Insurance benefits. For more information, visit [Temporary Employment Insurance measures to respond to major changes in economic conditions](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html).

If you're sharing benefits for the same person with other caregivers, only 1 caregiver serves the waiting period.

You must confirm in the online application whether you or another caregiver will serve the 1-week waiting period.

## When payments start

If you're eligible for Employment Insurance (EI) caregiving benefits and have provided all the required information, you'll get your first payment about 28 days after you apply.

If you're not eligible, we'll notify you of the decision made but you won't get any payments. If you disagree with the decision, you can request a formal reconsideration of that decision. You must submit the request to Service Canada within 30 days of the date you were notified.

## Biweekly reporting

You'll get instructions on how to complete a biweekly report. You must fill it out every 2 weeks to show that you're still eligible to continue getting the benefits.

In each biweekly report you'll need to tell us about:

* any dates and hours worked
* any earnings before deductions, even if you'll be paid later
* the contact information of any employers
* hours spent at school or in a training course
* if you received any training allowance
* if you were available for work
* if you were out of the country
* other money you get, even if you’ll receive it later

 What happens if my situation changes?

If the health of the person you’re caring for changes or if your own situation does, you may be eligible for other types of EI benefits.

We encourage you to contact Service Canada for advice on your specific situation.

## While receiving benefits

While receiving caregiving benefits, you must continue to be eligible.

Please contact Service Canada if:

* the person you're providing care or support to no longer requires your care or support, or
* you start working or earn money. For more information on how earnings impact your benefits, visit [Working while on claim](/en/employment-social-development/programs/ei/ei-list/working-while-claim.html)

If you don't inform us of these changes, you risk being [overpaid](/en/employment-social-development/programs/ei/ei-list/overpayments.html) and having to repay benefits.

### If your situation changes

You may be eligible for other types of EI benefits. This could include a different caregiving benefit if the state of health of the person you're caring for changes, or sickness benefits if you become ill yourself. You must meet the conditions for each benefit.

We encourage you to contact [Service Canada](/en/employment-social-development/corporate/contact/ei-individual.html) for advice on your specific circumstances.

## How we protect your personal information

Service Canada collects the personal information you put in any EI application. This helps us decide if you are eligible for EI caregiving benefits.

Service Canada must follow strict rules to keep your information safe. You can find out more about these rules by reading the privacy notice statement.

By starting an application for EI caregiving benefits, it means you consent to the terms of the privacy notice statement.

## Document navigation

* [Previous: How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)
* [Next: How to apply](/en/services/benefits/ei/caregiving/apply.html)

## Page details

Date modified:
:   2025-03-28

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
