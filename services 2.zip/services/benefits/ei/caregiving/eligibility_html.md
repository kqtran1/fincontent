---
source_url: https://www.canada.ca/en/services/benefits/ei/caregiving/eligibility.html
scraped_at: 2025-08-24 16:56:18
filename: en/services/benefits/ei/caregiving/eligibility_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae/proches-aidants/admissibilite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Employment Insurance benefits](/en/services/benefits/ei.html)
4. [EI caregiving benefits](/en/services/benefits/ei/caregiving.html)

# Do you qualify

# EI caregiving benefits

* [Who can qualify](#gc-document-nav)
* [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)  [How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)
  + [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)  [Employment Insurance Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en) New
* [After you apply](/en/services/benefits/ei/caregiving/after-applying.html) [After you apply](/en/services/benefits/ei/caregiving/after-applying.html)
* [How to apply](/en/services/benefits/ei/caregiving/apply.html) [How to apply](/en/services/benefits/ei/caregiving/apply.html)
* [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html) [Information for medical professionals](/en/services/benefits/ei/caregiving/individuals-medical-professionals.html)

# Who can qualify

**We encourage you to apply as soon as possible and let us determine if you qualify.**

## For insurable employees

There are 2 conditions to meet.

* You have at least 600 insured hours of work in the 52 weeks before the start of your claim or since the start of your last claim, whichever is shorter
* You can show that your regular weekly earnings from work have decreased by more than 40% for at least 1 week due to time off to care for a family member who is critically ill or injured, or needing end-of-life care

## For self-employed people

There are 3 conditions to meet.

* You must have entered into an agreement with the [Canada Employment Insurance Commission](/en/employment-social-development/corporate/portfolio/ei-commission.html) (CEIC). The CEIC plays a leadership role in overseeing Employment Insurance. Your agreement needs to be active for 12 months or more before you can apply for benefits

 How do you know if you have entered into an agreement with the CEIC?

You can [log in to My Service Canada Account](/en/employment-social-development/services/my-account.html). Under the Employment Insurance section, you will be able to "View my agreement status (self-employed)".

* You've earned a minimum amount of self-employed earnings in the previous calendar year. To be eligible for benefits between January 1, 2025 and December 31, 2025, you need to have made at least $8,826 in net self-employed earnings in 2024
* You can show that the time you spent working in your business has decreased by more than 40% for at least 1 week due to time off to care for a family member who is critically ill or injured, or needing end-of-life care

## For fishers

There is 1 condition to meet.

* You must have earned $3,760 or more from self-employment in fishing during the [qualifying period](/en/services/benefits/ei/ei-fishing/eligibility.html)

## For everyone

To access these EI caregiving benefits, all of the following conditions must also be true:

* a medical doctor or nurse practitioner has certified that the person you're providing care for or supporting is critically ill or injured, or needing end-of-life care
* you're a family member or you're considered to be like a family member to the person who needs care

 What is needed to prove that you’re considered to be like a family member?

The person needing care or their legal representative must complete the [attestation form](https://catalogue.servicecanada.gc.ca/content/EForms/en/Detail.html?Form=INS5223) to confirm that your are considered to be like family.

For a child, the parent or legal guardian must sign the form.

You must provide the form as part of your application for benefits.

## When the person you're caring for lives outside of Canada

You may be eligible to receive these benefits.

The medical certificate for the person who is critically ill or injured or needs end-of-life care must be completed by a medical doctor or nurse practitioner in the country where that person is receiving care.

## Document navigation

* [Previous: EI caregiving benefits](/en/services/benefits/ei/caregiving.html)
* [Next: How much you could get](/en/services/benefits/ei/caregiving/benefits-amounts.html)

## Page details

Date modified:
:   2024-12-27

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
