---
source_url: https://www.canada.ca/en/services/benefits/finder/tool.html
scraped_at: 2025-08-24 17:25:01
filename: en/services/benefits/finder/tool_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/chercheur/outil.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Benefits Finder | Find benefits and financial help](/en/services/benefits/finder.html)

Benefits finder

# List of government benefits

Find Government of Canada support for major life events like finding a home, starting a family, getting injured, planning for retirement or changing jobs.

## Version Beta

This new Benefits Finder is a work in progress. Help improve it by giving your [feedback](https://forms-formulaires.alpha.canada.ca/en/id/clwzf86mr03i2x8831c5r9zk6).

## Benefits

### Filters

results out of

Search by keyword
Toggle audience filters visibility I am looking for benefits for…

Audience

* Everyone
* Seniors and retirees
* Youth
* Students
* Parents and legal guardians
* Caregivers
* Military and Veterans
* Indigenous Peoples
* Newcomer to Canada
* Canadians living abroad
* Victims of crime

Toggle Topic filters visibility I am interested in benefits about…

Topic

* Health and well-being
* Disability
* Starting a family/raising children
* Retirement
* Going to school
* Jobs, volunteering and training
* Losing your job or unable to work
* Starting or owning a business
* Renting or home ownership
* Marriage or common-law
* Divorce or separation
* Grants and funding for projects
* Taxes
* What to do when someone dies

Toggle Type filters visibility

Type

* Grant/Subsidy
* Finder
* Funding/Loan
* Training
* Benefit
* Loan
* Rebate
* Service
* Provincial/Territorial web site
* Internship
* Volunteer

### Results

### Results

Benefit

#### [Canada Pension Plan (CPP) Annuities](https://www.canada.ca/en/employment-social-development/services/cpp-annuities.html)

Learn about the administration of annuities currently under payment as well as those to become payable at a later date.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement

Canada Pension Plan (CPP) Annuities , Pensions and seniors, Retirement and planning

Benefit

#### [Guaranteed Income Supplement (GIS)](https://www.canada.ca/en/services/benefits/publicpensions/cpp/old-age-security/guaranteed-income-supplement.html)

The Gauranteed Income Supplement (GIS) provides additional financial assistance to low-income Old Age Security (OAS) recipients.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement

Guaranteed Income Supplement (GIS) , Pensions and seniors, Retirement and planning, $300, 300, low income, low-income, low income seniors, low-income seniors, Income assistance

Benefit

#### [Old Age Security (OAS)](https://www.canada.ca/en/services/benefits/publicpensions/cpp/old-age-security.html)

The Old Age Security (OAS) pension is a monthly payment you can get if you are 65 and older. You must be a Canadian citizen or legal resident and have lived in Canada for at least 10 years after the age of 18.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement

Old Age Security (OAS) , Pensions and seniors, Retirement and planning

Benefit

#### [Registered Retirement Savings Plan (RRSP)](https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/rrsps-related-plans/registered-retirement-savings-plan-rrsp.html)

A Registered Retirement Savings Plan (RRSP), is a tax-deferred savings plan for retirement.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement

Registered Retirement Savings Plan (RRSP), Pensions and seniors, Retirement and planning

Benefit

#### [Canada Pension Plan (CPP)](https://www.canada.ca/en/services/benefits/publicpensions/cpp.html)

A monthly, taxable benefit that replaces part of your income when you retire. If you qualify, you’ll receive the CPP retirement pension for the rest of your life.

Location: Canada

Audience:

* Everyone
* Everyone
* Seniors and retirees

Topic:

* Retirement

Canada Pension Plan (CPP) , Pensions and seniors, Retirement and planning, Income assistance

Benefit

#### [Canada Pension Plan (CPP) Disability Benefit](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit.html)

Financial support to individuals with severe and prolonged disabilities that prevent them from working.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Disability
* Losing your job or unable to work
* Health and well-being

Canada Pension Plan (CPP) Disability Benefit , Disability, Pensions and seniors, Losing your job or unable to work

Benefit

#### [Canada Pension Plan (CPP) Disability Benefit - Vocational Rehabilitation](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-disability-benefit/vocational-rehabilitation.html)

The Disability Vocational Rehabilitation Program helps Canada Pension Plan (CPP) disability benefit recipients return to work with vocational counselling, financial support for training, and job-search services.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Disability
* Jobs, volunteering and training
* Losing your job or unable to work
* Health and well-being

Canada Pension Plan (CPP) Disability Benefit - Vocational Rehabilitation , Disability, Pensions and seniors, Work and career, Employee, volunteer, or trainee, Losing your job or unable to work

Benefit

#### [Employment Insurance (EI) Reconsideration](https://www.canada.ca/en/services/benefits/ei/ei-reconsideration.html)

If you disagree with a decision Service Canada made on your Employment Insurance (EI) application for benefits, you can request a reconsideration of that decision.

Location: Canada

Audience:

* Everyone

Topic:

* Losing your job or unable to work

Employment Insurance (EI) Reconsideration, Employment Insurance and leave, Losing your job or unable to work, Income assistance

Benefit

#### [Allowance](https://www.canada.ca/en/services/benefits/publicpensions/cpp/old-age-security/guaranteed-income-supplement/allowance.html)

The Allowance is a monthly payment available to eligible Canadians who are 60 to 64 years of age and who are the spouses or common-law partners of a Guaranteed Income Supplement (GIS) recipient.

Location: Canada

Audience:

* Seniors and retirees
* Everyone

Topic:

* Marriage or common-law
* Retirement

Allowance, Pensions and seniors, Retirement and planning, Married or common-law, Income assistance

Benefit

#### [Canada Pension Plan (CPP) International Benefits](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-international.html)

The Canada Pension Plan (CPP) International Benefits program ensures that eligible contributors receive their CPP benefits even if they live outside Canada.

Location: Canada

Audience:

* Everyone
* Seniors and retirees
* Canadians living abroad

Topic:

* Retirement

Canada Pension Plan (CPP) International Benefits , Pensions and seniors, Canadians living abroad, Retirement and planning

Benefit

#### [Canada Pension Plan (CPP) Credit Splitting](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-split-credits.html)

The Canada Pension Plan (CPP) contributions you and your spouse or common-law partner made during the time you lived together can be equally divided after a divorce or separation.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement
* Divorce or separation

Canada Pension Plan (CPP) Credit Splitting, Pensions and seniors, Divorced or separating, Retirement and planning

Rebate

#### [Refund of Federal Excise Tax on Gasoline (XE8)](https://www.canada.ca/en/revenue-agency/services/forms-publications/forms/xe8.html)

A refund for some of the gas you bought if you have a mobility impairment that prevents you from using public transportation.

Location: Canada

Audience:

* Everyone

Topic:

* Disability

Refund of Federal Excise Tax on Gasoline (XE8), Disability, Health and well-being, Rebate

Benefit

#### [Registered Disability Savings Plan (RDSP)](https://www.canada.ca/en/employment-social-development/programs/disability/savings.html)

A long-term savings plan to help people with disabilities, who are approved for the Disability Tax Credit, save for the future.

Location: Canada

Audience:

* Everyone

Topic:

* Disability

Registered Disability Savings Plan (RDSP), Disability, Health and well-being

Benefit

#### [Employment Insurance (EI) Regular Benefits](https://www.canada.ca/en/services/benefits/ei/ei-regular-benefit.html)

Employment Insurance (EI) provides temporary financial assistance to individuals who lose their jobs or face reduced work hours.

Location: Canada

Audience:

* Everyone

Topic:

* Losing your job or unable to work
* Jobs, volunteering and training

Employment Insurance (EI) Regular Benefits, Employment Insurance and leave, Losing your job or unable to work, Income assistance

Benefit

#### [Allowance for the Survivor](https://www.canada.ca/en/services/benefits/publicpensions/cpp/old-age-security/guaranteed-income-supplement/allowance-survivor.html)

Provides additional income support for surviving spouses or common-law partners 60 to 64 years old.

Location: Canada

Audience:

* Seniors and retirees
* Everyone

Topic:

* Retirement
* What to do when someone dies

Allowance for the Survivor, Pensions and seniors, Retirement and planning, Navigating a death, Income assistance

Benefit

#### [Canada Pension Plan (CPP) Survivor's Pension](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-survivor-pension.html)

Provides a monthly pension to the surviving spouse or common-law partner of a deceased contributor to the Canada Pension Plan (CPP).

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* Retirement
* What to do when someone dies

Canada Pension Plan (CPP) Survivor's Pension , Pensions and seniors, Retirement and planning, Navigating a death

Benefit

#### [Employment Insurance (EI) Sickness Benefits](https://www.canada.ca/en/services/benefits/ei/ei-sickness.html)

Benefits for individuals unable to work due to illness or injury.

Location: Canada

Audience:

* Everyone

Topic:

* Losing your job or unable to work
* Health and well-being
* Disability

Employment Insurnce (EI) Sickness Benefits, Employment Insurance and leave, Health, Losing your job or unable to work, Income assistance

Benefit

#### [Canada Disability Benefit](https://www.canada.ca/en/services/benefits/disability/canada-disability-benefit.html)

The Canada Disability Benefit provides direct financial support to people with disabilities who are between 18 and 64 years old.

Location: Canada

Audience:

* Caregivers

Topic:

* Disability
* Losing your job or unable to work
* Health and well-being

Benefit

#### [Repayment Assistance Plan (RAP) – Disability assistance](https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/repay/assistance/rap/disabilities.html)

Repayment Assistance Plan for student loan borrowers with Disabilities (RAP-D).

Location: Canada

Audience:

* Everyone
* Youth
* Students

Topic:

* Disability
* Going to school

Repayment Assistance Plan (RAP) – Disability assistance, Disability, Students and education planning, Youth, Students and education planning

Service

#### [Skills for Success – Assessment and training tools](https://www.canada.ca/en/services/jobs/training/initiatives/skills-success/tools.html)

Provides tools and resources for improving essential skills.

Location: Canada

Audience:

* Everyone

Topic:

* Jobs, volunteering and training

Skills for Success – Assessment and training tools, Work and career, Youth, Students and education planning, Employee, volunteer, or trainee

Benefit

#### [Wage Earner Protection Program](https://www.canada.ca/en/employment-social-development/services/wage-earner-protection/employee.html)

Provides financial protection for unpaid wages, vacation pay, and severance

Location: Canada

Audience:

* Everyone

Topic:

* Jobs, volunteering and training

Wage Earner Protection Program, Work and career, Employee, volunteer, or trainee, Losing your job or unable to work

Service

#### [Canadian Mental Health Association (CMHA) - Bounce Back](https://cmha.ca/bounce-back/)

A free skill-building program designed to help adults and youth 15+ manage low mood, mild to moderate depression, anxiety, stress or worry.

Location: Canada

Audience:

* Everyone
* Youth

Topic:

* Health and well-being

Canadian Mental Health Association (CMHA) - Bounce Back, Health, Youth, Health and well-being, Mental health

Benefit

#### [Accessible Navigation to Employment (ANTE) Program](https://chha.ca/programs-and-projects/)

Enhances the skills of Deaf and Hard of Hearing Canadians and trains employers to reduce employment barriers for the community. Free online micro-credential courses to upgrade skills and prepare individuals for employment.

Location: Canada

Audience:

* Everyone

Topic:

* Disability
* Health and well-being
* Jobs, volunteering and training

Accessible Navigation to Employment (ANTE) Program, Disability, Work and career, Employee, volunteer, or trainee

Service

#### [Accessibility complaints about transportation services](https://otc-cta.gc.ca/eng/accessibility-complaints-about-transportation-services)

Help to submit and resolve individual complaints about accessibility in federal transportation services through facilitation, mediation or adjudication.

Location: Canada

Audience:

* Everyone

Topic:

* Disability
* Health and well-being

Accessibility complaints about transportation services, Disability, Health and well-being, Transportation, Accessible public transit

Service

#### [Canadian Hard of Hearing Association (CHHA) - Mentorship Program](https://chha.ca/mentorship-program/)

Connects individuals with hearing loss with experienced mentors that help with personal development, career advice, and navigating daily life with hearing loss.

Location: Canada

Audience:

* Everyone

Topic:

* Disability
* Health and well-being

Canadian Hard of Hearing Association (CHHA) - Mentorship Program, Disability, Health and well-being, Hard of hearing

Loan

#### [Canada Apprentice Loan](https://www.canada.ca/en/services/jobs/training/support-skilled-trades-apprentices/loan.html)

With the Canada Apprentice Loan, you can get up to $4,000 in interest-free loans per period of technical training.

Location: Canada

Audience:

* Everyone
* Students
* Youth

Topic:

* Jobs, volunteering and training
* Going to school

Canada Apprentice Loan, Students and education planning, Work and career, Youth, Students and education planning, Employee, volunteer, or trainee, Loan

Benefit

#### [Employment Insurance (EI) Fishing Benefits](https://www.canada.ca/en/services/benefits/ei/ei-fishing.html)

Provides benefits to self-employed fishers who are actively seeking work.

Location: Canada

Audience:

* Everyone

Topic:

* Jobs, volunteering and training
* Losing your job or unable to work
* Starting or owning a business

Employment Insurance (EI) Fishing Benefits, Employment Insurance and leave, Work and career, Employee, volunteer, or trainee, Starting or owning a business, Losing your job or unable to work

Benefit

#### [Employment Insurance (EI) for Self-Employed Workers](https://www.canada.ca/en/services/benefits/ei/ei-self-employed-workers.html)

Opportunity to access EI special benefits for people who run their own business or control more than 40% of their corporation’s voting shares.

Location: Canada

Audience:

* Everyone

Topic:

* Jobs, volunteering and training
* Starting or owning a business
* Losing your job or unable to work

Employment Insurance (EI) for Self-Employed Workers , Employment Insurance and leave, Work and career, Starting or owning a business, Losing your job or unable to work

Service

#### [Canadian Mental Health Association (CMHA) - Not Myself Today](https://cmha.ca/what-we-do/national-programs/workplace-mental-health/not-myself-today/)

Not Myself Today is a practical and proven solution for transforming mental health in your workplace. A nominal, annual subscription gets you and your employees full access to the member-only online portal.

Location: Canada

Audience:

* Everyone

Topic:

* Health and well-being
* Jobs, volunteering and training

Canadian Mental Health Association (CMHA) - Not Myself Today, Health, Work and career, Employee, volunteer, or trainee, Mental health

Service

#### [Canadian Mental Health Association (CMHA) - Psychological Health & Safety Training](https://cmha.ca/what-we-do/national-programs/workplace-mental-health/psychological-health-safety-training/)

CMHA National offers both Psychological Health and Safety Professional Certificate and our course, Psychological Health and Safety: The Essentials.

Location: Canada

Audience:

* Everyone

Topic:

* Health and well-being
* Jobs, volunteering and training

Canadian Mental Health Association (CMHA) - Psychological Health & Safety Training, Health, Work and career, Employee, volunteer, or trainee, Mental health

Service

#### [Canadian Mental Health Association (CMHA) - Recovery Colleges](https://cmha.ca/what-we-do/national-programs/recovery-colleges/)

Recovery Colleges provide an innovative learning space where anyone can access free courses, webinars, workshops, and events to learn, gain new skills, and connect with others in their community.

Location: Canada

Audience:

* Everyone

Topic:

* Health and well-being
* Jobs, volunteering and training

Canadian Mental Health Association (CMHA) - Recovery Colleges, Health, Employee, volunteer, or trainee, Mental health

Service

#### [Canadian Mental Health Association (CMHA) - Resilient Minds](https://cmha.ca/resilient-minds/)

A trauma and evidence-informed, peer-led psychological health awareness training program designed by and for first responders across Canada.

Location: Canada

Audience:

* Everyone

Topic:

* Health and well-being
* Jobs, volunteering and training

Canadian Mental Health Association (CMHA) - Resilient Minds, Health, Work and career, Employee, volunteer, or trainee, Mental health

Benefit

#### [Repayment Assistance Plan (RAP)](https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/repay/assistance/rap.html)

Repayment assistance Plan for student loan borrowers experienceing financial difficulty.

Location: Canada

Audience:

* Everyone
* Youth
* Students

Topic:

* Going to school

Repayment Assistance Plan (RAP), Students and education planning, Youth, Students and education planning

Benefit

#### [Employment Insurance (EI) for Apprentices](https://www.canada.ca/en/services/jobs/training/support-skilled-trades-apprentices/ei-apprentices.html)

Employment Insurance (EI) benefits may be available for apprentices who have been referred by their province or territory to attend full-time technical training (sometimes referred to as block-release training).

Location: Canada

Audience:

* Everyone
* Students

Topic:

* Going to school
* Jobs, volunteering and training
* Losing your job or unable to work

Employment Insurance (EI) for Apprentices, Employment Insurance and leave, Students and education planning, Work and career, Youth, Students and education planning, Employee, volunteer, or trainee, Losing your job or unable to work

Benefit

#### [Veteran's Exceptional Incapacity Allowance](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/compensation-illness-or-injury/exceptional-incapacity-allowance)

Additional monthly payment for a disability pensioner if your illness or injury impacts your quality of life.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Seniors and retirees

Topic:

* Health and well-being
* Disability
* Retirement

Veteran's Exceptional Incapacity Allowance, Disability, Military and veterans, Pensions and Seniors, Retirement and planning

Benefit

#### [Employment Insurance (EI) Caregiving Benefits](https://www.canada.ca/en/services/benefits/ei/caregiving.html)

Financial support for caregivers who are away from work to provide support to a critically ill or injured person or someone needing end-of-life care.

Location: Canada

Audience:

* Everyone
* Caregivers
* Parents and legal guardians

Topic:

* Losing your job or unable to work

Employment Insurance (EI) Caregiving Benefits, Employment Insurance and leave, Family and caregiving, Caregiving and adult dependents, Losing your job or unable to work

Benefit

#### [Canada Pension Plan (CPP) Death Benefits](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-death-benefit.html)

Provides a one-time lump-sum payment to the estate or surviving family members of a deceased CPP contributor.

Location: Canada

Audience:

* Everyone
* Seniors and retirees

Topic:

* What to do when someone dies

Canada Pension Plan (CPP) Death Benefits, Pensions and seniors, Retirement and planning, Navigating a death

Benefit

#### [Canada student loans program - Severe permanent disability benefit](https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/repay/assistance/severe-disability.html)

Information on student loans forgiveness for a borrower who has a severe and permanent disability preventing them from pursuing further post-secondary education and from working.

Location: Canada

Audience:

* Everyone
* Students

Topic:

* Disability
* Going to school

Canada student loans program - Severe permanent disability benefit, Disability, Students and education planning, Students and education planning

Grant/Subsidy

#### [Grant for services and equipment for students with permanent disabilities](https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/disabilities-service-equipment.html)

A grant towards tuition, textbook, and accommodation costs for eligible students with a permanent disability.

Location: Canada

Audience:

* Everyone
* Students

Topic:

* Going to school
* Disability

Grant for services and equipment for students with permanent disabilities, Disability, Students and education planning, Students and education planning

Service

#### [Canadian Mental Health Association (CMHA) - Suicide Crisis Help Line](https://988.ca/)

Call or text 9-8-8. A safe space to talk, 24 hours a day, every day of the year.

Location: Canada

Audience:

* Everyone

Topic:

* Health and well-being

Canadian Mental Health Association (CMHA) - Suicide Crisis Help Line, Health, Health and well-being, Suicide

Benefit

#### [Canada Pension Plan (CPP) Children's Benefit](https://www.canada.ca/en/services/benefits/publicpensions/cpp/cpp-childrens-benefit.html)

Provides financial assistance to children of disabled or deceased CPP contributors

Location: Canada

Audience:

* Everyone
* Seniors and retirees
* Caregivers
* Parents and legal guardians

Topic:

* Retirement
* Disability
* Starting a family/raising children

Canada Pension Plan (CPP) Children's Benefit , Pensions and seniors, Family and caregiving, Starting a family/raising children, Retirement and planning, Navigating a death

Service

#### [Military - Leave Benefits](https://www.canada.ca/en/department-national-defence/corporate/policies-standards/leave-policy-manual.html)

The Canadian Forces Leave Policy Manual and rules associated with different types of leave.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Losing your job or unable to work

Military - Leave Benefits, Military and veterans, Losing your job or unable to work

Benefit

#### [Lifelong Learning Plan (LLP)](https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/rrsps-related-plans/lifelong-learning-plan.html)

Allows you to withdraw funds from your RRSPs for education or training.

Location: Canada

Audience:

* Everyone
* Students

Topic:

* Going to school
* Jobs, volunteering and training

Lifelong Learning Plan (LLP) , Students and education planning, Work and career, Students and education planning, Employee, volunteer, or trainee

Benefit

#### [Veterans - Attendance Allowance](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/compensation-illness-or-injury/attendance-allowance)

Monthly payments for a disability pensioner whose health needs require daily personal care support.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Seniors and retirees
* Caregivers

Topic:

* Disability
* Retirement
* Health and well-being

Veterans - Attendance Allowance, Pensions and seniors, Disability, Military and veterans, Caregiving and adult dependents, Retirement and planning, Health and well-being

Training

#### [Cadets](https://www.canada.ca/en/department-national-defence/services/cadets-junior-canadian-rangers/cadets.html)

A dynamic, funded program for young Canadians aged 12 to 18 across the country. Join the Sea, Army or Air Cadets and participate in exciting and challenging activities that you can’t experience anywhere else.

Location: Canada

Audience:

* Military and Veterans
* Youth
* Everyone

Topic:

* Jobs, volunteering and training

Cadets, Work and career, Military and veterans, Youth

Finder

#### [Business Benefits Finder](https://innovation.ised-isde.canada.ca/s/?language=en_CA)

Financial support for businesses, entreprenuers and not-for-profit organizations.

Location: Canada

Audience:

* Everyone

Topic:

* Starting or owning a business

Business Benefits Finder, businesses, entrepreuners, not-for-profit organizations, funding, grants, financial support

Benefit

#### [Registered Education Savings Plans (RESP) and related benefits](https://www.canada.ca/en/services/benefits/education/education-savings/estimating-amounts.html)

Matches contributions to Registered Education Savings Plans (RESPs) to help save for a child’s education.

Location: Canada

Audience:

* Everyone
* Students
* Parents and legal guardians
* Youth

Topic:

* Going to school
* Starting a family/raising children

Registered Education Savings Plans (RESP) and related benefits, Family and caregiving, Students and education planning, Youth, Students and education planning

Funding/Loan

#### [Canada Greener Affordable Housing](https://www.cmhc-schl.gc.ca/professionals/project-funding-and-mortgage-financing/funding-programs/all-funding-programs/canada-greener-affordable-housing-program)

Provides contributions for pre-retrofit activities needed to plan, prepare, and apply for retrofit funding. It also offers forgivable and low-interest loans to help affordable housing providers complete deep energy retrofits on existing multi-unit residential buildings.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Canada Greener Affordable Housing, Housing, Renting or home ownership, Housing assistance

Grant/Subsidy

#### [Canada Greener Homes Grant](https://natural-resources.canada.ca/energy-efficiency/homes/canada-greener-homes-initiative/canada-greener-homes-grant/24833)

Grant towards eligible retrofits like home insulation, windows and doors, heat pumps and solar panels as well as resiliency measures.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Canada Greener Homes Grant, Housing, Renting or home ownership, Grants

Loan

#### [Canada Greener Homes Loan](https://natural-resources.canada.ca/energy-efficiency/homes/canada-greener-homes-initiative/canada-greener-homes-loan/24286)

Offers interest-free financing from $5,000 to $40,000 to help complete major retrofits recommended by an energy advisor.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Canada Greener Homes Loan, Housing, Starting or owning a business, Loans

Benefit

#### [First home savings account](https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/first-home-savings-account.html)

A registered plan which allows first-time home buyers to save to buy or build a qualifying first home tax-free (up to certain limits).

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

First home savings account, Housing, Renting or home ownership, Housing assistance

Rebate

#### [GST/HST new housing rebate](https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/gst-hst-rebates/new-housing-rebate.html)

Recover part of GST/HST paid for a new or renovated home that is your primary residence.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

GST/HST new housing rebate, Housing, Renting or home ownership, Rebate, Housing assistance

Benefit

#### [Home Buyers' Plan (HBP)](https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/rrsps-related-plans/what-home-buyers-plan.html)

Allows first-time homebuyers to withdraw funds from their RRSPs for a down payment.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Home Buyers' Plan (HBP) , Housing, Renting or home ownership

Benefit

#### [Mortgage Loan Insurance](https://www.cmhc-schl.gc.ca/en/finance-and-investing/mortgage-loan-insurance)

Provides mortgage insurance for homebuyers with a down payment of less than 20%.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Mortgage Loan Insurance, Housing, Renting or home ownership, Housing assistance

Rebate

#### [GST/HST New Housing Rebate](https://www.canada.ca/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-home-construction/new-housing-rebate.html)

Provides a rebate for the GST/HST paid on the purchase of a new or substantially renovated home.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

GST/HST New Housing Rebate , Housing, Renting or home ownership

Benefit

#### [Oil to Heat Pump Affordability Program](https://natural-resources.canada.ca/energy-efficiency/homes/canada-greener-homes-initiative/oil-heat-pump-affordability-program/24775)

Helps eligible homeowners with median income or less who are currently heating their homes with oil make the transition to a better, more efficient option.

Location: Canada

Audience:

* Everyone

Topic:

* Renting or home ownership

Oil to Heat Pump Affordability Program, Housing, Renting or home ownership

Benefit

#### [Employment Insurance (EI) Maternity and Parental Benefits](https://www.canada.ca/en/services/benefits/ei/ei-maternity-parental.html)

Financial assistance to:
-people who are away from work because they're pregnant or have recently given birth
-parents who are away from work to care for their newborn or newly adopted child

Location: Canada

Audience:

* Everyone
* Parents and legal guardians

Topic:

* Starting a family/raising children
* Losing your job or unable to work

Employment Insurance (EI) Maternity and Parental Benefits, Employment Insurance and leave, Family and caregiving, Losing your job or unable to work, Starting a family

Benefit

#### [Additional Pain and Suffering Compensation (Veterans)](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/compensation-illness-or-injury/additional-pain-and-suffering-compensation)

Monthly payments in recognition of any severe and permanent disability, related to your military service, which creates a barrier to life after service.

Location: Canada

Audience:

* Military and Veterans
* Everyone

Topic:

* Disability

Additional Pain and Suffering Compensation (Veterans), Disability, Military and veterans, Health and well-being, Veterans, Veteran assistance

Service

#### [Veterans - Help from the Bureau of Pensions Advocates](https://www.veterans.gc.ca/eng/veterans-rights/how-to-appeal/bureau-pensions-advocates)

If you choose to review or appeal a disability benefits decision made by Veterans Affairs Canada, the Bureau of Pensions Advocates (BPA)–a nation-wide organization of lawyers within Veterans Affairs Canada–can provide you with free legal advice and representation.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Disability

Veterans - Help from the Bureau of Pensions Advocates, Military and veterans, Disability, Health and well-being

Benefit

#### [Canada Dental Benefit](https://www.canada.ca/en/revenue-agency/services/child-family-benefits/dental-benefit.html)

The interim Canada Dental Benefit is intended to help lower dental costs for eligible families earning less than $90,000 per year.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians
* Caregivers
* Seniors and retirees

Topic:

* Health and well-being
* Starting a family/raising children

Canada Dental Benefit, Family and caregiving, Health, Health and well-being, Benefits

Benefit

#### [Canadian Dental Care Plan](https://www.canada.ca/en/services/benefits/dental/dental-care-plan.html)

Help to lower dental costs for eligible families earning less than $90,000 per year.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians
* Caregivers
* Seniors and retirees

Topic:

* Starting a family/raising children
* Health and well-being

Canadian Dental Care Plan, Family and caregiving, Health, Health and well-being, Dental, Dental benefits for seniors, Dental care plan

Finder

#### [Grants and funding programs to fund my project](https://www.canada.ca/en/services/benefits/finder.html)

Find grants and funding programs to fund your project.

Location: Canada

Audience:

* Everyone

Topic:

* Grants and funding for projects

Grants, funding, project funding

Benefit

#### [University and College Entrance Preparation Program (UCEPP)](https://www.sac-isc.gc.ca/eng/1100100033688/1531936422341)

A program that enables First Nations students to attain the academic level required for entrance into degree and diploma credit programs, as prioritized and directed by First Nations.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Students
* Youth

Topic:

* Going to school

University and College Entrance Preparation Program (UCEPP), Students and education planning, Indigenous peoples, Youth, Students and education planning

Benefit

#### [Canadian Forces Income Support](http://www.veterans.gc.ca/eng/services/financial/cf-income-support)

Provides a tax-free payment for Canadian Forces Members who have completed the Rehabilitation Program and are able to work but have not been able to find a job or currently have a low-paying job.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Jobs, volunteering and training
* Disability

Canadian Forces Income Support, Disability, Military and veterans, Work and career, Employee, volunteer, or trainee, Losing your job or unable to work, Income assistance

Finder

#### [Personal income tax deductions, credits and expenses](https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/deductions-credits-expenses.html)

Find out which deductions, credits and expenses you can claim to reduce the amount of tax you need to pay.

Location: Canada

Audience:

* Everyone

Topic:

* Taxes

Income tax, tax deductions, credits, tax expenses, fiscal

Benefit

#### [Employment Insurance (EI) -Workers and residents outside of Canada](https://www.canada.ca/en/services/benefits/ei/ei-outside-canada.html)

Benefits that people who work outside Canada for a Canadian company or the Canadian government may be entitled to.

Location: Canada

Audience:

* Everyone
* Canadians living abroad

Topic:

* Losing your job or unable to work

Employment Insurance (EI) -Workers and residents outside of Canada, Employment Insurance and leave, Canadians living abroad, Losing your job or unable to work

Benefit

#### [On-reserve Income Assistance program](https://www.sac-isc.gc.ca/eng/1100100035256/1533307528663)

This program helps eligible on-reserve residents and Status Indians in Yukon to cover daily living costs and access pre-employment supports.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Jobs, volunteering and training
* Losing your job or unable to work

On-reserve Income Assistance program, Indigenous peoples, Employee, volunteer, or trainee, Losing your job or unable to work, Income assistance

Service

#### [Crisis Texting Service for Kids of CAF Families](https://cfmws.ca/support-services/families/children-youth/crisis-texting-service)

Children, youth and young adults from military families can access free mental health and well-being support.
Text CAFKIDS to 686868
Texte JEUNESFAC à 686868

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Youth

Topic:

* Starting a family/raising children
* Health and well-being

Crisis Texting Service for Kids of CAF Families, Health, Military and veterans, Youth, Starting a family/raising children, Health and well-being

Benefit

#### [Education reimbursement in the Canadian Armed Forces](https://www.canada.ca/en/department-national-defence/services/benefits-military/education-training/reimbursements-allowances/education.html)

Eligible members, including Primary Reservists, may claim full or partial reimbursement of certificates, single courses, diplomas, or degrees.

Location: Canada

Audience:

* Everyone
* Students
* Military and Veterans

Topic:

* Going to school
* Jobs, volunteering and training

Education reimbursement in the Canadian Armed Forces, Students and education planning, Military and veterans, Students and education planning, Employee, volunteer, or trainee

Volunteer

#### [Cadet Instructor Cadre Officers](https://www.canada.ca/en/department-national-defence/services/cadets-junior-canadian-rangers/leadership-of-the-programs/ciccoats.html)

There are many ways adults can serve the Cadet Program whether it is as a member of the Cadet Instructor Cadre, an officer or non-commissioned member of the Cadet Organizations Administration and Training Service, or as a volunteer.

Location: Canada

Audience:

* Military and Veterans
* Everyone

Topic:

* Jobs, volunteering and training

Cadet Instructor Cadre Officers, Work and career, Military and veterans, Employee, volunteer, or trainee

Training

#### [Canadian Armed Forces (CAF) summer training programs](https://forces.ca/en/programs-for-indigenous-peoples/summer-programs/)

Five summer training programs that are six weeks in duration, combining a variety of Military training and Indigenous cultural teachings. Participants will be paid during their participation in the program.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Jobs, volunteering and training

Canadian Armed Forces (CAF) summer training programs, Work and career, Military and veterans, Employee, volunteer, or trainee, Indigenous

Service

#### [Veterans - Career Transition Services](https://www.veterans.gc.ca/eng/education-and-jobs/finding-a-job/career-transition-services)

Services for veterans transitioning to civilian careers

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Jobs, volunteering and training

Veterans - Career Transition Services, Work and career, Military and veterans, Employee, volunteer, or trainee

Training

#### [Junior Canadian Rangers](https://www.canada.ca/en/department-national-defence/services/cadets-junior-canadian-rangers/junior-canadian-rangers.html)

A challenging and rewarding program for youth in remote communities across Canada. The program integrates practical skills and cultural practices in a fun and friendly environment.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Military and Veterans
* Youth

Topic:

* Jobs, volunteering and training

Junior Canadian Rangers, Indigenous peoples, Military and veterans, Work and career, Youth

Benefit

#### [Canada Child Benefit](https://www.canada.ca/en/revenue-agency/services/child-family-benefits/canada-child-benefit-overview.html)

A tax-free monthly payment made to eligible families to help with the cost of raising children under 18 years of age.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians

Topic:

* Starting a family/raising children

Canada Child Benefit, Family and caregiving, Starting a family/raising children, Benefits

Service

#### [Nobody's Perfect Parenting Program](https://www.canada.ca/en/public-health/services/health-promotion/childhood-adolescence/parent/nobody-perfect.html)

A parenting program for parents of children aged 0-5 years.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians

Topic:

* Starting a family/raising children

Nobody's Perfect Parenting Program , Family and caregiving, Starting a family/raising children

Service

#### [Military -Children’s Education Management](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/children-education-management/about-childrens-education-management.html)

CEM provides services for the education of children of CAF members both inside and outside of Canada.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Students
* Youth

Topic:

* Starting a family/raising children

Military -Children’s Education Management , Students and education planning, Military and veterans, Youth, Starting a family/raising children

Benefit

#### [Veteran's Education and Training Benefit](https://www.veterans.gc.ca/eng/education-and-jobs/back-to-school/education-training-benefit)

Offers funding for education and post-military employment goals.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Students

Topic:

* Going to school

Veteran's Education and Training Benefit , Students and education planning, Military and veterans, Students and education planning, Employee, volunteer, or trainee

Service

#### [CAF Operational Trauma and Stress Support Program](https://www.canada.ca/en/department-national-defence/programs/caf-mental-health-services.html#otssp)

The Operational Trauma and Stress Support Program provides assessment and treatment for Canadian Armed Forces (CAF) members who struggle with operational stress injuries.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Disability
* Health and well-being

CAF Operational Trauma and Stress Support Program, Disability, Military and veterans, Health, Health and well-being, Veterans

Service

#### [Case Management Program](https://www.canada.ca/en/department-national-defence/programs/case-management-program.html)

Provides professional guidance to Canadian Armed Forces (CAF) members following illness or injury with the goal of facilitating the achievement of optimal health and wellness.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Disability
* Health and well-being

Case Management Program, Disability, Military and veterans, Health, Health and well-being, Recovery

Benefit

#### [Military - Benefits for the Ill and Injured](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/benefits-ill-injured.html)

Canadian Armed Forces benefits for you and your family during a time of illness and injury.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Disability
* Health and well-being

Military - Benefits for the Ill and Injured , Disability, Military and veterans, Health, Health and well-being

Service

#### [Veterans - Operational Stress Injury (OSI) Clinics](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/assessment-and-treatment/osi-clinics)

OSI Clinics provide assessment, treatment, prevention and support.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being
* Disability

Veterans - Operational Stress Injury (OSI) Clinics, Health, Military and veterans, Disability, Health and well-being

Service

#### [Veterans - Peer support](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/counselling-services/talk-someone-who-can-relate)

There are peer support networks for members or Veterans of the CAF or the RCMP living with an operational stress injury (OSI).

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being
* Disability

Veterans - Peer support, Health, Military and veterans, Disability, Health and well-being

Service

#### [Veterans - Rehabilitation services](https://www.veterans.gc.ca/en/health-programs-and-services/physical-health-and-wellness/rehabilitation-services)

Rehabilitation services for veterans to improve health and help with adjusting to life at home, in your community or at work.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being
* Disability

Veterans - Rehabilitation services, Health, Military and veterans, Disability, Health and well-being

Benefit

#### [Veteran's Disability Benefits](https://www.veterans.gc.ca/en/health-programs-and-services/physical-health-and-wellness/compensation-illness-or-injury/disability-benefits)

Veterans with service-related medical conditions or disabilities can access tax-free financial payments and support.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being
* Disability

Veteran's Disability Benefits, Disability, Military and veterans, Health and well-being

Service

#### [Veterans Review and Appeal Board](https://www.vrab-tacra.gc.ca/Home-accueil-eng.cfm)

Provides appeal services to Veterans, Canadian Armed Forces and RCMP members and their families.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being
* Disability

Veterans Review and Appeal Board, Disability, Military and veterans, Health and well-being

Benefit

#### [Child Disability Benefit (CDB)](https://www.canada.ca/en/revenue-agency/services/child-family-benefits/child-disability-benefit.html)

Financial support for families caring for a child with a disability.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians
* Caregivers

Topic:

* Disability
* Starting a family/raising children
* Health and well-being

Child Disability Benefit (CDB), Family and caregiving, Disability, Starting a family/raising children, Caregiving and adult dependents, Health and well-being

Finder

#### [Indigenous Bursaries Search Tool](https://www.sac-isc.gc.ca/eng/1351185180120/1351685455328)

The Indigenous bursaries search tool is a searchable list of 536 bursaries, scholarships and incentives aimed at Indigenous students across Canada.

Location: Canada

Audience:

* Everyone
* Students
* Indigenous Peoples

Topic:

* Going to school

Indigenous Bursaries Search Tool, Students and education planning, Indigenous peoples, Students and education planning

Benefit

#### [Indigenous Services Canada (ISC) Post-Secondary Student Support Program](https://www.sac-isc.gc.ca/eng/1100100033682/1531933580211)

Financial assistance to First Nations students who are enrolled in eligible post-secondary programs.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Students

Topic:

* Going to school

Indigenous Services Canada (ISC) Post-Secondary Student Support Program, Students and education planning, Indigenous peoples, Students and education planning

Benefit

#### [Legal Studies for Indigenous People Program (LSIP)](https://www.justice.gc.ca/eng/fund-fina/acf-fca/lsap-aeda.html)

Promotes the equitable representation of Indigenous people in the legal profession by providing bursaries to Métis and non-status Indians who wish to attend law school.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Students

Topic:

* Going to school

Legal Studies for Indigenous People Program (LSIP), Students and education planning, Indigenous peoples, Students and education planning

Service

#### [Indigenous Skills and Employment Training Program (ISET)](https://www.canada.ca/en/employment-social-development/programs/indigenous-skills-employment-training.html)

Supports Indigenous people in gaining skills and finding employment.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Jobs, volunteering and training

Indigenous Skills and Employment Training Program (ISET), Indigenous peoples, Work and career, Employee, volunteer, or trainee

Service

#### [First Nations and Inuit home and community care](https://www.sac-isc.gc.ca/eng/1582550638699/1582550666787)

Home and community care services to disabled, ill or elderly Indigenous and Inuit people living in First Nations and Inuit communities.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Disability
* Health and well-being

First Nations and Inuit home and community care, Disability, Indigenous peoples, Health, Health and well-being, First Nations

Service

#### [CAF - The Royal Canadian Chaplain Service](https://www.canada.ca/en/department-national-defence/programs/royal-canadian-chaplain.html)

Contributes to the operational effectiveness of the Canadian Armed Forces (CAF) by supporting the moral and spiritual wellbeing of military personnel and their families – domestically and internationally.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CAF - The Royal Canadian Chaplain Service, Military and veterans, Health and well-being, Veterans

Service

#### [CAF Addictions Treatment Program](https://www.canada.ca/en/department-national-defence/programs/caf-mental-health-services.html#atp)

Provides assessment and treatment to Canadian Armed Forces (CAF) members struggling with alcohol, drugs, and gambling, as well as other addictions.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CAF Addictions Treatment Program, Military and veterans, Health, Health and well-being, Veterans, Addicition

Service

#### [CAF Mental Health Program](https://www.canada.ca/en/department-national-defence/programs/caf-mental-health-services.html#mhp)

The program offers specialized mental health services to Canadian Armed Forces (CAF) members who are referred by their physician.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CAF Mental Health Program, Military and veterans, Health, Health and well-being, Veterans

Service

#### [CAF Psychosocial Services Program](https://www.canada.ca/en/department-national-defence/programs/caf-mental-health-services.html#psp)

The program offers bilingual mental health and administrative services to Canadian Armed Forces (CAF) members on a walk-in basis.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CAF Psychosocial Services Program, Military and veterans, Health, Health and well-being, Veterans

Training

#### [CAF Road to Mental Readiness Program](https://www.canada.ca/en/department-national-defence/programs/road-to-mental-readiness.html)

A program offers resilience and mental health training to Canadian Armed Forces (CAF) members throughout their careers.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CAF Road to Mental Readiness Program, Military and veterans, Health, Health and well-being, Veterans

Service

#### [CF Member Assistance Program](https://www.canada.ca/en/department-national-defence/programs/member-assistance.html)

The CFMAP offers confidential, voluntary, short term counselling to assist with resolving many of today's stresses at home and in the work place.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

CF Member Assistance Program, Health, Health and well-being, CF Member, Mental health, Counselling

Service

#### [Military - Family Information Line](https://cfmws.ca/support-services/family-information-line)

365 days a year, 24 hours a day. We listen. . A confidential, personal, bilingual and free service offering information, support, referrals, reassurance and crisis management to the military community.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Military - Family Information Line, Health, Military and veterans, Health and well-being

Benefit

#### [Military - Medical and Dental Benefits](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/medical-dental.html)

Comprehensive medical and dental services available to Canadian Armed Forces (CAF) members under the Spectrum of Care.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Military - Medical and Dental Benefits, Military and veterans, Health, Health and well-being, Dental Care

Service

#### [Military Family Resource Centres (MFRC)](https://cfmws.ca/support-services/families/military-family-resource-centres)

MFRCs are essentially the heart of their military communities. Dedicated staff are frontline service providers, responsible for connecting military families to a wide range of programs and services.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Military Family Resource Centres (MFRC), Military and veterans, Health and well-being, Veteran assistance, Veterans

Service

#### [Sexual Misconduct Support and Resource Centre (SMSRC) - Community Consultations](https://www.canada.ca/en/department-national-defence/services/benefits-military/health-support/sexual-misconduct-response/smsrc-community-consultation-group.html)

The Sexual Misconduct Support and Resource Centre (SMSRC) invites members of the wider Defence community affected by sexual misconduct to provide their feedback, advice and recommendations on support services and resources available to them.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Sexual Misconduct Support and Resource Centre (SMSRC) - Community Consultations , Military and veterans, Health and well-being, Sexual Misconduct, Veterans assistance, Veterans support

Service

#### [Sexual Misconduct Support and Resource Centre (SMSRC) - Independent Legal Assistance Program](https://www.canada.ca/en/department-national-defence/services/benefits-military/health-support/sexual-misconduct-response/legal-assistance-program.html)

The Independent Legal Assistance (ILA) program is an initiative to facilitate access to legal services for individuals who have experienced military sexual misconduct.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Sexual Misconduct Support and Resource Centre (SMSRC) - Independent Legal Assistance Program, Military and veterans, Health and well-being, Veterans assistance, Veterans support

Service

#### [Sexual Misconduct Support and Resource Centre (SMSRC) - Peer support group services](https://www.canada.ca/en/department-national-defence/services/benefits-military/health-support/sexual-misconduct-response/mst-peer-support-program-consultations/gathering-feedback.html)

In partnership with Veterans Affairs Canada (VAC), the SMSRC is offering a peer support program for those that have been affected by sexual misconduct and/or military sexual trauma (MST).

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Sexual Misconduct Support and Resource Centre (SMSRC) - Peer support group services, Military and veterans, Health and well-being, Veterans assistance, Veterans support

Service

#### [Sexual Misconduct Support and Resource Centre (SMSRC) - Support Services](https://www.canada.ca/en/department-national-defence/services/benefits-military/health-support/sexual-misconduct-response/get-support.html)

Sexual Misconduct Support and Resource Centre (SMSRC) provides support services to those directly or indirectly affected by sexual misconduct

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Sexual Misconduct Support and Resource Centre (SMSRC) - Support Services, Military and veterans, Health and well-being

Finder

#### [Sexual misconduct support resources search tool](https://www.canada.ca/en/department-national-defence/services/benefits-military/health-support/sexual-misconduct-response/resources-search-tool.html)

If you have been affected by or observed sexual misconduct, or are supporting someone who has been affected by sexual misconduct, you can use the search tool below to find support and care services in your area.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Sexual misconduct support resources search tool, Military and veterans, Health and well-being

Service

#### [Veterans - Family Peer Support (OSISS)](https://veterans.gc.ca/en/families-and-caregivers/health-programs-and-services/family-peer-support-osiss)

Operational Stress Injury Social Support (OSISS) is a peer support network for CAF members, Veterans and their families experiencing an operational stress injury (OSI).

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Family Peer Support (OSISS), Health, Military and veterans, Health and well-being

Benefit

#### [Veterans - Group Health Insurance](https://veterans.gc.ca/en/families-and-caregivers/health-programs-and-services/group-health-insurance)

Access for Veterans to group health insurance through the Public Service Health Care Plan.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Group Health Insurance, Health, Military and veterans, Health and well-being

Benefit

#### [Veterans - Health-related travel expenses](https://www.veterans.gc.ca/en/health-programs-and-services/mental-health-and-wellness/medical-costs/health-related-travel-expenses)

Coverage for veterans for travel expenses related to healthcare services or benefits.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Health-related travel expenses , Health, Military and veterans, Health and well-being

Benefit

#### [Veterans - Mental Health Benefits](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/medical-costs/mental-health-benefits)

Coverage for treatment of certain mental health conditions. Available as soon as you apply for a VAC disability benefit.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Mental Health Benefits, Health, Military and veterans, Health and well-being

Service

#### [Veterans - Talk to a Mental Health Professional](https://www.veterans.gc.ca/eng/contact/talk-to-a-professional)

Connects veterans and their families with professionals for support and assistance.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Talk to a Mental Health Professional , Health, Military and veterans, Health and well-being

Benefit

#### [Veterans - Treatment benefits](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/medical-costs/coverage-services-prescriptions-and-devices)

Financial support to veterans for health-care services such as prescription drugs, psychological counselling, and more.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Health and well-being

Veterans - Treatment benefits, Health, Military and veterans, Health and well-being

Internship

#### [Federal Internship for Newcomers Program](https://www.canada.ca/en/immigration-refugees-citizenship/services/new-immigrants/prepare-life-canada/prepare-work/federal-internship.html)

Provides internship opportunities for new immigrants to gain Canadian work experience.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

* Jobs, volunteering and training

Federal Internship for Newcomers Program, Work and career, Immigration, Employee, volunteer, or trainee, Newcomer to Canada

Service

#### [Language Classes for New Immigrants](https://www.canada.ca/en/immigration-refugees-citizenship/services/new-immigrants/new-life-canada/improve-english-french/classes.html)

Free English and French language classes for permanent residents and protected persons.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

* Jobs, volunteering and training

Language Classes for New Immigrants , Immigration, Work and career, Newcomer to Canada, Employee, volunteer, or trainee, English class, French class

Training

#### [Canadian Armed Forces Indigenous Entry Program (CAFIEP)](https://forces.ca/en/programs-for-indigenous-peoples/cafiep/)

The Canadian Armed Forces Indigenous Entry Program (CAFIEP) offers a three-week program for Indigenous peoples who are considering a career in the Canadian Armed Forces (CAF).

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Indigenous Peoples

Topic:

* Jobs, volunteering and training

Canadian Armed Forces Indigenous Entry Program (CAFIEP), Indigenous peoples, Military and veterans, Employee, volunteer, or trainee

Benefit

#### [Home Child Care Provider Pilot and Home Support Worker Pilot](https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/caregivers/child-care-home-support-worker.html)

Pilot programs that lets qualified caregivers come to Canada with the goal of becoming permanent residents

Location: Canada

Audience:

* Everyone
* Caregivers
* Newcomer to Canada

Topic:

* Jobs, volunteering and training

Home Child Care Provider Pilot and Home Support Worker Pilot, Family and caregiving, Caregiving and adult dependents, Newcomer to Canada

Service

#### [Work temporarily as a caregiver](https://www.canada.ca/en/immigration-refugees-citizenship/services/immigrate-canada/caregivers/work-temporarily-caregiver.html)

If you don’t meet the requirements for permanent residence, or can’t apply under the Home Child Care Provider or Home Support Worker pilots, you may be able to work temporarily as a caregiver

Location: Canada

Audience:

* Everyone
* Caregivers
* Newcomer to Canada

Topic:

* Jobs, volunteering and training

Work temporarily as a caregiver, Family and caregiving, Newcomer to Canada, Caregiving and adult dependents

Benefit

#### [Indigenous Leadership Opportunity Year (ILOY)](https://forces.ca/en/programs-for-indigenous-peoples/iloy/)

The Indigenous Leadership Opportunity Year (ILOY) gives you a highly positive and productive academic year of educational and leadership experience at the Royal Military College of Canada (RMC) in Kingston, Ontario.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Military and Veterans
* Students

Topic:

* Going to school

Indigenous Leadership Opportunity Year (ILOY), Indigenous peoples, Military and veterans, Students and education planning, Students and education planning

Benefit

#### [Veteran Family Program](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/counselling-services/veteran-family-program)

Continued access to services from Military Family Resource Centres to assist medically-released Veterans and their family.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Parents and legal guardians

Topic:

* Health and well-being
* Starting a family/raising children

Veteran Family Program, Health, Military and veterans, Starting a family/raising children

Finder

#### [Scholarship Search Tool](https://www.educanada.ca/scholarships-bourses/search-scholarships-rechercher-bourses.aspx?lang=eng)

Find international scholarship opportunities available for Canadian and international students, researchers and postsecondary institutions.

Location: Canada

Audience:

* Everyone
* Youth
* Students
* Newcomer to Canada
* Canadians living abroad

Topic:

* Going to school

Scholarship Search Tool, Students and education planning, Youth, Students and education planning

Service

#### [Federal Indian Day Schools health support services](https://www.sac-isc.gc.ca/eng/1594067962949/1594068284591)

Find health support services for individuals affected by the trauma associated with their attendance at an historic Federal Indian Day School.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Federal Indian Day Schools health support services, Indigenous peoples, Health, Health and well-being

Finder

#### [Government of Canada programs and initiatives to support Indigenous women, girls and 2SLGBTQI+ people](https://www.rcaanc-cirnac.gc.ca/eng/1671807890017/1671807916721)

Find programs and initiatives that have been put in place by the Government of Canada to address the federal pathway, national action plan and Calls for Justice.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Government of Canada programs and initiatives to support Indigenous women, girls and 2SLGBTQI+ people, Indigenous peoples, Health and well-being

Service

#### [Hope for Wellness Helpline](https://www.sac-isc.gc.ca/eng/1576089519527/1576089566478)

The Hope for Wellness Help Line offers immediate help to all Indigenous peoples across Canada 24 hours a day, 7 days a week. Call 1-855-242-3310 or chat online at hopeforwellness.ca.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Hope for Wellness Helpline, Health, Indigenous peoples, Health and well-being, Indigenous peoples

Service

#### [Indian Residential Schools Resolution Health Support Program](https://www.sac-isc.gc.ca/eng/1581971225188/1581971250953)

This program provides cultural and emotional support, and mental health counselling services to Survivors of Indian Residential Schools and the families of former students.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Indian Residential Schools Resolution Health Support Program, Indigenous peoples, Health, Health and well-being, Residential Schools

Service

#### [Mental health counselling benefits for First Nations and Inuit](https://www.sac-isc.gc.ca/eng/1576088923626/1576088963494)

Get information on counselling benefits. Find out what is covered, how to access services and how providers can register to offer services.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Mental health counselling benefits for First Nations and Inuit, Health, Indigenous peoples, Health and well-being

Benefit

#### [Non-insured health benefits for First Nations and Inuit](https://www.sac-isc.gc.ca/eng/1572537161086/1572537234517)

Provides eligible First Nations and Inuit clients with coverage for a range of health benefits that are not covered through other social programs, private insurance plans, or provincial or territorial health insurance.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Non-insured health benefits for First Nations and Inuit, Health, Indigenous peoples, Health and well-being, Financial support for medical expenses, medical benefits

Service

#### [Residential Schools Missing Children Community Support Fund](https://www.rcaanc-cirnac.gc.ca/eng/1622742779529/1628608766235)

Supporting Indigenous communities and families as they seek to research, locate, and document burial sites associated with former residential schools.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Residential Schools Missing Children Community Support Fund, Indigenous peoples, Health and well-being

Finder

#### [Substance use treatment centres for First Nations and Inuit](https://www.sac-isc.gc.ca/eng/1576090254932/1576090371511)

Find a treatment centre near you.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

Substance use treatment centres for First Nations and Inuit, Indigenous peoples, Health, Health and well-being, Recovery, Medical assistance

Service

#### [The National Residential School Crisis Line](https://nac-cnn.ca/resources/)

Call 1-866-925-4419. The National Residential School Crisis Line is available at all times, free of charge. Free support is also available through the Hope for Wellness chatline at 1-800-721-0066 or using the chat box at https://www.hopeforwellness.ca/.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Health and well-being

The National Residential School Crisis Line, Indigenous peoples, Health, Health and well-being, Residential School

Benefit

#### [War Veterans Allowance](https://www.veterans.gc.ca/en/financial-programs-and-services/income-support/war-veterans-allowance)

The War Veterans Allowance (WVA) is a tax-free, monthly benefit to help low-income war Veterans and their dependents or their survivors.

Location: Canada

Audience:

* Everyone
* Parents and legal guardians
* Caregivers
* Military and Veterans

Topic:

* Starting a family/raising children

War Veterans Allowance, Family and caregiving, Military and veterans,

Benefit

#### [Veterans - Support for families and caregivers](https://veterans.gc.ca/en/families-and-caregivers/health-programs-and-services/support-families-and-caregivers)

Provides support for families and caregivers of veterans

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Caregivers

Topic:

* Starting a family/raising children

Veterans - Support for families and caregivers, Family and caregiving, Military and veterans, Starting a family/raising children, Caregiving and adult dependents

Benefit

#### [Canadian Forces Housing Differential](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/canadian-forces-housing-differential.html)

Assisting CAF members in adjusting to housing costs in different locations within Canada.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* Renting or home ownership

Canadian Forces Housing Differential, Housing, Military and veterans, Renting or home ownership, Housing assistance

Benefit

#### [Inuit Child First Initiative](https://www.sac-isc.gc.ca/eng/1536348095773/1536348148664)

The Inuit Child First Initiative ensures Inuit children have access to the essential government funded health, social and educational products, services and supports they need, when they need them.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Starting a family/raising children

Inuit Child First Initiative, Indigenous peoples, Family and caregiving, Youth, Starting a family/raising children

Benefit

#### [Health Care for Refugees](https://www.canada.ca/en/immigration-refugees-citizenship/services/refugees/help-within-canada/health-care.html)

Offers health care coverage to refugees and protected persons upon arrival in Canada.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

* Health and well-being

Health Care for Refugees , Health, Newcomer to Canada

Finder

#### [Newcomer Services Finder](https://www.cic.gc.ca/english/newcomers/services/index.asp)

Look for free newcomer services to help you look for a job, get a language assessment, register for language classes, find a place to live, sign up for kids school and learn about community services.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

* Going to school
* Jobs, volunteering and training
* Renting or home ownership
* Starting a family/raising children
* Health and well-being

Newcomer Services Finder, Immigration, Newcomer to Canada

Loan

#### [Direct Lending Program for First Nation Communities](https://www.cmhc-schl.gc.ca/professionals/project-funding-and-mortgage-financing/funding-programs/all-funding-programs/funding-first-nations-development/direct-lending-program-first-nation-communities)

Property financing and loan renewals for affordable housing projects in First Nation communities.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

Direct Lending Program for First Nation Communities, Indigenous peoples, Housing, Renting or home ownership, Housing assistance

Loan

#### [Insured Loans for On-Reserve First Nation Housing](https://www.cmhc-schl.gc.ca/professionals/project-funding-and-mortgage-financing/funding-programs/all-funding-programs/funding-first-nations-development/insured-loans-on-reserve-first-nation-housing)

Insured loans to help First Nation members living on-reserve to get access to financing for housing projects and renovations.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

Insured Loans for On-Reserve First Nation Housing, Housing, Indigenous peoples, Renting or home ownership

Loan

#### [Ministerial Loan Guarantees](https://www.sac-isc.gc.ca/eng/1100100010759/1533297595541)

Ministerial Loan Guarantees are used to secure loans to build, purchase or renovate on-reserve housing.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

Ministerial Loan Guarantees, Housing, Indigenous peoples, Renting or home ownership

Benefit

#### [New construction funding for Indigenous housing](https://www.cmhc-schl.gc.ca/professionals/project-funding-and-mortgage-financing/funding-programs/indigenous/new-construction)

Funding and financing to build new housing for Indigenous communities on-reserve and off-reserve in Canada.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

New construction funding for Indigenous housing, Housing, Indigenous peoples, Renting or home ownership

Benefit

#### [On-reserve Residential Rehabilitation Assistance Program (RRAP)](https://www.cmhc-schl.gc.ca/en/developing-and-renovating/funding-opportunities/on-reserve-renovation-programs/residential-rehabilitation-assistance-program)

Funding for major repairs, emergency repairs and adaptations to improve the health and safety of on-reserve housing.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

On-reserve Residential Rehabilitation Assistance Program (RRAP), Housing, Indigenous peoples, Renting or home ownership

Benefit

#### [Renovation funding for Indigenous housing](https://www.cmhc-schl.gc.ca/professionals/project-funding-and-mortgage-financing/funding-programs/indigenous/repair-and-renewal)

Funding and financing to repair and renew on-reserve and off-reserve housing for Indigenous communities.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Renting or home ownership

Renovation funding for Indigenous housing, Housing, Indigenous peoples, Renting or home ownership, Housing assistance

Service

#### [Update the Indian Register](https://www.sac-isc.gc.ca/eng/1100100032475/1572459510512)

Update, report a birth or report a death in the Indian Register.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples

Topic:

* Starting a family/raising children
* What to do when someone dies

Update the Indian Register, Family and caregiving, Indigenous peoples, Starting a family/raising children, Navigating a death

Service

#### [Estate services for First Nations](https://www.sac-isc.gc.ca/eng/1100100032357/1581866877231)

Services to help you manage the property of a minor or a dependent adult who usually lives on a reserve or the estate of a deceased family member or friend who usually lived on a reserve.

Location: Canada

Audience:

* Everyone
* Indigenous Peoples
* Parents and legal guardians
* Caregivers

Topic:

* Starting a family/raising children
* What to do when someone dies

Estate services for First Nations, Indigenous peoples, Family and caregiving, Starting a family/raising children, Caregiving and adult dependents, Navigating a death

Benefit

#### [Military Death Benefits](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/military-death-benefits.html)

Claims and reimbursements for the family, spouse or estate of a deceased Canadian Armed Forces (CAF) member.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* What to do when someone dies

Military Death Benefits, Military and veterans, Navigating a death, Veteran assistance, Veterans

Benefit

#### [Veterans - Funeral and Burial Assistance](https://www.veterans.gc.ca/eng/financial-support/death-and-bereavement/funeral-burial-assistance)

Funeral and burial assistance is provided throughthe Last Post Fund – a non-profit organization – to help pay for funeral and burial services, including a military gravestone, for eligible Veterans.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* What to do when someone dies

Veterans - Funeral and Burial Assistance, Military and veterans, Navigating a death

Service

#### [Veterans - Speak to a chaplain](https://www.veterans.gc.ca/en/health-programs-and-services/mental-health-and-wellness/counselling-services/speak-chaplain)

Spiritual support when Veterans or their families are dealing with end of life issues or bereavement.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

* What to do when someone dies

Veterans - Speak to a chaplain, Military and veterans, Navigating a death

Benefit

#### [Attending Parole Board of Canada Hearings](https://www.justice.gc.ca/eng/fund-fina/cj-jp/fund-fond/attend-audience.html)

The Victims Fund offers financial assistance to registered victims (and their support person) who wish to attend hearings for the offender who harmed them in order to help victims participate more fully in the criminal justice system.

Location: Canada

Audience:

* Victims of crime
* Everyone

Topic:

* Health and well-being

Attending Parole Board of Canada Hearings, Victims of crime, Health and well-being

Service

#### [Register as a Victim of Crime](https://www.canada.ca/en/parole-board/services/victims/how-to-register-as-a-victim.html)

Register as a victim of crime with either the Parole Board of Canada (PBC) or the Correctional Service of Canada (CSC).

Location: Canada

Audience:

* Everyone
* Victims of crime

Topic:

* Health and well-being

Register as a Victim of Crime, Victims of Crime, Health and well-being

Finder

#### [Victims Services Directory (VSD)](https://www.justice.gc.ca/eng/cj-jp/victims-victimes/information-renseignements.html)

For contact information for the provincial or regional victim services in your area, you can search the national online Victim Services Directory (VSD).

Location: Canada

Audience:

* Everyone
* Victims of crime

Topic:

* Health and well-being

Victims Services Directory (VSD), Victims of Crime, Health and well-being

Benefit

#### [Canadian Benefit for Parents of Young Victims of Crime](https://www.canada.ca/en/employment-social-development/services/parents-young-victims-crime/apply.html)

Offers financial assistance to parents who have taken time off work and expierenced a loss of income due to the death or disappearance of a child.

Location: Canada

Audience:

* Everyone
* Victims of crime

Topic:

* Starting a family/raising children
* Health and well-being

Canadian Benefit for Parents of Young Victims of Crime, Family and caregiving, Victims of Crime, Starting a family/raising children, Health and well-being

Benefit

#### [Financial Assistance for Canadians Victimized Abroad](https://www.justice.gc.ca/eng/fund-fina/cj-jp/fund-fond/abroad-etranger.html)

Canadians who have been the victim of a serious violent crime in a foreign country may be eligible for financial assistance through the Victims Fund.

Location: Canada

Audience:

* Everyone
* Victims of crime
* Canadians living abroad

Topic:

* Health and well-being

Financial Assistance for Canadians Victimized Abroad, Victims of Crime, Canadians living abroad, Health and well-being

Rebate

#### [Canada Carbon Rebate (CCR)](https://www.canada.ca/en/revenue-agency/services/child-family-benefits/cai-payment.html)

A tax-free quarterly payment to help eligible individuals and families offset the cost of the federal pollution pricing.

Location: Canada

Audience:

* Everyone

Topic:

Canada Carbon Rebate (CCR), Rebate

Service

#### [Community Volunteer Income Tax Program (CVITP)](https://www.canada.ca/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program.html)

Free tax clinics where volunteers complete tax returns for people with a modest income and a simple tax situation.

Location: Canada

Audience:

* Everyone

Topic:

Community Volunteer Income Tax Program (CVITP) , ,

Loan

#### [Immigration Loans Program](https://www.canada.ca/en/immigration-refugees-citizenship/services/refugees/help-within-canada/financial.html)

Financial help to refugees selected for resettlement. The loans are used to cover the costs of:
a) transportation to Canada, and
b) additional settlement costs, if needed, once you are in Canada.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

Immigration Loans Program, Immigration, Newcomer to Canada, Financial assistance

Benefit

#### [Military - Relocation, travel, and accommodation benefits](https://www.canada.ca/en/department-national-defence/services/benefits-military/pay-pension-benefits/benefits/relocation-travel-accommodation.html)

Temporary duty, travel, relocation, and accommodation benefits for the Canadian Armed Forces.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

Military - Relocation, travel, and accommodation benefits, Military and veterans,

Benefit

#### [Resettlement Assistance Program](https://www.canada.ca/en/immigration-refugees-citizenship/services/refugees/help-within-canada/financial.html)

Financial resettlement help to Convention Refugees Abroad. In some cases, they offer this help to members of the Country of Asylum Class who have been:
a) identified as refugees with special needs and
b) admitted to Canada as government-assisted refugees.

Location: Canada

Audience:

* Everyone
* Newcomer to Canada

Topic:

Resettlement Assistance Program, Immigration, Newcomer to Canada

Benefit

#### [Tax-Free Savings Account (TFSA)](https://www.canada.ca/en/revenue-agency/services/tax/registered-plans-administrators/tax-free-savings-account-tfsa.html)

Details about TFSA, a tax-advantaged savings account for Canadians.

Location: Canada

Audience:

* Everyone

Topic:

Tax-Free Savings Account (TFSA), ,

Benefit

#### [Veterans - Financial Advice](https://www.veterans.gc.ca/eng/financial-support/financial-planning/financial-advice)

You can receive up to $500 to get advice from a financial professional on how to invest and manage your lump-sum award from Veterans Affairs Canada.

Location: Canada

Audience:

* Everyone
* Military and Veterans

Topic:

Veterans - Financial Advice, Military and veterans,

Benefit

#### [Veterans Caregiver Recognition Benefit](https://www.veterans.gc.ca/en/mental-and-physical-health/mental-health-and-wellness/compensation-illness-or-injury/caregiver-recognition-benefit)

A monthly payment for an informal caregiver, such as a family member or friend, who provides you with daily personal care support.

Location: Canada

Audience:

Topic:

Veterans Caregiver Recognition Benefit, Family and caregiving, Military and veterans, Caregiving and adult dependents

Benefit

#### [Veterans Independence Program](https://www.veterans.gc.ca/en/financial-programs-and-services/help-home/veterans-independence-program)

The Veterans Independence Program provides annual tax-free funding for services such as grounds maintenance, housekeeping, meal preparation, personal care, and professional health and support services to help eligible veterans remain independent at home.

Location: Canada

Audience:

* Everyone
* Military and Veterans
* Caregivers

Topic:

Veterans Independence Program, Military and veterans, Caregiving and adult dependents

No item match this combination of filters.

## Page details

Date modified:
:   2024-08-14

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
