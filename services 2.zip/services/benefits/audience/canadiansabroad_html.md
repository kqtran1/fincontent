---
source_url: https://www.canada.ca/en/services/benefits/audience/canadiansabroad.html
scraped_at: 2025-08-24 13:31:44
filename: en/services/benefits/audience/canadiansabroad_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/clientele/canadiansetranger.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Benefits by audience](/en/services/benefits/audience.html)

# Benefits for Canadians living abroad

# Benefits for Canadians living abroad

Includes information on Employment Insurance (EI), pensions, benefits and taxes, for those who work or live outside of Canada.

## Services and information

### [Employment Insurance workers and residents outside Canada](/en/services/benefits/ei/ei-outside-canada.html)

Benefits that people who work outside Canada for a Canadian company or the Canadian government may be entitled to.

### [Taxation for Canadians travelling, living or working outside Canada](http://www.travel.gc.ca/air/travelling-money#Taxes)

Canadians travelling extensively, living or working abroad may still have to pay Canadian and provincial or territorial income taxes.

### [Lived or living outside Canada - Pensions and benefits](/en/services/benefits/publicpensions/cpp/cpp-international.html)

Information on eligibility for pensions and benefits from Canada and other countries because of social security agreements.

### [Receiving payment of Old Age Security and Canada Pension Plan pensions and benefits outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international/benefit-amount.html)

Save money by receiving payments in the local currency.

### [Taxes on Pensions and Benefits for those outside Canada](/en/services/benefits/publicpensions/cpp/cpp-international/before-apply.html)

Benefits for those outside of Canada may be subject to Canadian income tax called the "non-resident tax".

### [Living abroad](http://travel.gc.ca/travelling/living-abroad)

Everything you need to know to prepare to leave Canada to live in a foreign country.

## Page details

### From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

Date modified:
:   2025-08-18

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
