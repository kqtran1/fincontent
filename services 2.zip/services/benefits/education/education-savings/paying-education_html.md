---
source_url: https://www.canada.ca/en/services/benefits/education/education-savings/paying-education.html
scraped_at: 2025-08-24 17:26:12
filename: en/services/benefits/education/education-savings/paying-education_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/epargne-etudes/paiement-education.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Registered Education Savings Plans and related benefits](/en/services/benefits/education/education-savings.html)

# Registered Education Savings Plans and related benefits

* [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html) [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html#gc-document-nav)
* [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html) [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html#gc-document-nav)
* [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html) [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html#gc-document-nav)
* [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html)
* [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html) [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html#gc-document-nav)

# Pay for education using the Registered Education Savings Plan

## On this page

* [Taking money out of an RESP](#_withdrawals)
* [How to use the RESP to pay for education](#_howto)
  + [1. See if the school is eligible](#_eligible)
  + [2. Request money on behalf of the beneficiary](#_request)
  + [3. Provide required documentation](#_docu)
* [Amount that can be withdrawn](#_amount)
* [Track the grant amounts you use for education](#_trackgrant)
* [If you don’t use the RESP for education](#_ifnotedu)

## Taking money out of an RESP

Money in a Registered Education Savings Plan (RESP) can come from many sources:

* **contributions** from the [subscriber](#inline_content_modal_sub "subscriber definition") and/or others
* **benefits** received, like the Canada Learning Bond (CLB), Canada Education Savings Grant (CESG), and/or provincial benefits
* **interest accumulated** on the money in the RESP

Because of these different sources of money in an RESP, there are different ways to withdraw.

**Educational Assistance Payments (EAPs)** include money from benefits and accumulated interest. EAPs are considered income for the [beneficiary](#inline_content_modal_bens "beneficiary definition") and are taxed when taken from the RESP. However, beneficiaries may not have much income during their studies, so it is possible that the beneficiary pays little to no tax when receiving an EAP.

**A withdrawal of contributions** can be requested by the RESP subscriber. The contributions can be taken out of the RESP tax-free and returned to the subscriber. The subscriber may choose to give these funds to the beneficiary. For example, a subscriber could request a withdrawal of contributions if they have no longer received any benefits in their RESP.

If interest in the RESP is not used by the beneficiary through an EAP, accumulated interest can be paid out on its own. This is called an **Accumulated Income Payment (AIP)** and is usually paid to the subscriber. It is taxed at the regular income tax rate of the subscriber, plus an additional 20% (or 12% for subscribers residing in Quebec).

For more information, consult the section about [taking money out of an RESP from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/payments-resp.html).

## How to use the RESP to pay for education

You can use the money in the RESP to pay for education right away or keep it for future education. To take money out of the RESP to pay for education, the [subscriber](#inline_content_modal_sub "subscriber definition") asks the RESP [promoter](#inline_content_modal_prom "promoter definition") for an EAP. The [beneficiary](#inline_content_modal_bens "beneficiary definition") can use the EAP money to pay for expenses like tuition, books, tools, transportation, and rent.

To receive an EAP and pay for education:

* the beneficiary must enrol in full- or part-time studies at an [eligible school](#_eligible) (in Canada or abroad). Programs must meet the [minimum weeks of study and hours per week](#_minimum) to be eligible
* the subscriber must request the EAP from the RESP promoter
* the beneficiary must provide the RESP promoter with [proof of enrolment](#_docu)

### 1. See if the school is eligible

It is the responsibility of the RESP promoter to check if a school is eligible before giving the beneficiary money to pay for school. The school must be one of the following:

* Canadian universities, colleges or other educational institutions
  Check the following lists to see if the education institution is eligible:
  + universities and colleges: [List of Designated Educational Institutions](/en/employment-social-development/programs/designated-schools.html)
  + other educational institutions and professional schools: [List of Certified Institutions](http://certification.esdc.gc.ca/lea-mcl/h.4m.2%40-eng.jsp;jsessionid=yyY2J2SDMrJcWN1P44dCsVTQQcS8ptqxXzkRQBLrRZKNv92wt2y6!-2132938879)

  If you can't find your school on these lists, you may still be eligible to receive an EAP if the school has been designated by a provincial authority under the *Canada Student Loans Act*. Your student financial assistance office can provide more information. For the contact information for the [student financial assistance office in your province/territory](/en/employment-social-development/services/education/province-territory-student-financial-assistance.html) or call Service Canada at 1 800 O‑Canada (1‑800‑622‑6232).
* Outside of Canada: Universities, colleges, or other educational institutions

  For the purposes of EAP, eligible educational institutions outside of Canada do not have to be on the List of Designated Educational Institutions. For an EAP to be paid out, the beneficiary must have been enrolled in a course with a duration of not less than 13 consecutive weeks (3 weeks for university programs).

#### Minimum program length

To be eligible for an EAP, the educational program must last a certain number of weeks, and include a certain number of hours per week.

* Full-time program in Canada

  A course or program that lasts at least 3 weeks in a row, with at least 10 hours of instruction or work per week.
* Full-time program outside Canada

  A program at a foreign educational institution with a duration of at least 13 weeks, or 3 weeks for university programs.
* Part-time program in Canada

  An educational program at post-secondary school level that lasts at least 3 consecutive weeks, and that requires a student to spend not less than 12 hours per month on courses in the program.

### 2. Request money on behalf of the beneficiary

To withdraw money from the RESP, the [subscriber](#inline_content_modal_sub "subscriber definition") should contact their RESP [promoter](#inline_content_modal_prom "promoter definition").

Once the [beneficiary](#inline_content_modal_bens "beneficiary definition") has enrolled full‑time or part‑time in a qualifying post‑secondary educational program, the subscriber can request an EAP to withdraw money from the RESP to help pay for the beneficiary’s studies.

EAPs include the interest earned in the RESP as well as benefits received. EAPs are considered taxable income for the beneficiary.

### 3. Provide required documentation to support your request

The RESP promoter will ask to see **official proof of enrollment** before giving the beneficiary the EAP. They may also provide a list of allowable expenses that the money can be used for, or they **may ask for receipts** for school purchases to prove the money is being spent on allowable educational expenses.

Because they are responsible for administering the RESP in accordance with the *Income Tax Act*, your RESP promoter determines what is considered a reasonable expense. Any expense that is in accordance with the Act and the terms of the plan would be considered reasonable.

## Amount of money that can be withdrawn

* Full-time program

  If the [beneficiary](#inline_content_modal_bens "beneficiary definition") is enrolled in full‑time post‑secondary studies, EAPs are limited to $8,000 during the first‑13‑consecutive weeks of enrollment.

  After that, you may request any available amount with no limit unless the beneficiary takes a break from their studies and does not re-enroll in a qualifying educational program for 12 months. If that happens, the original limit is reinstated.

  For both full- and part-time studies, the beneficiary is also eligible to receive payments for up to 6 months after the end of their enrollment in a qualifying program (provided the provisions of the RESP allow this benefit). This is only possible if the expenses would have qualified for EAPs if they had been paid immediately before the beneficiary's enrollment stopped.
* Part-time program

  If the [beneficiary](#inline_content_modal_bens "beneficiary definition") is enrolled in part-time studies, EAPs are limited to $4,000 for every 13-week period of enrollment.

  For both full- and part-time studies, the beneficiary is also eligible to receive payments for up to 6 months after the end of their enrollment in a qualifying program (provided the provisions of the RESP allow this benefit). This is only possible if the expenses would have qualified for EAPs if they had been paid immediately before the beneficiary’s enrollment stopped.
* Withdrawing over the limit

  If you need to withdraw more money than the limits allow for full- or part-time studies, you can make a request with the help of your RESP promoter. The [promoter](#inline_content_modal_prom "promoter definition") must send the request, along with all verified receipts for school-related expenses, to the Canada Education Savings Program. If the request is approved, the Canada Education Savings Program will advise your promoter.

## Track the CESG amounts you use for education

When a [beneficiary](#inline_content_modal_bens "beneficiary definition") receives an EAP, they will also receive a notice detailing the amount of the CESG in the payment received. The beneficiary cannot receive more than $7,200 from the CESG in their lifetime. It is their responsibility to keep track of the CESG amount received; **beneficiaries must repay any amount over the $7,200 limit.**

## If you don’t use the RESP for education

You have 4 choices:

* keep the RESP open and leave the money in it for future studies
* replace the beneficiary
* transfer the money to other registered savings plans
* close the RESP

Consult [Managing your RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html) for more information.

## Definitions

### "Promoter" definition

The **promoter** is the financial organization where you open the RESP. The promoter administers all amounts contributed into the RESP and releases money from the RESP to the beneficiary when it is needed for eligible expenses for education after high school.

### "Subscriber" definition

The **subscriber** is the person who opens the RESP with a promoter. Anyone can be a subscriber and open an RESP for a child. This includes parents, guardians, grandparents, other relatives, and friends. The subscriber can also choose to make contributions. Contributions to the RESP are not needed to receive the CLB, but are needed to receive the CESG.

### "Beneficiary" definition

The **beneficiary** is the person (usually a child) who will get money from the RESP to pay for their education after high school, as long as the school and program are eligible.

* The beneficiary can be a child or an adult
* The beneficiary can be the same person as the subscriber, if an adult opens an RESP for themselves
* Depending on the plan type, there can be more than one beneficiary for each RESP

### "Adjusted family income" definition

The adjusted family income is the amount used, in part, to determine eligibility for the CLB and the amount of the CESG. Adjusted family income is the primary caregiver's, and their spouse/common-law partner's pre-taxed income (line 23600 of the income tax return), minus any Canada Child Benefit (CCB) and Registered Disability Savings Plan (RDSP) income received. If you repaid any CCB or RDSP income in a given year, you can add that amount is added back into your adjusted family income.

#### How to calculate adjusted family income

Primary caregiver's yearly pre-taxed income

Plus spouse or common-law partner's yearly pre-taxed income, if applicable

Minus CCB and RDSP income received

Plus CCB and RDSP income repaid to the Government

Equals      adjusted family income

### "Primary caregiver" definition

This is the person who is eligible to receive the Canada Child Benefit in the child's name. The signature and Social Insurance Number of the primary caregiver or of their cohabiting spouse or common-law partner , are required when requesting certain benefits.

The primary caregiver may also be a public institution: A child care department, agency, institution or organization eligible to receive payments under the Children’s Special Allowances Act, for the child, for at least 1 month of the benefit year. To request the CESG and the CLB, the public primary caregiver must provide their Business Number (BN).

### Document navigation

* [Previous: Contribution amounts](/en/services/benefits/education/education-savings/opening-plan.html)
* [Next: Managing your RESP, taxes and transfers](/en/services/benefits/education/education-savings/managing-plan.html)

## Page details

Date modified:
:   2023-12-28

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
