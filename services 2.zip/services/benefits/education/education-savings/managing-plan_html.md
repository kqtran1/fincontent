---
source_url: https://www.canada.ca/en/services/benefits/education/education-savings/managing-plan.html
scraped_at: 2025-08-24 16:44:08
filename: en/services/benefits/education/education-savings/managing-plan_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/epargne-etudes/gestion-plan.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Registered Education Savings Plans and related benefits](/en/services/benefits/education/education-savings.html)

# Registered Education Savings Plans and related benefits

* [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html) [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html#gc-document-nav)
* [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html) [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html#gc-document-nav)
* [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html) [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html#gc-document-nav)
* [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html) [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html#gc-document-nav)
* [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html)

# Managing the Registered Education Savings Plan, taxes and transfers

## On this page

* [How long RESPs can stay open](#_howlong)
* [Contributing to the RESP](#_contrib)
* [Adding or changing beneficiaries](#_addbens)
* [Beneficiaries named on more than 1 RESP](#_number)
* [RESPs and taxes](#_taxes)
* [Transfers to other registered savings plans](#_transfers)
* [Closing the RESP](#_closing)

## How long RESPs can stay open

You can make contributions into a Registered Education Savings Plan (RESP) until 31 years after it was first opened. You would then have until the end of the 35th year after the plan was first opened to use the funds before the RESP expires (or up to 40 years for a specified plan).

If the [beneficiary](#inline_content_modal_bens "beneficiary definition") chooses not to continue their education right after high school, the RESP can stay open in the case that they change their mind later.

## Contributing to the RESP

Some types of RESPs require specific monthly contributions. Other types let you put money into the RESP whenever you want. Check with your RESP [promoter](#inline_content_modal_prom "promoter definition") to know the different options and obligations of your RESP. **No contributions to the RESP are needed to get the Canada Learning Bond (CLB)**.

There is no annual limit to how much you can contribute to the RESP. Over the lifetime of the RESP, the maximum that can be contributed is $50,000 per beneficiary.

* Over-contributions

  An over-contribution occurs when the total contributions made to a [beneficiary](#inline_content_modal_bens "beneficiary definition") in 1 or more RESP(s) exceed the lifetime limit of $50,000.

  When an over-contribution occurs, you will be required to pay tax in the amount of 1% per month on your share of the over-contribution until it is withdrawn.
* Withdrawing contributions

  Under normal circumstances, a withdrawal of contributions will require a repayment of the CESG, except when:

  + you withdraw contributions to eliminate an over-contribution, and
  + the total over-contribution is not more than $4,000 at the time of withdrawal, or
  + the [beneficiary](#inline_content_modal_bens "beneficiary definition") is eligible for an Educational Assistance Payment (EAP)

  If the total over-contribution is more than $4,000 at the time of withdrawal, the CESG is repayable on the entire amount withdrawn. If this happens, the grant room is not restored by the repaid amount of the CESG.

  For more information, consult the section about [over-contributions as well as tax penalties from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/resp-contributions.html).

### Tracking RESP contributions

It's important to track how much you contribute to the RESP, especially if you have more than 1. Make sure you don't over-contribute. You should also  [track how much CESG you receive](/en/services/benefits/education/education-savings/paying-education.html#_trackgrant) to make sure you don't go over the CESG lifetime limit.

* **Family plan contributions**

  If you have a family plan with 2 or more children, contributions must be tracked for each child named in the plan. You can make more than 1 contribution at a time, and the amounts do not have to be the same for each child.
* **Group plan contributions**

  When you open a group plan, you may be required to make contributions into the group RESP at set times for the duration of the RESP contract.

  The RESP [promoter](#inline_content_modal_prom "promoter definition") will credit the money you put into the group RESP to an account in your name. Any government benefits received by the [beneficiary](#inline_content_modal_bens "beneficiary definition") will be put into a separate account that is in the beneficiary’s name.

  The interest earned on your savings can be shared within the group plan; however, the interest earned on government benefits cannot be shared and goes directly to the beneficiary named in the RESP.

## Adding or changing beneficiaries

* Adding another child to a RESP family plan

  To add another child to an existing RESP family plan, the child must be related to you by blood or adoption, and they must:

  + be under 21 years old at the time you add them to the plan; or
  + have been a [beneficiary](#inline_content_modal_bens "beneficiary definition") of another family RESP immediately before being added to this one

  As with any RESP, you must provide the new beneficiary’s Social Insurance Number (SIN) to the RESP [promoter](#inline_content_modal_prom "promoter definition").

  If government benefits have already been paid into the RESP, you can add a sibling of the existing beneficiary to the RESP without penalty.

  If you add a beneficiary who is not a sibling of the beneficiaries already named on the plan, you will need to repay the benefits to the relevant government (federal or provincial).
* Naming a replacement beneficiary

  You may change the [beneficiary](#inline_content_modal_bens "beneficiary definition") named on an individual, family or group RESP.

  Ask your [promoter](#inline_content_modal_prom "promoter definition") how your contributions will be affected if you switch beneficiaries.

  As with opening any RESP, the new beneficiary’s Social Insurance Number (SIN) must be provided.

  There are special rules to consider when changing the beneficiary. When the beneficiary changes, the contributions made for the former beneficiary are now intended for the new beneficiary. If the new beneficiary already has a RESP, this may create an [over-contribution](#_contrib). There are 2 exceptions:

  + if the new beneficiary is under 21 years of age, and both the new and the former beneficiary have the same parent
  + if both beneficiaries are under 21 years of age, and are connected by a blood relationship or adoption to the original subscriber of the RESP

## Beneficiaries named on more than 1 RESP

You can be named as the [beneficiary](#inline_content_modal_bens "beneficiary definition") or [subscriber](#inline_content_modal_sub "subscriber definition") on more than 1 RESP. There is no limit on the number of RESPs from different institutions an individual can have in their name, but there is a lifetime RESP contribution limit of $50,000 per beneficiary. This limit includes all contributions made in all RESPs combined. It is important for subscribers to let each other know about their contributions. This will maximize the yearly CESG room, while respecting the lifetime contribution limit of $50,000.

The CESG gets paid to the RESP with the earliest contribution

CESG payments are made to a single plan on a first-come, first-served basis, subject to annual CESG and lifetime CESG limits. If you have 2 RESPs with the same beneficiary, the CESG may only get added to one of the RESPs.

For example: If you contribute $2,500 (the maximum amount for the CESG calculation) through one RESP [promoter](#inline_content_modal_prom "promoter definition") on January 15, and later put in a subsequent $2,500 through a different promoter on February 15, the CESG will only be deposited into the first plan you contributed to. When contributions are made on the same date the amounts are split in half between 2 plans, each plan receives one half of the CESG.

If you contribute through monthly instalments, the CESG is paid into each plan until either the maximum that can be paid in a year, or the lifetime contribution limit, is reached.

## RESPs and taxes

* If the RESP is used for education
  + your money earns interest tax-free while it is in the RESP
  + you do not get a tax deduction for the money you put into a RESP
  + your investment earnings in the RESP will not be taxed until money is taken out to pay for your child's education
  + money paid out of the RESP as an Educational Assistance Payment (EAP) is taxed in the hands of the student. Since many students have little or no other income, they can usually withdraw the money tax-free
  + the money that you have put in the RESP can also be used by the [beneficiary](#inline_content_modal_bens "beneficiary definition") for their education, or returned to you, tax-free

  For more information, please call the Canada Revenue Agency at 1‑800‑959‑8281 or consult the section about [Educational Assistance Payments from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/payments-resp.html#eap).
* If the RESP is not used for education
  + you will not be taxed on the amount you contributed to the RESP, but you will have to pay taxes on the money that you earned in your plan as interest. This money is called **accumulated income**. It will be taxed at your regular income tax level, plus an additional 20% (or 12% if the subscriber lives in Quebec)
  + the money that you have put into the RESP is returned to you
  + the CESG can be shared with a sibling if they have CESG room available—otherwise, the CESG must be returned to the Government of Canada
  + the CLB can only be used by an eligible [beneficiary](#inline_content_modal_bens "beneficiary definition") for education, so if it is unused, it must be returned to the Government of Canada
  + talk to your RESP promoter to find out about any conditions that may apply to the plan if your child does not continue his or her education after high school

## Transfers to other registered savings plans

Below is a quick summary on making transfers. For more information, consult the section about [transferring money from RESPs to other Plans from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/payments-resp.html#transferring).

* Transfer money to a Registered Retirement Savings Plan (RRSP)

  You may be able to transfer up to $50,000 of earnings tax-free from the RESP to an RRSP using an Accumulated Income Payment (AIP). For more information, consult the section about [Accumulated Income Payments from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/payments-resp.html#aip).
* Transfer money to a Registered Disability Savings Plan (RDSP)

  You may be able to transfer investment earnings from your RESP to an RDSP if the plans share a common [beneficiary](#inline_content_modal_bens "beneficiary definition") and one of the following conditions is met:

  + the beneficiary of the RESP has a severe and prolonged mental impairment that can reasonably be expected to prevent the beneficiary from pursuing post-secondary education; or
  + the RESP has been open for at least 10 years and each beneficiary is at least 21 years of age and is not pursuing post-secondary education; or
  + the RESP has been open for at least 35 years

  **Note:** You should speak to your RESP [promoter](#inline_content_modal_prom "promoter definition") to find out if this option is available under the terms of your plan.

  The following RDSP requirements must also be met at the time the rollover is made:

  + the beneficiary is eligible for the Disability Tax Credit (DTC)
  + the beneficiary is less than 60 years of age in the year the rollover is made
  + the beneficiary is a resident of Canada
  + the rollover amount cannot cause the RDSP to exceed the lifetime contribution limit of $200,000, and
  + the plan must not be a Specified Disability Savings Plan

  When RESP investment earnings are rolled over to an RDSP, the RESP must be closed before March of the year following the year of the rollover. In addition, the remaining Canada Education Savings Grant, Canada Learning Bond and provincial incentives must be repaid. Contributions in the RESP will be returned to the RESP [subscriber](#inline_content_modal_sub "subscriber definition").

  For more information on rolling over education savings to an RDSP, see [RDSP Bulletin No. 4](/en/revenue-agency/services/tax/registered-plans-administrators/bulletins/compliance-bulletin-4.html) or call 1‑800‑959‑8281 (TTY users call 1‑800‑665‑0354).

  **Ask your promoter for details and restrictions.**
* Transfer money to a Registered Education Savings Plan (RESP)

  Most transfers from one RESP to another RESP will have no tax implications. This is the case when the person transferring and receiving the RESP have the same [beneficiary](#inline_content_modal_bens "beneficiary definition").

  There are also no tax implications when a beneficiary who is transferring the RESP has a sibling who is a beneficiary under the receiving RESP.

  For more information, consult the section about [transferring from one RESP to another from the Canada Revenue Agency](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps/payments-resp.html#transferring).

## Closing the RESP

Any savings that remain in your RESP when it closes will be handled as follows:

* money received from benefits will be returned to the Government of Canada (or provincial government for provincial benefits), and
* any personal contributions to the account will be returned to the person who opened the RESP and will not be taxed

The accumulated interest earned on benefits and contributions can be:

* paid to the [subscriber](#inline_content_modal_sub "subscriber definition") and taxed (AIP)
* transferred to a RESP of the subscriber or the subscriber’s spouse
* transferred to a child’s RESP
* gifted to a designated educational institution

Note: You do not need to close an RESP to receive an AIP.

Ask your RESP [promoter](#inline_content_modal_prom "promoter definition") for more details and for explanations on any conditions or penalties that may apply to your RESP should you decide to close it.

## Definitions

### "Promoter" definition

The **promoter** is the financial organization where you open the RESP. The promoter administers all amounts contributed into the RESP and releases money from the RESP to the beneficiary when it is needed for eligible expenses for education after high school.

### "Subscriber" definition

The **subscriber** is the person who opens the RESP with a promoter. Anyone can be a subscriber and open a RESP for a child. This includes parents, guardians, grandparents, other relatives, and friends. The subscriber can also choose to make contributions. Contributions to the RESP are not needed to receive the CLB, but are needed to receive the CESG.

### "Beneficiary" definition

The **beneficiary** is the person (usually a child) who will get money from the RESP to pay for their education after high school, as long as the school and program are eligible.

* The beneficiary can be a child or an adult
* The beneficiary can be the same person as the subscriber, if an adult opens a RESP for themselves
* Depending on the plan type, there can be more than one beneficiary for each RESP

### "Adjusted family income" definition

The adjusted family income is the amount used, in part, to determine eligibility for the CLB and the amount of the CESG. Adjusted family income is the primary caregiver's, and their spouse/common-law partner's pre-taxed income (line 23600 of the income tax return), minus any Canada Child Benefit (CCB) and Registered Disability Savings Plan (RDSP) income received. If you repaid any CCB or RDSP income in a given year, you can add that amount is added back into your adjusted family income.

#### How to calculate adjusted family income

Primary caregiver's yearly pre-taxed income

Plus spouse or common-law partner's yearly pre-taxed income, if applicable

Minus CCB and RDSP income received

Plus CCB and RDSP income repaid to the Government

Equals      adjusted family income

### "Primary caregiver" definition

This is the person who is eligible to receive the Canada Child Benefit in the child's name. The signature and Social Insurance Number of the primary caregiver or of their cohabiting spouse or common-law partner , are required when requesting certain benefits.

The primary caregiver may also be a public institution: A child care department, agency, institution or organization eligible to receive payments under the Children’s Special Allowances Act, for the child, for at least 1 month of the benefit year. To request the CESG and the CLB, the public primary caregiver must provide their Business Number (BN).

### Document navigation

* [Previous: Open a RESP and apply for benefits](http://test.canada.ca/service-canada/eric/CESP/CESP-subway-proto-usingRESP.html)

## Page details

Date modified:
:   2024-06-27

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
