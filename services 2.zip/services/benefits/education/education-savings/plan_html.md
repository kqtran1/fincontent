---
source_url: https://www.canada.ca/en/services/benefits/education/education-savings/plan.html
scraped_at: 2025-08-24 16:43:52
filename: en/services/benefits/education/education-savings/plan_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/epargne-etudes/plan.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Registered Education Savings Plans and related benefits](/en/services/benefits/education/education-savings.html)

# Registered Education Savings Plans and related benefits

* [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html)
* [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html) [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html#gc-document-nav)
* [Open an RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html) [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html#gc-document-nav)
* [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html) [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html#gc-document-nav)
* [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html) [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html#gc-document-nav)

# How the Registered Education Savings Plan and related benefits work together

## Program Updates

Beginning in April 2028, the Government of Canada will automatically open a Registered Education Savings Plan (RESP) to receive the CLB for an eligible child:

* born in 2024 or later
* with a valid Social Insurance Number (SIN)
* that is not already named as a beneficiary of an RESP by age 4

Also, beginning in April 2028, the age limit to claim the CLB retroactively will be extended from 20 to 30 years. This will ensure that eligible beneficiaries will not lose out on funds for their post-secondary education if they decide to postpone their studies.

To learn more about CLB automatic enrollment, please call 1-833-294-2CLB (1-833-294-2252).

## How an RESP works

A Registered Education Savings Plan (RESP) is a special savings account to help save for a child's education after high school, including trade schools, CEGEPs, colleges, universities, and apprenticeship programs. When you open a plan, you can ask your financial institution (the promoter) to apply for benefits to help pay for the child's education after high school. If the child is eligible, they can receive the following in the RESP:

* The **[Canada Learning Bond (CLB)](/en/services/benefits/education/education-savings/estimating-amounts.html#_Bond)** can provide up to a lifetime maximum of **$2,000**
* The **[Canada Education Savings Grant (CESG)](/en/services/benefits/education/education-savings/estimating-amounts.html#_Grant)** can provide up to a lifetime maximum of **$7,200**
* British Columbia and Quebec offer  [provincial benefits](/en/services/benefits/education/education-savings/estimating-amounts.html#_Prov), as well

**Savings and benefits in the RESP can be used to pay for eligible education expenses like rent, tuition, books, tools, and transportation.**

**Any adult can open an RESP account for a child:** parents, guardians, grandparents, other relatives, and friends.

Adults can also open RESPs for themselves. Adults born in 2004 or later may also receive the CLB for themselves until the age of 21.

The **subscriber** is the person who opens the RESP with a promoter, including adults opening RESPs for themselves. The subscriber can also choose to make contributions. Contributions to the RESP are not needed to receive the CLB but, are needed to receive the CESG.

The **beneficiary** is the person (usually a child) who will get money from the RESP to pay for their education after high school, as long as the school and program are eligible.

* The beneficiary can be a child or an adult
* The beneficiary can be the same person as the subscriber, if an adult opens an RESP for themselves
* Depending on the plan type, there can be more than one beneficiary for each RESP

The **promoter** is the financial organization where you open the RESP. The promoter administers all amounts contributed into the RESP and releases money from the RESP to the beneficiary when it is needed for eligible expenses for education after high school.

### Document navigation

* [Next: How much you could get](/en/services/benefits/education/education-savings/estimating-amounts.html)

## Page details

Date modified:
:   2024-11-04

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
