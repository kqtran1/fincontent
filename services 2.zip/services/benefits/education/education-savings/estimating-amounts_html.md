---
source_url: https://www.canada.ca/en/services/benefits/education/education-savings/estimating-amounts.html
scraped_at: 2025-08-24 18:41:20
filename: en/services/benefits/education/education-savings/estimating-amounts_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/epargne-etudes/estimation-montants.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Registered Education Savings Plans and related benefits](/en/services/benefits/education/education-savings.html)

# Registered Education Savings Plans and related benefits

* [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html) [How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html#gc-document-nav)
* [How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html)
* [Open an RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html) [Open RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html#gc-document-nav)
* [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html) [Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html#gc-document-nav)
* [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html) [Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html#gc-document-nav)

# How much money benefits could add to the Registered Education Savings Plan

## Program Updates

Beginning in April 2028, the Government of Canada will automatically open a Registered Education Savings Plan (RESP) to receive the Canada Learning Bond (CLB) for an eligible child:

* born in 2024 or later
* with a valid Social Insurance Number (SIN)
* that is not already named as a beneficiary of an RESP by age 4

Also, beginning in April 2028, the age limit to claim the CLB retroactively will be extended from 20 to 30 years. This will ensure that eligible beneficiaries will not lose out on funds for their post-secondary education if they decide to postpone their studies.

To learn more about CLB automatic enrollment, please call 1-833-294-2CLB (1-833-294-2252).

## On this page

* [Benefits can add money to the RESP](#_Benefits)
* [CLB amounts and eligibility criteria](#_Bond)
* [CESG amounts and eligibility criteria](#_Grant)
* [Other benefits for people in British Columbia and Québec](#_Prov)

## Benefits can add money to the RESP

Open an RESP with a financial institution of your choice to help set aside money to pay for the costs of a child's education after high school. Start early and watch your money grow with accumulated interest and education savings benefits from the Government of Canada.

The [beneficiary](/en/services/benefits/education/education-savings/estimating-amounts.html#inline_content_modal_bens "beneficiary definition") of an RESP may also be eligible for the Canada Learning Bond (CLB) and the Canada Education Savings Grant (CESG). Provincial benefits are also available for eligible recipients in British Columbia and Québec.

* The CLB provides up to**$2,000 (lifetime maximum)**in an RESP for eligible children from families living with low income
  + No contributions to the RESP are needed to get the CLB
  + A beneficiary will receive $500 their first year of eligibility, then another $100 for each year of eligibility year after until the age of 15
  + The CLB is retroactive. Primary caregiver can request the CLB for an eligible child until the day before they turn 18.
  + It must be claimed before the beneficiary turns 21
* The CESG provides up to **$7,200 (lifetime maximum) in** an RESP for eligible children regardless of income
  + Contributions must be made to the RESP to get the CESG
  + The CESG adds a maximum of $500 to an RESP each year, and up to another $100 for eligible families living with low or middle- income
  + If a subscriber does not receive the maximum CESG amount in a given year, the subscriber can catch up on this amount by making more contributions to the RESP in the following years
  + The CESG is available until the end of the calendar year that the beneficiary turns 17
* Beneficiaries living in British Columbia may be eligible for an additional one‑time **$1,200** grant, and beneficiaries living in Québec may be eligible for a refundable tax credit with a lifetime maximum of **$3,600.**

## CLB amounts and eligibility criteria

If the [beneficiary](#inline_content_modal_bens "beneficiary definition") is eligible to receive the Canada Learning Bond (CLB), they could receive **$500 the first year in an RESP**, and then another **$100 each eligible year** after that until the age of 15, up to a lifetime maximum of $2,000.

Once they turn 18 years of age, eligible beneficiaries can take the steps to request the CLB for themselves. They have until the day before they turn 21 to open their own RESP and request unclaimed amounts of CLB.

### CLB eligibility

To be eligible for the CLB, the beneficiary must:

* be a resident of Canada prior to the CLB payment is made to the RESP
* have a Social Insurance Number (SIN)
* be named as a beneficiary in an RESP
* be born on or after January 1, 2004
* be from a family with [low-income](#_clb_income)

As well, the primary caregiver of the beneficiary must:

* have filed income tax returns for each year they wish to request the CLB for the beneficiary
* be eligible to receive the [Canada Child Benefit (CCB)](https://www.canada.ca/en/revenue-agency/services/child-family-benefits/canada-child-benefit-overview.html)

No contributions to the RESP are needed to get the CLB. Eligibility for the CLB is based on the [adjusted family income](#inline_content_modal_income "adjusted family income definition") of the [primary caregiver](#inline_content_modal_pcg "primary caregiver definition").

The CLB is retroactive. The CLB amounts accumulate each year of eligibility until December 31 of the year in which the beneficiary turns 15. The primary caregiver can request the CLB for an eligible child until the day before they turn 18. Once the child turns 18, they could also become the subscriber of their own RESP and request the CLB for themselves, until the day before they turn 21.

Children in care, for whom a Children’s Special Allowance is payable, are also eligible for the CLB.

For July 1, 2024, to June 30, 2025, the income eligibility amount for the CLB is based on the following.

Table 1: Adjusted family income and eligibility for the CLB

| Number of children | Adjusted income level |
| --- | --- |
| 1 to 3 | Less than or equal to $55,867 |
| 4 | Less than $63,036 |
| 5 | Less than $70,234 |

For families with more than 5 children, call 1 800 O‑Canada (1-800-622-6232).

## CESG amounts and eligibility criteria

If the [beneficiary](#inline_content_modal_bens "beneficiary definition") is eligible to receive the Canada Education Savings Grant (CESG), they could receive up to **$500 each year** of eligibility. Eligible children from families with middle- or low-income could receive up to **another $100 each year.** The lifetime maximum that can be received from the CESG is $7,200 until the age of 17.

To receive the CESG, **contributions must be made to the RESP.** The CESG adds an amount to the RESP based on contributions made. If eligible, beneficiaries can receive up to 20% of the first $2,500 contributed to the RESP. Eligible beneficiaries from families with middle- and low-income can receive an additional 10% or 20% of the first $500 contributed to the RESP.

CESG amounts accumulate and can carry-forward to the current year. If you don’t receive the maximum CESG amount in a given year, you can still receive it in future years. You can catch up on this amount by making more contributions to the RESP.

### How much eligible beneficiaries could get from the CESG each year

If the annual adjusted family income is $55,867 or less

If it's the beneficiary's first year of eligibility for the CESG, the CESG could provide **up to $600**:

* 20% of the first $2,500 contributed to the RESP = **$500**
* 20% of the first $500 contributed to the RESP = **$100**
* Any amount of contribution will receive the CESG, up to these limits

In this example, to receive $600 from the CESG, contributions made to the RESP over the year would total $2,500.

Unused CESG amounts can carry forward to later years. If the beneficiary didn't receive the maximum CESG amount in a previous year, the CESG could provide up to another $500, for a total of $1,100 in a given year:

* 20% of contributions on top of the first $2,500, up to another $2,500 contribution = **$500**
* You must have unused CESG amounts from previous years

In this example, contributions made to the RESP this year would total $5,000 to receive $1,100 from the CESG. This includes the amount for the given year and the carry-forward amount from previous years.

If annual adjusted family income is greater than $55,867 and up to $111,733

If it's the [beneficiary's](#inline_content_modal_bens "beneficiary definition") first year of eligibility for the CESG, the CESG could provide **up to $550:**

* 20% of the first $2,500 contributed to the RESP = **$500**
* 10% of the first $500 contributed to the RESP = **$50**
* Any amount of contribution will receive the CESG, up to these limits.

In this example, to receive $550 from the CESG, contributions made to the RESP over the year would total $2,500.

Unused CESG amounts can carry forward to later years. If the beneficiary didn't receive the maximum CESG amount in a previous year, the CESG could provide up **to another $500, for a total of $1,050 in a given year:**

* 20% of contributions on top of the first $2,500, up to another $2,500 contribution: **$500**
* You must have unused CESG amounts from previous years

In this example, contributions made to the RESP this year would total $5,000 to receive $1,050 from the CESG. This includes the amount for the given year and the carry-forward amount from previous years.

If annual adjusted family income is greater than $111,733

If it's the [beneficiary's](#inline_content_modal_bens "beneficiary definition") first year of eligibility for the CESG, the CESG could provide **up to $500:**

* 20% of the first $2,500 contributed to the RESP = **$500**
* Any amount of contribution will receive the CESG, up to these limits

In this example, to receive $500 from the CESG, contributions made to the RESP over the year would total $2,500.

Unused CESG amounts can carry forward to later years. If the beneficiary didn't receive the maximum CESG amount in a previous year, the CESG could provide up to **another $500, for a total of $1,000 in a given year:**

* 20% of contributions on top of the first $2,500, up to another $2,500 contribution = **$500**
* You must have unused CESG amounts from previous years

In this example, contributions made to the RESP this year would total $5,000 to receive $1,000 from the CESG. This includes the amount for the given year and the carry-forward amount from previous years.

[How to determine your adjusted family income](#inline_content_modal_income "adjusted family income definition")

### CESG eligibility

The CESG is available until the end of the calendar year that a child turns 17. **A contribution must be made to the RESP to receive the CESG.**

To be eligible for the CESG, the child must:

* be a resident of Canada at the time the contribution to the plan is made
* have a Social Insurance Number (SIN)
* be named as a beneficiary in an RESP
* be 17 years old or younger

Use the **calendar year** to determine:

* CESG eligibility
* the amount of contributions made
* the CESG room earned and used in the last year

There are eligibility restrictions for children who are 16 or 17 years old.

CESG eligibility for children aged 16 or 17

Children who are 16 or 17 years old may be eligible to get the CESG. To be eligible, they must meet at least one of the following conditions before the end of the calendar year they turn 15:

* a total of at least $2,000 is contributed to (and not withdrawn from) the RESP
* a minimum annual contribution of $100 is made to (and not withdrawn from) the RESP in any four previous years

CESG carry forward

Unused CESG amounts from previous years accumulate until the end of the year in which the child turns 17, even if they are not a beneficiary of an RESP.

If there is an unused CESG amount from previous years, the [subscriber](#inline_content_modal_sub "subscriber definition") can contribute more than $2,500 to the RESP per year and receive up to 20% of their contributions (up to $5,000) each year. This way, a child could get up to $1,000 of the CESG in their RESP per calendar year if there are unused amounts from previous years.

As long as the lifetime CESG limit ($7,200) is not exceeded, the CESG room can be carried forward.

## Other benefits for people in British Columbia and Québec

British Columbia and Québec offer provincial benefits that may add money to an RESP. This is on top of any money from the CLB or CESG.

British Columbia Training and Education Savings Grant (BCTESG)

The B.C. Government will contribute $1,200 to eligible children through the [B.C. Training and Education Savings Grant (BCTESG)](https://www2.gov.bc.ca/gov/content/education-training/k-12/support/scholarships/bc-training-and-education-savings-grant).

To be eligible for the $1,200 BCTESG:

* parent and child must be residents of B.C.
* child must be aged 6 to 8
* child must be named as beneficiary of an RESP with a participating financial institution

Québec Education Savings Incentive (QESI)

The [Québec Education Savings Incentive (QESI)](https://www.revenuquebec.ca/en/citizens/tax-credits/quebec-education-savings-incentive/) is a tax measure that encourages Québec families to start saving early for the post-secondary education of their children and grandchildren. The lifetime maximum that can be received from the QESI is $3,600 for eligible beneficiaries.

## Definitions

### "Promoter" definition

The **promoter** is the financial organization where you open the RESP. The promoter administers all amounts contributed into the RESP and releases money from the RESP to the beneficiary when it is needed for eligible expenses for education after high school.

### "Subscriber" definition

The **subscriber** is the person who opens the RESP with a promoter. Anyone can be a subscriber and open an RESP for a child. This includes parents, guardians, grandparents, other relatives, and friends. The subscriber can also choose to make contributions. Contributions to the RESP are not needed to receive the CLB, but are needed to receive the CESG.

### "Beneficiary" definition

The **beneficiary** is the person (usually a child) who will get money from the RESP to pay for their education after high school, as long as the school and program are eligible.

* The beneficiary can be a child or an adult
* The beneficiary can be the same person as the subscriber, if an adult opens an RESP for themselves
* Depending on the plan type, there can be more than one beneficiary for each RESP

### "Adjusted family income" definition

The adjusted family income is the amount used, in part, to determine eligibility for the CLB and the amount of the CESG. Adjusted family income is the primary caregiver's and their spouse/common-law partner's pre-taxed income (line 23600 of the income tax return), minus any Universal Child Care Benefit (UCCB) and Registered Disability Savings Plan (RDSP) income received. If you or your spouse/common-law partner repaid any UCCB or RDSP income in a given year, this amount is added into your adjusted family income.

#### How to calculate adjusted family income

Primary caregiver's yearly pre-taxed income

Plus spouse or common-law partner's yearly pre-taxed income, if applicable

Minus UCCB and RDSP income received

Plus UCCB and RDSP income repaid to the Government

Equals      adjusted family income

### "Primary caregiver" definition

This is the person who is eligible to receive the Canada Child Benefit in the child's name. The signature and Social Insurance Number of the primary caregiver or of their cohabiting spouse or common-law partner , are required when requesting certain benefits.

The primary caregiver may also be a public institution: A child care department, agency, institution or organization eligible to receive payments under the Children’s Special Allowances Act, for the child, for at least 1 month of the benefit year. To request the CESG and the CLB, the public primary caregiver must provide their Business Number (BN).

## Document navigation

* [Previous: How the RESP, the Bond, and grants work together](/en/services/benefits/education/education-savings/plan.html)
* [Next: Make contributions](/en/services/benefits/education/education-savings/opening-plan.html)

## Page details

Date modified:
:   2025-01-24

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
