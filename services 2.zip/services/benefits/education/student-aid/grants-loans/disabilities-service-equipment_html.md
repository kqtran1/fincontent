---
source_url: https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/disabilities-service-equipment.html
scraped_at: 2025-08-24 18:07:31
filename: en/services/benefits/education/student-aid/grants-loans/disabilities-service-equipment_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/aide-etudiants/bourses-prets/equipement-services-invalidite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Student aid](/en/services/benefits/education/student-aid.html)

# Canada Student Grant for Services and Equipment – Students with Disabilities

If you need education-related services or equipment, apply for the Canada Student Grant for Services and Equipment – Students with Disabilities. You can apply at the same time as you apply for student aid with your province or territory.

## Eligibility

You could be eligible for this grant if you apply and:

* have a financial need
* are a student in a qualified program at [a designated school](/en/employment-social-development/programs/designated-schools.html)
* are a student with a disability recognized by the Canada Student Financial Assistance Program;
* provide with your application, a document(s) that shows that you have a disability;
* send written confirmation from a qualified person that you need education-related services or equipment; and
* send a document which confirms the related cost of equipment and services.

To confirm your education-related services or equipment, a qualified person can be a:

* rehabilitation caseworker;
* official from a centre for students with disabilities;
* guidance counselor; or
* financial aid administrator from the student’s school.

## How much you could receive

You could receive up to $20,000 per school year. The school year runs from August 1 to July 31.

## Apply

[Apply for student aid](/en/services/benefits/education/student-aid/grants-loans/province-apply.html) with your province or territory.

## Related services and information

* [Canada Student Grant for Students with Disabilities](/en/employment-social-development/services/education/grants/disabilities.html)

## Page details

Date modified:
:   2022-08-02

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
