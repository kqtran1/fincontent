---
source_url: https://www.canada.ca/en/services/benefits/education/student-aid/grants-loans/province-apply.html
scraped_at: 2025-08-24 17:36:30
filename: en/services/benefits/education/student-aid/grants-loans/province-apply_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/aide-etudiants/bourses-prets/province-demande.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)
4. [Student aid](/en/services/benefits/education/student-aid.html)

# Canada Student Grants and Loans – Apply with your province or territory

**From: [Employment and Social Development Canada](/en/employment-social-development.html)**

* [What student grants and loans offer](/en/services/benefits/education/student-aid/grants-loans.html)
* [Apply with your province or territory](/en/services/benefits/education/student-aid/grants-loans/province-apply.html)
* [Loan agreement](/en/services/benefits/education/student-aid/grants-loans/loan-agreement.html)

Go to your province or territory to:

* find out if you're eligible for student grants and loans
* know how much you could get
* apply for student grants and loans

## Provincial and territorial student aid offices

* [Alberta Student Aid](https://studentaid.alberta.ca/)
* [British Columbia Student Aid](https://studentaidbc.ca/)
* [Manitoba Student Aid](https://www.edu.gov.mb.ca/msa/)
* [New Brunswick Student Financial Services](https://www2.gnb.ca/content/gnb/en/corporate/promo/student-financial-services.html)
* [Newfoundland and Labrador Student Aid](https://www.gov.nl.ca/education/studentaid/)
* [Northwest Territories Student Financial Assistance](https://www.ece.gov.nt.ca/en/services/student-financial-assistance)
* [Nova Scotia Student Assistance](https://novascotia.ca/studentassistance/)
* [Nunavut Student Funding](https://www.gov.nu.ca/student-funding)
* [Ontario Student Assistance Program (OSAP)](https://www.ontario.ca/page/osap-ontario-student-assistance-program)
* [Prince Edward Island Student Financial Services](https://www.princeedwardisland.ca/en/topic/student-loans-bursaries-grants-and-awards?utm_source=redirect&utm_medium=url&utm_campaign=studentloans)
* [Quebec Student Financial Aid](http://www.afe.gouv.qc.ca/en/)
* [Saskatchewan Student Loans](http://www.saskatchewan.ca/studentloans#utm_campaign=q2_2015&utm_medium=short&utm_source=%2Fstudentloans)
* [Yukon Student Financial Assistance](http://www.yukonstudentaid.com/)

After you apply, your provincial or territorial student aid service will be in touch with you for the steps that will follow.

## Apply for part-time student grants and loans

To apply for part-time student aid in Manitoba, New Brunswick or Yukon you will need to submit the following form.

* [Part-Time Canada Student Grant and Loan Application 2025 to 2026 (PDF, 232 KB)](/content/dam/canada/employment-social-development/migration/documents/assets/portfolio/docs/en/student_loans/forms/SDE0031_EN_.pdf)

For all other provinces or territory, visit their website to submit an application.

## Confirm your enrolment

In order to receive your grant and/or loan money, you or your school will need to confirm that you are enrolled. Log in to your secure [National Student Loans Service Centre account](https://www.csnpe-nslsc.canada.ca/en/home) to confirm your enrolment.

## Document navigation

* [Previous : What student grants and loans offer](/en/services/benefits/education/student-aid/grants-loans.html)
* [Next : More information](/en/services/benefits/education/student-aid/grants-loans/loan-agreement.html)

## Page details

Date modified:
:   2025-08-21

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
