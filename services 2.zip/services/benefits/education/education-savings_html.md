---
source_url: https://www.canada.ca/en/services/benefits/education/education-savings.html
scraped_at: 2025-08-24 16:16:36
filename: en/services/benefits/education/education-savings_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/education/epargne-etudes.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)
3. [Student aid and education planning](/en/services/benefits/education.html)

# Registered Education Savings Plans and related benefits

The Registered Education Savings Plan (RESP) is a **long-term savings plan** to help people save for a child's education after high school, including trade schools, CEGEPs, colleges, universities, and apprenticeship programs. An adult can also open an RESP for themselves.

When you open an RESP, you can ask your financial institution (the promoter) to apply for benefits like the **Canada Learning Bond (CLB)** and the **Canada Education Savings Grant (CESG)**. If the child is eligible, these benefits will be received in the RESP to help with the cost of the child's education. Eligible expenses can include tuition, books, tools, transportation, and rent. British Columbia and Quebec also offer provincial benefits.

## Sections

[How the RESP and related benefits work together](/en/services/benefits/education/education-savings/plan.html)
:   To receive benefits like the CLB, the CESG, and provincial benefits, you need to open an RESP.

[How much money benefits could add to the RESP](/en/services/benefits/education/education-savings/estimating-amounts.html)
:   Estimate how much money the CLB, the CESG and provincial benefits could add to the RESP. Consult the detailed eligibility criteria and amounts for each benefit.

[Open an RESP and apply for benefits](/en/services/benefits/education/education-savings/opening-plan.html)
:   Any adult can open an RESP and apply for the CLB, CESG and provincial benefits. Use the list of promoters to find one that offers the benefits the child is eligible for.

[Pay for education using the RESP](/en/services/benefits/education/education-savings/paying-education.html)
:   You can use the money in the RESP to pay for the child's education after high school. Determine if the school is eligible, and request the money from your promoter.

[Managing the RESP, taxes, and transfers](/en/services/benefits/education/education-savings/managing-plan.html)
:   How long RESPs can stay open, how to change or add beneficiaries, how RESPs are taxed, how to transfer RESP funds, and how to close a plan.

## If you have questions about RESPs and benefits

If you have questions about the RESP, the CLB, the CESG, or provincial benefits, you should **contact your RESP promoter first**. Your promoter should know the specific details of your RESP and be able to help you. For more general inquiries, you can [submit a form](https://srv144.services.gc.ca/cgi-bin/ContactForm-FormulaireContact/index.aspx?GoCTemplateCulture=en-CA&section=cesp) to the Canada Education Savings Program.

## Resources and publications

We have additional resources and information available to RESP promoter organizations, as well as a list of all reports and publications from the [Canada Education Savings Program.](/en/employment-social-development/programs/canada-education-savings.html)

* [Resources for RESP promoters](/en/services/benefits/education/education-savings/resp-promoters.html)
* [Reports and publications](/en/employment-social-development/services/student-financial-aid/education-savings/reports.html)

## Page details

Date modified:
:   2024-11-04

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
