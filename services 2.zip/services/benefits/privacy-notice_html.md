---
source_url: https://www.canada.ca/en/services/benefits/privacy-notice.html
scraped_at: 2025-08-24 18:29:53
filename: en/services/benefits/privacy-notice_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/demande-confidentialite.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Privacy notice statement

EI benefits

# Before you apply

You must read the Privacy notice statement before you start the application.

## Privacy notice statement

### Collecting your personal information

Service Canada, which is part of Employment and Social Development Canada (ESDC), administers the Employment Insurance (EI) program.

Service Canada collects personal information you put in an EI benefit application to decide whether you qualify for EI benefits.

Your Social Insurance Number (SIN) is collected and used to identify your file with Service Canada and to confirm your identity by comparing the information you give us with the information found in your SIN record.

The *Employment Insurance Act* and the *Directive on the Social Insurance Number* allow Service Canada to collect your information.

### Protecting your privacy

Your privacy is important to us. You have the right to the protection of, access to, and correction of your personal information.

Your personal information is administered in keeping with:

* the *Employment Insurance Act*
* the *Privacy Act*
* any other applicable privacy laws governing the protection of personal information under the control of Service Canada

The personal information we collect is described in the following personal information banks:

* [Employment Insurance Claim Files (ESDC PPU 151)](/en/employment-social-development/corporate/transparency/access-information/reports/infosource/infosource-detailed.html#h2.3-3.16)
* [Employment Benefits and Support Measures (ESDC PPU 293)](/en/employment-social-development/corporate/transparency/access-information/reports/infosource/infosource-detailed.html#h2.3-3.26)

Your personal information will be used and disclosed in keeping with the conditions listed in each bank. It will be kept as long as is required by the *Employment Insurance Act*.

You can learn more about these personal information banks including how to submit an Access to Information request in [*Info Source (Information about Programs and Information Holdings)*](/en/employment-social-development/corporate/transparency/access-information/reports/infosource.html?utm_campaign=not-applicable&utm_medium=vanity-url&utm_source=canada-ca_infosource-esdc).

If you don't agree with the way Service Canada handles your personal information, you can contact the Office of the Privacy Commissioner of Canada to [report a concern](https://www.priv.gc.ca/en/report-a-concern/).

### Self-employed program clients

If you've registered with the self-employed program, Service Canada may share your information with the Canada Revenue Agency (CRA) for the administration of the *Income Tax Act*.

CRA may provide Service Canada with information about your net self-employment earnings and your income information for this year and the past 2 years.

Service Canada will use this information to decide whether you qualify for benefits, to confirm the income information on your claim, and to determine or amend your EI weekly benefit rate.

If you've registered with the self-employed program, your information is described in the [Registration for the Employment Insurance Measure for Self-Employed People (ESDC PPU 323)](/en/employment-social-development/corporate/transparency/access-information/reports/infosource/infosource-detailed.html#h2.3-3.19) personal information bank.

### Sharing your information

Service Canada may use or share the information you provide:

* within ESDC for policy analysis, research and/or evaluation activities. These uses or activities won't affect any administrative decisions made about you
* with third parties such as academics, research groups, or private-sector firms under specific contract to the Department, or to other government or contracted agencies

* with federal government institutions according to legislation and/or signed information-sharing agreements
* with provincial, territorial, municipal, and aboriginal governments and their authorized third-party service providers according to formal agreements and memoranda of understanding to administer employment benefits and support measures, including training
* with the Province of Quebec for the administration of the *Employment Insurance Act* and the Québec Parental Insurance Plan

You can learn more about how Service Canada may use or share your personal information in [Employment Insurance Claim Files (ESDC PPU 151)](/en/employment-social-development/corporate/transparency/access-information/reports/infosource/infosource-detailed.html#h2.3-3.16).

We use the hCaptcha anti-bot service on our website to monitor network traffic to identify any unauthorized attempts to access our online services. This network traffic information is shared with the third party responsible for the hCaptcha service.

### Why we need your personal information

You choose whether to apply for EI benefits. We use your information to decide whether you qualify for EI benefits, the Family Supplement, employment programs and support measures, including training.

If you don't provide your personal information in your application, you can't be considered for benefits.

## Apply for EI

By starting this application, you consent to the terms of the above privacy notice statement.

[Start application](https://srv270.hrdc-drhc.gc.ca/AW/introduction?GoCTemplateCulture=en-CA)

## Page details

Date modified:
:   2024-04-19

## About this site

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
