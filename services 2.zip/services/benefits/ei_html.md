---
source_url: https://www.canada.ca/en/services/benefits/ei.html
scraped_at: 2025-08-24 13:04:34
filename: en/services/benefits/ei_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/prestations/ae.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Benefits](/en/services/benefits.html)

# Employment Insurance benefits

Employment Insurance (EI) benefits information, how to apply and how to submit a report.

## Information about wildfires

Service Canada programs and services might be affected by recent wildfires.

Find out more by visiting the [Help for individuals affected by hazardous weather page](/en/employment-social-development/corporate/notices/hazardous-weather.html).

## Potential delays in Canada Post delivery services

Mail delivery for some programs and services may be delayed. Consult the measures in place during the [potential disruption of Canada Post services](/en/employment-social-development/corporate/portfolio/service-canada/postal-disruption.html).

## Most requested

* [Temporary EI measures](/en/services/benefits/ei/temporary-measures-for-major-economic-conditions.html) New
* [Submit your EI report](/en/services/benefits/ei/employment-insurance-reporting.html#Internet-Reporting-Service)
* [Review your claim and records of employment](/en/employment-social-development/services/my-account.html)
* [EI Benefits Estimator](https://estimateurae-eiestimator.service.canada.ca/en)
* [Work-Sharing Program – employers](/en/employment-social-development/services/work-sharing.html)
* [Sign up for direct deposit](https://www.tpsgc-pwgsc.gc.ca/recgen/txt/depot-deposit-eng.html)
* [EI tax information (T4E)](/en/employment-social-development/programs/ei/ei-list/tax-slips-itemized.html)
* [EI forms](https://catalogue.servicecanada.gc.ca/content/EForms/en/Profile.html?Group=HRSDC/EI)
* [Consult the Benefits Finder](/en/services/benefits/finder.html)

## Services and information

### [Regular benefits](/en/services/benefits/ei/ei-regular-benefit.html)

Apply if you have lost your job through no fault of your own.

### [Sickness benefits](/en/services/benefits/ei/ei-sickness.html)

Apply if you’re unable to work due to illness, injury or quarantine.

### [Maternity and parental benefits](/en/services/benefits/ei/ei-maternity-parental.html)

Apply if you're pregnant, have recently given birth, are adopting a child or are caring for your newborn.

### [Caregiving benefits](/en/services/benefits/ei/caregiving.html)

Apply if you’re providing care or support to someone who is critically ill or injured, or in need of end-of-life care.

### [EI information for employers](/en/employment-social-development/programs/ei/ei-list/ei-employers.html)

Prepare records of employment, and learn about EI premiums, supplemental payments, Work-Sharing Program and other resources.

### [Benefits for self-employed people](/en/services/benefits/ei/ei-self-employed-workers.html)

Check your eligibility to receive EI special benefits, enter an agreement, pay premiums, and withdraw when needed.

### [Fishing benefits](/en/services/benefits/ei/ei-fishing.html)

Apply if you’re a self-employed fisher who is actively seeking work.

### [Find a job](/en/services/jobs.html)

Search for jobs in Canada and apply or extend a work permit.

### [Benefits for Canadians living abroad](/en/services/benefits/audience/canadiansabroad.html)

If you live or work outside of Canada, find information on EI benefits, pensions, and taxes.

## Features

![](/content/dam/themes/benefits/features/20180905-1.jpg)

### [Additional support for workers in seasonal employment](/en/employment-social-development/corporate/portfolio/service-canada/ei-seasonal-workers.html)

Extra weeks of regular benefits for workers with seasonal jobs in targeted regions.

![Desktop monitor opened on a Canada website page](/content/dam/esdc-edsc/images/services/my-account/video-access-services/MSCA_image.png)

### [Video: What is My Service Canada Account](/en/employment-social-development/services/my-account/video-access-services.html)

Discover what MSCA offers and how having an account can help you access your EI services and benefits.

## Contributors

## From:

* [Employment and Social Development Canada](/en/employment-social-development.html)

## Page details

Date modified:
:   2025-07-16

## About this site

### Employment Insurance

* [Contact Employment Insurance](/en/employment-social-development/corporate/contact/ei-individual.html)

### Government of Canada

* [All contacts](/en/contact.html)
* [Departments and agencies](/en/government/dept.html)
* [About government](/en/government/system.html)

#### Themes and topics

* [Jobs](/en/services/jobs.html)
* [Immigration and citizenship](/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](/en/services/business.html)
* [Benefits](/en/services/benefits.html)
* [Health](/en/services/health.html)
* [Taxes](/en/services/taxes.html)
* [Environment and natural resources](/en/services/environment.html)
* [National security and defence](/en/services/defence.html)
* [Culture, history and sport](/en/services/culture.html)
* [Policing, justice and emergencies](/en/services/policing.html)
* [Transport and infrastructure](/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](/en/services/finance.html)
* [Science and innovation](/en/services/science.html)
* [Indigenous Peoples](/en/services/indigenous-peoples.html)
* [Veterans and military](/en/services/veterans-military.html)
* [Youth](/en/services/youth.html)
* [Manage life events](/en/services/life-events.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](/en/transparency/terms.html)
* [Privacy](/en/transparency/privacy.html)

![Symbol of the Government of Canada](/etc/designs/canada/wet-boew/assets/wmms-blk.svg)
