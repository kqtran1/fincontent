3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)

# Conversion of foreign currency

If total revenue is expressed in a currency other than euros, the amount must be converted to euros using a rate of exchange that is acceptable by the Canada Revenue Agency (CRA).

If an amount of Canadian digital services revenue is expressed in a currency other than Canadian dollars, the amount must be converted to Canadian dollars using a rate of exchange that is acceptable by CRA.

In general, a rate of exchange that is acceptable to the CRA is a rate quoted by the [Bank of Canada](https://www.bankofcanada.ca/rates/exchange/).

If the rate of exchange for a currency is not quoted by the Bank of Canada, the CRA will generally accept a rate from another source if the rate is:

* widely available
* verifiable
* published by an independent provider on an ongoing basis
* recognized by the market
* used in accordance with well-accepted business principles
* used for the preparation of the taxpayer's financial statements, and
* used consistently from year to year by the taxpayer

For practical reasons, the CRA will accept the use of an average of rates of exchange over a period of time (annual or monthly) in order to convert revenue. The same period of time must be used consistently from year to year.

## Page details

Date modified:
:   2025-04-04
