3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)

# Digital services tax

* [About the tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/about-tax.html)
* [Registering for an account](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-register.html)
* [Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)
* [Filing a return](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

# Filing a return

The first year of application of the digital services tax (DST) is the 2024 calendar year. In that first year, the tax will apply to taxable Canadian digital services revenue earned since January 1, 2022.

Foreign and domestic businesses that meet the filing requirements must file a DST return.

## On this page

* [Who must file](#toc0)
* [Before you file](#toc1)
* [How to file a return](#toc2)
* [Failure to file a return](#toc3)

## Who must file

A foreign or domestic business **must file a DST return** by June 30, 2025, if for any one of the 2022, 2023, or 2024 calendar years:

* The business had Canadian digital services revenue greater than nil in the calendar year
* The business had, or was a member (in the calendar year or in the prior calendar year) of a consolidated group that had, total revenue of at least €750 million during a fiscal year that ended in the prior calendar year
* The business had, or was a member (in the calendar year) of a consolidated group that had, Canadian digital services revenue greater than CAN$20 million in the calendar year

For information on the conversion of foreign currency, refer to: [Conversion of foreign currency](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/rate-exchange.html).

### Who can file on your behalf

You may elect a designated entity to file your DST return on your behalf if certain conditions are met.

For more information, refer to: [Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)

## Before you file

When you file your DST return, you will need to provide your account identifiers, contact information, and financial information for the 2022, 2023, and/or 2024 calendar years.

### Account identifiers

* Business name
* Business number with DST program account (XXXXX XXXX DTXXXX)

### Contact information

* Name of the primary contact
* Phone number of the primary contact

### Financial information

* Total revenue
* Canadian online marketplace services revenue
* Canadian online advertising services revenue
* Canadian social media services revenue
* Canadian user data revenue
* Canadian digital services revenue (CDSR) How to determine your CDSR

  Your CDSR is the total of your Canadian online marketplace services revenue, Canadian online advertising services revenue, Canadian social media services revenue, and Canadian user data revenue for the calendar year.

  For the 2022 and 2023 calendar years, you may use a simplified method for your calculation. To use the simplified method, you must **make an election** in your DST return and **provide your total revenues for 2022 and/or 2023**.

  For more information, refer to: [Calculate your Canadian digital services revenue](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file/calculate-cdsr.html)
* Deduction amount (allocated among group members based on the CDSR they each earned during a [relevant interval](#ntrvl "What is a relevant interval?"))
* Taxable CDSR
* [DST liability](#dst_lblt "What is the DST liability?")
* Amount paid

If you were a member of **more than one consolidated group during the calendar year**, you must also provide the following information for each relevant interval:

* Start and end dates of the relevant interval
* CDSR earned by your business
* CDSR earned by the consolidated group in which you were a member

## How to file a return

You must file a DST return through an Application Programming Interface (API) using a JavaScript Object Notation (JSON) schema.

For the filing data elements, refer to: [Before you file](#toc1)

### Steps to file a DST return

1. ### Request the instructions

   For the detailed instructions on how to file a DST return, including the schema, found in the Digital Services Tax Return Submission Guide, send an email to: APISERs-IPADCS@cra-arc.gc.ca.
2. ### Complete the certification process

   Once you request the instructions, we will instruct you to engage with our Certification Testing (CT) environment.

   We recommend that you complete the certification process early to ensure you have no difficulties when filing your return. The CT environment will be available **as of April 7, 2025**.
3. ### Use your token to file

   Once you complete the certification process as instructed, we will issue you a token. This token, along with your Digital Access Code or your EFILE number and password, will be required to file your DST return.

Complete the final filing steps, as outlined in the Digital Services Tax Return Submission Guide.

### Keeping records

You must keep all records necessary to determine whether you have complied with the *Digital Services Tax Act*. You must also keep all your records necessary to determine whether other entities in your consolidated group have complied with the Act.

Keep these records for at least **eight years** from the end of the calendar year to which they relate.

## Failure to file a return

### Penalty

If you fail to file a DST return when required, you are liable to a penalty equal to the total of:

* 5% of the tax for the year that was unpaid when the return was required to be filed, and
* 1% of the tax for the year that was unpaid when the return was required to be filed, for each complete month (not exceeding 12 months) in which the return is not filed.

### Interest

If you fail to pay an amount, interest will apply from the day your payment was due. The interest rate we use is determined every three months based on prescribed interest rates. Interest is compounded daily.

For more information, refer to: [Prescribed interest rates](/en/revenue-agency/services/tax/prescribed-interest-rates.html)

## Document navigation

* [Next: Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

## Relevant interval

A relevant interval is any period that starts at one relevant time and ends at the next relevant time. Every time an entity that has CDSR greater than nil joins or leaves a consolidated group, it creates a relevant time for the entity as well as for all the other members of the group.

## DST liability

For the 2024 calendar year, your DST liability is calculated by aggregating 3% of your taxable CDSR for each of the 2022, 2023 and 2024 calendar years in which the global revenue threshold and the in-scope revenue threshold are met.

## Page details

Date modified:
:   2025-04-04
