3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)

# Digital services tax

* [About the tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/about-tax.html)
* [Registering for an account](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-register.html)
* [Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)
* [Filing a return](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

# Contact us

Contact the Canada Revenue Agency (CRA) if you would like more information about the [digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html).

## Ask a general question about the digital services tax: Option 1

You can submit your question about the digital services tax using the [online form](https://forms-formulaires.alpha.canada.ca/en/id/cm6gzbozb002zyj69tzsfgkqm).

## Request a technical interpretation for the Digital Services Tax Act: Option 2

You can [request a technical interpretation](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/request-technical-interpretation.html) of specific provisions of the *Digital Services Tax Act*.

## Ask a question not related to the digital services tax: Option 3

To contact the CRA for other reasons, refer to: [Contact the CRA](/en/revenue-agency/corporate/contact-information.html)

## Page details

Date modified:
:   2025-06-30
