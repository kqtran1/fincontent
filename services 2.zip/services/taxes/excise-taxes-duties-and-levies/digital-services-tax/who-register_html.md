3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)

# Digital services tax

* [About the tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/about-tax.html)
* [Registering for an account](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-register.html)
* [Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)
* [Filing a return](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

# Registering for an account

## On this page

* [Who must register](#h_1)
* [How to register](#h_2)

## Who must register

A foreign or domestic business **must apply to register for a digital services tax (DST) program account** by January 31, 2025, if for any one of the 2022, 2023 or 2024 calendar years:

* The business had Canadian digital services revenue greater than nil in the calendar year
* The business had, or was a member (in the calendar year or in the prior calendar year) of a consolidated group that had, total revenue of at least €750 million during a fiscal year that ended in the prior calendar year
* The business had, or was a member (in the calendar year) of a consolidated group that had, Canadian digital services revenue greater than CAN$10 million in the calendar year

For information on the conversion of foreign currency, refer to: [Conversion of foreign currency](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/rate-exchange.html).

## How to register

### Steps to apply for a DST program account

1. #### Gather information about your business

   Information you need for registration:

   * Legal name
   * Business number (BN), if the business already has one
   * Date and place of incorporation and certificate number, if the business is incorporated
   * Physical address
   * Mailing address, if different from the physical address
   * Name and phone number of at least one officer or director
2. #### Submit your application

   You **must** use the DST account registration web form to apply to register for your DST program account.

   * If your business does not have a BN, it will receive one through the DST registration process.
   * If your business already has a BN, you **must** also use the DST account registration webform to request your DST program account.

   When you apply to register:

   * Enter your information in a timely manner because the form will time out after 30 minutes of inactivity
   * Complete the form in one session because you cannot save information during the registration process
   * You cannot create other program accounts using the form
   * Use the “Previous” button to return to previous windows of the registration form instead of the “Back” button in your web browser
3. #### Keep a copy of your confirmation number

   After you successfully submit the form, you will get a confirmation number. This number is your proof that the Canada Revenue Agency (CRA) has received your application. Keep a copy of the number for your records.
4. #### Wait for a response from the CRA

   We may have to contact you for more information. We may also ask you to submit incorporation or formation documents.

   When we have processed your registration request you will receive your BN and/or your DST program account number either electronically or in the mail, depending on the method you choose on your application.

## Document navigation

* [Next: Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)

## Page details

Date modified:
:   2025-08-06
