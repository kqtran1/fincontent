3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)
5. [Filing a return - Digital Services Tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)

# Digital services tax

* [About the tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/about-tax.html)
* [Registering for an account](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-register.html)
* [Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)
* [Filing a return](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)
  + [Calculating your Canadian digital services revenue](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file/calculate-cdsr.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

# Calculating your Canadian digital services revenue

**Use the calculation below to determine your Canadian digital services revenue (CDSR):**

* Canadian online marketplace services revenue
* plus Canadian online advertising services revenue
* plus Canadian social media services revenue
* plus Canadian user data revenue
* equals CDSR

## Simplified method for 2022 and 2023

Under the simplified method, your CDSR for the 2022 and/or 2023 calendar years is approximated by using the ratio of CDSR to total revenue for the 2024 calendar year.

### Calculate your estimated CDSR for 2022

* Total revenue for 2022
* times by CDSR for 2024
* divided by Total revenue for 2024
* equals Estimated CDSR for 2022

### Calculate your estimated CDSR for 2023

* Total revenue for 2023
* times by CDSR for 2024
* divided by Total revenue for 2024
* equals Estimated CDSR for 2023

### Making an election to use the simplified method

To use the simplified method, you must make an election in your DST return **by June 30, 2025**.

For revenue earned in the 2023 calendar year, the election can only be made if **one** of the following conditions is met:

* The election was also made for the 2022 calendar year
* Neither the global revenue threshold nor the in-scope revenue threshold was met for the 2022 calendar year

## Document navigation

* [Next: Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)

## Page details

Date modified:
:   2025-04-07
