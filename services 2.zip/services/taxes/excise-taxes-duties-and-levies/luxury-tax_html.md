3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)

# Luxury tax

Information on the luxury tax under the Select Luxury Items Tax Act.

## Services and information

### [Luxury tax registration](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/luxury-tax-registration.html)

Who has to register. When and how to register.

### [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html)

Luxury tax notices, memoranda, forms, rates and other technical publications.

### [Luxury tax registry](https://apps.cra-arc.gc.ca/ebci/enov/ltr/prot/ntr.action)

Verify a luxury tax account’s registration status.

### [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html)

How to determine the consideration and retail value for calculating the luxury tax.

### [Completing a Luxury Tax and Information Return for Registrants](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/completing-luxury-tax-return.html)

Line-by-line instructions on how to fill out Form B500.

### [Pay (remit) the luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/pay-luxury-tax.html)

When and how to pay (remit) the luxury tax.

### [Completing a Luxury Tax and Information Return for Non-Registrants](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/completing-luxury-tax-return-for-non-registrants.html)

Line-by-line instructions on how to fill out Form B501.

### [Search for a luxury tax certificate](https://apps.cra-arc.gc.ca/ebci/enov/ltc/prot/ntr.action)

View and print a luxury tax certificate for an aircraft or vessel.

### [Luxury tax on after-sales improvements](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/luxury-tax-after-sales-improvements.html)

Luxury tax on after-sales upgrades, modifications and other improvements made to certain vehicles, aircraft and vessels.

### [Third-Party Rebates on Sales of Luxury Items](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/third-party-rebates-sales-luxury-items.html)

How third party rebates affect the luxury tax

## Page details

Date modified:
:   2025-06-04
