3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Consideration and retail value

The luxury tax applies to certain vehicles and aircraft priced over $100,000 and certain vessels priced over $250,000. For more information on the application of the luxury tax, go to [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html).

The luxury tax is calculated using the **taxable amount** of the luxury item. Generally, the taxable amount is either the **value of consideration** or the **retail value** of the luxury item.

## On this page

* [How to determine the taxable amount for the sale of a luxury item](#1)
  + [What to include](#2)
  + [What not to include](#3)
  + [Example of luxury tax calculation](#4)
* [How to determine the taxable amount in other circumstances](#5)
  + [What is fair market value (FMV)](#6)
  + [Example of luxury tax calculation](#7)

## How to determine the taxable amount for the sale of a luxury item

If you are a vendor that sells luxury items, the taxable amount is the **value of consideration** in connection with the sale of the luxury item.

The value of consideration includes:

* the price of the **luxury item** being sold
* the price of any **improvements** (that is, goods that are installed on the luxury item or physically performed services that modify the luxury item) that are made in connection with the sale of the luxury item
* the price of any **incidental goods and services** that are supplied with the luxury item being sold
* any **fees** that relate to the sale of the luxury item
* any payable **federal and provincial levies** other than the GST/HST and the provincial sales tax in British Columbia, Saskatchewan, Manitoba and Quebec

Where applicable, you must include all of the above in calculating the luxury tax on the sale of a luxury item.

### What to include

The following are examples of what to include in the value of consideration for calculating the luxury tax on the sale of a luxury item. The following are **not** exhaustive lists.

#### Improvements

* Motor and engine upgrades
* Engine block heaters
* Remote starter and keyless entry systems
* On-board audio, entertainment, navigation, communication and lighting systems
* Extra options including power windows, sunroof and Wi-Fi capabilities
* On-board solar panel systems
* Heating and air conditioning systems
* Exterior upgrades including cosmetic and equipment installations
* Interior upgrades including upgrades to upholsteries and cabins
* Upholstery treatments
* Exterior paints, vinyl wraps and window tints
* Protective films and coatings
* Undercoating and rustproofing
* All-season, winter and performance tires that are installed on vehicles at the time of sale
* Etchings, immobilizers and other anti-theft systems

#### Incidental goods and services

* Motor and engine fuel in the fuel tanks of luxury items
* Chargers for electric vehicles
* Floor liners, cargo organizers and other interior accessories
* Lifejackets, embarkation ladders, parachutes, signal flare kits and emergency roadside kits
* Splash guards, deflectors and other exterior accessories
* Key chains, key fob covers, waterproof tarps, sunshades and other miscellaneous accessories
* Detailing and delivery services that are supplied with the sale of luxury items

#### Fees

* Administration and documentation fees
* Regulatory fees (e.g. OMVIC fee and AMVIC fee for vehicles in Ontario and Alberta)
* Title and ownership transfer fees
* Licencing and registration fees
* Finance arrangement fees
* Fees for registering liens and other security interests against luxury items (e.g. PPSA fee)
* Transportation and freight fees
* Pre-delivery inspection (PDI) fees

#### Federal and provincial levies

* Import duties and taxes
* Federal green levy on fuel‑inefficient vehicles
* Federal excise tax on air conditioners in vehicles
* Federal and provincial levies on motor and engine fuel in the fuel tanks of luxury items
* Provincial battery levies
* Provincial tire levies

### What not to include

The following are examples of what not to include in the value of consideration for calculating the luxury tax on the sale of a luxury item. This is **not** an exhaustive list.

* GST/HST
* PST in British Columbia and Saskatchewan (Note: the luxury vehicle tax in British Columbia is a form of PST)
* RST in Manitoba
* QST in Quebec
* Software upgrades that are performed remotely
* Extended warranties
* Repair, maintenance and service plans
* Emergency roadside assistance plans
* Road hazard protection plans
* Payment protection plans
* Insurance products
* Guaranteed asset protection coverages
* Seasonal storage services
* Paid subscription services that do not modify luxury items including navigation, media and internet subscription services
* Extra sets of tires that are not installed on vehicles at the time of sale

### Example of luxury tax calculation

A dealership sells a subject vehicle to a purchaser. The sale is made in Ontario. The price of the base subject vehicle is $200,000. The dealership charges the purchaser for various improvements, incidentals, fees and levies in connection with the sale of the subject vehicle. The dealership also supplies some improvements and incidentals at no additional charge and does not pass down the cost of some fees and levies to the purchaser.

The breakdown of the total cost for the purchaser is as follows:

Breakdown of the total cost

|  |  |
| --- | --- |
| Base subject vehicle | $200,000.00 |
|  |  |
| **Improvements** |  |
| Air conditioning | Included |
| Remote keyless entry | Included |
| Interior and exterior lighting | +$1,500.00 |
| Navigation and audio systems package | +$2,900.00 |
| Heads-up display | +$500.00 |
| Blind spot monitoring system | +$500.00 |
| Black interior | Included |
| Heated leather steering wheel | +$200.00 |
| Aluminum paddle shifters and pedals | +$200.00 |
| Blue metallic exterior | +$600.00 |
| Gloss blue brake calipers | +$550.00 |
| All-season tires with aluminum rims (installed on vehicle) | +$1,900.00 |
| Rustproofing | +$650.00 |
| Anti-theft alarm system | Included |
|  |  |
| **Incidentals** |  |
| Front licence plate bracket | Included |
| All-weather floor mats | +$200.00 |
| Battery charger and conditioner | +$110.00 |
| Emergency roadside kit | +$50.00 |
| Manufacturer-branded key fob cover | +$40.00 |
| Manufacturer-branded sunshade | +$100.00 |
| Full tank of fuel | Included |
| Home delivery charge | +$100.00 |
|  |  |
| **Fees** |  |
| OMVIC fee | +$10.00 |
| Licensing and registration fees | Included |
| Administration fee | +$350.00 |
| Freight and PDI fees | +$2,440.00 |
|  |  |
| **Levies** |  |
| Federal excise tax on air conditioners in vehicles | +$100.00 |
| Federal excise tax on full tank of fuel | Included |
| Federal green levy on fuel-inefficient vehicles | +$1,000.00 |
|  |  |
| **Subtotal for calculating the luxury tax** | **$214,000.00** |
| Luxury tax (10%) | +$21,400.00 |
|  |  |
| Extended warranty | +$2,500.00 |
| Winter tires on steel rims (not installed on vehicle) | +$2,500.00 |
| One-year subscription to music streaming service | +$100.00 |
|  |  |
| **Subtotal for calculating the GST/HST** | **$240,500.00** |
| GST/HST (13%) | +$31,265.00 |
|  |  |
| **Total** | **$271,765.00** |

The value of consideration for calculating the luxury tax is $214,000. The luxury tax is the lesser of 10% of $214,000 and 20% of $114,000 (the amount above the $100,000 price threshold for subject vehicles). Therefore, the dealership calculates the luxury tax as $21,400 ($214,000 × 10%). The dealership must remit $21,400 to the Canada Revenue Agency (CRA). The dealership decides to pass down the cost of the luxury tax to the purchaser.

The applicable GST/HST is applied to the final sale price, inclusive of the luxury tax. The dealership separately adds the price of the extended warranty, winter tires and music streaming service (which are not subject to the luxury tax but are subject to the GST/HST) and determines the final sale price before GST/HST to be $240,500.

With the applicable GST/HST, the total cost for the purchaser is $271,765.

## How to determine the taxable amount in other circumstances

In all other circumstances, except for importations, the taxable amount is the **retail value** of the luxury item. For information on calculating the luxury tax on importations, visit Canada Border Services Agency [Memorandum D18-4-1: Select luxury items tax on importation](https://www.cbsa-asfc.gc.ca/publications/dm-md/d18/d18-4-1-eng.html).

The retail value includes:

* the **fair market value (FMV)** of the luxury item at the time
* any **transportation or freight fees** that were not already included in the FMV
* any payable **federal and provincial levies**, other than the GST/HST and the provincial sales tax in British Columbia (PST), Saskatchewan (PST), Manitoba (RST) and Quebec (QST), that were not already included in the FMV

### What is fair market value (FMV)

The fair market value (FMV) is typically the highest price, expressed in terms of money, that a property would bring in an open and unrestricted market, between a willing purchaser and a willing seller who are both knowledgeable, informed and prudent, and who are acting independently of each other.

Generally, if you have sufficient knowledge of the luxury item, you may be able to, on your own, determine the FMV for the purposes of the luxury tax. Otherwise, you may obtain a third‑party appraisal from a qualified professional.

### Example of luxury tax calculation

A vessel retailer owns a subject vessel valued above $250,000 and leases it out to a lessee. A lease agreement between the retailer and the lessee is entered into on April 1, 2023, at which point the lessee first has the right to use the subject vessel under the lease agreement. The lessee also takes possession of the subject vessel at this time. The taxable amount is the retail value of the subject vessel at that time. The retailer knows that a willing purchaser dealing at arm’s length would pay as high as $350,000 for the subject vessel.

The retailer determines the FMV of the subject vessel at that time to be $350,000. There is a transportation fee of $10,000 that the retailer did not include in the FMV. There are no federal or provincial levies that apply to the subject vessel. The retail value of the subject vessel is $360,000 ($350,000 + $10,000).

The luxury tax is the lesser of 10% of $360,000 and 20% of $110,000 (the amount above the $250,000 price threshold for subject vessels). Therefore, the retailer calculates the luxury tax as $22,000 ($110,000 × 20%). The retailer must remit $22,000 to the CRA.

## Page details

Date modified:
:   2023-10-03
