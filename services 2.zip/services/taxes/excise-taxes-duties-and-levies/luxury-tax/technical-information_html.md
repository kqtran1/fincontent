3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Luxury tax technical information

The following are technical publications and other helpful information related to the luxury tax under the *Select Luxury Items Tax Act*.

For all enquiries on the application of the luxury tax, contact your regional excise office. The offices are listed at [Contact information – Excise and Specialty Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html).

For information on how to request a ruling or interpretation related to the application of the luxury tax, go to [Requesting an excise and specialty tax ruling or interpretation](/en/revenue-agency/services/forms-publications/publications/estrulings/requesting-excise-specialty-tax-ruling-interpretation.html).

For information on applying for registration for the luxury tax, go to [Luxury tax registration](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/luxury-tax-registration.html).

## Services and information

### [Luxury tax notices](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information/luxury-tax-notices.html)

Announcements about changes to the *Select Luxury Items Tax Act* and the CRA policy, as well as to the application and the administration of the luxury tax.

### [Luxury tax forms](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information/luxury-tax-forms.html)

Forms required under the *Select Luxury Items Tax Act*.

## Page details

Date modified:
:   2025-06-12
