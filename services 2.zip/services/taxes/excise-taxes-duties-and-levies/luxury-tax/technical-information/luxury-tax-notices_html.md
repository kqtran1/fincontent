3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)
5. [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html)

# Luxury tax notices

* [LTN1 Registration Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn1.html)
* [LTN2 Subject Vehicles Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn2.html)
* [LTN3 Subject Vessels Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn3.html)
* [LTN4 Subject Aircraft Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn4.html)

## Page details

Date modified:
:   2022-09-12
