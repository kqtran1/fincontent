3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)
5. [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html)

# Luxury tax forms

* [B500 Luxury Tax and Information Return for Registrants](/en/revenue-agency/services/forms-publications/forms/b500.html)
* [B501 Luxury Tax and Information Return for Non-Registrants](/en/revenue-agency/services/forms-publications/forms/b501.html)
* [B502 Luxury Tax - Information Return for Non-Registrants](/en/revenue-agency/services/forms-publications/forms/b502.html)
* [B503 Luxury Tax Rebate Application for Foreign Representatives](/en/revenue-agency/services/forms-publications/forms/b503.html)
* [L100-1 Luxury Tax Exemption Certificate for Subject Vehicles](/en/revenue-agency/services/forms-publications/forms/l100-1.html)
* [L100-2 Luxury Tax Exemption Certificate for Subject Vessels](/en/revenue-agency/services/forms-publications/forms/l100-2.html)
* [L100-3 Luxury Tax Exemption Certificate for Subject Aircraft](/en/revenue-agency/services/forms-publications/forms/l100-3.html)
* [L500 Luxury Tax Registration Application](/en/revenue-agency/services/forms-publications/forms/l500.html)
* [L500-1 Non-Resident – Records Kept Outside Canada](/en/revenue-agency/services/forms-publications/forms/l500-1.html)
* [L500-2 Application or Revocation of the Authorization to File Separate Luxury Tax Returns for Branches and Divisions](/en/revenue-agency/services/forms-publications/forms/l500-2.html)
* [L501 Tax Certificate Application](/en/revenue-agency/services/forms-publications/forms/l501.html)
* [L502 Special Import Certificate Application](/en/revenue-agency/services/forms-publications/forms/l502.html)

## Page details

Date modified:
:   2022-08-31
