3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Pay (remit) the luxury tax

Your payment is due at the same time as your return. If your payment is attached to your luxury tax return, the Canada Revenue Agency (CRA) will process the payment and send you a notice of assessment.

For more information on which method you can use, see [Payment options for fuel charge, air travellers security charge, information returns penalty, tax on insurance premiums, softwood lumber or luxury tax](/en/revenue-agency/services/payments/payments-cra/individual-payments/make-payment.html).

If you are a non-resident, you can make a payment by [wire transfer](/en/revenue-agency/services/about-canada-revenue-agency-cra/pay-wire-transfer-non-residents.html).

## If your payment is not attached

If there is an amount owing and you receive your CRA mail online, the CRA will send your mail to [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html). If you are registered for email notification service, the CRA will send you an email notification to the email address you previously provided when you have new mail to view in My Business Account. If the CRA mails you a notice of assessment, they will send you [Form RC159, Remittance Voucher - Amount Owing](/en/revenue-agency/services/forms-publications/request-payment-forms-remittance-vouchers.html#rc159).

Use this form to pay any outstanding amount. Form RC159 is not available on the website. The CRA can only provide it in a pre-printed format. To order this personalized form, go to [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html) or [Represent a Client](/en/revenue-agency/services/e-services/represent-a-client.html), or call Business Enquiries at **1-800-959-5525**.

## Interest charges for paying late

The CRA will charge you interest if you:

* have an overdue amount on your return
* make a late or insufficient payment

The CRA will hold any rebate you are entitled to until they receive all outstanding returns and amounts owing. This includes returns that are required to be filed under other Acts that the CRA administers.

## Page details

Date modified:
:   2025-05-15
