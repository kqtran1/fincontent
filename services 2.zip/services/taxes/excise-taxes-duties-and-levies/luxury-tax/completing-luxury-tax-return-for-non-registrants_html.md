3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Completing a Luxury Tax and Information Return for Non-Registrants (Form B501)

## On this page

* [Overview](#toc0)
* [Filling out Parts A, B and C](#toc1)
* [Filling out Parts D to J](#toc2)
* [Filling out Part K – Certification](#toc3)
* [Further information](#toc4)

## Overview

This page provides line-by-line instructions on how to fill out [Form B501, Luxury Tax and Information Return for Non-Registrants](/en/revenue-agency/services/forms-publications/forms/b501.html), which must be filed by every person that is not registered under the Select Luxury Items Tax Act for each reporting period where they have luxury tax payable (other than luxury tax on importations). This return must be filed on or before the last day of the first month after the end of the reporting period during which tax becomes payable.

You must complete all of the relevant parts of the return that apply to your situation:

* If you are liable for luxury tax payable on subject vehicles, you should fill out Parts A to D, G, H (if applicable) and K
* If you are liable for luxury tax payable on subject aircraft, you should fill out Parts A to C, E, G, I (if applicable) and K
* If you are liable for luxury tax payable on subject vessels, you should fill out Parts A to C, F, G, J (if applicable) and K

If you need more space to provide information for any parts of the return, attach a separate sheet of paper to the return.

## Filling out Parts A, B and C

### Part A – Type of return

If you are filing a return for a reporting period for which you have already submitted a return, tick "Amended"; otherwise, tick "Original".

### Part B – Identification

Provide the legal name, the physical address, the mailing address and the contact number of the business or organization for which the return is being filed. If applicable, provide the trading or operating name and the luxury tax account number or business number of the business or organization. If the name of the business or organization has changed, contact your Canada Revenue Agency (CRA) regional excise office to report the change. A list of the offices is available at [Contact Information – Excise and Speciality Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts.html).

If you are filing as an individual, provide your full name and initials, your physical address, your mailing address, your contact number and if applicable, your luxury tax account number.

Provide the address where the books and records are maintained. To keep records outside Canada, you must request an authorization to do so with the CRA by using [Form L500-1, Non-Resident - Records Kept outside Canada](https://www.canada.ca/content/dam/cra-arc/formspubs/pbg/l500-1/l500-1-22e.pdf).

Most correspondence is only available online in [My Business Account](/en/revenue-agency/services/e-services/cra-login-services.html) by default, except when a business has changed its delivery method to receive paper mail. Provide your email address if you want to receive an email notification from the CRA when you have new mail for your luxury tax account to view in My Business Account.

### Part C – Reporting period

Indicate the start date and end date of the reporting period covered by the return. A reporting period is generally a calendar quarter.

## Filling out Parts D to J

Refer to the chart at the top of Page 3 of the return to determine which parts of the return to fill out.

### Part D – Luxury tax payable on subject vehicles

Report the luxury tax payable on subject vehicles priced or valued above the $100,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the table, refer to [LTN2, Subject Vehicles Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn2.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 1 to 4, indicate the type of transaction, the date tax became payable, the vehicle identification number and the luxury tax payable for each subject vehicle. Each type of transaction has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number.

For sales of subject vehicles and purchases of subject vehicles, use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject vehicle:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $100,000)

For improvements made to subject vehicles during the improvement period, use the following formula to calculate the luxury tax payable on improvements made to each subject vehicle:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $100,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject vehicle if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $100,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject vehicle.

### Notes

The luxury tax on improvements will typically only apply to improvements made to subject vehicles that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that **total at least $5,000** and are made during the **improvement period** of the subject vehicle.

In circumstances where a sale or a purchase triggered the luxury tax on the subject vehicle, the improvement period begins on the day that an agreement for the sale/purchase is entered into and ends on the day that is one year after. If, during this time, the subject vehicle is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the subsequent sale is completed.

In all other circumstances, the improvement period of the subject vehicle begins on the day that the luxury tax on the subject vehicle initially became payable and ends on the day that is one year after. If, during this time, the subject vehicle is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. You should report the total of all amounts of luxury tax payable with respect to subject vehicles for the reporting period identified in Part C.

Add lines 1 to 4 and enter the result on line 5. This is the total luxury tax payable in respect of subject vehicles priced or valued above the $100,000 threshold and must also be entered on line 22 in Part G of the return.

### Part E – Luxury tax payable on subject aircraft

Report the luxury tax payable on subject aircraft priced or valued above the $100,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the tables, refer to [LTN4, Subject Aircraft Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn4.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 6 to 9, indicate the type of transaction, the date tax became payable, the serial number and the luxury tax payable for each subject aircraft. Each type of transaction has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. On the return, you can also apply for a tax certificate for each subject aircraft by ticking the corresponding box. Otherwise, you can use [Form L501, Tax Certificate Application](/en/revenue-agency/services/forms-publications/forms/l501.html) to apply for a tax certificate separately.

For lines 6 to 9, use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject aircraft:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $100,000)

In the corresponding fields in lines 10 to 12, indicate the date tax became payable, the serial number and the luxury tax payable on improvements for each subject aircraft. For lines 10 to 12, use the following formula to calculate the luxury tax payable on improvements made to each subject aircraft:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $100,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject aircraft if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $100,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject aircraft.

### Notes

The luxury tax on improvements will typically only apply to improvements made to subject aircraft that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that **total at least $5,000** and that are made during the **improvement period** of the subject aircraft.

In circumstances where a sale or a purchase triggered the luxury tax on the subject aircraft, the improvement period begins on the day that an agreement for the sale/purchase is entered into and ends on the day that is one year after. If, during this time, the subject aircraft is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the subsequent sale is completed.

In all other circumstances, the improvement period of the subject aircraft begins on the day that the luxury tax on the subject aircraft initially became payable and ends on the day that is one year after. If, during this time, the subject aircraft is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. On lines 10 to 12, you should report all amounts of luxury tax on improvements made to subject aircraft that are payable during the reporting period identified in Part C.

Add lines 6 to 12, including any luxury tax payable on subject aircraft listed on a separate sheet of paper, and enter the result on line 13. This is your total luxury tax payable in respect of subject aircraft priced or valued above the $100,000 threshold that must also be entered on line 23 in Part G of the return.

### Part F – Luxury tax payable on subject vessels

Report the luxury tax payable on subject vessels priced or valued above the $250,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the tables, refer to [LTN3, Subject Vessels Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn3.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 14 to 17, indicate the type of transaction, the date tax became payable, the hull identification number and the luxury tax payable for each subject vessel. Each type of transaction has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. On the return, you can also apply for a tax certificate for a each subject vessel by ticking the corresponding box. Otherwise, you can use [Form L501, Tax Certificate Application](/en/revenue-agency/services/forms-publications/forms/l501.html) to apply for a tax certificate separately.

For lines 14 to 17 use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject vessel:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $250,000)

In the corresponding fields in lines 18 to 20, indicate the date tax became payable, the hull identification number and the luxury tax payable on improvements for each subject vessel. For lines 18 to 20, use the following formula to calculate the luxury tax payable on improvements made to each subject vessel:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $250,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject vessel if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $250,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject vessel.

### Notes

The luxury tax on improvements will typically only apply to improvements made to subject vessels that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that total **at least $5,000** and that are made during the **improvement period** of the subject vessel.

In circumstances where a sale or a purchase triggered the luxury tax on the subject vessel, the improvement period begins on the day that an agreement for the sale/purchase is entered into and ends on the day that is one year after. If, during this time, the subject vessel is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the subsequent sale is completed.

In all other circumstances, the improvement period of the subject vessel begins on the day that the luxury tax on the subject vessel initially became payable and ends on the day that is one year after. If, during this time, the subject vessel is subsequently sold to another person dealing at arm’s length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. On lines 18 to 20, you should report all amounts of luxury tax on improvements made to subject vessel that are payable during the reporting period identified in Part C.

Add lines 14 to 20, including any luxury tax payable on subject vessels listed on a separate sheet of paper, and enter the result on line 21. This is your total luxury tax payable in respect of subject vessels priced or valued above the $250,000 threshold that must also be entered on line 24 in Part G of the return.

### Part G – Total luxury tax payable

Calculate your total amount of luxury tax payable in this part.

Luxury tax payable in respect of subject vehicles, subject aircraft and subject vessels determined in Parts D, E and F are carried forward here on lines 22, 23 and 24, respectively.

Indicate the sum of lines 22 to 24 on line 25, which is your total amount of luxury tax payable.

Tick the appropriate box to indicate your intention with respect to making the payment for your luxury tax payable.

### Part H– Information return on subject vehicles

Fill out this part if you completed a sale of, or imported, a subject vehicle during the reporting period, the taxable amount of the subject vehicle is above the $100,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed or at the time of importation.

Indicate the circumstance relating to the sale, the sale completion date or the importation date, the identification number and the taxable amount in the corresponding fields for each subject vehicle. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject vehicle and the date when ownership of the subject vehicle was transferred to the purchaser.

### Part I – Information return on subject aircraft

Fill out this part if you completed a sale of a subject aircraft during the reporting period, the taxable amount of the subject aircraft is above the $100,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed.

Indicate the circumstance relating to the sale, the sale completion date, the serial number and the taxable amount in the corresponding fields for each subject aircraft. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject aircraft and the date when ownership of the subject item was transferred to the purchaser.

### Part J – Information return on subject vessels

Fill out this part if you completed a sale of a subject vessel during the reporting period, the taxable amount of the subject vessel is above the $250,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed.

Indicate the circumstance relating to the sale, the sale completion date, the hull identification number and the taxable amount in the corresponding fields for each subject vessel. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject item and the date when ownership of the subject item was transferred to the purchaser.

## Filling out Part K – Certification

An authorized person must print their name and title, sign and date the return, and provide a current telephone number where they may be contacted about this luxury tax and information return. An authorized person is a person who has the authority to act on behalf of the legal entity or the individual

identified in Part B.

## Further information

For all **technical publications** related to the Select Luxury Items Tax Act, go to Luxury tax technical information.

For all **enquiries** about filing your return, call **1-866-330-3304**.

## Page details

Date modified:
:   2025-05-15
