3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Luxury tax registration

As part of the Government of Canada’s commitment toward a fairer tax system, Budget 2021 announced the introduction of a luxury tax on the sale or importation of select luxury items. The luxury tax applies to certain vehicles and aircraft priced above $100,000 and certain vessels priced above $250,000. The luxury tax comes into effect on **September 1, 2022**.

## On this page

* [Who must register under the Select Luxury Items Tax Act](#h-1)
* [When to register](#h-2)
* [How to register](#h-3)
* [After you submit your registration application](#h-4)

## Who must register under the Select Luxury Items Tax Act

Generally, you are required to register with the Canada Revenue Agency (CRA), under the Select Luxury Items Tax Act, if you are a:

* manufacturer
* wholesaler
* retailer
* importer

and in the course of your business activities you sell or import certain vehicles and aircraft priced over **$100,000** and certain vessels priced over **$250,000**.

To find out if you are required to register, see [Notice LTN1 – Registration Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn1.html).

## When to register

You are required to apply to register with the CRA as a registered vendor of vehicles, aircraft, vessels, or a combination, by the earlier of:

* the day of the first sale of a vehicle, aircraft, or vessel above the respective threshold
* the day of the first importation of a vehicle, aircraft, or vessel above the respective threshold

We invite you to register ahead of time to ensure you are prepared when the Select Luxury Items Tax Act comes into effect on September 1, 2022. Registering ahead of time ensures that you can obtain and hold tax-free inventory of vehicles, aircraft or vessels you are registering for.

## How to register

If you are a branch or division that shares a business number with your head office, only your head office should register for a Luxury Tax program account. If your head office wants your branch or division to submit Luxury Tax returns separately, they must fill out L500-2, Application or Revocation of the Authorization to File Separate Luxury Tax Returns for Branches and Divisions.

Use one of the options listed below. Registering using Business Registration Online is the fastest and easiest way to receive a registration confirmation letter from the CRA. If you complete your registration using one of the other options, it may take longer for the CRA to process your registration and issue your registration confirmation letter.

**Option 1 –** [Business Registration Online](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/bro-register.html)

This is the simplest way to complete your registration. You can also use this option if you don’t yet have a business number. Follow the directions to create your business number (if required), and to add the Luxury Tax program account to your existing or newly created business number, then select ‘confirm’.

**Option 2 –** [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html) **(MyBA)**

You must be registered for MyBA to submit a registration form. Once registered:

1. Sign into My Business Account
2. Complete form [L500, Luxury Tax Registration Application](/en/revenue-agency/services/forms-publications/forms/l500.html)
3. Use the “Submit documents” function to upload your completed form
4. Select the option to upload a document without a case or reference number
5. In the list of possible reasons for your submission, choose “Luxury Tax, Fuel Charge, Excise Duty, Excise Tax and ATSC”
6. Select, “Submit Luxury Tax registration forms or supporting document”
7. Choose and attach your saved form.

**Option 3– By postal mail**
Send your completed [L500 Luxury Tax Registration Application](/en/revenue-agency/services/forms-publications/forms/l500.html) to the appropriate address listed on the last page of the form.

**Additional forms you may need to fill out when registering**

If you would like to apply to keep books and records outside Canada, an authorization under subsection 88(3) of the Select Luxury Items Tax Act may be granted to maintain such records outside Canada. To request this authorization, you must fill out form [L500-1, Non-Resident – Records Kept Outside Canada](/en/revenue-agency/services/forms-publications/forms/l500-1.html). You can file this form electronically using the "Submit documents" service in [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html), or send the filled-out signed form to the appropriate address listed on the last page of the L500-1.

If you would like to apply to file separate returns for different branches or divisions of your business under subsection 73(1) of the Select Luxury Items Tax Act, you must fill out form [L500-2, Application or Revocation of the Authorization to File Separate Luxury Tax Returns for Branches and Divisions](/en/revenue-agency/services/forms-publications/forms/l500-2.html). You can file this form electronically using the "Submit documents" service in [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html), or send the filled-out signed form to the appropriate address listed on the last page of the L500-2.

## After you submit your registration application

When your registration application is processed, the CRA will inform you of your registration number and effective date of registration. You may also sign in to [My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html) to view your registration information. This will allow you to view your registration confirmation letter.

Your registration could be delayed if there is missing or incomplete information.

If more than 30 days have passed since you submitted your registration application, you can call **1‑877‑432‑5472** to inquire about the status of your application.

If you are unsure if you need to register, call **1-866-330-3304**.

## Page details

Date modified:
:   2023-06-27
