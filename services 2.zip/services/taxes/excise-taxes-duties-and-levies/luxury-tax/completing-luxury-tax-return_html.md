3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Completing a Luxury Tax and Information Return for Registrants (Form B500)

## On this page

* [Overview](#h_0)
* [Filling out Parts A, B and C](#h_1)
* [Filling out Parts D to K](#h_2)
* [Filling out Part L – Certification](#h_3)
* [Further information](#h_4)

## Overview

This page provides line-by-line instructions on how to fill out [Form B500, Luxury Tax and Information Return for Registrants](/en/revenue-agency/services/forms-publications/forms/b500.html), which must be filed for every reporting period by registered vendors under the Select Luxury Items Tax Act.

You must complete all of the relevant parts of the return that apply to your situation:

* If you are a registered vendor of subject vehicles, you should fill out Parts A to D, H, I (if applicable) and L
* If you are a registered vendor of subject aircraft, you should fill out Parts A to C, E, H, J (if applicable) and L
* If you are a registered vendor of subject vessels, you should fill out Parts A to C, F, H, K (if applicable) and L
* If you would like to claim a rebate to be applied against your net tax payable, you should fill out Part G

If you need more space to provide information for any parts of the return, attach a separate sheet of paper to the return.

## Filling out Parts A, B and C

### Part A – Type of return

If you are filing a return for a reporting period for which you have already submitted a return, tick "Amended"; otherwise, tick "Original".

### Part B – Business information

Provide the legal name and the account number for which the return is being filed. If the name of the business has changed, contact your Canada Revenue Agency (CRA) regional excise office to report the change. A list of the offices is available at [Contact Information – Excise and Speciality Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts.html).

### Part C – Reporting period

Indicate the start date and end date of the reporting period covered by the return. A reporting period is generally a calendar quarter.

If you are filing the final return for the account identified in Part B and have canceled your registration, tick "Final return" and enter the beginning of the reporting period as the start date and the effective date of cancellation as the end date. You can also make a request to cancel your registration by ticking "Final return" and entering the beginning of the reporting period as the start date and the date of dissolution, date of amalgamation or date that you ceased activities as the end date.

If the return does not cover a full reporting period because you became a registrant during a reporting period, enter the effective date of registration as the start date and the end of the reporting period as the end date.

## Filling out Parts D to K

Refer to the chart at the top of Page 2 of the return to determine which parts of the return to fill out.

### Part D – Luxury tax payable on subject vehicles

Report the luxury tax payable on subject vehicles priced or valued above the $100,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the table, refer to [LTN2, Subject Vehicles Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn2.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 1 to 5, enter the number of subject vehicles where luxury tax is payable and the amount of luxury tax payable during the reporting period for each of the listed circumstances.

For lines 1 to 3 and 5, use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject vehicle:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $100,000)

For line 4, use the following formula to calculate the luxury tax payable on improvements made to each subject vehicle:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $100,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject vehicle if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $100,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject vehicle.

##### Notes

The luxury tax on improvements will typically only apply to improvements made to subject vehicles that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that **total at least $5,000** and that are made during the **improvement period** of the subject vehicle.

For the purposes of Form B500, the improvement period of the subject vehicle begins on the day that the luxury tax on the subject vehicle initially became payable and ends on the day that is one year after. If, during this time, the subject vehicle is subsequently sold to another person dealing at arm's length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. On line 4, you should report the total of all amounts of luxury tax on improvements made to subject vehicles that is payable during the reporting period identified in Part C.

Add lines 1 to 5 and enter the result on line 6. This is the total luxury tax payable in respect of subject vehicles priced or valued above the $100,000 threshold and must also be entered on line 28 in Part H of the return.

### Part E – Luxury tax payable on subject aircraft

Report the luxury tax payable on subject aircraft priced or valued above the $100,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the tables, refer to [LTN4, Subject Aircraft Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn4.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 7 to 10, indicate the type of transaction, the date tax became payable, the serial number and the luxury tax payable for each subject aircraft. Each type of transaction has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. On the return, you can also apply for a tax certificate for each subject aircraft by ticking the corresponding box. Otherwise, you can use [Form L501, Tax Certificate Application](/en/revenue-agency/services/forms-publications/forms/l501.html) to apply for a tax certificate separately.

For lines 7 to 10, use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject aircraft:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $100,000)

In the corresponding fields in lines 11 to 13, indicate the date tax became payable, the serial number and the luxury tax payable on improvements for each subject aircraft. For lines 11 to 13, use the following formula to calculate the luxury tax payable on improvements made to each subject aircraft:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $100,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject aircraft if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $100,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject aircraft.

##### Notes

The luxury tax on improvements will typically only apply to improvements made to subject aircraft that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that **total at least $5,000** and that are made during the **improvement period** of the subject aircraft.

For the purposes of Form B500, the improvement period of the subject aircraft begins on the day that the luxury tax on the subject aircraft initially became payable and ends on the day that is one year after. If, during this time, the subject aircraft is subsequently sold to another person dealing at arm's length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. On lines 11 to 13, you should report all amounts of luxury tax on improvements made to subject aircraft that are payable during the reporting period identified in Part C.

Add lines 7 to 13, including any luxury tax payable on subject aircraft listed on a separate sheet of paper, and enter the result on line 14. This is your total luxury tax payable in respect of subject aircraft priced or valued above the $100,000 threshold that must also be entered on line 29 in Part H of the return.

### Part F – Luxury tax payable on subject vessels

Report the luxury tax payable on subject vessels priced or valued above the $250,000 threshold in this part.

For more information on when and how to calculate the luxury tax payable that must be reported on each line of the tables, refer to [LTN3, Subject Vessels Under the Select Luxury Items Tax Act](/en/revenue-agency/services/forms-publications/publications/ltn3.html) and the [Consideration and retail value](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/consideration-retail-value.html) web page.

In the corresponding fields in lines 15 to 18, indicate the type of transaction, the date tax became payable, the hull identification number and the luxury tax payable for each subject vessel. Each type of transaction has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. On the return, you can also apply for a tax certificate for a each subject vessel by ticking the corresponding box. Otherwise, you can use [Form L501, Tax Certificate Application](/en/revenue-agency/services/forms-publications/forms/l501.html) to apply for a tax certificate separately.

For lines 15 to 18 use the **lesser** of the following two amounts to calculate the luxury tax payable for each subject vessel:

1. 0.10 × taxable amount
2. 0.20 × (taxable amount - $250,000)

In the corresponding fields in lines 19 to 21, indicate the date tax became payable, the hull identification number and the luxury tax payable on improvements for each subject vessel. For lines 19 to 21, use the following formula to calculate the luxury tax payable on improvements made to each subject vessel:

**A - B**

**A** is the **lesser** of:

1. 0.10 × total taxable amount
2. 0.20 × (total taxable amount - $250,000)

The "total taxable amount" is the taxable amount that would have been used to calculate the luxury tax on the subject vessel if the value of consideration for the improvements had been initially included.

**B** is the **lesser** of:

1. 0.10 × unimproved taxable amount
2. 0.20 × (unimproved taxable amount - $250,000)

The "unimproved taxable amount" is equal to the taxable amount of the subject vessel.

##### Notes

The luxury tax on improvements will typically only apply to improvements made to subject vessels that were already subject to the luxury tax. The luxury tax on improvements will apply to improvements that **total at least $5,000** and that are made during the **improvement period** of the subject vessel.

For the purposes of Form B500, the improvement period of the subject vessel begins on the day that the luxury tax on the subject vessel initially became payable and ends on the day that is one year after. If, during this time, the subject vessel is subsequently sold to another person dealing at arm's length, then the improvement period ends on the day that the sale is completed.

The luxury tax on improvements is payable on the day that follows the end of the improvement period. On lines 19 to 21, you should report all amounts of luxury tax on improvements made to subject vessel that are payable during the reporting period identified in Part C.

Add lines 15 to 21, including any luxury tax payable on subject vessels listed on a separate sheet of paper, and enter the result on line 22. This is your total luxury tax payable in respect of subject vessels priced or valued above the $250,000 threshold that must also be entered on line 30 in Part H of the return.

### Part G – Rebates to net tax

Claim eligible rebates of luxury tax to be applied to your net tax payable in this part.

To claim a rebate of luxury tax on a subject item, you must request the rebate through a return with the CRA within **two years** after the end of the reporting period when the tax became payable on the subject item.

##### Notes

Currently, only rebates for exports of subject items may be claimed through the return.

If you sold a subject item to a purchaser and the purchaser exports the subject item at a later date, you are eligible to claim a rebate if all of the following conditions are met:

* You are a registered vendor of that type of subject item at the time the sale is completed
* The purchaser is not a registered vendor of that type of subject item at any time between when the sale of the subject item is completed and when the subject item is exported
* You are liable for the tax in respect of the sale of the subject item at the time the sale is completed and the tax is reported by you on the return for the reporting period that includes the day when the tax becomes payable
* The subject item is not used in Canada at any time before it is exported except to the extent reasonably necessary or incidental to its manufacture, offering for sale, transportation or exportation
* The subject item is not registered with the Government of Canada or a province before it is exported except if the registration is done solely for a purpose incidental to its manufacture, offering for sale, transportation or exportation
* The purchaser exports the subject item as soon after the sale is completed as is reasonable having regard to the circumstances surrounding the exportation, the sale and, if applicable, the normal business practice of the purchaser and vendor
* The purchaser provides you with, and you retain, evidence satisfactory to the CRA of the exportation of the subject item by the purchaser

In the corresponding fields in lines 23 to 26, enter the type of subject item, the type of rebate, the serial or identification number, the reporting period end and the rebate amount for each subject item where you are claiming a rebate to be applied to your net tax payable. Each type of subject item and each type of rebate have been attributed a number or letter in the first and second columns of the table. You can use the drop-down menu to indicate the appropriate letter and number.

The "reporting period end when tax became payable" is the end date of the reporting period that includes the date the sale of a subject item was completed. The amount of rebate that may be claimed is equal to the amount of the luxury tax that became payable by the vendor on the sale of the subject item.

Add lines 23 to 26, including any rebates listed on a separate sheet of paper, and enter the result on line 27. This is your total rebates being claimed to your net tax payable which must also be entered on line 32 in Part H of the return.

### Part H – Determination of net tax

Calculate your total net luxury tax in this part.

#### Total net tax

Luxury tax payable in respect of subject vehicles, subject aircraft and subject vessels determined in Parts D, E and F are carried forward here on lines 28, 29 and 30, respectively.

Indicate the sum of lines 28 to 30 on line 31, which is your total amount of luxury tax payable.

The total rebates to net tax entered on line 27 in Part G is carried forward on line 32.

Subtract line 32 from line 31 and enter the result, which is your total net tax, on line 33.

If line 33 is a positive amount, enter it on line 34. If line 33 is a negative amount, enter it on line 35. Enter ‘'0'' on line 33 for a reporting period resulting in no luxury tax payable.

For any tax payable, tick the appropriate box to indicate your intention with respect to making the payment.

#### Net tax rebate options

Tick the appropriate box to indicate how you want the CRA to process your net tax rebate.

You can only transfer a net tax rebate to be applied to an amount owing under another program belonging to the business identified in Part B of the return. If you would like to transfer funds to another program, provide the account number and the reporting period ending date. The ‘'reporting period ending date'' refers to the last day of the reporting period or fiscal period for that program.

### Part I – Information return on subject vehicles

You are **not** required to complete Part I, if you are a registered vendor of subject vehicles and you are not registered or required to be registered for any other type of subject item.

Otherwise, fill out this part if you completed a sale of a subject vehicle during the reporting period, the taxable amount of the subject vehicle is above the $100,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed.

Indicate the circumstance relating to the sale, the sale completion date, the vehicle identification number and the taxable amount in the corresponding fields for each subject vehicle. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject vehicle and the date when ownership of the subject vehicle was transferred to the purchaser.

### Part J – Information return on subject aircraft

Fill out this part if you completed a sale of a subject aircraft during the reporting period, the taxable amount of the subject aircraft is above the $100,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed.

Indicate the circumstance relating to the sale, the sale completion date, the serial number and the taxable amount in the corresponding fields for each subject aircraft. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the appropriate number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject aircraft and the date when ownership of the subject item was transferred to the purchaser.

### Part K – Information return on subject vessels

Fill out this part if you completed a sale of a subject vessel during the reporting period, the taxable amount of the subject vessel is above the $250,000 threshold and due to specific circumstances, you did not have to remit the luxury tax payable at the time the sale was completed.

Indicate the circumstance relating to the sale, the sale completion date, the hull identification number and the taxable amount in the corresponding fields for each subject vessel. Each circumstance has been attributed a number in the first column of the table. You can use the drop-down menu to indicate the number. The "sale completion date" is the earlier of the date when the purchaser took possession of the subject item and the date when ownership of the subject item was transferred to the purchaser.

## Filling out Part L – Certification

An authorized person must print their name and title, sign and date the return, and provide a current telephone number where they may be contacted about this luxury tax and information return. An authorized person is a person who has the authority to act on behalf of the legal entity identified in Part B.

## Further information

For all **technical publications** related to the Select Luxury Items Tax Act, go to [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html).

For all **enquiries** about filing your return, call **1-866-330-3304**.

## Page details

Date modified:
:   2022-12-23
