3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Luxury tax on after-sales improvements

The luxury tax applies to sales of certain vehicles and aircraft priced over $100,000 and certain vessels priced over $250,000 (the relevant price thresholds), which is generally calculated at the lesser of 10% of the sales price and 20% of the amount above the relevant price threshold.

The luxury tax also applies to after-sales upgrades, modifications and other improvements meeting certain conditions that are made to these vehicles, aircraft and vessels. If you purchase a vehicle, aircraft or vessel, and luxury tax applied to the luxury item at the time of sale, you may be required to pay the luxury tax on after‑sales improvements.

## On this page

* [Who must pay the luxury tax on after-sales improvements](#h_1)
* [When would the luxury tax on after-sales improvements apply](#h_2)
  + [What are improvements](#h_3)
  + [What is the improvement period of a luxury item](#h_4)
* [What is taxable](#h_5)
* [What is not taxable](#h_6)
* [How to calculate the luxury tax on after-sales improvements](#h_7)
* [How to report and remit the luxury tax on after-sales improvements](#h_8)
* [Example of luxury tax on after-sales improvements](#h_9)

## Who must pay the luxury tax on after-sales improvements

The purchaser of a luxury item is liable for paying any applicable luxury tax on after‑sales improvements made to the luxury item.

Generally, you are liable for the luxury tax on after-sales improvements made to the luxury item if you are a:

* consumer
* leasing or rental company
* charter or time-share provider

## When would the luxury tax on after-sales improvements apply

The luxury tax applies to after‑sales improvements if the following conditions are met:

* the **luxury tax applied to the luxury item** when the vendor sold the luxury item to the purchaser
* the price of after-sales improvements that are taxable totals **$5,000 or greater**
* the after-sales improvements are completed during the **improvement period** of the luxury item

### What are improvements

For the purposes of the luxury tax, **improvements** include:

* goods that are installed in or on, or are affixed to the luxury item
* services that are physically performed and that modify the luxury item

**After-sales improvements** refer to those improvements that are made to a luxury item after it is sold to a purchaser. Most after-sale upgrades and modifications are considered after‑sales improvements and could be subject to the luxury tax.

However, there are certain excluded improvements, which are goods and services that could meet the definition of “improvements” but are exempt from the luxury tax. Refer to the “[What is not taxable](#h_6)” section below.

### What is the improvement period of a luxury item

The improvement period of a luxury item begins on the day that an agreement for the sale of the luxury item is entered into and ends on the day that is one year after the sale is completed. If, during this time, the luxury item is subsequently sold to a person dealing at arm’s length, then the improvement period ends on the day that the subsequent sale is completed.

## What is taxable

The following are examples of after-sales improvements that could be subject to the luxury tax. The following is **not** an exhaustive list.

**Taxable after-sales improvements**

* Motor or engine upgrades
* Engine block heaters
* Remote starter and keyless entry systems
* On-board audio, entertainment, navigation, communication and lighting systems
* On-board solar panel systems
* Heating and air conditioning systems
* Roof racks and rails
* Trailers affixed to vessels or aircraft
* All-season, winter and performance tires that are installed by a service provider
* Exterior upgrades including cosmetic and equipment upgrades (e.g. body kits, spoilers, docking and anchoring equipment, etc.)
* Interior upgrades including upgrades to upholsteries and cabins
* Upholstery treatments
* Exterior paints, vinyl wraps and window tints
* Protective films and coatings
* Undercoating and rustproofing
* Etchings, immobilizers and other anti-theft systems

## What is not taxable

The following are examples of goods and services that are not subject to the luxury tax on after-sales improvements. The following are **not** exhaustive lists.

**Excluded improvements**

The following are goods and services that could meet the definition of “improvements” but are specifically exempt from the luxury tax.

* Repair services
* Cleaning services
* Maintenance services
* Replacement parts for damaged, defective or non-functioning parts
* Child car seats, tether anchors, and other goods and services relating to child safety seating systems or child safety restraint systems for vehicles
* Trailers and campers for vehicles
* Wheelchair lifts, transfer seats, wheelchair securement systems, and other goods and services that specifically equip or adapt vehicles for their use by or in transporting individuals using a wheelchair
* Hand controls, steering aids, extension controls, and other goods and services that equip or adapt vehicles with auxiliary driving controls to facilitate their operation by individuals with a disability

**Not considered after-sales improvements**

The following are not considered after-sales improvements as they do not meet the definition of “improvements”.

* Software updates that are performed remotely
* Paid subscription services that do not modify luxury items including navigation, media and internet subscription services
* Extended warranties
* Insurance products
* Appraisal services
* Inspection services
* Marine survey services

## How to calculate the luxury tax on after-sales improvements

The luxury tax on after-sales improvements is equal to the difference between:

* **A.** The amount of luxury tax that would have been payable if the total sales price of the luxury item initially included the price of the after-sales improvements that are taxable
* **B.** The amount of luxury tax that was actually payable on the luxury item (without taking the price of the improvements into consideration)

The formula for calculating the luxury tax on after-sales improvements is as follows:

**A - B**

Where **A** is the lesser of:

* 10% × total taxable amount
* 20% x (total taxable amount - relevant price threshold)

The "total taxable amount" is equal to the sum of the initial price of the luxury item and the price of the taxable after-sales improvements.

Where **B** is the lesser of:

* 10% × unimproved taxable amount
* 20% × (unimproved taxable amount - relevant price threshold)

The “unimproved taxable amount” is equal to the initial price of the luxury item.

## How to report and remit the luxury tax on after-sales improvements

If you are liable for the luxury tax on after-sales improvements, you must report the tax to the CRA using [Form B501, Luxury Tax and Information Return for Non‑Registrants](/en/revenue-agency/services/forms-publications/forms/b501.html). The luxury tax on improvements is payable on the day that follows the improvement period. You must file Form B501 with the CRA for the reporting period where you have luxury tax payable.

A reporting period is generally a calendar quarter. The return must be filed with the CRA by the end of the month that follows the end of the reporting period. Payment of luxury tax owing for that reporting period is also due at this time.

### Notes

Effective 2023, the reporting periods and filing/payment deadlines are as follows:

**Reporting period**

January 1 to March 31
April 1 to June 30
July 1 to September 30
October 1 to December 31

**Filing/payment deadline**

April 30
July 31
October 31
January 31

For line-by-line instructions on how to fill out Form B501, visit the [Completing a Luxury Tax and Information Return for Non‑Registrants](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/completing-luxury-tax-return-for-non-registrants.html) web page.

For information on how remit the luxury tax to the CRA, visit the [Pay (remit) the luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/pay-luxury-tax.html) web page.

## Example of luxury tax on after-sales improvements

On February 1, 2023, a consumer enters into a sales agreement with a dealership and purchases a subject vehicle for $150,000. The sale is completed on that date. The unimproved taxable amount is $150,000 and the relevant price threshold is $100,000.

The luxury tax on the subject vehicle at the time of sale (**B**) is calculated as follows4.

luxury tax on subject vehicle at time of sale

|  |  |
| --- | --- |
| Unimproved taxable amount | $150,000 |
|  |  |
| **B** is the lesser of: |  |
| * 10% × $150,000 | $15,000 |
| * 20% × ($150,000 - $100,000) | $10,000 |
|  |  |
| **Luxury tax payable on the subject vehicle (B)** | **$10,000** |

The improvement period of the subject vehicle is February 1, 2023 to February 1, 2024.

On March 3, 2023, the consumer pays a service provider to perform window tinting and vehicle wrapping services for $600 and $3,000, respectively.

On April 18, 2023, the consumer pays another service provider to install a remote starter for $500, a 360-degree camera system for $800 and underbody glow lights for $700. On August 4, 2023, the consumer pays the same service provider to lower the vehicle by lowering the suspensions for $2,000.

On August 11, 2023, the consumer pays a third service provider to conduct a safety inspection on the subject vehicle for $300.

The price of the taxable after-sales improvements completed during the improvement period is $7,600, as illustrated below:

Taxable after sale improvements

|  |  |
| --- | --- |
| **After-sales goods and services** |  |
| Window tinting | $600 |
| Vehicle wrapping | +$3,000 |
| Remote starter | +$500 |
| 360-degree camera system | +$800 |
| Underbody glow lights | +$700 |
| Lowering vehicle | +$2,000 |
| Safety inspection | Not taxable |
|  |  |
| **Price of taxable after-sales improvements** | **$7,600** |

The amount of luxury tax that would have been payable if the total sales price of the subject vehicle initially included the price of the taxable after-sales improvements (**A**) is $11,520, as illustrated below:

luxury tax that would have been payable if the total sales price of the subject vehicle initially included the price of the taxable after-sales improvements

|  |  |
| --- | --- |
| Initial price of subject vehicle | $150,000 |
| Price of taxable after-sales improvements | +$7,600 |
| **Total taxable amount** | **$157,600** |
|  |  |
| **A** is the lesser of: |  |
| * 10% × $157,600 | $15,760 |
| * 20% x ($157,600 - $100,000) | $11,520 |
| **Luxury tax that would have been payable on total price (A)** | **$11,520** |

Using the formula **A - B**, the luxury tax on after-sales improvements is calculated as follows:

the formula A - B, the luxury tax on after-sales improvements is calculated as

|  |  |
| --- | --- |
| Luxury tax that would have been payable on total price (**A**) | $11,520 |
| Luxury tax payable on the subject vehicle (**B**) | - $10,000 |
| **Luxury tax on after-sales improvements** | **$1,520** |

Therefore, the luxury tax on after-sales improvements is $1,520. The luxury tax is payable on February 2, 2024. The consumer must file Form B501 for the January 1, 2024 to March 31, 2024 reporting period. The consumer must report and remit the $1,520 in luxury tax to the CRA by April 30, 2024.

## Page details

Date modified:
:   2023-05-30
