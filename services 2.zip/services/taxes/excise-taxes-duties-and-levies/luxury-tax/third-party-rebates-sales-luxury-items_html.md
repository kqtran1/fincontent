3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Luxury tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

# Third-Party Rebates on Sales of Luxury Items

## On this page

* [Overview](#toc0)
* [Third-Party Rebates](#toc1)
  + [Mail-in Rebates](#toc2)
  + [Point-of-Sale Rebates](#toc3)
* [Treatment of the taxable amount when a third-party makes a rebate payment](#toc4)
* [Example of a Mail-in Rebate](#toc5)
  + [Purchased Subject Vehicle](#toc6)
* [Example of a Rebate at the Point-of-Sale](#toc7)
  + [Purchased Subject Vehicle](#toc8)

## Overview

The luxury tax applies to sales of certain vehicles and aircraft priced over $100,000 and certain vessels priced over $250,000.

The vendor (usually a retailer) is generally liable for the luxury tax payable on the sale of a luxury item.

The luxury tax is calculated using the **taxable amount** of the luxury item. The **taxable amount** is the **value of consideration** for the sale of the subject item expressed in money and the fair market value of the consideration other than money at the time at which the sale is completed. It is the amount that the retailer is legally entitled to be paid by the consumer.

For more information on the application of the luxury tax, go to [Luxury tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax/technical-information.html).

## Third-Party Rebates

Third-party rebates are financial incentives provided by suppliers (such as manufacturers) to consumers to encourage the purchase of their products. Rebates are generally in the form of cash rebates or reductions to the selling price.

There are generally two ways third-party rebates are applied:

### Mail-in Rebates

Manufacturers may include a rebate application with the goods they sell. After buying the item from the retailer, the consumer fills out the application and mails it directly to the manufacturer.

### Point-of-Sale Rebates

Manufacturers may also give rebates to their consumers through the retailer when buying goods. The manufacturer pays the amount of the rebate to the retailer, who then transfers the rebate to the consumer by reducing the retail price of the good at the time of sale.

## Treatment of the taxable amount when a third-party makes a rebate payment

The payment of a rebate by a third-party to the consumer does not reduce the **value of consideration** received by the vendor. In other words, the **taxable amount** does not change as a result of this payment.

The payment of the rebate is a separate transaction from the sale, involving a third-party and the consumer and not involving the vendor (otherwise than as facilitator of the rebate at the point-of-sale).

## Example of a Mail-in Rebate

### Purchased Subject Vehicle

Initial Price from Retailer

**$115,000**

Less:

Discount (price adjustment)

($10,000)

Add:

Truck liner

$500

Running boards

$750

Trailer hitch

$450

Vinyl wrap

$4,000

Taxable Amount

**$110,700**

(the value of consideration received by the retailer is $110,700)

Luxury Tax amount (lesser of 10% of $110,700 and 20% of $110,700 less $100,000)

**$2,140**

Sub-Total

$112,840

GST

$5,642

Total

**$118,482**

(the purchaser pays the retailer the total amount of $118,482)

Less:

Manufacturer’s Rebate (the purchaser completes and submits a mail-in rebate application form and receives payment by mail)

($2,000)

Final cost to Purchaser

**$116,482**

(the value of consideration is $110,700: the payment of the manufacturer’s rebate paid to the purchaser has no impact on the consideration received by the retailer)

## Example of a Rebate at the Point-of-Sale

### Purchased Subject Vehicle

Initial Price from Retailer

**$140,000**

Less:

Discount (price adjustment)

($5,000)

Add:

Floor mats

$100

Upgraded audio system

$4,000

Freight/Pre-delivery Inspection

$2,000

Taxable Amount

**$141,100**

(the value of consideration received by the retailer is $141,100)

Luxury Tax amount (lesser of 10% of $141,100 and 20% of $141,100 less $100,000)

**$8,220**

Sub-Total

$149,320

GST

$7,466

Total

**$156,786**

Less:

Manufacturer’s Rebate (the purchaser is eligible for a manufacturer’s rebate and assigns the application for the rebate over to the retailer. The retailer, in turn, reduces the final cost to the purchaser by the amount of the rebate and receives the payment from the manufacturer)

($2,000)

Final cost to Purchaser

**$154,786**

(the value of consideration received by the retailer is $141,100: $139,100 in money and $2,000 in the assignment of the manufacturer’s rebate)

## Page details

Date modified:
:   2025-05-27
