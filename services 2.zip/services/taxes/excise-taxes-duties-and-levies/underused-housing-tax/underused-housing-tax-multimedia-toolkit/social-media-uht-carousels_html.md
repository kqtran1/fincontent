3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Underused Housing Tax (UHT) multimedia toolkit](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-multimedia-toolkit.html)

# Social media - Carousels - Underused Housing Tax (UHT)

![](/content/dam/cra-arc/ht-thmb-sclmd-1-e.jpg)

Complement your social media platform and choose from a selection visuals to download.

## Carousel: Will the federal UHT affect you?

Carousel text: Will the federal UHT affect you?

Carousel text:

> Will the federal Underused Housing Tax (UHT) affect you?
>
> The UHT is an annual 1% tax on the ownership of vacant or underused housing in Canada.
>
> You may need to pay the UHT even when exempt from other municipal or provincial vacancy taxes.
>
> Unsure if you need to pay? The CRA’s self-assessment tool can help.
>
> Visit canada.ca/cra-uht

Download links: Will the federal UHT affect you?

### English carousel

* [Download English 1080 pixels x 1080 pixels image (ZIP, 1.2 MB)](/content/dam/cra-arc/cra_uht_carousel_v1_1080x1080_eng.zip)

### French carousel

* [Download French 1080 pixels x 1080 pixels image (ZIP, 1.2 MB)](/content/dam/cra-arc/cra_uht_carousel_v1_1080x1080_fra.zip)

## Carousel: Have you heard about Canada’s UHT?

Carousel text: Have you heard about Canada’s UHT?

Carousel text:

> Have you heard about Canada’s Underused Housing Tax (UHT)?
>
> You may need to file a UHT return and pay the tax.
>
> Learn who the UHT affects, how to file a UHT return, and when to pay the tax.
>
> canada.ca/cra-uht

Download links: Have you heard about Canada’s UHT?

### English carousel

* [Download English 1080 pixels x 1080 pixels image (ZIP, 977 KB)](/content/dam/cra-arc/cra_uht_carousel_v2_1080x1080_eng.zip)

### French carousel

* [Download French 1080 pixels x 1080 pixels image (ZIP, 1,002 KB)](/content/dam/cra-arc/cra_uht_carousel_v2_1080x1080_fra.zip)

## Carousel: Do you own residential property in Canada?

Carousel text: Do you own residential property in Canada?

Carousel text:

> Do you own residential property in Canada?
>
> The Underused Housing Tax (UHT) may affect you.
>
> Unsure if you need to file? The CRA’s self-assessment tool can help.
>
> canada.ca/cra-uht

Download links: Do you own residential property in Canada?

### English carousel

* [Download English 1080 pixels x 1080 pixels image (ZIP, 1.1 MB)](/content/dam/cra-arc/cra_uht_carousel_v3_1080x1080_eng.zip)

### French carousel

* [Download French 1080 pixels x 1080 pixels image (ZIP, 1.2 MB)](/content/dam/cra-arc/cra_uht_carousel_v3_1080x1080_fra.zip)

## Page details

Date modified:
:   2025-02-18
