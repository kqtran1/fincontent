3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Underused Housing Tax (UHT) multimedia toolkit](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-multimedia-toolkit.html)

# Will the new Underused Housing Tax (UHT) affect you?

[![

](/content/dam/cra-arc/uht-thmb-vd-30-e.jpg)](https://www.youtube.com/watch?v=g9CinXC8dp8)

## Transcript

Will the new Underused Housing Tax (UHT) affect you?

The UHT is an annual federal 1% tax

It applies to the ownership of vacant or underused housing in Canada

You may be required to pay the UHT even if you’re exempt from municipal or provincial vacancy taxes

Use our interactive tool to learn if the tax applies to you

If you’re affected, file the UHT return by April 30

The CRA must receive payment by April 30 unless you are exempt

Visit [canada.ca/cra-uht](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html?utm_campaign=not-applicable&utm_medium=vanity-url&utm_source=canada-ca_cra-uht)

## Page details

Date modified:
:   2025-07-09
