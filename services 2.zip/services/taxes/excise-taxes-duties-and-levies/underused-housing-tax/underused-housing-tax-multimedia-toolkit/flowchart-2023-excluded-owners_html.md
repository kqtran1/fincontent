3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Underused Housing Tax (UHT) multimedia toolkit](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-multimedia-toolkit.html)

# Flowchart: 2023 Excluded Owners

![Flowchart: Flowchart 2023 Excluded Owners (Refer to flowchart description)](/content/dam/cra-arc/cra_uht_flowchart_2023_e.jpg)

[Open flowchart (PDF)](/content/dam/cra-arc/cra_uht_flowchart_2023_e.pdf)

PDF, 154 KB, 1 page

Flowchart description

The flowchart asks you yes or no questions.

## Question 1: Are you an owner of the residential property as a partner of a partnership?

If your answer is “Yes”:

* go to question 2

If your answer is “No”:

* go to question 3

## Question 2: Is the partnership a specified Canadian partnership?

If your answer is “Yes”:

* You are an excluded owner

If your answer is “No”:

* You are an affected owner

## Question 3: Are you an owner of the residential property as a trustee of a trust?

If your answer is “Yes”:

* go to question 4

If your answer is “No”:

* go to question 6

## Question 4: Is the trust a specified Canadian trust?

If your answer is “Yes”:

* You are an excluded owner

If your answer is “No”:

* go to question 5

## Question 5: Is the trust any of the following trusts under the ITA:

* a mutual fund trust
* a real estate investment trust
* a SIFT trust?

If your answer is “Yes”:

* You are an excluded owner

If your answer is “No”:

* You are an affected owner

## Question 6: Are you an owner of the residential property in a capacity other than as a partner or trustee?

If your answer is “Yes”:

* go to question 7

If your answer is “No”:

* If you are not an owner of a residential property, generally you do not have any UHT obligation. (The word "generally" is added as a person who is not an owner may have obligations under Part 5 of the UHTA.) If you are an owner of a residential property, please go back and choose the appropriate answer.

## Question 7: Are you any of the following…

* a specified Canadian corporation
* a citizen or permanent resident of Canada (including a personal representative of a deceased individual)
* a Canadian corporation whose shares are listed on a Canadian stock exchange designated under the ITA
* the Government of Canada (or an agent of)
* a Government of a province (or an agent of)
* an Indigenous governing body under the DISA
* a registered charity under the ITA
* any of the following under the ETA:
  + a cooperative housing corporation
  + a hospital authority
  + a municipality
  + a para-municipal organization
  + a public college
  + a school authority
  + a university?

If your answer is “Yes”:

* You are an excluded owner

If your answer is “No”:

* go to question 8

## Question 8: Are you a Canadian corporation and is at least 90% of your corporation’s shares owned or controlled by one of the following:

* a mutual fund trust under the ITA
* a real estate investment trust under the ITA
* a SIFT trust under the ITA
* a Canadian corporation whose shares are listed on a Canadian stock exchange designated under the ITA?

If your answer is “Yes”:

* You are an excluded owner

If your answer is “No”:

* You are an affected owner

Excluded owners have no obligations under the Underused Housing Tax Act. Affected owners must file a UHT return and pay the tax unless an exemption applies. To learn more about the UHT and exemptions, visit [canada.ca/cra-uht](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html).

* **DISA** = Department of Indigenous Services Act
* **ETA** = Excise Tax Act
* **ITA** = Income Tax Act
* **SIFT** = specified investment flow-through

## Other languages

* [French (PDF, 151 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_f.pdf)
* [Chinese (Traditional) - 中文 (繁體) (PDF, 190 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_tc.pdf)
* [Chinese (Simplified) - 中文 (简体) (PDF, 316 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_sc.pdf)
* [Hindi - हिंदी (PDF, 81 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_hi.pdf)
* [Tagalog (PDF, 153 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_tl.pdf)
* [Punjabi - ਪੰਜਾਬੀ (PDF, 183 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_pa.pdf)
* [Urdu - اُردُو (PDF, 133 KB)](/content/dam/cra-arc/cra_uht_flowchart_2023_e_ur.pdf)

## Page details

Date modified:
:   2024-12-31
