3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Determine your responsibilities

Understand if you need to file a return, and if you may qualify for an exemption from paying the tax.

### [Determine if you are an affected or excluded residential property owner](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)

Interactive tool to help you decide if you need to file returns for the 2022 calendar year or the 2023 and onward calendar years

### [Determine if you qualify for an exemption from paying the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html)

If you’re an affected owner, find out if you have to pay the tax for the 2022 calendar year or the 2023 and onward calendar years

## Page details

Date modified:
:   2025-06-09
