3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# When to file the return and pay the tax

The due date to file your return, make any elections, and pay amounts you owe for a calendar year is:

* **April 30 of the following calendar year.**

When the due date for a return falls on a Saturday, Sunday or a public holiday recognized by the Canada Revenue Agency (CRA), your return is on time if the CRA receives it, or if it is postmarked, on or before the next business day.

## Penalties and interest for failing to file the return on time

There are penalties if we do not receive your return when it is due.

Caption text

| Type of affected owner | Minimum penalty |
| --- | --- |
| Individual | $1,000 |
| Corporation | $2,000 |

You will also have to pay interest if we do not receive the amounts you owe (tax payable) when they are is due.

For more details, refer to:

* [Prescribed interest rates](/en/revenue-agency/services/tax/prescribed-interest-rates.html)

### Certain exemptions non-applicable for the penalty calculation

If you do not file your return by December 31 of the following calendar year, and you are an affected owner who claims certain exemptions, there is an adjustment to the penalty calculation that could result in higher penalties.

Review tax notices:

* [UHTN3, Failure to file your return by December 31 of the following calendar year](/en/revenue-agency/services/forms-publications/publications/uhtn3/filing-return-paying-underused-housing-tax.html#_Toc121913353)

### Section navigation

* [Next: How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)

## Page details

Date modified:
:   2025-06-09
