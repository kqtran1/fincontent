3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Amend your return

Wait until you receive your notice of assessment before amending your return.

Amending your return allows you to make changes to sections including:

* Part 1 – Information about the owner
* Part 2 – Information about your residential property in Canada
* Part 3 – Multiple residential properties
* Part 4 – Exemption for primary place of residence
* Part 5 – Exemption for qualifying occupancy
* Part 6 – Other exemptions

You **cannot revise** your elections in Sections 2 and 3 of Part 3 and in Part 7:

* Part 3 – Multiple residential properties
  + Section 2 – Election to designate a residential property
  + Section 3 – Joint election to designate a residential property
* Part 7 – Fair market value (FMV) election

After you have requested an amendment to your return, only provide supporting documents when the CRA asks for them and send them using the method requested in the letter from CRA.

You can amend your return online, by mail, or by fax.

Online
:   **Individuals** or **corporations** can submit the amended return using the web version of the online form:

    [Online form for the Underused Housing Tax return](https://apps.cra-arc.gc.ca/ebci/sres/ext/pub/ntrUhtFlng?request_locale=en_CA)

    * Read through initial information page and select "Next".
    * Select applicable account type and Digital Access Code or EFILE on-line number.
    * Select "Next".
    * Check "checkmark" box 010 – Amended.
    * Select the applicable year under 012 – Calendar Year.
    * Enter your Social insurance number, individual tax number, temporary tax number or business number (BN-RU).
    * Enter your Digital Access Code or EFILE number and password.
    * Select "Next".
    * You will then be brought to a list of returns that can be amended.
    * Select the return to amend by clicking on the applicable property address. Please note: If the property address of the return you are trying to amend is not listed, the initial return has not been assessed and is not available to amend.
    * You will then be brought to the information reported on the initial return. Review each page and make the applicable changes.
    * Once you have reviewed all pages and have made the necessary changes, select "Submit" to submit the amended return.
    * You will then receive a confirmation of receipt.

    **Canadian citizens and permanent residents** can complete and submit the return using one of CRA's secure portals.

    If you are filing as an **individual**

    [Sign
    in to My Account](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html) [Register for CRA My Account](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html)

    * Go to the left menu and select "Tax returns".
    * Go to the column on the right, scroll down and select "Underused housing tax." Scroll to the "Returns" section and select the "Amend" link beside the applicable tax year and property address of the return you are attempting to change. Please note: If the applicable tax year and property address is not in the list of available properties to amend, the initial return has not been assessed and is not available to amend. You will then be brought to the information reported on the initial return. Review each page and make the applicable changes.
    * Once you have reviewed all pages and have made the necessary changes, select "Submit" to submit the amended return. You will then receive a confirmation of receipt.

    If you are filing as a Canadian corporation

    [Sign in to My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html) [Register for My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html)

    * Go to the left menu, scroll down and select "Underused housing tax".
    * Select your RU number in the drop-down list.
    * Scroll to the "Returns" section and select the "Adjust" link beside the applicable tax year and property address of the return you are attempting to change. Please note: If the applicable tax year and property address is not in the list of available properties to adjust, the initial return has not been assessed and is not available to adjust. You will then be brought to the information reported on the initial return. Review each page and make the applicable changes.
    * Once you have reviewed all pages and have made the necessary changes, select "Submit" to submit the adjusted return. You will then receive a confirmation of receipt.

    If you are filing **for** an individual or Canadian corporation

    [Sign
    in to Represent a Client](/en/revenue-agency/services/e-services/represent-a-client.html)

    [Register - representatives in Canada](/en/revenue-agency/services/e-services/cra-login-services/register-cra-sign-in-services.html#hlp1e)

    [Register - non-resident representatives](/en/revenue-agency/services/e-services/cra-login-services/register-cra-sign-in-services.html#hlp1f)

    As an authorized representative, if you have access to an individual’s account or corporation’s account, use the following method:

    If you are representing an individual

    * Go to the left menu and select "Tax returns".
    * Go to the column on the right, scroll down and select "Underused housing tax." Scroll to the "Returns" section and select the "Amend" link beside the applicable tax year and property address of the return you are attempting to change. Please note: If the applicable tax year and property address is not in the list of available properties to amend, the initial return has not been assessed and is not available to amend.
    * You will then be brought to the information reported on the initial return. Review each page and make the applicable changes.
    * Once you have reviewed all pages and made the necessary changes, select "Submit" to submit the amended return. You will then receive a confirmation of receipt.

    If you are representing a Canadian corporation

    * Go to the left menu, scroll down and select "Underused housing tax".
    * Select your RU number in the drop-down list.
    * Scroll to the "Returns" section and select the "Adjust" link beside the applicable tax year and property address of the return you are attempting to change. Please note: If the applicable tax year and property address is not in the list of available properties to adjust, the initial return has not been assessed and is not available to adjust. You will then be brought to the information reported on the initial return. Review each page and make the applicable changes.
    * Once you have reviewed all pages and made the necessary changes, select "Submit" to submit the adjusted return. You will then receive a confirmation of receipt.

By mail or fax
:   **What form to use**

    * [UHT-2900, Underused Housing Tax Return and Election Form](/en/revenue-agency/services/forms-publications/forms/uht-2900.html)

    To amend your return by mail or fax, you will need to complete and sign a new return. Ensure you check "checkmark" the box beside 010 Amended at the beginning of the return and make the requested changes from the original filed return. The return needs to be completed in full, signed and dated before submitting to the CRA.

    Where to send the amended return depends on the location of either the individual or the corporation.

    Select the location where you reside, or where your corporation is physically located

    * Canada

      Choose a province or territory

      + [Alberta](#winnipeg_tc)
      + [British Columbia](#winnipeg_tc)
      + [Manitoba](#winnipeg_tc)
      + [New Brunswick](#sudbury_tc)
      + [Newfoundland and Labrador](#sudbury_tc)
      + [Nova Scotia](#sudbury_tc)
      + [Northwest Territories](#winnipeg_tc)
      + [Nunavut](#winnipeg_tc)
      + Ontario

        Choose a location within Ontario

        - [Barrie](#sudbury_tc)
        - [Sudbury](#sudbury_tc)
        - [Toronto](#sudbury_tc)
        - [Another location in Ontario](#winnipeg_tc)
      + [Prince Edward Island](#sudbury_tc)
      + [Quebec](#sudbury_tc)
      + [Saskatchewan](#winnipeg_tc)
      + [Yukon](#winnipeg_tc)
    * [Denmark](#winnipeg_tc)
    * [France](#winnipeg_tc)
    * [Netherlands](#winnipeg_tc)
    * [United Kingdom](#winnipeg_tc)
    * [United States of America](#winnipeg_tc)
    * [Another country](#sudbury_tc)

    ## Winnipeg Tax Centre

    Winnipeg Tax Centre
    Post Office Box 14001
    Station Main
    Winnipeg MB R3C 3M3
    Canada

    Fax: 204-984-5164

    ## Sudbury Tax Centre

    Sudbury Tax Centre
    1050 Notre Dame Avenue
    Sudbury ON P3A 5C2
    Canada

    Fax: 705-671-3994 or 1-855-276-1529

## When the amended return has been assessed

The CRA will send you one of the following:

* a notice of reassessment showing any changes to your return.
* a letter explaining why the CRA did not make the changes you requested or why no changes were needed.

## Document navigation

* [Next: Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

## Page details

Date modified:
:   2025-06-09
