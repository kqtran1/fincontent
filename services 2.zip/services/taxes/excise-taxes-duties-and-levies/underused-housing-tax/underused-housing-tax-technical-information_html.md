3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused housing tax technical information

The following are technical publications and other helpful information related to the underused housing tax.

For general enquiries about the underused housing tax, call the applicable telephone number:

* if you are calling about a residential property that is owned by an individual and you are calling from:
  + within Canada or the United States, call **1-800-959-8281**
  + outside Canada and the United States, call **613-940-8495** (collect calls accepted)
* if you are calling about a residential property that is owned by a corporation and you are calling from:
  + within Canada or the United States, call **1-800-959-5525**
  + outside Canada and the United States, call **613-940-8497** (collect calls accepted)

For more information on the underused housing tax, go to [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html).

## [Underused housing tax notices](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-technical-information/underused-housing-tax-notices.html)

Announcements about the Underused Housing Tax Act and CRA policies that affect the application and administration of the underused housing tax.

## [Underused housing tax forms](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-technical-information/underused-housing-tax-forms.html)

Forms required under the Underused Housing Tax Act.

## [Underused housing tax vacation property designation tool](https://apps.cra-arc.gc.ca/ebci/sres/ext/pub/ntrUhtExpnTl?request_locale=en_CA)

A tool designed to help individuals determine whether their residential property is located in an eligible area of Canada for the purposes of the vacation property exemption.

## [Underused Housing Tax Act and related regulations made under this Act](https://laws-lois.justice.gc.ca/eng/acts/U-0.5/index.html)

The Underused Housing Tax Act and related regulations (Department of Justice).

## Page details

Date modified:
:   2025-02-27
