3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Pay the tax

If you are an **affected owner**, and your ownership of the residential property **does not qualify for an exemption**, you must pay the underused housing tax for the calendar year by April 30 of the following year.

## How to pay

Individuals and corporations **must** pay all amounts owing in **Canadian dollars**.

Pay with one of the following methods:

* Online
* By wire transfer or internationally issued credit card
* By cheque

### Online

Individuals and corporations with a Canadian bank account, may pay using [My Payment](/en/revenue-agency/services/e-services/payment-save-time-pay-online.html).

If you are an individual

* Select "Pay now"
* Under Individuals, select “Individual income tax (T1)”
* Select “Underused Housing Tax”

If you are a corporation

* Select "Pay now"
* Under Businesses, select “Underused Housing Tax”
* Select either:
  + “Payment on filing” (to make your payment when filing your return)
  + “Amount owing” (to pay an amount owing from your notice of (re) assessment, statement, or letters issued by the CRA)

As a corporation, you may also pay using either of the following methods:

* [Online banking](/en/revenue-agency/services/about-canada-revenue-agency-cra/pay-online-banking.html)
* Online banking with your Canadian financial institution

### By wire transfer or internationally issued credit card

If you do not have a Canadian bank account or if you are a corporation without a Canadian bank account, pay using a wire transfer or an internationally issued credit card.

For more information, refer to: [Pay without a Canadian bank account](/en/revenue-agency/services/about-canada-revenue-agency-cra/pay-wire-transfer-non-residents.html).

### By cheque

Write your cheque with the following details:

Made out to
:   Receiver General for Canada

Memo field
:   * Calendar year for which you are paying
    * Your tax number
      + Individuals: SIN, ITN, or TTN
      + Corporations: CRA Underused Housing Tax business number (BN-RU)

Choose how you want to mail it:

* ### If you file a paper return

  + Mail your cheque with your return to your designated tax centre

  [Find your designated tax centre address](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html#bymail)

  If you already mailed your return, or have received a Notice of (re)assessment with an amount owing, you will need to mail your cheque separately to:

  Canada Revenue Agency
  PO Box 3800 STN A
  Sudbury ON P3A 0C3
* ### If you file online

  Mail your cheque separately to:

  Canada Revenue Agency
  PO Box 3800 STN A
  Sudbury ON P3A 0C3

### Section navigation

* [Next: Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)

## Page details

Date modified:
:   2025-06-09
