3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Contact us

Find out the best way to contact the CRA by answering a few questions based on your situation.

Make a selection and **scroll down** for further questions and results.

What are you contacting the CRA about?

* General enquiries about the Underused Housing Tax

  General enquiries can only be made by phone.

  Who is the property owner?

  + An individual

    Are you calling from either Canada or the United States?

    - Yes
    - No
  + A corporation

    Are you calling from either Canada or the United States?

    - Yes
    - No
* How to submit your Underused Housing Tax return (UHT-2900)

  How would you like to submit your return?

  + Online
  + By mail or fax
* How to file a Notice of Objection

## You can Call the CRA

Before you call
:   To confirm your identity, you’ll need your:

    * tax identifier number (SIN, ITN, or TTN)
    * full name and date of birth
    * complete address
    * assessed tax return, notice of assessment or reassessment, or other tax document, or be signed in to CRA My Account

    * business number with an RU account
    * business name
    * complete business address
    * assessed tax return, notice of assessment or reassessment, other tax document, or be signed in to CRA My Business Account

**Telephone number**
:   For those in Canada or the United States calling about electronic filing of UHT election form.

    1-800-387-0720 (opens up phone application)**1-800-387-0720**
:   For those outside of Canada or the United States calling about electronic filing of UHT election form.

    **1-613-221-3224 (collect calls accepted)**
:   For those individuals inside of Canada or the United States calling about a general enquiry.

    1-800-959-8281 (opens up phone application)**1-800-959-8281**
:   For those individuals outside of Canada or the United States calling about a general enquiry.

    **1-613-940-8495 (collect calls accepted)**
:   For those businesses inside of Canada or the United States calling about a general enquiry.

    1-800-959-5525 (opens up phone application)**1-800-959-5525**
:   For those businesses outside of Canada or the United States calling about a general enquiry.

    **1-613-940-8497 (collect calls accepted)**

**TTY number**
:   If you use a teletypewriter:
    1-800-665-0354 (opens up tty application)**1-800-665-0354**

    If you use an operator-assisted relay service, call:
    1-800-387-0720 (opens up phone application)**1-800-387-0720**

    If you use an operator-assisted relay service, call:
    **1-613-221-3224 (collect calls accepted)**

    If you use an operator-assisted relay service, call:
    1-800-959-8281 (opens up phone application)**1-800-959-8281**

    If you use an operator-assisted relay service, call:
    **1-613-940-8495 (collect calls accepted)**

    If you use an operator-assisted relay service, call:
    1-800-959-5525 (opens up phone application)**1-800-959-5525**

    If you use an operator-assisted relay service, call:
    **1-613-940-8497 (collect calls accepted)**

Hours
:   General enquiries for businesses hours

    | Date | Hours |
    | --- | --- |
    | Monday to Friday | 8:00 am to 8:00 pm ET |
    | Saturday and Sunday | Closed |

    Closed on [public holidays](/en/revenue-agency/services/tax/public-holidays.html)

## You can Mail your request to the CRA

Determine how to resolve your dispute

Should you file an objection or is there another way to resolve your dispute?

Find the option that is relevant to your situation: [Filing a notice of objection](/en/revenue-agency/services/about-canada-revenue-agency-cra/complaints-disputes/underused-housing-tax.html)

## You can Submit your return online

There are different options for submitting your return online.

**Find the option that is relevant to your situation:** [Filing online](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html#online)

## You can Mail or fax your return to a Tax Centre

You must mail or fax your return to the correct Tax Centre.

This depends on where the affected owner is located. This could be you, or it could be your corporation.

**Find the correct:** [Tax Centre mailing address or fax number](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html#bymail)

## Page details

Date modified:
:   2025-06-09
