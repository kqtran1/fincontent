3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Underused housing tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-technical-information.html)

# Underused housing tax forms

* [UHT0001 Notice of Objection - Underused Housing Tax Act](/en/revenue-agency/services/forms-publications/forms/uht0001.html)
* [UHT-2900 Underused Housing Tax Return and Election Form](/en/revenue-agency/services/forms-publications/forms/uht-2900.html)

## Page details

Date modified:
:   2023-09-28
