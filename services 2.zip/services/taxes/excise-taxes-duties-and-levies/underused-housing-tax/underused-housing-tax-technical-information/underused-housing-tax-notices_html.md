3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Underused housing tax technical information](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-technical-information.html)

# Underused housing tax notices

* [UHTN1, Introduction to the Underused Housing Tax](/en/revenue-agency/services/forms-publications/publications/uhtn1.html)
* [UHTN2, Calculating the Underused Housing Tax Payable](/en/revenue-agency/services/forms-publications/publications/uhtn2.html)
* [UHTN3, Filing a Return and Paying the Underused Housing Tax](/en/revenue-agency/services/forms-publications/publications/uhtn3.html)
* [UHTN4, Exemptions for Specified Canadian Partnerships, Trusts and Corporations](/en/revenue-agency/services/forms-publications/publications/uhtn4.html)
* [UHTN5, Exemption for vacation properties](/en/revenue-agency/services/forms-publications/publications/uhtn5.html)
* [UHTN6, Exemption for Primary Place of Residence](/en/revenue-agency/services/forms-publications/publications/uhtn6.html)
* [UHTN7, Exemption for Qualifying Occupancy](/en/revenue-agency/services/forms-publications/publications/uhtn7.html)
* [UHTN8, Special Rule and Elections for Individual Owners of Multiple Residential Properties](/en/revenue-agency/services/forms-publications/publications/uhtn8.html)
* [UHTN9, Exemptions for Residential Properties That Cannot be Used Year-round](/en/revenue-agency/services/forms-publications/publications/uhtn9.html)
* [UHTN10, Exemptions for Uninhabitable Residential Properties](/en/revenue-agency/services/forms-publications/publications/uhtn10.html)
* [UHTN11, Exemption for New Owners](/en/revenue-agency/services/forms-publications/publications/uhtn11.html)
* [UHTN12, Exemptions for Deceased Individuals and Their Personal Representatives or Co-owners](/en/revenue-agency/services/forms-publications/publications/uhtn12.html)
* [UHTN13, Exemptions for New Residential Properties](/en/revenue-agency/services/forms-publications/publications/uhtn13.html)
* [UHTN14, Exemption for Vacation Properties: Manual Place-search Instructions](/en/revenue-agency/services/forms-publications/publications/uhtn14.html)
* [UHTN15, Questions and Answers About the Underused Housing Tax](/en/revenue-agency/services/forms-publications/publications/uhtn15.html)
* [UHTN16, Proposed Amendments to the Underused Housing Tax](/en/revenue-agency/services/forms-publications/publications/uhtn16.html)

## Page details

Date modified:
:   2024-03-08
