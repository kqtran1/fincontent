3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)
5. [Determine your responsibilities – Underused Housing Tax (UHT)](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
  + [Determine if you are an affected or excluded residential property owner](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)
  + [Determine if you qualify for an exemption from paying the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Determine if you are an affected or excluded residential property owner

If you are an **affected owner** on December 31 you **must file** an Underused Housing Tax return for the calendar year.

Interactive questions

A [text](#text_version) version is available if needed.

### Find out which type of owner you are based on your situation

Each set of questions applies **separately** to:

* each owner of a residential property (if there is more than one owner)
* each residential property owned (if more than one property is owned)
* each capacity in which you are the owner of a residential property (if you are the owner of a residential property in more than one capacity).

The CRA does **not** collect or retain any of the information you enter on this page

### Choose the situation that applies to you on December 31

Make a selection and **scroll down** for further questions and results.

Which calendar year are you filing for?

* 2023 and subsequent calendar years

  Do you own the residential property as a partner of a partnership?

  What is a partnership?

  For UHT purposes, in all parts of Canada (other than Quebec), the CRA interprets the term partnership to mean the relationship that exists between persons carrying on a business in common with a view to profit.

  Partnerships constituted in Quebec

  For partnerships constituted in Quebec, the CRA interprets the term partnership based on the legal definition of contract of partnership in the Civil Code of Quebec:

  > “A contract of partnership is a contract by which the parties, in a spirit of cooperation, agree to carry on an activity, including the operation of an enterprise, to contribute thereto by combining property, knowledge or activities and to share among themselves any resulting pecuniary profits”

  The fact that two people own a property together does not, of itself, create a partnership.

  A familial relationship between two or more people who own a residential property does not, of itself, create a partnership, regardless of whether they are related by:

  + marriage
  + a common-law partnership (for example, two individuals who cohabit in a conjugal relationship throughout a continuous 12-month period)
  + a blood relationship (for example, a parent and a child; a brother and a sister)
  + adoption

  Review tax notice: [UHTN15, Questions about partnerships](/en/revenue-agency/services/forms-publications/publications/uhtn15/questions-answers-underused-housing-tax.html#_Toc130994813)

  + Yes

    Is the partnership a specified Canadian partnership?

    - Yes
    - No
  + No

    Do you own the residential property as a trustee of a trust?

    - Yes

      Is the trust any of the following:

      * A specified Canadian trust
      * A mutual fund trust for Canadian income tax purposes
      * A real estate investment trust for Canadian income tax purposes
      * A specified investment flow-through (SIFT) trust for Canadian income tax purposes

      * Yes
      * No
    - No

      Are you:

      Who is a foreign national?

      A foreign national is an individual who is **not** a citizen or permanent resident of Canada.

      * A citizen or permanent resident of Canada

        Which capacity do you own the residential property?

        + In your own right (as an individual)
        + As a representative of a deceased individual
        + I don't know
      * A foreign national
      * A corporation

        Is your corporation any of the following:

        + A registered charity for Canadian income tax purposes
        + A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority, or university for Canadian GST/HST purposes
        + An Indigenous governing body

        + Yes
        + No

          Is your corporation incorporated or continued in Canada?

          - Yes

            Does your corporation have share capital (that is, it has stock)?

            * Yes

              Does your corporation have shares listed on a Canadian stock exchange designated for Canadian income tax purposes?

              + Yes
              + No

                Is less than 10% of your corporation's shares owned or controlled (directly or indirectly) by any combination of foreign nationals and corporations that are incorporated or continued otherwise than under the laws of Canada or a province?

                - Yes
                - No

                  Is at least 90% of your corporation's shares owned or controlled by one, or any combination, of the following :

                  * A mutual fund trust for Canadian income tax purposes
                  * A real estate investment trust for Canadian income tax purposes
                  * A specified investment flow-through (SIFT) trust for Canadian income tax purposes
                  * A corporation that is incorporated or continued under the laws of Canada or a province whose shares are listed on a Canadian stock exchange that is designated for Canadian income tax purpose

                  * Yes
                  * No
            * No

              Do both of the following apply to your corporation?

              + Your corporation's chairperson or other presiding officer is a citizen or permanent resident of Canada; and
              + More than 90% of your corporation's directors are citizens or permanent residents of Canada

              + Yes
              + No
          - No
      * A registered charity for Canadian income tax purposes
      * A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority, or university for Canadian GST/HST purposes
      * An Indigenous governing body
      * The government of Canada or a province, or an agent of the government of Canada or a province
      * Unsure (none of the above)
* 2022

  Are you:

  Who is a foreign national?

  A foreign national is an individual who is **not** a citizen or permanent resident of Canada.

  + A citizen or permanent resident of Canada

    Do you own the residential property as a trustee of any of the following trusts?

    - A mutual fund trust for Canadian income tax purposes
    - A real estate investment trust for Canadian income tax purposes
    - A specified investment flow-through (SIFT) trust for Canadian income tax purposes

    - Yes
    - No

      Do you own the residential property as a trustee of any other type of trust (other than as a personal representative of a deceased individual)?

      * Yes
      * No

        Do you own the residential property as a partner of a partnership?

        What is a partnership?

        For UHT purposes, in all parts of Canada (other than Quebec), the CRA interprets the term partnership to mean the relationship that exists between persons carrying on a business in common with a view to profit.

        Partnerships constituted in Quebec

        For partnerships constituted in Quebec, the CRA interprets the term partnership based on the legal definition of contract of partnership in the Civil Code of Quebec:

        > “A contract of partnership is a contract by which the parties, in a spirit of cooperation, agree to carry on an activity, including the operation of an enterprise, to contribute thereto by combining property, knowledge or activities and to share among themselves any resulting pecuniary profits”

        The fact that two people own a property together does not, of itself, create a partnership.

        A familial relationship between two or more people who own a residential property does not, of itself, create a partnership, regardless of whether they are related by:

        + marriage
        + a common-law partnership (for example, two individuals who cohabit in a conjugal relationship throughout a continuous 12-month period)
        + a blood relationship (for example, a parent and a child; a brother and a sister)
        + adoption

        Review tax notice: [UHTN15, Questions about partnerships](/en/revenue-agency/services/forms-publications/publications/uhtn15/questions-answers-underused-housing-tax.html#_Toc130994813)

        + Yes
        + No
  + A foreign national

    Do you own the residential property as a trustee of any of the following trusts?

    - A mutual fund trust for Canadian income tax purposes
    - A real estate investment trust for Canadian income tax purposes
    - A specified investment flow-through (SIFT) trust for Canadian income tax purposes

    - Yes
    - No
  + A corporation

    Is your corporation any of the following:

    - A registered charity for Canadian income tax purposes
    - A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority, or university for Canadian GST/HST purposes
    - An Indigenous governing body
    - A corporation wholly owned by an Indigenous governing body

    - Yes
    - No

      Does your corporation own the residential property as a trustee of any of the following trusts?

      * A mutual fund trust for Canadian income tax pruposes
      * A real estate investment trust for Canadian income tax purposes
      * A specified investment flow-through (SIFT) trust for Canadian income tax

      * Yes
      * No

        Is your corporation incorporated in Canada?

        + Yes

          Does your corporation have share capital (that is, it has stock)?

          - Yes

            Does your corporation have shares listed on a Canadian stock exchange designated for Canadian income tax purposes?

            * Yes
            * No
          - No
        + No
  + A registered charity for Canadian income tax purposes
  + A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority, or university for Canadian GST/HST purposes
  + An Indigenous governing body or a corporation wholly owned by such a body
  + The government of Canada or a province, or an agent of the government of Canada or a province
  + Unsure (none of the above)

#### Based on your choice, your result is: You may be an excluded owner in this capacity

If you are an excluded owner, you **do not** have to file a return or pay the tax.

Review tax notice: [UHTN1, Who is an excluded owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc12)

**If you own the residential property in another capacity**, you will be treated **separately**, and must determine if you are an affected owner or excluded owner in that capacity.

#### Based on your choice, your result is: You may be an affected owner in this capacity

If you are an affected owner, you **must file** a return for the residential property.

You will also have to **pay the tax** unless you qualify for an exemption.

[Determine if you qualify for an exemption from paying the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html)

Review tax notice: [UHTN1, Who is an affected owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc18)

**If you own the residential property in another capacity**, you will be treated **separately**, and must determine if you are an affected owner or excluded owner in that capacity.

#### Based on your choice, your result is: You may be an excluded owner in this capacity

If you are an excluded owner, you **do not** have to file a return or pay the tax.

Review tax notice: [UHTN1, Who is an excluded owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc12)

**If you own the residential property in another capacity**, you will be treated **separately**, and must determine if you are an affected owner or excluded owner in that capacity.

#### Based on your choice, your result is: You may be an affected owner

If you are an affected owner, you **must file** a return for the residential property.

You will also have to **pay the tax** unless you qualify for an exemption.

[Determine if you qualify for an exemption from paying the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html)

Review tax notice: [UHTN1, Affected owners](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#_Toc122681156%20target=)

**If you own the residential property in another capacity**, you will be treated **separately**, and must determine if you are an affected owner or excluded owner in that capacity.

### These results are not binding on the CRA

The results that are obtained after you complete the interactive tool are dependent on the accuracy of the information that is entered.

#### Based on your choice, your result is: You are unsure

If you are uncertain about your obligations under the Underused Housing Tax Act, you may contact us or request a ruling or interpretation about how the tax applies to your specific situation.

[Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

 Text version

Use this version if you do not want to answer [interactive questions](#interactive).

2023 and onward calendar years

### Types of owners

There are 2 types of owners for the purposes of the Underused Housing Tax:

* Excluded owner
* Affected owner

#### Excluded owner

If you are an excluded owner, you **do not** have to file a return or pay the tax.

If you own the residential property in more than one capacity, you are treated as a separate person for each of your ownership capacities, if one of those capacities is either a partner of a partnership or a trustee of a trust.

If you are an affected owner in one of your ownership capacities of a residential property, you will have to file a return for that ownership capacity in which you are an affected owner of the residential property. You will also have to pay the tax for that ownership capacity unless you qualify for an exemption from paying the tax.

An **excluded owner** includes:

* An owner of the residential property as a trustee of any of the following trusts:
  + A specified Canadian trust
  + A mutual fund trust for Canadian income tax purposes
  + A real estate investment trust for Canadian income tax purposes
  + A specified investment flow-through (SIFT) trust for Canadian income tax purposes
* An owner of the residential property as a partner of a specified Canadian partnership
* An owner of the residential property (but neither as a trustee of a trust nor as a partner of a partnership) and you are any of the following:
  + The government of Canada or a province, or an agent of the government of Canada or a province
  + An individual who is a citizen or permanent resident of Canada
  + A specified Canadian corporation
  + A corporation incorporated or continued under the laws of Canada or a province whose shares are listed on a Canadian stock exchange designated for Canadian income tax purposes
  + A registered charity for Canadian income tax purposes
  + A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority or university for Canadian GST/HST purposes
  + An Indigenous governing body
  + A corporation incorporated or continued under the laws of Canada or a province having at least 90% of its shares owned or controlled by one, or any combination, of the following:
    - A trust that is a mutual fund trust for Canadian income tax purposes
    - A trust that is a real estate investment trust for Canadian income tax purposes
    - A trust that is a SIFT trust for Canadian income tax purposes
    - A corporation that is incorporated or continued under the laws of Canada or a province whose shares are listed on a Canadian stock exchange designated for Canadian income tax purposes
* An individual who is a citizen or permanent resident of Canada and an owner of the residential property as a personal representative of a deceased individual

Review tax notice: [UHTN1, Who is an excluded owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc12)

#### Affected owner

If you are not an excluded owner, then you are an affected owner.

If you are an affected owner of a residential property in Canada on December 31, you **must** file a return for each residential property that you own as an affected owner.

If you own the residential property in more than one capacity, you are treated as a separate person for each of your ownership capacities, if one of those capacities is either a partner of a partnership or a trustee of a trust.

You also have to pay the tax unless you qualify for an exemption.

Review tax notice: [UHTN1, Who is an affected owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc18)

 2022 calendar year

### Types of owners

There are 2 types of owners for the purposes of the Underused Housing Tax:

* Excluded owner
* Affected owner

#### Excluded owner

If you are an excluded owner, you **do not** have to file a return or pay the tax.

If you own the residential property in more than one capacity, you are treated as a separate person for each of your ownership capacities, if one of those capacities is either a partner of a partnership or a trustee of a trust.

If you are an affected owner in one of your ownership capacities of a residential property, you will have to file a return for that ownership capacity in which you are an affected owner of the residential property. You will also have to pay the tax for that ownership capacity unless you qualify for an exemption from paying the tax.

An **excluded owner** includes, but is not limited to:

* An individual who is a citizen or permanent resident of Canada unless you are an owner of the residential property as either of the following:
  + a trustee of a trust (except if you are the personal representative of a deceased individual, in which case you are an excluded owner of the residential property)
  + a partner of a partnership
* Any person that owns a residential property as a trustee of a mutual fund trust, real estate investment trust, or specified investment flow-through (SIFT) trust for Canadian income tax purposes
* A Canadian corporation whose shares are listed on a Canadian stock exchange designated for Canadian income tax purposes
* A registered charity for Canadian income tax purposes
* A cooperative housing corporation, hospital authority, municipality, para-municipal organization, public college, school authority, or university for Canadian GST/HST purposes
* An Indigenous governing body
* The government of Canada or a province, or an agent of the government of Canada or a province

Review tax notice: [UHTN1, Who is an excluded owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc12)

#### Affected owner

If you are not an excluded owner, then you are an affected owner.

If you are an affected owner of a residential property in Canada on December 31, you **must** file a return for each residential property that you own as an affected owner.

If you own the residential property in more than one capacity, you would be treated as a separate person for each of your ownership capacities, if one of those capacities is either a partner of a partnership or a trustee of a trust.

You will also have to pay the tax unless you qualify for an exemption.

Review tax notice: [UHTN1, Who is an affected owner](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc18)

## Foreign national

A foreign national is an individual who is **not** a Canadian citizen or permanent resident.

## Foreign corporation

A foreign corporation is a corporation who is **neither** incorporated nor continued under the laws of Canada or a province.

### Section navigation

* [Next: When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)

## Page details

Date modified:
:   2025-04-04
