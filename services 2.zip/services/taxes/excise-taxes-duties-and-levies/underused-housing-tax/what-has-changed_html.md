3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# What has changed

On June 20, 2024, amendments to the Underused Housing Tax Act (UHTA) contained in Bill C-69 received Royal Assent, which means that they are now law. For information about this legislation, please visit [C-69 (44-1) - LEGISinfo - Parliament of Canada](https://www.parl.ca/legisinfo/en/bill/44-1/c-69).

With the amendments to the UHTA contained in Bill C-69, starting with the 2023 calendar year, the majority of Canadian owners of residential property do not have to file a return or pay the tax.

Draft legislative and regulatory proposals

Draft legislative and regulatory proposals relating to the proposed changes were released for public consultation in the draft legislation section of the Department of Finance website.

Refer to: [Legislative and Regulatory Proposals Relating to the Underused Housing Tax Act and Explanatory Notes (canada.ca)](https://fin.canada.ca/drleg-apl/2023/uhta-ltlsu-1123-eng.html)

## Changes starting with the 2023 calendar year

* More Canadian owners are included in definition of excluded owner
  + Refer to: [Determine if you are an affected or excluded owner](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)
* Additional category in which affected owners may qualify for an exemption from paying the tax
  + Refer to: [Exemption for employee accommodations](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html#em-occ)
* Exemption for vacation properties added to the list of certain exemptions to which an adjusted penalty calculation may apply
  + Refer to: [Certain exemptions non-applicable for the penalty calculation](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html#non-app)

## Changes starting with the 2022 calendar year

* The original minimum penalty for individuals and corporations has been reduced
  + Refer to: [Penalties and interest reduction and exceptions](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html#penalties)
* You may need to amend a return you previously filed and file additional new return(s) for a residential property
  + Refer to: [If you are the owner in more than one capacity](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html#morecap)
* For UHT purposes, certain residential condominium units have been removed from the definition of residential property
  + Refer to: [Prescribed residential property](#rp "residential property description")

### Section navigation

* [Next: Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)

## Residential property

## Page details

Date modified:
:   2025-06-09
