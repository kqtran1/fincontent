3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# How to complete the return and calculate the tax

If you are an **affected owner** of a residential property in Canada on December 31 of a calendar year, **you must file** an Underused Housing Tax (UHT) return for the calendar year.

If you are an affected owner of more than one residential property, you must file a separate return for each of those properties.

If you are one of several affected owners of the residential property, each of you must file a separate return for the property.

If you are an owner of a residential property in more than one capacity on December 31 of a calendar year, and one of those multiple capacities is as a partner of a partnership or as a trustee of a trust, you are treated as a separate person in respect of each of those multiple capacities. You have to file a separate UHT return for each capacity in which you are an affected owner of the residential property.

[Determine if you are an affected owner](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)

## What form to use

* [UHT-2900, Underused Housing Tax Return and Election Form](/en/revenue-agency/services/forms-publications/forms/uht-2900.html)

Follow the steps below to help you fill out the parts of your return relevant to your situation.

1. ### Part 1 - Information about the affected owner

   You must have a valid CRA tax identifier number to file your return.

   Tax identifier numbers

   The following tax identifier numbers may be used depending on the situation:

   * Social insurance number **(SIN)**
   * Individual tax number **(ITN)**
   * Temporary taxation number **(TTN)**
   * Canadian business number **(BN)** with an Underused Housing Tax **(RU)** program account identifier code

   A trust account number (TAN) cannot be used to file Underused Housing Tax returns.

   Tax identifier numbers for individuals

   Depending on your citizenship, if you are an individual, you must file your return using either a SIN, an ITN, or a TTN.

   #### Canadian citizens or permanent residents

   You **must** use your SIN to file your return.

   If you do not already have a SIN, you must apply for one.

   [Apply for a SIN](/en/employment-social-development/services/sin/apply.html)

   #### Foreign nationals

   If you already have a SIN, you must use it to file your return.

   If you **do not** have a SIN, you **must** use your ITN or TTN to file your return.

   Foreign nationals (use an ITN)
   * If you are a temporary resident and have previously been assigned a TTN, please use this number to file your return.
   * If you are not a temporary resident or have not been assigned a TTN, you should use an ITN.

   If you do not have an ITN, you must apply for one.

   [Apply for an ITN](/en/revenue-agency/services/tax/international-non-residents-tax/in-outside-canada/apply-individual-tax-number.html#how)

   If you do not have a valid ITN, and are concerned with meeting the filing deadline, you may be able to apply for one by completing the application form (Form T1261) and mailing it with your paper return.

   You will not be able to complete an electronic return without a valid ITN.

   Make sure to file your ITN application form, all supporting documentation required for the ITN application, and your Underused Housing Tax return together.

   Tax identifier numbers for corporations

   If you are a corporation, you must file your return using a BN **with** an RU program account identifier code.

   If you already have a BN, you will have to register your RU program account before you can file your return.

   If you **do not** have a BN, you must get one **and** register your RU program account before you can file your return.

   If you are filing **multiple returns**, you only need to register for **one** RU program account to file all your UHT returns for the calendar year. You **do not** need separate RU program account identifier codes.

   Canadian corporations

   Refer to [Business Registration Online](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register.html#bro) to:

   * Get a business number (BN)
   * Get an Underused Housing Tax (RU) program account identifier code
   If your corporation is in Quebec

   Refer to: [Businesses operating in Quebec](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register.html#bissque)

   Corporations outside of Canada

   If you need to get a business number (BN), register through:

   [Non-resident business number](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register.html#nr-bn_accregistrtn_webform)

   If you need to get an Underused Housing Tax (RU) program account identifier code, register through:

   [Non-resident Underused Housing Tax registration form](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register.html#uht_webform)

   If you are a non-resident corporation and you have a question about obtaining a BN or registering your RU program account, the physical location of your business outside Canada will determine the telephone number that you must use to call the CRA.

   To determine which phone number is applicable to you, refer to:

   [Non-resident enquiries](/en/revenue-agency/corporate/contact-information/non-resident-gst-hst-enquiries.html)
2. ### Part 2 - Information about your residential property in Canada

   You must determine your ownership percentage, as well as the value of the residential property.

   Determine your ownership percentage

   If you are an affected owner of a residential property on December 31 of a calendar year, your **ownership percentage** of the residential property for the calendar year is determined as follows:

   * if you are an owner of the residential property in a single capacity and the land registration system indicates you hold a particular percentage of ownership of the residential property, use that percentage
   * if you are an owner of the residential property in more than one capacity and the land registration system separately indicates a percentage of ownership for each of your ownership capacities, use the percentage indicated for the applicable ownership capacity
   * if the land registration system indicates a group of persons that includes you holds a percentage of ownership of the residential property, divide that percentage by the number of persons in that group
   * if the above does not apply, use the percentage determined by the following formula:
     + (100% - A)/B
       - Where
         * A is the sum of all percentages of ownership held by another person or group of persons as indicated in the land registration system
         * B is the total number of persons (without taking their ownership in multiple capacities into account) with no percentage of ownership is indicated in the land registration system

   Alternative rule for owners in multiple capacities

   If you are an owner of a residential property in multiple capacities and if the land registration system does not separately indicate a percentage of ownership for each of your ownership capacities, you may also determine and use a percentage that reasonably reflects your percentage of ownership for the applicable ownership capacity. It is your responsibility to maintain adequate records to support your determination. If you do not have adequate records to support your determination, the CRA may determine your ownership percentage using one of the aforementioned rules applicable to the situation.

   For more information on ownership in multiple capacities, refer to [Underused Housing Tax Notice UHTN1, Introduction to the Underused Housing Tax](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#toc19).

   Determine the value of the residential property

   There are 2 ways to determine the value of a residential property.

   The general rule is to use its taxable value.

   What is taxable value

   The taxable value of the residential property for a calendar year is the **greater** of the following amounts:

   * The value of the residential property established by an authority that has the power to establish the assessed value of property for purposes of calculating a property tax
   * The residential property's most recent sale price, on or before December 31 of the calendar year

   Review tax notice: [UHTN2, Calculating the tax payable using the taxable value](/en/revenue-agency/services/forms-publications/publications/uhtn2/calculating-underused-housing-tax-payable.html#_Toc122091881)

   If you want to use the residential property's fair market value to make your calculation, you must file a [Fair market value (FMV) election](#FMV-election).

   [Review tax notice: UHTN2, Calculating the Underused Housing Tax Payable](/en/revenue-agency/services/forms-publications/publications/uhtn2.html)
3. ### Part 3 - Multiple residential properties

   This part only applies to **affected owners who are individuals**, and who are **not** Canadian citizens or permanent residents of Canada.

   Section 1 – Multiple properties

   If you own more than one residential property in Canada on December 31, you **must** file a separate return for each property.

   Section 2 – Election to designate a residential property

   Complete this section if you answered **yes** for line 300, and **no** for line 310.

   **Line 315**: By answering yes, you are designating the residential property (described in Part 2) for purposes of the exemptions for primary place of residence (Part 4) and qualifying occupancy (Part 5).

   This means you are declaring:

   * Only the residential property can be considered as qualifying for the **exemption for primary place of residence**
   * For only the residential property can your personal occupancy of a dwelling unit (or the personal occupancy of your spouse or common-law partner) be considered as usable for the **exemption for qualifying occupancy**

   You **must** fill out this section to be eligible for one of these 2 exemptions.

   Section 3 – Joint election to designate a residential property

   Complete this section if you answered **yes** for line 310.

   **Line 320**: By answering yes, you are designating the residential property (described in Part 2) for purposes of the exemptions for primary place of residence (Part 4) and qualifying occupancy (Part 5).

   This means you are declaring:

   * Only the residential property can be considered as qualifying for the **exemption for primary place of residence**
   * For only the residential property can your personal occupancy of a dwelling unit (or the personal occupancy of your spouse or common-law partner) be considered as usable for the **exemption for qualifying occupancy**

   You **must** fill out this section to be eligible for one of these 2 exemptions.

   To constitute a valid joint election, your spouse or common-law partner must elect to designate the **same** residential property for the calendar year in an UHT return for a residential property they own.

   The election is incomplete until the CRA receives your spouse or common-law partner's portion of the election on their UHT return designating the **same** residential property.

   If you choose to make an election, you may only designate one residential property.

   You cannot elect to designate different residential properties to claim multiple exemptions based on your, or your spouse's or common-law partner's, personal occupancy of the properties.

   Review tax notice: [UHTN8, Special Rule and Elections for Individual Owners of Multiple Residential Properties](/en/revenue-agency/services/forms-publications/publications/uhtn8/special-rule-elections-individual-owners-multiple-residential-properties.html)
4. ### Part 4 - Exemption for primary place of residence

   Only owners who are **individuals** may qualify for this exemption.

   If you are neither a Canadian citizen nor permanent resident, and between you and your spouse or common-law partner (who is neither a Canadian citizen nor permanent resident) you are owners of multiple residential properties, you **must** fill out the election in [Part 3](#part-3) to **claim this exemption**.

   Review tax notice: [UHTN6, Exemption for residential properties that are used a primary place of residence](/en/revenue-agency/services/forms-publications/publications/uhtn6/exemption-primary-place-residence.html#_Toc122423683)
5. ### Part 5 - Exemption for qualifying occupancy

   If you are neither a Canadian citizen nor permanent resident, and between you and your spouse or common-law partner (who is neither a Canadian citizen nor permanent resident) you are owners of multiple residential properties, you **must** fill out the election in [Part 3](#part-3) for your personal occupancy to be included in a qualifying occupancy period.

   Review tax notice: [UHTN7, Exemption for residential properties that are used for qualifying occupancy](/en/revenue-agency/services/forms-publications/publications/uhtn7/exemption-qualifying-occupancy.html#_Toc122423683)
6. ### Part 6 - Other exemptions

   Complete this part if you are claiming an exemption **other than** the exemption for primary place of residence or qualifying occupancy.

   You may only select one exemption.

   [Determine if you qualify for an exemption from paying the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-qualify-exemption.html)
7. ### Part 7 - Fair market value (FMV) election

   If you have claimed an exemption in Parts 4, 5 or 6, you do not need to fill out Part 7.

   If you choose to make a FMV election for a particular residential property, you are electing to use the FMV of your property instead of its [taxable value](#taxable-value) to calculate your tax payable for the calendar year.

   Fair market value (FMV)

   To calculate the tax you owe using the fair market value of a residential property, you must file an election by completing this section.

   An owner electing to use fair market value for the calculation has to get a **written appraisal** of the property. The written appraisal must be determined by an accredited, professional, real estate appraiser operating at arm’s length to the owner. The intended use of the written appraisal must be to help in the administration of the Underused Housing Tax Act.

   Acceptable Professional Associations and Designations
   * Appraisal Institute of Canada (AIC)
     + Accredited Appraiser Canadian Institute (AACI)
     + Canadian Residential Appraiser (CRA)
   * Canadian National Association of Real Estate Appraisers
     + Designated Appraiser Residential (DAR)
     + Designated Appraiser Commercial (DAC)
   * Ordre des évaluateurs agréés du Québec (OEAQ)
     + Chartered Appraiser (C.App./É.A.)

   If you have an appraisal report from an appraiser that does not have a designation from one of these associations and need further clarification, please [contact the CRA](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html).

   Review tax notice: [UHTN2, Calculating the tax payable using the FMV](/en/revenue-agency/services/forms-publications/publications/uhtn2/calculating-underused-housing-tax-payable.html#_Toc122091883)
8. ### Part 8 - Calculation of tax payable

   If you have claimed an exemption in Parts 4, 5 or 6, you do not need to fill out Part 8.

   If your ownership of a residential property does not qualify for an exemption from paying the tax for a calendar year, you must calculate what you owe.

   The Underused Housing Tax rate is 1%.

   To calculate what you owe, multiply the value of the residential property by the tax rate. Then multiply that result by your ownership percentage of the property.

   * Value of the property
   * times Underused Housing Tax rate (1%)
   * times Your ownership percentage
   * equals  Underused Housing Tax amount owed
   Calculation example

   For the 2023 calendar year, the value of the residential property is $500,000.

   You are 1 of 2 owners, each indicated in the land registration system as holding 50% ownership in the property.

   * $500,000 (Value of the property)
   * × times 1% (Underused Housing Tax rate)
   * × times 50% (Your ownership percentage)
   * = equals  $2,500 (Underused Housing Tax amount owed for the 2023 calendar year)

   Review tax notice: [UHTN2, Calculating tax payable](/en/revenue-agency/services/forms-publications/publications/uhtn2/calculating-underused-housing-tax-payable.html#_Toc122091879)

## Primary place of residence

## Qualifying occupancy

## Keep your records

You must keep records to support the information you provide in your return. If you claim an exemption but do not have adequate records to support it, we may **disallow** it.

Generally, you must keep your records for 6 years from the end of the year they relate to. Your records must be kept in Canada, in English or French, unless otherwise authorized by the Minister.

We cannot provide a defined list of records that you can use to support an exemption because each person’s situation is unique.

Examples of records to keep

Examples of records to support the information you provide in your return could include, but are not limited to the following:

* Municipal property tax assessment notice
* Purchase and sales agreements
* Land registration records
* Partnership or trust agreements
* Articles of incorporation or share registries
* Invoices, receipts, or statements
* Formal contracts or agreements
* Diaries, journals, letters, or images
* Bank or credit card statements
* Deposit slips
* Cheques
* Contracts
* Logbooks
* Written appraisal report
* General correspondence whether written, or in any other form

* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)

## Page details

Date modified:
:   2025-06-09
