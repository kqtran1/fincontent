3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# Who must file a return and pay the tax

You must file an Underused Housing Tax (UHT) return for **each** of your properties in Canada for which **all of the following** conditions are met on December 31 of a calendar year:

* The property is a [residential property](#residential_property "residential property description") for UHT purposes
* You are an [owner](#owner "owner description") of the residential property
* You are not an **exluded owner** of the residential property, that is, you are an **affected owner**.

## Affected owner

As an affected owner, you must file an annual return.

You will also have to pay the tax unless you qualify for an exemption.

If you are an affected owner of more than one residential property in Canada, you must file a separate return for **each property**.

If you are one of several affected owners of the residential property, **each of you** must file a separate return for the property.

[Determine the type of owner you are](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)

## Excluded owner

Generally, Canadian owners of residential property are excluded owners.

If you are an excluded owner you **do not** have to:

* File a return
* Pay the tax

[Determine the type of owner you are](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities/determine-affected-excluded.html)

## If you are an owner in more than one capacity

Starting with the 2022 calendar year, if you own the residential property in more than one capacity, you will be treated as a separate person for each of your ownership capacities, if one of those capacities is either:

* A partner of a partnership
* A trustee of a trust

You may be an affected owner in one capacity, but an excluded owner in another capacity. You must file a separate return for each capacity in which you are an affected owner of the residential property.

You may need to amend a return you previously filed and file additional new return(s) for a residential property for a previous calendar year if:

* You determine that you needed to file multiple returns based on your ownership capacities
* You filed only one return for all ownership capacities

Review tax notice: [UHTN16, Ownership in multiple capacities](/en/revenue-agency/services/forms-publications/publications/uhtn16/proposed-amendments-to-underused-housing-tax.html#_Toc157159136)

### Section navigation

* [Next: Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)

## Residential property

Generally, residential property is defined as property that is either:

* A detached house or similar building that contains a maximum of 3 dwelling units, including the related land
* A semi-detached house, rowhouse unit, or condominium, including the related land

Starting with the 2022 calendar year, a residential condominium unit would not be residential property for UHT purposes if these 3 conditions are met:

* The residential condominium unit is part of a building that has at least 4 residential condominium units
* You own at least 90% of the residential condominium units in that building
* At least 90% of the residential condominium units you own in the building are used to provide individuals with continuous occupancy as a place of residence or lodging for a period of at least one month

This means that an owner of such a residential condominium unit would not need to file a UHT return or pay the UHT for that unit.

Review tax notices:

* [UHTN1, Residential property](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#_Toc122681148)
* [UHTN15, Questions about residential property](/en/revenue-agency/services/forms-publications/publications/uhtn15/questions-answers-underused-housing-tax.html#_Toc130994816)
* [UHTN16, Prescribed residential property](/en/revenue-agency/services/forms-publications/publications/uhtn16/proposed-amendments-to-underused-housing-tax.html#_Toc157159139)

## Owner

You are an owner of residential property if you are:

* Identified as, or considered to be, an owner of the residential property in the land registration system where the residential property is located
* A life tenant under a life estate in the residential property
* A life lease holder of the residential property
* A lessee that has continuous possession of the land on which the residential property is situated under a long-term lease

Review tax notice: [UHTN1, Owner of residential property](/en/revenue-agency/services/forms-publications/publications/uhtn1/introduction-underused-housing-tax.html#_Toc122681153)

## Partner of a partnership

For UHT purposes, in all parts of Canada (other than Quebec), the CRA interprets the term partnership to mean the relationship that exists between persons carrying on a business in common with a view to profit.

Partnerships constituted in Quebec

For partnerships constituted in Quebec, the CRA interprets the term partnership based on the legal definition of contract of partnership in the Civil Code of Quebec:

> “A contract of partnership is a contract by which the parties, in a spirit of cooperation, agree to carry on an activity, including the operation of an enterprise, to contribute thereto by combining property, knowledge or activities and to share among themselves any resulting pecuniary profits”

The fact that two people own a property together does not, of itself, create a partnership.

A familial relationship between two or more people who own a residential property does not, of itself, create a partnership, regardless of whether they are related by:

* marriage
* a common-law partnership (for example, two individuals who cohabit in a conjugal relationship throughout a continuous 12-month period)
* a blood relationship (for example, a parent and a child; a brother and a sister)
* adoption

Review tax notice: [UHTN15, Questions about partnerships](/en/revenue-agency/services/forms-publications/publications/uhtn15/questions-answers-underused-housing-tax.html#_Toc130994813)

## Page details

Date modified:
:   2025-06-09
