3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

# Underused Housing Tax

* [What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
* [Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
* [Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
* [When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
* [How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
* [File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
* [Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
* [Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
* [Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)

# File the return

You can file your return online, by mail, or by fax.

Online
:   **Individuals** or **corporations** can submit the return using the web version of the online form:

    * [Online form for the Underused Housing Tax return](https://apps.cra-arc.gc.ca/ebci/sres/ext/pub/ntrUhtFlng?request_locale=en_CA)

    **Canadian citizens and permanent residents** can complete and submit the return using one of CRA's secure portals.

    If you are filing as an **individual**

    [Sign
    in to My Account](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html) [Registerfor CRA My Account](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals.html)

    * Go to the left menu and select “Tax returns”
    * Go to the column on the right, scroll down and select “Underused housing tax”
    * Select the “File a UHT return” button

    If you are filing **for** as a Canadian corporation

    [Sign
    in to My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html) [Register for My Business Account](/en/revenue-agency/services/e-services/digital-services-businesses/business-account.html)

    * Go to the left menu, scroll down and select “Underused housing tax”
    * Select your RU number in the drop-down list
    * Scroll down to the “Returns” section and select the “File a return” button

    If you are filing **for** an individual or Canadian corporation

    [Sign
    in to Represent a Client](/en/revenue-agency/services/e-services/represent-a-client.html)

    [Register - representatives in Canada](/en/revenue-agency/services/e-services/cra-login-services/register-cra-sign-in-services.html)

    [Register - non-resident representatives](/en/revenue-agency/services/e-services/cra-login-services/register-cra-sign-in-services.html)

    As an authorized representative, if you have access to an individual’s account or corporation’s account, use the following method:

    If you are representing an individual

    * Go to the left menu and select “Tax returns”
    * Go to the column on the right, scroll down and select “Underused housing tax”
    * Select the “File a UHT return” button

    If you are representing a Canadian corporation

    * Go to the left menu, scroll down and select “Underused housing tax”
    * Select your RU number in the drop-down list
    * Scroll down to the “Returns” section and select the “File a return” button

By mail or fax
:   **What form to use**

    * [UHT-2900, Underused Housing Tax Return and Election Form](/en/revenue-agency/services/forms-publications/forms/uht-2900.html)

    Where to send your return depends on the location of either you (as an individual), or your corporation.

    Select the location where you reside, or where your corporation is physically located

    * Canada

      Choose a province or territory

      + [Alberta](#winnipeg_tc)
      + [British Columbia](#winnipeg_tc)
      + [Manitoba](#winnipeg_tc)
      + [New Brunswick](#sudbury_tc)
      + [Newfoundland and Labrador](#sudbury_tc)
      + [Nova Scotia](#sudbury_tc)
      + [Northwest Territories](#winnipeg_tc)
      + [Nunavut](#winnipeg_tc)
      + Ontario

        Choose a location within Ontario

        - [Barrie](#sudbury_tc)
        - [Sudbury](#sudbury_tc)
        - [Toronto](#sudbury_tc)
        - [Another location in Ontario](#winnipeg_tc)
      + [Prince Edward Island](#sudbury_tc)
      + [Quebec](#sudbury_tc)
      + [Saskatchewan](#winnipeg_tc)
      + [Yukon](#winnipeg_tc)
    * [Denmark](#winnipeg_tc)
    * [France](#winnipeg_tc)
    * [Netherlands](#winnipeg_tc)
    * [United Kingdom](#winnipeg_tc)
    * [United States of America](#winnipeg_tc)
    * [Another country](#sudbury_tc)

    ## Winnipeg Tax Centre

    Winnipeg Tax Centre
    Post Office Box 14001
    Station Main
    Winnipeg MB R3C 3M3
    Canada

    Fax: 204-984-5164

    ## Sudbury Tax Centre

    Sudbury Tax Centre
    1050 Notre Dame Avenue
    Sudbury ON P3A 5C2
    Canada

    Fax: 705-671-3994 or 1-855-276-1529

### Section navigation

* [Next: Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)

## Page details

Date modified:
:   2025-06-09
