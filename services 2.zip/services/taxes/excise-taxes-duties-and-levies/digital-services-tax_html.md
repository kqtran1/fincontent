3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)

# Digital services tax

## Source of the new tax

The *Digital Services Tax Act* received royal assent on June 20, 2024 and came into force on June 28, 2024.

The Government of Canada has introduced the digital services tax (DST). The DST requires foreign and domestic large businesses to pay tax on certain revenue earned from engaging with online users in Canada if they meet certain conditions. Affected businesses will have to apply to register for a DST program account and may have to file a DST return.

## Sections

[About the tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/about-tax.html)
:   Learn about the digital services tax

[Registering for an account](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-register.html)
:   Determine if you must apply to register for a program account and learn about the registration process

[Making a designated entity election](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/make-election.html)
:   Determine if you can make a designated entity election and learn about how to make this election

[Filing a return](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/who-file.html)
:   Determine who must file a return and learn about how to file

[Contact us](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax/contact.html)
:   Contact the Canada Revenue Agency if you have a general question or if you would like to request a technical interpretation

## Related information

* [Digital Services Tax Act](https://laws-lois.justice.gc.ca/eng/acts/D-1.65/)
* [Explanatory Notes for the Digital Services Tax Act and Related Regulations](https://fin.canada.ca/drleg-apl/2024/nwmm-amvm-0724-n-eng.html)

## Page details

Date modified:
:   2025-07-17
