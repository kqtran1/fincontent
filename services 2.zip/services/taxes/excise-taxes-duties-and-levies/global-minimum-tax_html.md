3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)

# Global minimum tax

## Source of the rules

The *Global Minimum Tax Act* received royal assent on June 20, 2024.

## Related information

* [Global Minimum Tax Act](https://lois.justice.gc.ca/eng/acts/g-3.3/index.html)
* [Explanatory Notes Relating to the Global Minimum Tax Act](https://fin.canada.ca/drleg-apl/2024/nwmm-amvm-0424-n-3-eng.html)
* [Global Anti-Base Erosion Model Rules (Pillar Two)](https://www.oecd.org/tax/beps/tax-challenges-arising-from-the-digitalisation-of-the-economy-global-anti-base-erosion-model-rules-pillar-two.html)

To reduce the incentive for certain multinational enterprise (MNE) groups to shift profits to low-tax jurisdictions and limit the erosion of the Canadian tax base, the Government of Canada introduced the global minimum tax.

The tax ensures certain qualifying MNE groups are subject to a minimum effective tax rate on their profits in every jurisdiction in which they operate.

Members of qualifying MNE groups may have to register for a global minimum tax program account and file one or more forms.

Information on when to register, how to register, and how to file will be available at a later date.

## On this page

* [About the tax](#gmt)
* [Who must file](#wh_rgstr)
* [When to file](#fl_rtrn)
* [Contact us](#cntct)

## About the tax

Canada is a member of the Organisation for Economic Co-operation and Development (OECD) and Group of 20 (G20) Inclusive Framework on Base Erosion and Profit Shifting (the Inclusive Framework). As a member, Canada joined a two-pillar plan for international tax reform. Pillar Two is a key part of the two-pillar plan.

### Pillar Two

Pillar Two consists of rules that are generally intended to be implemented through changes to each country’s domestic tax laws. Members of the Inclusive Framework that implement Pillar Two are required to do so in a way that is consistent with the outcomes from the Global Anti-Base Erosion (GloBE) Model Rules, as well as the Commentary and Administrative Guidance on the GloBE Model Rules. These materials are approved by the Inclusive Framework and are published by the OECD.

### The global minimum tax

The global minimum tax implements Pillar Two along with a domestic minimum top-up tax that would apply to Canadian entities of MNEs that are within the scope of Pillar Two. The tax ensures that a minimum effective tax rate of 15% applies to profits of qualifying MNE groups, in every jurisdiction in which they operate.

### The Global Minimum Tax Act

The Act received royal assent on June 20, 2024, and applies to qualifying MNE groups for fiscal years that begin on or after December 31, 2023.

Part 2 of the Act implements the Pillar Two Income Inclusion Rule (IIR) found in the GloBE Model Rules. As a global minimum tax, it imposes liability for top-up tax on certain persons in respect of a qualifying MNE group.

Part 3 of the Act implements the domestic minimum top-up tax as provided for in the GloBE Model Rules and further elaborated in the Commentary. It allows Canada to retain taxing rights on income sourced in Canada and ensures any qualifying MNE groups with Canadian entities will pay the minimum rate of 15% tax in Canada in respect of those entities.

## Who must file

A member of a qualifying MNE group must file for a particular fiscal year when the group has €750 million or more in revenue reported in the consolidated financial statements of its ultimate parent entity (in at least 2 of the 4 fiscal years immediately preceding the particular fiscal year).

The member **must file** one or more of the following forms:

* GloBE Information Return (GIR)
* Global Minimum Tax Return
* GIR Notification

A constituent entity or person may be appointed to file on behalf of all constituent entities or persons that must file with the CRA.

### Who must file a GIR

**One** of the following constituent entities of a qualifying MNE group must file a GIR with the CRA:

* The **designated filing entity** must file when there is one that is located in Canada
* The **ultimate parent entity** must file when the following conditions are **all** met:
  + The ultimate parent entity is located in Canada
  + The MNE group does not have a designated filing entity located in Canada
* **Each constituent** entity located in Canada or a **designated local entity** must file when the following conditions are **all** met:
  + The MNE group does not have an ultimate parent entity or designated filing entity located in Canada
  + The MNE group does not have an ultimate parent entity or designated filing entity outside Canada that filed the GIR directly with the CRA on or before the GIR due date
  + **Either** the MNE group does not have a qualifying foreign filing entity **or** it has a qualifying foreign filing entity, but the CRA notified the constituent entities located in Canada or the designated notification entity that it has not received a GIR from the qualifying foreign filing entity's jurisdiction

### Who must file a Global Minimum Tax Return

Each person that is liable to pay tax under Part 2 or Part 3 of the Act, or each Canadian filing entity, must file a Global Minimum Tax Return with the CRA.

### Who must file a GIR Notification

If a [qualifying foreign filing entity](#qffe) is filing the GIR for the MNE group with the tax authority of the jurisdiction where it is located, each constituent entity located in Canada, or a designated notification entity must file a GIR Notification with the CRA.

## When to file

The earliest date by which the forms must be filed is **June 30, 2026**.

However, depending on a qualifying MNE group’s fiscal year, one of the following **later dates** is the due date for a qualifying MNE group’s forms:

* 18 months after the last day of the fiscal year, if it is the first fiscal year that an entity of the qualifying MNE group is subject to:
  + Part 3 of the Act
  + a [qualified IIR](#iir)
* 15 months after the last day of the fiscal year, in any other case

## Contact us

Contact the CRA if you would like more information about the global minimum tax.

* ## Ask a general question about the global minimum tax: Option 1

  You can submit your question about the global minimum tax using the [online form](https://forms-formulaires.alpha.canada.ca/en/id/cm4xbk48000bxsdyfy6hshlar).
* ## Request a technical interpretation for the *Global Minimum Tax Act*: Option 2

  You can [request a technical interpretation](/en/services/taxes/excise-taxes-duties-and-levies/global-minimum-tax/request-technical-interpretation.html) of specific provisions of the *Global Minimum Tax Act*.
* ## Ask a question not related to the global minimum tax: Option 3

  To contact the CRA for other reasons, refer to: [Contact the CRA](/en/revenue-agency/corporate/contact-information.html)

## Qualified Income Inclusion Rule

A qualified Income Inclusion Rule (IIR) for a fiscal year means an IIR that has qualified status (including transitional qualified status) for the fiscal year as determined by the Inclusive Framework and published on the website of the OECD.

## Qualifying foreign filing entity

A qualifying foreign filing entity (QFFE) is an ultimate parent entity or a designated filing entity of the MNE group that is located in a foreign jurisdiction and that is obligated to file a GloBE information return with the tax authority of the foreign jurisdiction, provided that the foreign jurisdiction has a qualifying competent authority agreement that is in effect on or before the GloBE information return exchange date for the fiscal year. Canada must be a party to that agreement for the entity to be a QFFE.

## Page details

Date modified:
:   2025-03-17
