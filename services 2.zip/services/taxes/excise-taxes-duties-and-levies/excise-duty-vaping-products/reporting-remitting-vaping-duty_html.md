3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* Reporting and remitting the excise duty on vaping products
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Reporting and remitting the excise duty on vaping products

## On this page

* [Who must file and when](#h-1)
* [How to file and pay](#h-2)
* [After sending a return](#h-3)
* [Filing or paying late](#h-4)
* [What records to keep](#h-5)
* [Additional Information](#h-6)

## Who must file and when

### Vaping product licensees

All vaping product licensees must file monthly returns to report their manufacturing and/or stamping activities (including inventories) and, if applicable, duty payable.

The **monthly** Form [B600, Vaping Duty and Information Return](/en/revenue-agency/services/forms-publications/forms/b600.html) is due by the last day of the calendar month following the reporting period.

You must file a return even if you have:

* No business transactions
* No duty to pay (remit)

When a due date falls on a **Saturday**, a **Sunday** or a [public holiday recognized by the CRA](/en/revenue-agency/services/tax/public-holidays.html), your return is considered to be filed on time if we receive it on or before the **next business day**.

If you also hold an excise warehouse licence, you are required to file monthly Form B262, Excise Duty Return – Excise Warehouse Licensee. This return is due by the last day of the calendar month following the reporting period. For more information on Form B262, see [Excise Duty Memoranda, EDM10.1.3, Completing an Excise Duty Return – Excise Warehouse Licensee](/en/revenue-agency/services/forms-publications/publications/edm10-1-3.html).

### Vaping prescribed persons

If you are a vaping prescribed person that imports stamped vaping products, you are required to file [Form B601, Vaping Information Return – Prescribed Person](/en/revenue-agency/services/forms-publications/forms/b601.html) **monthly** to report your inventory and usage of vaping excise stamps.

You must report even if you did not import any stamped products during the month.

## How to file and pay

### Vaping product licensees

As a vaping product licensee, you may file your return using **either** of the following methods:

* online through My Business Account using the File a return link
* by mail using [Form B600, Vaping Duty and Information Return](/en/revenue-agency/services/forms-publications/forms/b600.html)

If you are also claiming a refund of vaping duty and any additional vaping duty, use **either** of the following methods:

* online through My Business Account using the File a refund link
* by mail using [Form B602, Application for a Refund of Vaping Duty](/en/revenue-agency/services/forms-publications/forms/b602.html) and attaching it to your return

Your payment is due at the same time as your return. For more information on which methods you can use to pay, see [Payment options for excise duty](/en/revenue-agency/services/payments/payments-cra/individual-payments/make-payment.html).

### Vaping prescribed person

As a vaping prescribed person, you may file your return using either of the following methods:

* online through My Business Account using the File a return link
* by mail using [Form B601, Vaping Information Return – Prescribed Person](/en/revenue-agency/services/forms-publications/forms/b601.html)

Vaping duty and any additional vaping duty on imports of stamped vaping products is paid to the Canada Border Services Agency (CBSA) at the time of importation. For further information, please contact CBSA at 1-800-461-9999.

## After sending a return

When we receive your return, we will process your payment (if attached) and send you a notice of assessment of your return.

If your payment is not attached, we will assess the amount owing and send you a notice of assessment using **either** of the following methods:

* in [My Business Account](/en/revenue-agency/services/e-services/cra-login-services.html) if you receive your mail online. If you are registered for email notification service, the CRA will send you an email notification to the email address you previously provided when you have new mail to view in My Business Account.
* by mail

We will **not** send you a notice of assessment if your return includes no duty to pay (that is, a nil return).

### What to do if you have an amount owing

If there is an amount owing and you have registered for email notification service, we will send you an email notification that there is mail for you to view in My Business Account concerning paying the outstanding amount. If you have not registered for email notification service, we will mail you a notice of assessment along with Form RC159, Amount Owing Remittance Voucher.

Use Form RC159 to pay any outstanding amount. This form is not available on our website. We can only provide it in a pre-printed format. To order this personalized form, go to My Business Account, Represent a Client or call Business Enquiries at 1-800-959-5525.

## Filing or paying late

CRA may charge you penalties and interest if you:

* do not file on time
* receive a demand to file and do not do so
* make a false statement or omission

CRA will charge you interest if you:

* have an overdue amount on your return
* make a late or insufficient payment

We may hold a refund you are entitled to until we receive all outstanding returns and amounts owing. This includes returns that are required to be filed under other legislation administered by the CRA. We may also use a refund of vaping duty and any additional vaping duty and any additional vaping duty that you are entitled to receive to off-set your outstanding amounts in accordance with the law.

We may also restrict your ability to order vaping excise stamps until we receive all outstanding returns.

## What records to keep

You must keep all records that will support the information you have provided on forms B600, B601, and B602. This includes the amount of vaping products manufactured, received, used, packaged, stamped, sold, exported and disposed of.

Your records must also support the information reported in respect of the possession and use of any vaping excise stamps issued to you.

You must keep your records for a period of at least **6 years** from the end of the last year to which they relate.

## Additional information

For more information, see [EDN82 Calculation of Vaping Duty](/en/revenue-agency/services/forms-publications/publications/edn82.html) and Additional Vaping Duty.

If you have further questions, contact your regional excise office. For the contact information of the regional excise offices: [Contact Information – Excise Duty, Excise Taxes, Fuel Charge, and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts.html).

## Page details

Date modified:
:   2025-05-15
