3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Completing an application for a refund of vaping duty

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* Completing an application for a refund of vaping duty

# Completing an application for a refund of vaping duty

## On this page

* [Instructions for Part A: Business information](#h-1)
* [Instructions for Part B: Calculation of the refund amounts](#h-2)
* [Instructions for Part C: Refund options](#h-3)
* [Instructions for Part D: Certification](#h-4)

This page provides line-by-line instructions on how to fill out [Form B602, Application for a Refund of Vaping Duty](/en/revenue-agency/services/forms-publications/forms/b602.html), which is required to be filed by vaping product licensees who want to claim a refund of the duty paid on vaping products under the Excise Act, 2001.

This application form must be completed and filed with the CRA no later than two years after the duty was paid in error or the vaping product was re-worked or destroyed. For more information, see [Excise Duty Notice EDN78, General Information – Vaping Products](/en/revenue-agency/services/forms-publications/publications/edn78.html).

For imported stamped vaping products, the vaping duty would have been paid to the Canada Border Services Agency (CBSA). Therefore, this application form may **not** be used to claim a refund on these products. For more information on whether a refund may be claimed on imported stamped vaping products, contact the CBSA.

## Instructions for Part A: Business information

Part A of the application is used to identify the vaping product licensee. Current and accurate information is required for each field as follows:

### Business information

Provide the legal name and the business number of the account for which the application is being filed. If the legal name of the business has changed, you need to contact your CRA regional excise office to report the change. A list of the offices is available at [Contact Information – Excise Duty, Excise Taxes, Fuel Charge and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts.html).

### Physical business location

Provide the address of the physical location of the premises for which the application is being filed. If the application being filed is in relation to a consolidated return for more than one premises, provide the physical location of the filing account. If the physical address of the business has changed, you need to contact your CRA regional excise office to report the change.

### Reporting period

Identify the start and end dates of the calendar month for which the application is being filed. If the application does not cover a full calendar month because you received or cancelled your licence partway through a calendar month, enter the start and end dates that cover your operations for that particular calendar month.

## Instructions for Part B: Calculation of the refund amounts

For each refund amount requested, provide the appropriate details within the chart included in this part. The details required to be reported in each column are as follows:

### Reason for refund

The Excise Act, 2001 provides for three allowances for a refund of vaping duty and/or additional vaping duty. A refund may be requested for:

* an amount paid in error (for example, a calculation error was made or duty was paid on a product that should have been duty-relieved).
* vaping products that are re-worked in accordance with section 187.2 of the Act.
* vaping products that are destroyed in accordance with section 187.2 of the Act.

You must receive approval from the CRA prior to re-working or destroying any vaping products.

For more information, please contact your regional excise office: [Contact Information – Excise Duty, Excise Taxes, Fuel Charge and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts.html).

Select the appropriate reason from the drop-down list provided.

### Product Type

Select the appropriate product type of the vaping product for which you are requesting the refund. If a particular refund relates to more than one product type, the refund will have to be reported separately depending on the product type. For example, if 100 vaping pods containing 2.9 mL each and 100 containers each with 30 mL of vaping liquid are both destroyed, these must be reported separately on two rows.

### Jurisdiction

As provinces or territories join the coordinated taxation framework, the additional jurisdictions will be added to the drop-down list and will be available for selection.

Select the appropriate jurisdiction from the drop-down list according to the vaping excise stamp used on the product. If a refund claim relates to more than one jurisdiction, the refund will have to be reported separately for each jurisdiction.

**Note:** If your refund claim involves products which are not all stamped for the same jurisdiction, you must separate the refund claim by jurisdiction. For example if you have destroyed 100 packages of vaping pods, half of which were stamped for Ontario and the other half of which were stamped for Canada, these must be split and entered on separate lines of the B602 form.

### Number of packages

Indicate the number of packages associated with the refund being claimed. If four vaping pods have been put into a single package to be sold to the consumer, this would only count as one package. The number indicated here should also correspond to the number of stamps used on the products related to the refund request.

### Vaping duty ($)

Enter the amount of vaping duty, in dollars, that you are requesting to be refunded for the products listed on each specific row.

### Additional vaping duty ($)

As provinces or territories join the coordinated taxation framework, the additional vaping duty column will be accessible to input the appropriate information.

Enter the amount of additional vaping duty, in dollars, that you are requesting to be refunded for the products listed on each specific row.

### Total

Add all of the entries under the vaping duty column and enter the result on line 1.

Add all of the entries under the additional vaping duty column and enter the result on line 2.

### Total refund

Add the amounts from line 1 and line 2 and enter the result on line 3.

## Instructions for Part C: Refund options

Indicate in this section how you would like your refund to be issued to you. If you choose to transfer an amount from the refund to another account, you must also enter the applicable 15-digit account number and the last day of the reporting period to which you would like the refund applied. You can only transfer to an account that starts with the same 9-digit business number as the one indicated under Part A – Business information.

If you are submitting this refund application along with your monthly [Form B600, Vaping Duty and Information Return](/en/revenue-agency/services/forms-publications/forms/b600.html), and if the net amount reported on line 13 of Form B600 is a positive amount, you do not need to fill out this section. Your refund will be applied against your total duty payable on Form B600.

## Instructions for Part D: Certification

An authorized person must print their name and title, sign and date the application, and provide a current telephone number. Enter the complete name and telephone number of a person who may be contacted about the application for a refund of vaping duty.

## Page details

Date modified:
:   2024-06-24
