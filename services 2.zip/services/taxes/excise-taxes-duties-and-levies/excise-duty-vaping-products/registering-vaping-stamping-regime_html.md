3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* Registering for the vaping stamping regime
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Registering for the vaping stamping regime

## On this page

* [Overview](#h-1)
* [Who must register](#h-2)
* [How to register](#h-3)
* [After you register](#h-4)
* [Additional information](#h-5)

## Overview

The following persons are required to affix vaping excise stamps to packaged vaping products intended for the Canadian duty-paid market:

* Vaping product licensees who package vaping products
* Vaping product licensees who import packaged vaping products
* Vaping prescribed persons who import packaged vaping products

The following vaping products are **not** required to be stamped:

* Vaping product drugs that have been assigned a Drug Identification Number under the Food and Drug Regulations
* Vaping products intended for export
* Vaping products intended to be sold to an accredited representative

Products intended for export or for sale to an accredited representative must immediately be marked as per the Stamping and Marking of Tobacco, Cannabis, and Vaping Product Regulations , and may be required to enter an excise warehouse.

For information on applying for an excise warehouse licence, see [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html).

Purpose of the vaping stamping regime

The vaping stamping regime:

* shows that the product was produced legally and that applicable duties were paid
* allows law enforcement agencies, retailers, and consumers to identify counterfeit and contraband products
 Placement of the vaping excise stamps on the packaging

The placement of the vaping excise stamp on the package must meet **all** the following requirements. The stamp must:

* be in a conspicuous place on the package
* seal the package
* remain affixed after the package is opened
* not interfere with the stamp’s security features
* not obstruct information required by an Act of Parliament – such as labelling requirements from Health Canada

A vaping product is considered packaged when it is packaged in the smallest package (including any outer wrapper, package, box, or other container) in which it is sold to the consumer.

## Who must register

Under the amendments to the Excise Act, 2001, you must register for the vaping stamping regime if you are:

* the last vaping product licensee who packages the vaping product for final retail sale into the Canadian duty-paid market
* a vaping product licensee who imports packaged vaping products intended for sale into the Canadian duty-paid market
* a vaping prescribed person registered to get vaping excise stamps in order to import packaged vaping products into the Canadian duty-paid market.

You **do not** have to register if you are:

* a vaping product licensee who **only** packages vaping products for export out of Canada
* a vaping product licensee who **only** packages vaping product drugs
* a vaping product licensee who **only** packages vaping products to be sold to an accredited representative
* a vaping product licensee who does not package vaping products into the smallest package in which it is sold to the consumer

You can register for the vaping stamping regime at the same time as you apply for a vaping product licence or vaping prescribed person registration under the Excise Act, 2001.

## How to register

You can register for the vaping stamping regime by using [Form L601, Registration for Vaping Stamping Regime](/en/revenue-agency/services/forms-publications/forms/l601.html).

## After you register

We will review your registration to determine if you are eligible for the vaping stamping regime based on the information provided on your Form L601. We may contact you if we need more information.

We will send you a letter by mail to confirm your registration and provide instructions on how to purchase stamps. The CRA has the authority to issue and limit the number of vaping excise stamps purchased.

### Order process for the vaping excise stamps

After a person has been registered for the vaping stamping regime, the order process is as follows:

* stamp orders are placed through the on-line excise stamp ordering system
* CRA reviews the stamp orders
* the stamp provider processes the order and arranges secure delivery of the stamps (cost of delivery and applicable insurance is borne by the stamp purchaser)
* the stamp purchaser acknowledges receipt of all stamps delivered

### Your responsibilities as someone registered for the vaping stamping regime

Your responsibilities once registered for the vaping stamping regime are:

* affix vaping excise stamps to vaping products in accordance with the Act
* report on your inventory of stamps either on Form B600, Vaping Duty and Information Return (for vaping product licensees) or on Form B601, Vaping Information Return – Prescribed Person
* keep all your supporting documents for 6 years to support the use and destruction of stamps

Penalties may apply on vaping excise stamps that are unaccounted for.

## Additional information

If you have further questions, contact your regional excise duty office. For the contact information of the regional excise duty offices: [Contact Information – Excise Duty, Excise Taxes, Fuel Charge, and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html).

You may email questions to lpvapingg@cra-arc.gc.ca or call 1-866-330-3304.

## Page details

Date modified:
:   2025-07-30
