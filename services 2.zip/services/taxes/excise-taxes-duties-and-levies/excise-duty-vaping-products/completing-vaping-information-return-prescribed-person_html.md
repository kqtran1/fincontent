3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* Completing a vaping information return – prescribed person
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Completing a vaping information return – prescribed person

## On this page

* [Instructions for Part A: Business information](#h-1)
* [Instructions for Part B: Vaping excise stamp inventory](#h-2)
* [Instructions for Part C: Certification](#h-3)

This page provides line-by-line instructions on how to fill out [Form B601, Vaping Information Return – Prescribed Person](/en/revenue-agency/services/forms-publications/forms/b601.html), which is required to be filed monthly by vaping prescribed persons authorized to obtain vaping excise stamps under the Excise Act, 2001.

## Instructions for Part A: Business information

Part A of the return is used to identify the vaping prescribed person. Current and accurate information is required for each field as follows:

### Business information

Provide the legal name and the business number of the account for which the return is being filed. If the legal name of the business has changed, you need to contact your regional excise office. The contact information is available at [Contact Information – Excise Duty, Excise Taxes, Fuel Charge and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts.html).

### Books and records location

Provide the address of the location where books and records are being kept for which the return is being filed. If the location of the books and records of the business has changed, you need to contact your regional excise office to report the change.

### Type of return

If you are filing a return for a reporting period for which you already have submitted a return, select "Amended." Otherwise, select "Original".

### Reporting period

Identify the start and end dates of the calendar month for which the return is being filed. If the return does not cover a full calendar month because you received or cancelled your prescribed person registration partway through a calendar month, enter the start and end dates that cover your registration for that particular calendar month.

## Instructions for Part B: Vaping excise stamp inventory

This section requires an inventory reconciliation of the vaping excise stamps for each reporting period. Inventory reporting is required to be conducted based on the jurisdiction of the stamp.

As provinces or territories join a coordinated taxation framework, respective jurisdictional lines will become accessible to report the required information.

For more information regarding vaping excise stamps, see [Excise Duty Notice EDN80, Overview of the Vaping Excise Stamps](/en/revenue-agency/services/forms-publications/publications/edn80.html).

### Opening inventory (column A)

The opening stamp inventory on the return must equal the previous reporting period’s closing inventory for each jurisdiction. Enter amounts for "Opening inventory" for each jurisdiction.

### Stamps received (column B)

Enter the quantity of vaping excise stamps received during the reporting period from the authorized vaping excise stamp provider in this column, for each applicable jurisdiction.

Stamps are considered as received when they are delivered to the  vaping prescribed person’s chosen delivery location (for dry stamps) or when they are delivered to the adhesive supplier. A vaping prescribed person is responsible for stamps that are held by a third party for adhesive application.

### Stamps on products imported (column C)

Enter the quantity of stamps affixed to vaping products that were imported during the reporting period in this column for each jurisdiction. Stamps are reported in this column at the time that the stamped products are imported, **not** when the stamp is affixed to the product outside of Canada.

**Note:** A vaping prescribed person is only allowed to import fully packaged, stamped vaping products. A vaping prescribed person is **not** allowed to stamp vaping products in Canada.

### Destroyed stamps (column D)

Enter the quantity of stamps that were destroyed during the reporting period in the column, for each jurisdiction.

**Note:** Vaping excise stamps must be destroyed in Canada. Prior to destroying any vaping excise stamps, you must obtain approval from your regional excise office. A list of the offices is available at [Contact Information – Excise Duty, Excise Taxes, Fuel Charge and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts.html). Failure to do so may result in a penalty for unaccounted for stamps.

### Inventory adjustments (column E)

Adjustments may be necessary to balance the physical inventory with the book inventory. The closing or book inventory must agree with the physical inventory for the reporting period. All adjusting entries are subject to audit and must be entered as "Inventory adjustments" in column E.

### Closing inventory (column F)

The closing inventory is the sum of columns A and B, minus columns C and D, plus or minus any adjustments in column E, and the results for each respective jurisdiction are entered in this column F:

**A + B – C – D ± E**

This closing inventory of vaping excise stamps will become the opening inventory for the following reporting period, for each respective jurisdiction.

## Instructions for Part C: Certification

An authorized person must print their name and title, sign and date the return, and provide a current telephone number. Enter the complete name and telephone number of a person who may be contacted about the vaping information return.

## Page details

Date modified:
:   2024-06-24
