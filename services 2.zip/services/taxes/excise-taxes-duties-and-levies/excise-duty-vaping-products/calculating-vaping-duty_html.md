3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* Calculating excise duty on vaping products
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Calculating excise duty on vaping products

## On this page

* [Who must pay](#h-1)
* [How to calculate](#h-2)
* [How to report](#h-3)
* [What records to keep](#h-4)
* [Additional Information](#h-5)

## Who must pay

A vaping product licensee who **packages** vaping products manufactured in Canada must pay the vaping duty and any additional vaping duty at the time of stamping. Stamping must occur no later than the end of the second calendar month after the month in which the vaping product was packaged.

A vaping product is considered packaged when it is placed in the smallest package, including any outer wrapper, package, box or other container, in which it is sold to the consumer.

If packaged vaping products are imported by a vaping product licensee for stamping in Canada, the licensee must pay the vaping duty and any additional vaping duty at the time of stamping. Stamping must occur no later than the end of the second calendar month after the month in which the vaping product was released by the Canada Border Services Agency.

For imported stamped vaping products, the person who must pay the vaping duty and any additional vaping duty is the importer, owner, or other person who is liable to pay the duty under the Customs Act. The excise duty on imported vaping products is payable to the Canada Border Services Agency at the time of importation.

If a vaping product licensee imports unpackaged vaping products for further manufacturing in Canada, they are not required to pay vaping duty or any additional vaping duty at the time of importation.

## How to calculate

The excise duty rates on vaping products are outlined in Schedule 8 of the Excise Act, 2001 and are as follows:

For vaping liquids:

For vaping products intended for consumption, sale or use in all provinces:

Vaping Duty

* $1 per 2 millilitres (mL), or fraction thereof, for the first 10 mL of vaping substance in the vaping device or immediate container
* $1 per 10 mL, or fraction thereof, for amounts over the first 10 mL

**PLUS**, for vaping products intended for consumption, sale or use by consumers in a specified vaping province:

Additional Vaping Duty:

* $1 per 2 millilitres (mL), or fraction thereof, for the first 10 mL of vaping substance in the vaping device or immediate container
* $1 per 10 mL, or fraction thereof, for amounts over the first 10 mL

The same rates above apply to vaping solids on a per gram basis.

Effective July 1, 2024 the specified vaping provinces are Ontario, Quebec, Northwest Territories, and Nunavut.

### Examples:

1. A package containing 4 pods, with each pod containing 1.5 mL of vaping liquid, which is intended for sale in a province that is **not** a specified vaping province, attracts $4 of vaping duty ($1 per 1.5 mL pod). It is important to note that the vaping duty is calculated on the quantity of vaping liquid contained in each individual pod, not on the total volume contained in the package.
2. A package containing 4 pods, with each pod containing 1.5 mL of vaping liquid, which is intended for sale in a specified vaping province, attracts $4 of vaping duty ($1 per 1.5 mL pod) **plus** $4 of additional vaping duty ($1 per 1.5 mL pod), for a total of $8 of duty.
3. A 30 mL bottle of vaping liquid, which is intended for sale in a province which is **not** a specified vaping province, attracts $7 of vaping duty ($5 for the first 10 mL plus $2 for the next 20 mL).
4. A 30mL bottle of vaping liquid, which is intended for sale in a specified vaping province, attracts $7 of vaping duty ($5 for the first 10 mL plus $2 for the next 20 mL) **plus** $7 of additional vaping duty ($5 for the first 10 mL plus $2 for the next 20 mL), for a total of $14 of duty.

Notice to the reader: Budget 2024 announced increases to the rates for vaping duty and additional vaping duty. Effective July 1, 2024 the rates will be the following:

Vaping duty

* $1.12 per 2 millilitres (mL), or fraction thereof, for the first 10 mL of vaping substance in the vaping device or immediate container
* $1.12 per 10 mL, or fraction thereof, for amounts over the first 10 mL

Additional vaping duty

* $1.12 per 2 millilitres (mL), or fraction thereof, for the first 10 mL of vaping substance in the vaping device or immediate container
* $1.12 per 10 mL, or fraction thereof, for amounts over the first 10 mL

The same rates above apply to vaping solids on a per gram basis.

## How to report

For vaping products stamped in Canada, a vaping product licensee must report and pay (remit) the vaping duty and any additional vaping duty payable using Form [B600, Vaping Duty and Information Return](/en/revenue-agency/services/forms-publications/forms/b600.html). Form B600 and any corresponding duty remittance for a given month (that is, a reporting period) are due by the last day of the calendar month following the reporting period.

The vaping duty and any additional vaping duty payable on stamped vaping products imported into Canada is reported and paid to the CBSA upon importation.

## What records to keep

You must keep all records that will support the information you provide on your Form B600. This includes the amount of vaping products manufactured, received, used, packaged, stamped, re-worked, sold, exported and disposed of.

You must also be able to support the vaping duty and any additional vaping duty that you reported as payable.

You must keep your records for a period of at least **6 years** from the end of the last year to which they relate.

## Additional information

For more information, see [EDN82 Calculation of Vaping Duty](/en/revenue-agency/services/forms-publications/publications/edn82.html) or EDN96, Additional Vaping Duty.

If you have further questions, contact your regional excise office. For the contact information of the regional excise offices: [Contact Information – Excise Duty, Excise Taxes, Fuel Charge, and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html).

## Page details

Date modified:
:   2024-06-24
