3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* Applying for a vaping product licence
* [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Applying for a vaping product licence

## On this page

* [Who must apply](#h-1)
* [Eligibility conditions](#h-2)
* [How to apply](#h-3)
* [After you apply](#h-4)
* [Additional Information](#h-5)

## Who must apply

You must apply for a vaping product licence under the Excise Act, 2001 if you intend to manufacture vaping products in Canada or if you intend to apply vaping excise stamps to imported packaged vaping products in Canada.

Manufacturing includes **any** step in the production of the vaping product. This includes:

* blending or mixing vaping substances
* inserting a vaping substance into a vaping device
* any step in packaging the vaping product

### What do you require for your vaping business?

Will you be manufacturing or stamping vaping products in Canada?

**Note:** Manufacturing includes **any** step in the production of a vaping product, including inserting a vaping substance into a vaping device or packaging the vaping product.

* Yes

  You require a vaping product licence.

  Are you also importing vaping products into Canada?

  + Yes

    **Note:** If you already qualify for a vaping product licence, you are able to obtain stamps under this licence for application prior to importation. No vaping prescribed person registration is needed.

    You do not require any further licence or registration.

    Are you importing unfinished/unpackaged vaping products into Canada for further manufacturing?

    - Yes

      **Note:** In order to import non-duty-paid, unfinished/unpackaged vaping products into Canada for further manufacturing, you must have a valid vaping product licence. You will provide this information to the Canada Border Services Agency upon importation.

      You do not require any further licence or registration.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
    - No

      You do not require any further licence or registration.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
  + No

    You do not require any further licence or registration.

    Are you importing unfinished/unpackaged vaping products into Canada for further manufacturing?

    - Yes
    - No
* No

  Will you be importing vaping products into Canada?

  + Yes

    You require to be registered as a vaping prescribed person for the purposes of obtaining vaping excise stamps.

    Will you be stamping the vaping products prior to importation or in Canada (or both)?

    - Stamping In Canada (or both)

      You require a vaping product licence.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
    - Stamping Prior to importation

      You are required to become a vaping prescribed person for the purposes of obtaining vaping excise stamps.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
  + No

Will you be stamping the vaping products prior to importation or in Canada (or both)?

No licence or registration is required.

You do not require any further registration.

You do not require any further registration.

**Note:** In order to import non-duty-paid, unfinished/unpackaged vaping products into Canada for further manufacturing, you must have a valid vaping product licence. You will provide this information to the Canada Border Services Agency upon importation.

You may require an excise warehouse licence

**Note:** If you require more information on whether or not you require an excise warehouse licence, please contact your regional excise office [CONTACTS Contact Information – Excise and Specialty Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts.html)

If you will **only** be importing packaged, **stamped** vaping products into Canada, refer to [Applying as an importer of stamped vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html).

You **do not** have to apply for a licence if either of the following situations apply:

* You are not manufacturing or stamping vaping products in Canada
* You are manufacturing vaping products only for your personal use

If you will be exporting vaping products or selling vaping products to an accredited representative for their personal use, you may also require an excise warehouse licence.

Unstamped, packaged vaping products that are entered into an excise warehouse for the purpose of exporting or selling to an accredited representative, must have the appropriate vaping product markings as outlined in the Stamping and Marking of Tobacco, Cannabis, and Vaping Products Regulations. For more information, refer to [EDN 83 Vaping Product Marking Requirements](/en/revenue-agency/services/forms-publications/publications/edn83.html).

You may apply for your excise warehouse licence on the same application as your vaping product licence using [Form L600 Vaping Product Licence Application.](/en/revenue-agency/services/forms-publications/forms/l600.html)

If you will be packaging vaping products intended for the Canadian duty-paid market, or will be importing packaged vaping products for stamping in Canada, you must also register for the vaping stamping regime. For more information, see [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html).

### Licences are valid for up to 3 years

The vaping product licence is valid for a maximum of 3 years. Your licence will **not** be automatically renewed. To renew your licence, you must apply for a licence renewal using [Form L600 Vaping Product Licence Application](/en/revenue-agency/services/forms-publications/forms/l600.html) no later than 30 days before the expiration date of your current licence. You must continue to meet the requirements of the licence throughout the period you are licensed.

## Eligibility conditions

To apply for or renew a vaping product licence, you must meet **all** of the following conditions:

* You are not the subject of a receivership of your debts
* You have not failed to comply with any Act of Parliament (other than the Excise Act, 2001) or of a provincial or territorial legislature that deals with the taxation or control of alcohol, tobacco products, cannabis products or vaping products, or any regulations under it in the past 5 years
* You have not acted to defraud His Majesty in the past 5 years
* Each individual involved must be at least 18 years of age
* You must have a valid business address in Canada
* You must have sufficient financial resources to conduct your business in a responsible manner

You must also provide the following:

* A list of all premises that will be manufacturing or stamping vaping products
* A business plan (including a business industry overview, operating plan, financial plan or source of funds, and a sales and marketing plan)
* Acceptable financial security

### Financial security requirement

The minimum amount of financial security required for a vaping product licence is $5,000 and the maximum financial security amount is $5 million.

For more information on how to calculate security refer to [EDN79 Obtaining and Renewing a Vaping Product Licence](/en/revenue-agency/services/forms-publications/publications/edn79.html).

## How to apply

To apply for a vaping product licence use [Form L600, Vaping Product Licence Application](/en/revenue-agency/services/forms-publications/forms/l600.html).

You may also need to attach the following to support your vaping product licence application:

* [Form L600-A, Schedule A – Other Business Locations](/en/revenue-agency/services/forms-publications/forms/l600-a.html)
* [Form L600-B, Schedule B – Information Relating to Individuals, Partners, Directors, Officers, or Shareholders](/en/revenue-agency/services/forms-publications/forms/l600-b.html)
* [Form L601, Registration for Vaping Stamping Regime](/en/revenue-agency/services/forms-publications/forms/l601.html)
* [Form L602, Surety Bond for Vaping Product Licensee](/en/revenue-agency/services/forms-publications/forms/l602.html)

## After you apply

We will review your application to determine if you are eligible for a vaping product licence based on the information provided on your Form L600. We may contact you if we need more information.

Upon meeting the eligibility criteria, we will send you confirmation of your CRA vaping product licence approval and give you your new excise duty program account number and vaping licence number.

### Your responsibilities as a vaping product licensee

As a vaping product licensee, you must:

* Register for the vaping stamping regime (if you are packaging or stamping vaping products for sale in the Canadian duty-paid market). See [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* Be accountable for all of the vaping excise stamps issued to you. You may be liable to a penalty for any stamps that are unaccounted for
* Calculate the vaping duty and any additional vaping duty imposed on vaping products. See [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* File a monthly [B600 Vaping Duty and Information Return](/en/revenue-agency/services/forms-publications/forms/b600.html), which includes the following:
  + Reporting your unpackaged vaping product inventory
  + Reporting your packaged vaping product inventory
  + Reporting your stamp inventory
  + Reporting and remitting the duty payable (See [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html))
* Keep all your supporting documents for at least 6 years to support all aspects of your operations
* Apply for a licence renewal at least 30 days before the expiry of your licence (the expiry date of your licence will be indicated in your licensing letter)
* Tell your regional excise office immediately if any information you provided in your licence application has changed or is no longer accurate.

### Changes to your vaping product licence

The CRA can suspend or cancel your licence if you no longer meet the conditions to be a licensee.

If a change of legal entity occurs (for example, a proprietorship incorporates), you would have to apply for a new licence using Form L600 and your existing vaping product licence would be cancelled.

For more information refer to [EDN 79 Obtaining and Renewing a Vaping Product Licence](/en/revenue-agency/services/forms-publications/publications/edn79.html).

### Additional information

For more information, refer to [EDN79 Obtaining and Renewing a Vaping Product Licence](/en/revenue-agency/services/forms-publications/publications/edn79.html).

If you have further questions, contact your regional excise duty office. [Contact Information – Excise Duty, Excise Taxes, Fuel Charge, and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html)

## Page details

Date modified:
:   2024-06-24
