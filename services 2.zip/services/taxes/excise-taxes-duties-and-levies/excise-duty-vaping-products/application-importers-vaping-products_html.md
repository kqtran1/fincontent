3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)
4. [Excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products.html)

# Excise duty for vaping products

* [Applying for a vaping product licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
* Applying as an importer of stamped vaping products
* [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* [Calculating excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
* [Reporting and remitting the excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html)
* [Completing a vaping duty and information return – vaping product licensee](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
* [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* [Completing an application for a refund of vaping duty](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)

# Applying as an importer of stamped vaping products

## On this page

* [Who must apply](#h-1)
* [Eligibility conditions](#h-2)
* [How to apply](#h-3)
* [After you apply](#h-4)
* [Additional information](#h-5)

## Who must apply

If you import stamped vaping products into the Canadian duty-paid market, and do not manufacture or stamp vaping products in Canada, you must apply to be a vaping prescribed person in order to obtain vaping excise stamps to affix to your products.

As a vaping prescribed person, packaged vaping products must be stamped prior to importation into Canada. If an imported vaping product intended for the duty-paid market is not stamped prior to importation, it must be entered into a sufferance warehouse for the purpose of being stamped. Sufferance warehouses are licensed by the Canada Border Services Agency. For more information, see [Sufferance warehouses](https://www.cbsa-asfc.gc.ca/import/codes/menu-eng.html).

**Exception**

If you will be importing stamped vaping products, but will also be manufacturing or stamping vaping product in Canada, you must get a vaping product licence.

You do **not** also need to apply to be a vaping prescribed person.

For more information: [Applying for a Vaping Product Licence](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html).

### What do you require for your vaping business?

Will you be manufacturing or stamping vaping products in Canada?

**Note:** Manufacturing includes **any** step in the production of a vaping product, including inserting a vaping substance into a vaping device or packaging the vaping product.

* Yes

  You require a vaping product licence.

  Are you also importing vaping products into Canada?

  + Yes

    **Note:** If you already qualify for a vaping product licence, you are able to obtain stamps under this licence for application prior to importation. No vaping prescribed person registration is needed.

    You do not require any further licence or registration.

    Are you importing unfinished/unpackaged vaping products into Canada for further manufacturing?

    - Yes

      **Note:** In order to import non-duty-paid, unfinished/unpackaged vaping products into Canada for further manufacturing, you must have a valid vaping product licence. You will provide this information to the Canada Border Services Agency upon importation.

      You do not require any further licence or registration.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
    - No

      You do not require any further licence or registration.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
  + No

    You do not require any further licence or registration.

    Are you importing unfinished/unpackaged vaping products into Canada for further manufacturing?

    - Yes
    - No
* No

  Will you be importing vaping products into Canada?

  + Yes

    You require to be registered as a vaping prescribed person for the purposes of obtaining vaping excise stamps.

    Will you be stamping the vaping products prior to importation or in Canada (or both)?

    - Stamping In Canada (or both)

      You require a vaping product licence.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
    - Stamping Prior to importation

      You are required to become a vaping prescribed person for the purposes of obtaining vaping excise stamps.

      Will you be exporting vaping products or selling vaping products to accredited representatives?

      * Yes
      * No
  + No

Will you be stamping the vaping products prior to importation or in Canada (or both)?

No licence or registration is required.

You do not require any further registration.

You do not require any further registration.

**Note:** In order to import non-duty-paid, unfinished/unpackaged vaping products into Canada for further manufacturing, you must have a valid vaping product licence. You will provide this information to the Canada Border Services Agency upon importation.

You may require an excise warehouse licence

**Note:** If you require more information on whether or not you require an excise warehouse licence, please contact your regional excise office [CONTACTS Contact Information – Excise and Specialty Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts.html)

You must also register for the vaping stamping regime before importing any stamped vaping products into Canada. For more information: [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html).

## Eligibility conditions

To apply to be a vaping prescribed person in order to get vaping excise stamps, you must meet **all** of the following conditions:

* You are not the subject of a receivership of your debts
* You have not failed to comply with any Act of Parliament (other than the Excise Act, 2001) or of a provincial or territorial legislature that deals with the taxation or control of alcohol, tobacco products, cannabis products, or vaping products, or any regulations under it in the past 5 years
* You have not acted to defraud His Majesty in the past 5 years
* Each individual involved must be at least 18 years of age
* You must have sufficient financial resources to conduct your business in a responsible manner

You must also provide the following:

* A list of the locations where vaping excise stamps are proposed to be shipped
* The address where books and records will be maintained to account for the vaping excise stamps issued, used on imported products, and/or destroyed
* A business plan (including a business industry overview, operating plan, financial plan or source of funds, and a sales and marketing plan)
* Acceptable financial security

### Financial security requirement

The minimum amount of financial security required for a vaping prescribed person is $5,000. The maximum financial security would be $5 million.

For more information refer to [EDN81 Becoming a Vaping Prescribed Person](/en/revenue-agency/services/forms-publications/publications/edn81.html).

## How to apply

To apply to be a vaping prescribed person, use [Form L603, Vaping Prescribed Person Application](/en/revenue-agency/services/forms-publications/forms/l603.html).

You may also need to attach the following to support your application:

* [Form L600-B, Schedule B – Information Relating to Individuals, Partners, Directors, Officers, or Shareholders](/en/revenue-agency/services/forms-publications/forms/l600-b.html)
* [Form L601, Registration for Vaping Stamping Regime](/en/revenue-agency/services/forms-publications/forms/l601.html)
* [Form L604, Surety Bond for Vaping – Prescribed Person](/en/revenue-agency/services/forms-publications/forms/l604.html)

## After you apply

We will review your application to determine if you are eligible to be a vaping prescribed person based on the information provided on your Form L603. We may contact you if we need more information.

Upon meeting the eligibility criteria, we will send you confirmation that  you meet the conditions to be a vaping prescribed person and give you your new excise duty program account number.

### Your responsibilities as a vaping prescribed person

As a vaping prescribed person, you must:

* Register for the vaping stamping regime. See [Registering for the vaping stamping regime](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
* File a monthly [B601 Vaping Information Return – Prescribed Person](/en/revenue-agency/services/forms-publications/forms/b601.html), which includes reporting your stamp inventory. See [Completing a vaping information return – prescribed person](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
* Keep all your supporting documents for at least 6 years to support all aspects of your stamp usage
* Be accountable for all of the vaping excise stamps issued to you. You may be liable to a penalty for any stamps that are unaccounted for
* Remit the vaping duty and any additional vaping duty on imported stamped vaping products to the Canada Border Services Agency at the time of importation
* Tell your regional excise office immediately if any information you provided in your application has changed or is no longer accurate.

### Effect and duration

A vaping prescribed person registration is effective from the date indicated in the letter of approval and it remains effective until the person either requests to cancel it or no longer qualifies to be a vaping prescribed person.

## Additional information

For more information, see [EDN81 Becoming a Vaping Prescribed Person](/en/revenue-agency/services/forms-publications/publications/edn81.html).

If you have further questions, contact your regional excise duty office. For the contact information of the regional excise duty offices: [Contact Information – Excise Duty, Excise Taxes, Fuel Charge, and Air Travellers Security Charge](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html).

## Page details

Date modified:
:   2024-06-24
