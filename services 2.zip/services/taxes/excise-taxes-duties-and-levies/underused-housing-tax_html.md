3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)

# Underused Housing Tax

The Underused Housing Tax (UHT) is an **annual federal** 1% tax on the ownership of vacant or underused housing in Canada that took effect on January 1, 2022.

The UHT generally applies to [foreign national](#Y) owners of housing in Canada. However, in some situations, the UHT also applies to some Canadian owners (such as certain partners, trustees, and corporations).

Provincial and municipal vacancy taxes

You may have heard about a new vacancy tax in certain provinces and municipalities in Canada. These vacancy taxes have been implemented by  **provincial** and  **municipal** governments and are different than the  **federal** Underused Housing Tax.

You must determine if you are affected by each of these taxes separately. If you are exempt from one tax, you may still be required to file a return and pay the other tax.

The CRA is not able to answer questions about taxes implemented by provincial and municipal governments.

[Determine if you are an affected owner for the Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html#determine)

## Sections

[What has changed](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/what-has-changed.html)
:   Changes to the UHT that affected the 2023 and onward calendar years and the 2022 calendar year

[Who must file a return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/who-file-pay.html)
:   Understand what an affected or excluded owner is

[Determine your responsibilities](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/determine-your-responsibilities.html)
:   Interactive tool to help you decide if you need to file, exemptions from paying the UHT

[When to file the return and pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/when-file.html)
:   Due date, penalties and interest

[How to complete the return and calculate the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/complete-return.html)
:   Filling out the return, keeping records

[File the return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/file-return.html)
:   Where to send the return

[Pay the tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/pay-tax.html)
:   Payment methods for individuals and corporations

[Amend your return](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/amend-return.html)
:   How to submit an amended return

[Contact us](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/contact.html)
:   If you have questions about the UHT

## Resources

* [Multimedia toolkit - Factsheets and promotional material](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-multimedia-toolkit.html)
* [Technical information](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax/underused-housing-tax-technical-information.html)

## Foreign national

A foreign national is an individual who is not a Canadian citizen or permanent resident.

## Page details

Date modified:
:   2025-04-04
