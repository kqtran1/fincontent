3. [Excise and specialty taxes](/en/services/taxes/excise-taxes-duties-and-levies.html)

# Excise duty on vaping products

An excise duty on vaping products was implemented on October 1, 2022 through the introduction of a new excise duty framework. The excise duty applies to vaping substances that are manufactured in Canada or imported and that are intended for use in a vaping device in Canada.

Manufacturers of vaping products are required to get a vaping product licence from the CRA. Importers who choose to apply the vaping excise stamp in Canada are also required to get a vaping product licence from the CRA. Importers who are exclusively applying the vaping excise stamp prior to importation are required to apply to become a vaping prescribed person with the CRA.

Manufacturers and importers are also required to register for the vaping stamping regime. All vaping products entering the Canadian duty-paid market are required to be packaged and stamped with an appropriate vaping excise. The excise stamp shows that duties have been paid.

The information described on this webpage is based on the Excise Act, 2001 and its regulations.

To learn how the excise duty on vaping products affects retailers and consumers, use the PDFs below.

* [Message to vaping retailers (PDF, 133 KB)](/content/dam/cra-arc/serv-info/tax/vpng_xcs_nfgrphc_rtlr-e.pdf)
* [Message to consumers of vaping products (PDF, 130 KB)](/content/dam/cra-arc/serv-info/tax/vpng_xcs_cnsmr_nfgrphc-e.pdf)

## Sections

[Applying for a vaping product licence: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/applying-vaping-product-licence.html)
:   Who must apply, eligibility conditions, how to apply, after you apply

[Applying as an importer of stamped vaping products: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/application-importers-vaping-products.html)
:   Who must apply, eligibility conditions, how to apply, after you apply

[Registering for the vaping stamping regime: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/registering-vaping-stamping-regime.html)
:   Overview, who must register, how to register, after you register

[Calculating excise duty on vaping products: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/calculating-vaping-duty.html)
:   Who must pay, how to calculate, how to report, what records to keep

[Reporting and remitting excise duty on vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/reporting-remitting-vaping-duty.html): Excise duty for vaping products
:   Who must file and when, how to file and pay, after sending a return, filing or paying late, what records to keep

[Completing a vaping duty and information return – vaping product licensee: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-duty-info-return-vaping-product-licensee.html)
:   How to complete the B600 Vaping Duty and Information Return

[Completing a vaping information return – prescribed person: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-vaping-information-return-prescribed-person.html)
:   How to complete the B601 Vaping Information Return – Prescribed Person

[Completing an application for a refund of vaping duty: Excise duty for vaping products](/en/services/taxes/excise-taxes-duties-and-levies/excise-duty-vaping-products/completing-application-refund-vaping-duty.html)
:   How to complete the B602, Application for a Refund of Vaping Duty

## Related Information

* [Bill C-59, Fall Economic Statement Implementation Act, 2023](https://www.parl.ca/DocumentViewer/en/44-1/bill/C-59/first-reading)
* [Excise Act, 2001](https://laws-lois.justice.gc.ca/eng/acts/E-14.1/index.html)
* [Excise duties technical information](/en/revenue-agency/services/tax/technical-information/excise-duty.html)
* [Excise duty notices under the Excise Act, 2001](/en/revenue-agency/services/tax/technical-information/excise-duty/excise-duty-notices.html#nvp)
* [Excise duty forms under the Excise Act, 2001](/en/revenue-agency/services/tax/technical-information/excise-duty/excise-duty-forms.html#_Forms_relating_to_4)
* [Contact Information – Excise and Specialty Tax Directorate](/en/revenue-agency/services/forms-publications/publications/contacts/excise-taxes-contacts.html)

## Page details

Date modified:
:   2025-01-02
