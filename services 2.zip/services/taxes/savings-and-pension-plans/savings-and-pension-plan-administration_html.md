3. [Savings and pension plans](/en/services/taxes/savings-and-pension-plans.html)

# Savings and pension plan administration

Annual limits, administrative procedures for registered plans, and links to bulletins, newsletters, and manuals.

![](/content/dam/themes/taxes/features/savings-and-pension-plans/cra-rfi-261.jpg)

## Services and information

### [What's new](/en/revenue-agency/services/tax/registered-plans-administrators/whats-new.html)

See the latest changes affecting savings and pension plans.

### [Annual limits](/en/revenue-agency/services/tax/registered-plans-administrators/pspa/mp-rrsp-dpsp-tfsa-limits-ympe.html)

Annual limits for deferred income and savings plans.

### [First home savings account administration](/en/revenue-agency/services/tax/registered-plans-administrators/first-home-savings-account.html)

Access administrative procedures and updates for the first home savings account (FHSA).

### [Registered pension plans administration](/en/revenue-agency/services/tax/registered-plans-administrators/about-registered-pension-plans-rpps.html)

Access registered pension plan updates, administrative procedures, and information from consultation sessions.

### [Registered education savings plans administration](/en/revenue-agency/services/tax/registered-plans-administrators/registered-education-savings-plans-resps.html)

Access registered education savings plan updates, administrative procedures, and information from consultation sessions.

### [Registered disability savings plans administration](/en/revenue-agency/services/tax/registered-plans-administrators/registered-disability-savings-plans-rdsps.html)

Access registered disability savings plan updates, administrative procedures, declaration of trust, and withholding tax.

### [Registered retirement savings plans and registered retirement income funds administration](/en/revenue-agency/services/tax/registered-plans-administrators/registered-retirement-savings-plans-registered-retirement-income-funds-rrsps-rrifs.html)

Access registered retirement savings plan and registered retirement income fund updates, and administrative procedures.

### [Registered investments administration](/en/revenue-agency/services/tax/registered-plans-administrators/registered-investments.html)

Access registered investment updates and listings published in the Canada Gazette.

### [Deferred profit sharing plan administration](/en/revenue-agency/services/tax/registered-plans-administrators/deferred-profit-sharing-plans.html)

Access deferred profit sharing plans updates, and administrative procedures.

### [Tax-free savings account administration](/en/revenue-agency/services/tax/registered-plans-administrators/tax-free-savings-account-tfsa.html)

Access tax-free savings account updates, and administrative procedures.

### [Pooled registered pension plans administration](/en/revenue-agency/services/tax/registered-plans-administrators/pooled-registered-pension-plans-prpps.html)

Access pooled registered pension plan updates, and administrative procedures.

### [Supplementary Unemployment Benefit Plans](/en/revenue-agency/services/tax/registered-plans-administrators/supplementary-unemployment-benefit-plans.html)

Access supplementary unemployment benefit plans updates, and administrative procedures.

### [Registered Plans related forms and publications](/en/revenue-agency/services/tax/registered-plans-administrators/forms-publications.html)

Forms, guides, information circulars, and income tax folios for savings and pension plans.

### [Contact the Registered Plans Directorate](/en/revenue-agency/services/tax/registered-plans-administrators/contact-registered-plans-directorate.html)

Find all the contact information for the Registered Plans Directorate.

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-01-31
