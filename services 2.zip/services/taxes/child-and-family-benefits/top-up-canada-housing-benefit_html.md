---
source_url: https://www.canada.ca/en/services/taxes/child-and-family-benefits/top-up-canada-housing-benefit.html
scraped_at: 2025-08-24 12:29:04
filename: en/services/taxes/child-and-family-benefits/top-up-canada-housing-benefit_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About government"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/impots/prestations-pour-enfants-et-familles/supplement-allocation-canadienne-logement.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](/en.html)

## Search

Search

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://www.international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Manage life events](https://www.canada.ca/en/services/life-events.html)

## Sign in

[Sign inCRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)

## You are here:

1. [Canada.ca](/en.html)
2. [Canada Revenue Agency (CRA)](/en/revenue-agency.html)
3. [Support from the CRA during difficult situations](/en/revenue-agency/services/support-difficult-situations.html)

# One-time top-up to the Canada Housing Benefit - Closed

Status: Closed

The one-time top-up to the Canada Housing Benefit helped low-income renters with the cost of renting. The Canada Revenue Agency (CRA) administered this one-time payment.

If your income and the amount you paid on rent qualified, you may have been eligible to apply for a tax-free one-time payment of $500.

Applications were open from December 12, 2022 to March 31, 2023.

## On this page

* [Impacts on taxes and other benefits](#toc0)
* [Verifying your eligibility](#toc1)

## Impacts on taxes and other benefits

The payment was **not** taxable. This means you did not need to report the **one-time** payment on your income tax return.

The one-time top-up to the Canada Housing Benefit did **not** reduce other federal income-tested benefits such as the Canada Workers Benefit, Canada Child Benefit, Goods and Services Tax Credit, and Guaranteed Income Supplement. Impacts on provincial or territorial benefits were determined at the discretion of each province or territory.

## Verifying your eligibility

The CRA routinely checks to confirm that recipients were entitled to the payment they received.

If you received a payment and are later found to be ineligible, you will be contacted to make arrangements to return the payment. If you are found to have misrepresented or concealed information to make a fraudulent claim, additional consequences and penalties may also be applied.

You can report suspected misuse through the [CRA's Leads program](/en/revenue-agency/programs/about-canada-revenue-agency-cra/suspected-tax-cheating-in-canada-overview.html).

## Page details

Date modified:
:   2025-06-26
