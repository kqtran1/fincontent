3. [Tax credits and benefits for individuals](/en/services/taxes/child-and-family-benefits.html)

# GST/HST break - Closed

Status: Closed

There was a temporary **GST/HST break** on certain items **from December 14, 2024, to February 15, 2025**. During the tax break, no GST or HST (whichever applied in your province or territory) was charged on qualifying items.

## On this page

* [Which types of items qualified for the GST/HST break](#toc0)
* [How you got this tax break on your purchases](#toc1)
  + [If you were charged GST/HST in error](#toc2)
* [As a business that charges the GST/HST](#toc3)
* [Related information](#toc4)

## Which types of items qualified for the GST/HST break

**No GST/HST** was charged on certain qualifying items from December 14, 2024, to February 15, 2025.

Types of items that qualified for the GST/HST break

| Type of qualifying product or service | Details, examples, and restrictions |
| --- | --- |
| Food | [Details, examples, and restrictions of food](#food "Food definition") Updated: December 11, 2024 |
| Beverages | [Details, examples, and restrictions of Beverages](#beverages "Beverages definition") Updated: December 11, 2024 |
| Restaurants, catering, and other food or drink establishments | [Details, examples, and restrictions of Restaurants, catering, and other food or drink establishments](#restaurant) Updated: December 6, 2024 |
| Children's clothing and footwear | [Details, examples, and restrictions of children's clothing and footwear](#clothing "Children's clothing and footwear definition") Updated: December 17, 2024 |
| Children's diapers | [Details, examples, and restrictions of children's diapers](#diapers "Children's diapers definition") |
| Children's car seats | [Details, examples, and restrictions of children's car seats](#carseats "Children's car seats definition") |
| Children's toys | [Details, examples, and restrictions of children's toys](#toys "Children's toys definition") Updated: December 17, 2024 |
| Jigsaw puzzles | New or used jigsaw puzzles for all ages qualified Updated: December 17, 2024 |
| Video game consoles, controllers, and physical video games | [Details, examples, and restrictions of children's video game consoles, controllers, and games](#videogames "Children's video game consoles, controllers, and games definition") Updated: December 17, 2024 |
| Physical books | [Details, examples, and restrictions of printed books](#books "Printed books definition") Updated: December 17, 2024 |
| Printed newspapers | [Details, examples, and restrictions of printed newspapers](#newspapers "Printed newspapers definition") |
| Christmas and similar decorative trees | [Details, examples, and restrictions of Christmas trees and similar decorative trees](#trees "Christmas trees and similar decorative trees definition") Updated: December 17, 2024 |

**No GST/HST** was charged on a qualifying item, as long as was **both**:

* **Paid for in full** between December 14, 2024, and February 15, 2025
  What "paid for in full" means for partial payments

  **Partial payments** for a qualifying item must have **all been made** between December 14, 2024, and February 15, 2025. However, there was an exception for deposits.

  If a **deposit** was paid on a qualifying item before December 14, 2024, the item still qualified as long as:

  + The entire remaining amount was paid between December 14, 2024, and February 15, 2025
  + The item was delivered (or made available) between December 14, 2024, and February 15, 2025
* **Delivered** or **made available** to the buyer between December 14, 2024, and February 15, 2025
  What "delivered" means for shipped items

  Generally, deliveries to consumers (such as most online shopping) are shipped **on behalf of the seller**. This means we consider those items delivered when **the item arrives at the destination address**.

  However, under a special rule included in the measure, if a supplier:

  + Used a shipping service (common carrier or consignee) for delivery **on behalf of the recipient**, we consider the item to have been delivered to the recipient at the time **the supplier transferred the item to the shipping service**
  + Sent the item by mail or courier to the recipient, we consider the item to have been delivered to the recipient at the time **the supplier mailed the item or transferred it to the courier**

The items that qualified for GST/HST relief during this period qualified **throughout the supply chain**, whether they were supplied from a manufacturer to a wholesaler, or from a wholesaler or a retailer to a consumer.

### Items purchased and imported from other countries

Goods that were imported during the GST/HST break qualified for the temporary GST/HST relief as long as they met the other qualifying conditions.

**Refer to:** [GST/HST break on imported items - Canada Border Services Agency (CBSA)](https://www.cbsa-asfc.gc.ca/import/tax-break-allegement-eng.html)

## How you got this tax break on your purchases

**You should have automatically received this tax break from the seller** on the qualifying items you purchased between December 14, 2024, and February 15, 2025. GST/HST should not have been charged on the qualifying items when you made your purchase, whether you made a purchase as an **individual** or in a **business-to-business** transaction.

Example: How the GST/HST break worked

A supplier sold a child’s car seat to a retailer on December 20, 2024, and did not charge tax. There was no GST/HST payable because a child’s car seat was a qualifying item (zero-rated). The retailer then sold the child’s car seat to an individual on December 24, 2024, and did not charge the tax. No GST/HST was charged, collected, or paid.

### 1. Supplier/manufacturer

* Sold a qualifying item
* Did not charge GST/HST

### 2. Retailer/restaurant

* Sold a qualifying item
* Did not charge GST/HST

### 3. Individual consumer

* Purchased a qualifying item
* Was not charged GST/HST

### If you were charged GST/HST in error

Do **not** call the CRA if you were charged the GST/HST in error.

If you believe you were charged GST/HST on a product that qualified for GST/HST relief, you should:

* Gather your receipts
* Request a refund of the GST/HST from the seller

If you cannot get a refund or credit from the seller

If the supplier, manufacturer or retailer does not provide a refund for the amount or is no longer in business, you can then apply for a GST/HST rebate for the amount of the GST/HST charged to you in error.

The item you were charged GST/HST on must be a [qualifying item you purchased between December 14, 2024, and February 15, 2025](#toc0).

#### How to apply for a GST/HST rebate

The minimum amount you can claim for a GST/HST rebate is $2. You must file your rebate application **within 2 years** after the date of your purchase.

You must **include the receipts** and other pertinent information in your application. Your rebate claim may be delayed or denied if the documents required are not sent with your application.

To minimize processing time and to reduce the number of times we may need to speak with you about your claim, **we recommend that you keep all your receipts and submit one claim** after the GST/HST break period is over. In any case, you can send only one application per calendar month.

**Individuals** can apply online using [their CRA account](/en/revenue-agency/services/e-services/cra-login-services.html).

Follow the instructions: [How to apply – Form GST189: Rebate under reason code 1C - GST/HST break](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/gst-hst-rebates/reason-code-1c-tax-break/file.html)

Example: An individual was incorrectly charged GST/HST

A supplier sold a child’s car seat to a retailer on December 20, 2024, and did not charge tax. There was no GST/HST payable because a child’s car seat was a qualifying item (zero-rated). The retailer then sold the child’s car seat to an individual on December 24, 2024, but charged GST/HST on the item. The individual requests a refund from the retailer but is unable to obtain the refund. The individual would then apply for a rebate.

#### 1. Retailer/restaurant

* Sold a qualifying item
* **Incorrectly** charged and remitted GST/HST for the item

#### 2. Consumer/individual (not registered for GST/HST)

* Requests a refund of the GST/HST from the seller
* Claims a GST/HST rebate using code 1C, “amounts paid in error”

**GST/HST registrants** can apply online using [their CRA account](/en/revenue-agency/services/e-services/cra-login-services.html). You must include receipts or other proof of delivery and payment. We recommend that you include your claim with your regular GST/HST return. You **cannot** claim an input tax credit for tax paid in error.

Follow the instructions: [How to apply – Form GST189: Rebate under reason code 1C - GST/HST break](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/gst-hst-rebates/reason-code-1c-tax-break/file.html)

Example: A business was incorrectly charged GST/HST by another business

A manufacturer sold a child’s car seat to a retailer (business) on December 20, 2024, and incorrectly charged tax to the retailer. There was no GST/HST payable because a child’s car seat was a qualifying item (zero-rated). The business requests a refund from the supplier, but the supplier informs the business that the tax has already been remitted to the CRA. The business would then apply for a rebate using Form GST189: Rebate under reason code 1C – GST/HST break, "amounts paid in error", and include the form with their regular GST/HST return.

#### 1. Supplier/manufacturer

* Sold a qualifying item
* **Incorrectly** charged and remitted GST/HST for the item

#### 2. Retailer/restaurant

* Requests a refund of the GST/HST from the supplier
* Claims a GST/HST rebate under code 1C

#### After you apply

All GST/HST rebates will be subject to an eligibility review. GST/HST rebates are expected to exceed normal processing times of 12 weeks to 16 weeks.

Do not call the CRA to get an update on your claim. Our contact centre agents will not have access to your file and will not be able to give you an update.

Follow the instructions: [After you apply - Form GST189: Rebate under reason code 1C - GST/HST break](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/gst-hst-rebates/reason-code-1c-tax-break/after.html)

## As a business that charges the GST/HST

What to do as a business that charges the GST/HST:

* [After the GST/HST break ends](#h3_1)
* [During the GST/HST break](#h3_2)
* [Efforts to comply and compliance actions](#h3_3)

### After the GST/HST break ends

Starting at 12:01 am (local time of the business) on February 16, 2025, **resume charging the GST/HST** on the qualifying goods and services listed above.

Keep your records and remit and report your regular GST/HST as usual.

To get important GST/HST break news and industry-specific **updates by email**, you can [sign up for CRA’s stakeholder message electronic mailing list](/en/revenue-agency/news/e-services/canada-revenue-electronic-mailing-lists/subscribe-a-canada-revenue-agency-electronic-mailing-list/electronic-mailing-list-stakeholder-messages.html).

Businesses can also contact us with technical GST/HST questions that are not answered here by calling 1-800-959-8287.

### During the GST/HST break

From December 14, 2024, to February 15, 2025,  you should **not have charged the GST/HST** on the qualifying goods and services listed above.

Keep your records and remit and report your regular GST/HST as usual.

In detail: zero-rating supplies of the qualifying goods and services

This measure adjusted the *Excise Tax Act* to temporarily zero-rate supplies of the qualifying goods and services during the GST/HST break. Zero-rated means that no GST/HST is charged when the supply is made because the tax rate is 0%.

GST/HST registrants can claim an **input tax credit** for the GST/HST paid or payable on expenses made to provide zero-rated supplies.

### **Related links**

* [How to charge and collect the GST/HST](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-which-rate.html)
* [Claiming input tax credits](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/complete-file-input-tax-credit.html)

Detailed guidance for restaurants and other eating or drinking establishments

The eligibility of food and beverages during the GST/HST break also applied to food and beverages served at restaurants (and other eating establishments):

* [Details, examples, and restrictions of food](#food "Food definition")
* [Details, examples, and restrictions of beverages](#beverages "Beverages definition")

### Prepared meals

Prepared meals and food, as well as all non-alcoholic beverages and eligible alcoholic beverages qualified for GST/HST relief during the eligible period (December 14, 2024, to February 15, 2025) when they were provided at restaurants, pubs, bars, food trucks, and other establishments that served food and/or beverages. Cannabis products that are food or beverages did not qualify for GST/HST relief.

### Food delivery

When an **eating establishment billed a customer directly for delivery** of a prepared meal,  the **delivery service qualified** for the temporary GST/HST relief because it generally has the same tax status as the prepared meal.

However, when a delivered prepared meal was **ordered through a platform**, two separate transactions occurred:

* The prepared meal was provided by the eating establishment to the customer
* A delivery service was provided by the platform provider to the customer

The **prepared meal** provided by the eating establishment to the customer **qualified** for GST/HST relief.

The **delivery service provided by the platform provider** to the customer **did not qualify** for GST/HST relief.

### Orders that included both qualifying and non-qualifying items

GST/HST relief **only applied to the qualifying items** (prepared meals, non-alcoholic beverages and eligible alcoholic beverages) during the GST/HST break.

When customers ordered prepared meals or eligible beverages which qualified for GST/HST relief, the GST/HST did not apply on these items.

However, where a customer ordered alcoholic beverages which did **not** qualify for GST/HST relief (such as spirits and liqueurs), the GST/HST still applied on those items.

### Cocktails and mixed beverages

Some beverages that are mixed **at the establishment** for customers (such as cocktails) may have also qualified for GST/HST relief during the eligible period.

**Mixed drinks that included only eligible beverages** such as beer, malt liquor, or wine, **qualified** for GST/HST relief.

* For example, a mimosa made of sparkling wine and orange juice, or a michelada made of beer and non-alcoholic ingredients qualified

**Mixed drinks that included an alcoholic beverage which did not qualify** for GST/HST relief, such as spirits or liqueurs, **did not qualify** for GST/HST relief.

* For example, a sangria that includes both wine and rum, or a mixed drink such as a vodka and soda, did **not** qualify

### Tips for Prepared Meals

A mandatory tip or gratuity **included as part of the bill** amount to pay has the same tax status as the prepared meal. This kind of tip **qualified** for GST/HST relief during the eligible period.

GST/HST did not apply to a tip or gratuity that was given freely by a customer to an employee of an eating establishment.

### Catering

A catering service generally qualified for GST/HST relief during the eligible period. The catering service must have been for the provision, preparation and serving of food, non-alcoholic beverages or eligible alcoholic beverages to qualify.

Other services that did **not** qualify for GST/HST relief included (but were not limited to):

* Event admission charges
* Facilities hosting fees
* Fees for musicians, disc jockeys or other entertainers
* Chef services where food was prepared and served by a chef but the ingredients to make the meal were not provided by the chef

### Effort to comply and compliance actions

Businesses who made reasonable efforts to comply with the legislation will not be the focus of our compliance actions.

We will be focusing on situations where businesses willfully and egregiously refused to comply with the temporary measures, such as a business that collected the GST/HST and did not remit it to the CRA.

## Related information

* Residents of Québec can find more information the GST/HST break at [GST/HST Break | Revenu Québec](https://www.revenuquebec.ca/en/gst-break/)
* [Questions and Answers about the GST/HST tax break for all Canadians - Canada.ca](/en/revenue-agency/services/forms-publications/publications/notice340/questions-answers-about-gst-hst-tax-break-for-all-canadians.html)

## Children's clothing and footwear

**These new or used items qualified for the temporary GST/HST relief as children's clothing or footwear:**

* Baby clothes, including bibs, bunting blankets, and receiving blankets
* Children's clothes in sizes XS, S, M, or L
* Babies' and children's socks, hats, ties, scarves, belts, suspenders, gloves, and mittens
* Babies' footwear
* Children's footwear with an insole length of 24.25 cm or less
* Sports clothing and dancewear such as jerseys, ski jackets, leotards, unitards, bodysuits, and dual-purpose swimwear that can reasonably be worn outside of sports or dance activities

**These items did not qualify:**

* Specialized clothing and footwear designed exclusively for sports or recreational activities (for example: wetsuits, soccer cleats, bowling shoes, skates, ski boots, tap shoes, pointe shoes)
* Adult clothing and footwear, even if it's purchased for a child
* Costumes and make-up
* Jewellery

## Children's diapers

**Diapers designed for children and babies qualified for the temporary GST/HST relief, including:**

* Cloth or disposable diapers
* Diaper inserts or liners
* Training pants
* Rubber pants designed for use with any of the above items

**These items did not qualify:**

* Children's diapers provided as part of a diaper service
* Adult diapers (even if they are purchased for a child)

Incontinence products specially designed for use by individuals with a disability were already not charged GST/HST.

## Children's car seats

**These items qualified for the temporary GST/HST relief as children's car seats:**

* Restraint systems or booster cushions that conform to the Canada Motor Vehicle Safety Standards:
  + Child restraint systems
  + Infant restraint systems
  + Booster seats
  + Restraint systems for infants with special needs
* In detail: [Motor Vehicle Restraint Systems and Booster Seats Safety Regulations - definitions](https://laws-lois.justice.gc.ca/eng/regulations/sor-2010-90/FullText.html)

**These items did not qualify:**

* Children's car seats and car booster seats that do not meet the Canada Motor Vehicle Safety Standards
* Travel systems, which are a combination of stroller, carrier and car seat sold as a single package

## Children's toys

**New or used children's toys that may have qualified for the temporary GST/HST relief:**

* Games, including:
  + Board games with physical components and rules, including replacement parts and add-on components such as dice
  + Card games, including playing cards and games that include trading cards
* Toys, toy sets and toy systems that either:
  + Imitate another item, whether real or imaginary
  + Involve building, creating or assembling structures, objects or models by using pieces, parts, materials or modelling compound
  + Involve sorting, stacking or organizing pieces, parts or materials
* Dolls, plush toys and soft toys and their accessories

These types of children's toys qualified if they were **intended for children under 14 years old** for learning or play. Toys that were marketed as being for an age below 14 (for example, a toy recommended for children ages 8 and up) would have qualified.

**These items did not qualify:**

* Games and toys that don’t meet the requirements above
* Collectibles that are not intended for play or learning, such as hockey cards or collectible dolls
* Toys and model sets that are marketed for adults (for example, adult construction brick or train sets)

## Physical books

**These new or used items qualified for the temporary GST/HST relief as physical books:**

* Most published, printed books (hardcover or softcover)
* Updates of printed books
* Guide books, and atlases that do not mostly contain street or road maps
* Magazines and periodicals (that have no more than 5% of their printed space devoted to advertising) supplied by subscription, if all the consideration is paid during the relief period and only for those magazines or periodicals that are delivered during the relief period
* Physical audio recordings of printed books, if 90% or more of the recording is a spoken reading of a printed book, including abridged versions (for example, a cassette, compact disc, or reel-to-reel tape version of a published book)
* Physical recordings of a performance of a published play
* Bound or unbound printed versions of scripture of any religion, such as the Quran, the Bible, prayer books, missals, hymn books, and Torah scrolls
* Illustrated versions of religious scriptures (for example, comic book versions)
* Printed books that are wrapped or packaged for sale as a single item with a physical read-only medium that is made up of either a reproduction of the printed book or material that makes specific reference to the printed book
  In detail: printed book packages for students

  If the product is specially designed for use by students enrolled in a qualifying course, a printed book packaged with a read-only medium or a right to access a website, or both of them, that contains material that is related to the subject matter of the printed book also qualifies. Most elementary, secondary and university level courses, as well as certain professional accreditation and vocational courses, are qualifying courses.

  For example, printed books that includes a copy of the full text of the novel on CD-ROM, and textbooks that include a CD-ROM with chapter summaries and interactive quizzes based on the subject material in the book would qualify.

**These items did not qualify:**

* E-books
* Downloadable audio books and e-audio books
* Magazines and periodicals that are not purchased by subscription or that have more than 5% of their printed space devoted to advertising
* Books designed primarily for writing on, such as address books, diaries, journals, and notebooks
* Colouring books, scrapbooks, sticker books, sketchbooks and albums for photographs, stamps or coins
* Brochures, pamphlets, catalogues and advertising material
* Warranty booklets and owner's manuals
* Agendas and calendars
* Certain directories and collections of street or road maps
* Cut-out and press-out books
* Collections of patterns, stencils, or blueprints
* Programs for events or performances
* Rate books
* Recordings of performances of musical scores
* Recordings of unpublished manuscripts
* CD-ROMs, DVDs, and Blu-ray discs with textual or visual information

## Printed newspapers

**A qualifying newspaper that qualified for the temporary GST/HST relief was a printed newspaper that:**

* Contains news, editorials, feature stories, or other information of interest to the general public
* Is published at regular intervals (usually daily, weekly or monthly)

**These items did not qualify:**

* Electronic and digital publications
* Flyers
* Inserts
* Magazines
* Periodicals
* Shoppers

## Video game consoles, controllers, and physical video games

**These new or used items qualified for the temporary GST/HST relief as video game consoles, controllers, and games:**

* Game consoles designed primarily for playing video games
* Controllers designed primarily for playing video games on a qualifying video game console
* Physical video games, in a tangible format designed for the read-only storage of information in digital format, that contains a video game designed for use with a qualifying video game console (for example, game cartridges)

**These items did not qualify:**

* Downloadable or online-only games
* Other gaming accessories, such as chairs and headsets

## Christmas and similar decorative trees

**New or used Christmas trees and similar decorative trees qualified for the temporary GST/HST relief, including:**

* Natural trees
* Artificial trees
* Hanukkah trees or bushes

**These items did not qualify:**

* Decorations for a Christmas tree or other decorative tree
* Holiday related decorations that are not in the physical form of a tree (for example, Christmas tree themed decorations for a wall)
* Poinsettia plants
* Mistletoe
* Wreaths

## Food

Most basic grocery items **already have no GST/HST** charged on them.

**These food items also temporarily had no GST/HST charged during the GST/HST break:**

* Prepared foods including sandwiches, salads, vegetable or cheese platters, and pre-made meals
* Snacks including chips, candy, baked goods, fruit-based snacks, and granola bars
* Energy bars or protein bars, if they meet **all** of the following criteria:
  + Compete directly with other similar products that are not enhanced by protein, caffeine, vitamins, and/or minerals (sold in a similar aisle in a store and are marketed in similar fashion)
  + Considered by the average person to be a food to satisfy hunger
  + Considered by Health Canada to be a food
* A gift basket that contains food and other items, if **90% or more** of the total value of the basket corresponds to items that would have no GST/HST charged on them if they were supplied separately

**These items did not qualify:**

* Food sold from a vending machine
* A gift basket that contains food and other items, if **less than 90%** of the total value of the basket corresponds to items that would have no GST/HST charged on them if they were supplied separately
* Dietary supplements
  In detail: dietary supplements

  Dietary supplements are not food or beverages and therefore did **not** qualify for the temporary GST/HST relief.

  Dietary supplements are consumed for their therapeutic or preventive effects or to achieve specific beneficial effects related to performance or physique. Dietary supplements are usually made with natural or synthetic ingredients and include products that contain natural or synthetic ingredients and include products such as vitamins, minerals, tonics, fibre, protein, amino acids, fatty acids, enzymes, herbal supplements, or compounds derived from plant or animal products.

  Examples of dietary supplements include:

  + Vitamins and minerals, such as multivitamin products
  + Protein isolate powder
  + Energy shots or wellness shots
  + Detox and cleanse products
  + Fibre mixes and supplements
  + Herbal supplements

  If a product has a Drug Identification Number (DIN), a Homeopathic Medicine Number (DIN-HM), or a Natural Product Number (NPN) as required by Health Canada it is a dietary supplement and did **not** qualify for the temporary GST/HST relief.

  The presence of any of the following factors is a strong indicator that a product is a dietary supplement and did not qualify for the temporary GST/HST relief:

  + Sold in tablet, pill, capsule or similar form
  + Sold in powdered or granulated form and consumed for its beneficial or therapeutic effects
  + Labelled as a dietary supplement or a supplement
  + Instructions for product consumption including timing, dosage and restrictions
  + Marketing claims that the product has a therapeutic or preventive effect, enhances mental or physical performance, or enhances physique
  + Emphasis on particular nutrients not commonly regarded by a consumer as an ingredient (such as whey protein isolate)
  + Claims that the product will promote weight loss
  + Warnings as to who should not consume the product. For example, the product should not be consumed, or should only be consumed in restricted amounts, by pregnant women or children under 16 years of age
  + The product is compared in its marketing to other products that are not considered to be food, beverage or ingredients.

  **Energy bars, protein bars and ready-to-consume energy or protein drinks (such as protein shakes)**

  These products are considered food or beverages and **qualified for the temporary GST/HST relief** when they met **all** the following criteria:

  + Compete directly with other similar products that are not enhanced by protein, caffeine, vitamins, and/or minerals (sold in a similar aisle in a store and are marketed in similar fashion)
  + Considered by the average person to be a food or beverage to satisfy hunger or thirst
  + Considered by Health Canada to be a beverage

  [Read more details of which products are considered dietary supplements](/en/revenue-agency/services/forms-publications/publications/gi-001/products-commonly-described-dietary-supplements.html)
* Cannabis products sold in the form of food
* Throat lozenges
* Other items that do not qualify as food for human consumption (for example, pet food)

**Related links:**

* [Meals and drinks for dine-in, takeout, delivery, and catering](#establishments)
* [How basic grocery items are regularly treated for GST/HST](/en/revenue-agency/services/forms-publications/publications/4-3/basic-groceries.html)

## Beverages

**These items qualified for the temporary GST/HST relief:**

* Non-alcoholic drinks, such as coffee, tea, carbonated drinks, juices, and smoothies
* Eligible alcoholic beverages:
  + Beer and malt beverages, for example, canned or bottled beer, pitchers of beer
  + Wine, cider and sake (including fortified) that are 22.9% alcohol by volume (ABV) or less
    In detail: Wine and sake (including fortified)

    Wine and sake qualify for GST/HST relief during the eligible period, along with other fortified beverages, if the absolute ethyl alcohol by volume (ABV) does not exceed 22.9%. If any alcoholic beverage is fortified in excess of 22.9% absolute ethyl ABV, it does not qualify for GST/HST relief.
  + Spirit coolers and premixed alcoholic beverages that are 7% ABV or less
    In detail: Spirit coolers and premixed alcoholic beverages

    Spirit coolers and premixed alcoholic beverages which are prepackaged for sale and contain **7% of absolute ethyl ABV or less qualify for GST/HST relief** during the eligible period.

    Spirit coolers and premixed alcoholic beverages which are prepackaged for sale and which contain **more than 7% of absolute ethyl ABV do not qualify** for GST/HST relief during the eligible period.
* Energy or protein drinks and shakes, if they meet **all** of the following criteria:
  + Compete directly with other similar products that are not enhanced by protein, caffeine, vitamins, and/or minerals (sold in a similar aisle in a store and are marketed in similar fashion)
  + Considered by the average person to be a beverage to satisfy thirst
  + Considered by Health Canada to be a beverage
* A gift basket that contains beverages and other items, if **90% or more** of the total value of the basket corresponds to items that would have no GST/HST charged on them if they were supplied separately

**These items did not qualify:**

* Beverages sold from a vending machine
* Non-eligible alcoholic beverages:
  + Alcoholic spirits and liqueurs
  + Alcoholic beverages (other than beer, malt beverages, wine, cider, and sake) with more than 7% ABV
* A gift basket that contains beverages and other items, if **less than 90%** of the total value of the basket corresponds to items that would have no GST/HST charged on them if they were supplied separately
* Dietary supplements
  In detail: dietary supplements

  Dietary supplements are not food or beverages and therefore did **not** qualify for the temporary GST/HST relief.

  Dietary supplements are consumed for their therapeutic or preventive effects or to achieve specific beneficial effects related to performance or physique. Dietary supplements are usually made with natural or synthetic ingredients and include products that contain natural or synthetic ingredients and include products such as vitamins, minerals, tonics, fibre, protein, amino acids, fatty acids, enzymes, herbal supplements, or compounds derived from plant or animal products.

  Examples of dietary supplements include:

  + Vitamins and minerals, such as multivitamin products
  + Protein isolate powder
  + Energy shots or wellness shots
  + Detox and cleanse products
  + Fibre mixes and supplements
  + Herbal supplements

  If a product has a Drug Identification Number (DIN), a Homeopathic Medicine Number (DIN-HM), or a Natural Product Number (NPN) as required by Health Canada it is a dietary supplement and did **not** qualify for the temporary GST/HST relief.

  The presence of any of the following factors is a strong indicator that a product is a dietary supplement and did not qualify for the temporary GST/HST relief:

  + Sold in tablet, pill, capsule or similar form
  + Sold in powdered or granulated form and consumed for its beneficial or therapeutic effects
  + Labelled as a dietary supplement or a supplement
  + Instructions for product consumption including timing, dosage and restrictions
  + Marketing claims that the product has a therapeutic or preventive effect, enhances mental or physical performance, or enhances physique
  + Emphasis on particular nutrients not commonly regarded by a consumer as an ingredient (such as whey protein isolate)
  + Claims that the product will promote weight loss
  + Warnings as to who should not consume the product. For example, the product should not be consumed, or should only be consumed in restricted amounts, by pregnant women or children under 16 years of age
  + The product is compared in its marketing to other products that are not considered to be food, beverage or ingredients.

  **Energy bars, protein bars and ready-to-consume energy or protein drinks (such as protein shakes)**

  These products are considered food or beverages and **qualified for the temporary GST/HST relief** when they met **all** the following criteria:

  + Compete directly with other similar products that are not enhanced by protein, caffeine, vitamins, and/or minerals (sold in a similar aisle in a store and are marketed in similar fashion)
  + Considered by the average person to be a food or beverage to satisfy hunger or thirst
  + Considered by Health Canada to be a food or beverage

  [Read more details of which products are considered dietary supplements](/en/revenue-agency/services/forms-publications/publications/gi-001/products-commonly-described-dietary-supplements.html)
* Cannabis products sold in the form of a beverage

**Related links:**

* [Meals and drinks for dine-in, takeout, delivery, and catering](#restaurant)
* [Mixed drinks served at establishments](#mixed-drinks)

## Page details

Date modified:
:   2025-02-18
