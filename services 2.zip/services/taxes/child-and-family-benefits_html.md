# Tax credits and benefits for individuals

## Possibility of a Strike at Canada Post

We are aware of possible job action at Canada Post. This page will be updated to share any impact to benefit and credit payments as soon as more details are available. Sign up to receive any future payments by [direct deposit](/en/public-services-procurement/services/payments-to-from-government/direct-deposit.html?utm_campaign=not-applicable&utm_medium=vanity-url&utm_source=canada-ca_direct-deposit) sent straight to your bank account.

Benefit programs, eligibility, application instructions, and payment dates.

## Most requested

* [CRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)
* [Benefit payment dates](/en/services/benefits/calendar.html)
* [Claiming deductions, credits, and expenses](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses.html)
* [Change your address](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/change-your-address.html)
* [Direct deposit](/en/revenue-agency/services/about-canada-revenue-agency-cra/direct-deposit.html)
* [Child and family benefits calculator](/en/revenue-agency/services/child-family-benefits/child-family-benefits-calculator.html)

## Types of tax credits and benefits

### [Canada child benefit (CCB)](/en/revenue-agency/services/child-family-benefits/canada-child-benefit-overview.html)

Monthly payment for eligible families with children under 18 years of age

### [GST/HST credit](/en/revenue-agency/services/child-family-benefits/goods-services-tax-harmonized-sales-tax-gst-hst-credit.html)

Quarterly payment for people with low and modest incomes, how much you could receive, and payment dates

### [Provincial and territorial benefits](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs.html)

Benefits that the CRA administers for the provinces and territories

Choose your location:

* [Alberta](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-alberta.html)
* [British Columbia](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-british-columbia.html)
* [Manitoba](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-manitoba.html)
* [New Brunswick](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-new-brunswick.html)
* [Newfoundland and Labrador](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-newfoundland-labrador.html)
* [Northwest Territories](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/northwest-territories.html)
* [Nova Scotia](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-nova-scotia.html)
* [Nunavut](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/nunavut.html)
* [Ontario](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-ontario.html)
* [Prince Edward Island](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-prince-edward-island.html)
* [Quebec](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-quebec.html)
* [Saskatchewan](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/province-saskatchewan.html)
* [Yukon](/en/revenue-agency/services/child-family-benefits/provincial-territorial-programs/yukon.html)

### [Disability tax credit (DTC)](/en/revenue-agency/services/tax/individuals/segments/tax-credits-deductions-persons-disabilities/disability-tax-credit.html)

Tax credit for people with severe impairments, who is eligible, how to apply, and how to claim it

### [Canada workers benefit](/en/revenue-agency/services/child-family-benefits/canada-workers-benefit.html)

Benefit for people who are working and have a low income, benefit amounts, and advance payment dates

### [Child disability benefit](/en/revenue-agency/services/child-family-benefits/child-disability-benefit.html)

Monthly payment to families who care for a child under age 18 who has a severe impairment

### [Canada caregiver credit](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/canada-caregiver-amount.html)

Tax credit for people who support a spouse, common-law partner, or a child with a physical or mental impairment

### [Canada training credit](/en/revenue-agency/services/child-family-benefits/canada-training-credit.html)

Tax credit for people paying tuition or fees for courses, and training fees you can claim

### [Home accessibility tax credit](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-31285-home-accessibility-expenses.html)

Tax credit for people making a home accessible, eligible homes, and eligible expenses

### [Children's special allowances](/en/revenue-agency/services/child-family-benefits/childrens-special-allowances.html)

Monthly payment for eligible federal and provincial agencies and institutions that care for children under 18 years of age

### [Canada Carbon Rebate (CCR)](/en/revenue-agency/services/child-family-benefits/canada-carbon-rebate.html) Closed

You may still be eligible if you are filing for a tax year 2021, 2022, 2023, or 2024

### [GST/HST break](/en/services/taxes/child-and-family-benefits/gst-hst-holiday-tax-break.html) Closed

Temporary GST/HST relief on certain items from December 14, 2024, to February 15, 2025

### [Canada Dental Benefit](/en/revenue-agency/services/child-family-benefits/dental-benefit.html) Closed

Who was eligible, what to do if your application is being reviewed or if you need to return the payment

## Find credits and benefits

### [Personal income tax deductions, credits, and expenses](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/deductions-credits-expenses.html)

What you may claim to reduce the amount of tax you need to pay

### [Getting the right CRA benefits and credits for your family](/en/revenue-agency/services/child-family-benefits.html)

Child and family benefits, eligibility, benefits calculator, and payment dates

### [Government benefits finder](https://benefitsfinder.services.gc.ca/hm?goctemplateculture=en-ca)

Answer questions to find federal, provincial, and territorial benefits that may apply to you

### [Getting your tax benefits and credits when in an abusive situation](/en/revenue-agency/services/child-family-benefits/benefits-credits-abusive-violent-situation.html)

How to get your CRA payments and confirm your personal information if your situation has changed

## Features

[![](/content/dam/cra-arc/camp-promo/features/t1-ft-360x203-2024-02-23.png)

SimpleFile by Phone

Did you receive a SimpleFile invitation letter? Auto-file your tax return over the phone.](/en/services/taxes/income-tax/personal-income-tax/how-file/simplefile.html)

[![](/content/dam/cra-arc/camp-promo/features/ft-180824-360x203.jpg)

Are your benefits being reviewed?

We're here to help!](/en/revenue-agency/services/child-family-benefits/validating-your-eligibility-benefits-credits.html)

[![](/content/dam/cra-arc/camp-promo/features/learn_about_taxes-202205-360x203.jpg)

Learn about your taxes

Use the new online learning tool to learn about taxes and how to do your taxes on your own.](/en/revenue-agency/services/tax/individuals/educational-programs.html)

## Contributors

### From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-08-13
