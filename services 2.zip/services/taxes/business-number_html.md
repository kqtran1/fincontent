# Business number

Use your federal business number to interact with the CRA and other government programs. Find out how to get one, register for CRA program accounts, and manage changes to your business.

## Most requested

* [CRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)

## Services and information

### [When you need a business number or Canada Revenue Agency program accounts](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/you-need-a-business-number-a-program-account.html)

Certain business activities require registration with the CRA.

### [How to register for a business number or CRA program accounts](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register.html)

Register for a business number or CRA program accounts by mail, phone, fax, or online.

### [Changes to your business and tax accounts](/en/revenue-agency/services/tax/businesses/topics/changes-your-business.html)

For common business changes, make updates online, inform the CRA, and other actions.

### [Authorize a representative or cancel their authorization](/en/revenue-agency/services/tax/representative-authorization.html)

Grant or cancel authorization to a representative, the types of access you can give, and the ways to authorize.

### [CRA registration and provincial or other federal programs](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/register-provincial-other-federal-programs.html)

Your business number registration can be connected to other federal or provincial programs.

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-01-31
