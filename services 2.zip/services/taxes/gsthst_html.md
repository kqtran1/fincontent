# GST/HST for businesses

**You may be looking for:** [GST/HST credit payments for individuals](/en/revenue-agency/services/child-family-benefits/goods-services-tax-harmonized-sales-tax-gst-hst-credit.html)

How to charge, remit, and report the Goods and Services Tax (GST) and the Harmonized Sales Tax (HST) as a business.

## Changes to HST in Nova Scotia

As of April 1, 2025, the HST rate has decreased to 14% in Nova Scotia.

[More information about the transition rules](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-which-rate.html#transitional)

## Most requested

* [GST/HST calculator and rates](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-which-rate/calculator.html)
* [Ready to file your GST/HST return](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/file-gst-hst-return/how-file.html#h_3)
* [Get a GST/HST access code](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/file-gst-hst-return/how-file/get-gst-hst-access-code.html)
* [GST/HST filing penalties](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/file-gst-hst-return/reporting-requirements-deadlines/gst-hst-filing-penalties.html)

## Services and information

### [Who needs to register for GST/HST](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/when-register-charge.html)

Find out if you have to register and start charging the GST/HST

### [Get a GST/HST number and manage your account](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/account-register.html)

Register for a GST/HST account or change or close your account

### [Charge and collect the GST/HST](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-which-rate.html)

Determine the rate to charge, manage receipts, and what to do with tax you collect

### [Calculate and prepare to report the GST/HST](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/calculate-prepare-report.html)

How to calculate net tax, determine input tax credits and prepare a return

### [File your GST/HST return](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/file-gst-hst-return.html)

When and how to file a return for each period, confirm and make changes after you file

### [Remit (pay) the GST/HST you collected](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/remit-pay-gst-hst-collected.html)

When and how to remit (pay) the tax, including by instalments

### [Claim a GST/HST rebate](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/gst-hst-rebates.html)

Claim a rebate of the GST/HST (or QST) you paid in certain situations

### [Confirm a GST/HST number](/en/revenue-agency/services/e-services/digital-services-businesses/confirming-a-gst-hst-account-number.html)

Find out if a business is registered to charge the GST/HST

## Focus on

* [Non-resident digital-economy businesses](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/digital-economy-gsthst.html)
* [Builders and construction](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-home-construction.html)
* [First Nations peoples and GST/HST](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-indigenous-peoples.html)
* [Charities](/en/revenue-agency/services/forms-publications/publications/rc4082.html)
* [Travel and conventions](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-specific-situations/gst-hst-information-travel-convention-industry.html)
* [Other special circumstances](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-specific-situations.html)

## Features

![](/content/dam/cra-arc/gst-hst/gst-bus-file.png)

### [Avoid penalties: file online](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/file-gst-hst-return/reporting-requirements-deadlines.html#toc_0)

If you have a reporting period that begins in 2024 or later, you must file your GST/HST returns electronically.

![](/content/dam/cra-arc/gst-hst/gst-bus-bro.png)

### [Business Registration Online](/en/revenue-agency/services/tax/businesses/topics/registering-your-business/business-registration-online-overview.html)

You can get a business number or register for GST/HST online, even if you have a SIN that starts with 9.

## Page details

Date modified:
:   2025-07-02
