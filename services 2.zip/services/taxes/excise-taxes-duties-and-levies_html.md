# Excise and specialty taxes

Excise duties and taxes, other levies and charges, and customs duties and tariffs collected by the federal government.

## Most requested

* [Excise duty rates](/en/revenue-agency/services/forms-publications/publications/edrates/excise-duty-rates.html)
* [Excise tax rates](/en/revenue-agency/services/forms-publications/publications/currate/current-rates-excise-taxes.html)

## Services and information

### [Underused Housing Tax](/en/services/taxes/excise-taxes-duties-and-levies/underused-housing-tax.html)

Filing and paying the tax on vacant or underused housing in Canada

### [Luxury Tax](/en/services/taxes/excise-taxes-duties-and-levies/luxury-tax.html)

Registering for and calculating the luxury tax on certain vehicles, aircraft and vessels

### [Customs tariff](http://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/menu-eng.html)

Current rates for customs duties and tariffs

### [Fuel charge](/en/revenue-agency/services/tax/excise-taxes-duties-levies/fuel-charge.html)

Registering for, reporting and paying the fuel charge on certain types of fuel and combustible waste

### [Air Travellers Security Charge](/en/revenue-agency/services/tax/technical-information/individuals-air-travellers-security-charge-atsc.html)

Current rates and information on collecting and paying the air travellers security charge (ATSC)

### [Excise duties](/en/revenue-agency/services/tax/technical-information/excise-duty.html)

Duties and licensing information on beer, wine, spirits, tobacco, cannabis and vaping products

### [Excise taxes](/en/revenue-agency/services/tax/technical-information/excise-taxes-special-levies.html)

Taxes on fuel-inefficient vehicles, automobile air conditioners, certain petroleum products and insurance premiums

### [Digital services tax](/en/services/taxes/excise-taxes-duties-and-levies/digital-services-tax.html)

Information relating to the tax on certain Canadian digital services revenue

### [Global minimum tax](/en/services/taxes/excise-taxes-duties-and-levies/global-minimum-tax.html)

Information relating to the global minimum tax on the profits of certain multinational enterprise groups

## Contributors

### From:

* [Canada Revenue Agency](https://www.canada.ca/en/revenue-agency.html)
* [Canada Border Services Agency](https://www.cbsa-asfc.gc.ca/menu-eng.html)

## Page details

Date modified:
:   2025-03-14
