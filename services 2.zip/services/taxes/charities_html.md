# Charities and giving

Charities listings, register and run a charity, and charitable tax credits.

![](/content/dam/cra-arc/images/charities/20140528.jpg)

## Most requested

* [Filing the T3010 annual return](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/filing-t3010-charity-return.html)
* [Issuing receipts](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/issuing-receipts.html)
* [Access our online services for charities](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/business-account.html)
* [Making a change to your organization](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/making-changes.html)
* [Subscribe to our electronic mailing list](/en/revenue-agency/news/e-services/canada-revenue-electronic-mailing-lists/electronic-mailing-list-charities-giving-whats-new.html)
* [Contact information](/en/revenue-agency/services/charities-giving/charities/contact-charities-directorate.html)

## Services and information

### [List of charities and other qualified donees](/en/revenue-agency/services/charities-giving/list-charities/list-charities-other-qualified-donees.html)

Find a charity or other qualified donee, their registered status, and their publicly available information.

### [Other organizations that can issue donation receipts](/en/revenue-agency/services/charities-giving/other-organizations-that-issue-donation-receipts-qualified-donees.html)

Lists of qualified donees, their application processes and obligations.

### [A to Z index of topics for charities](/en/revenue-agency/services/charities-giving/charities/charities-giving-a-index.html)

Search for information about charities and giving.

### [Registering for charitable or other qualified donee status](/en/revenue-agency/services/charities-giving/charities/registering-charitable-qualified-donee-status.html)

Apply for charitable registration or other qualified donee. Re-registration. Objections and appeals.

### [Operating a registered charity](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity.html)

Filing a return, gifting and receipting, charitable activities, books and records.

### [Fundraising activities](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/fundraising-activities-charities-other-qualified-donees.html)

Activities, issuing receipts for fundraising events, cause-related marketing.

### [Revoking registered status](/en/revenue-agency/services/charities-giving/charities/revoking-registered-status.html)

Types of revocation, consequences, annulment, re-registration.

### [Compliance, audits and sanctions](/en/revenue-agency/services/charities-giving/charities/compliance-audits-and-sanctions.html)

Audit process, consequences of non-compliance, sanctions and appeal rights.

### [Giving to charity](/en/revenue-agency/services/charities-giving/giving-charity-information-donors.html)

Who can issue official donation receipts, how to claim donations on your income tax and benefit return, how to donate wisely and avoid fraud.

### [Guidance, videos, forms and more](/en/revenue-agency/services/charities-giving/charities/guidance-videos-forms.html)

Guidance products and policies, videos, forms, checklists and Charities information sessions.

### [Charity news and contact us](/en/revenue-agency/services/charities-giving/charities/charity-news-contact-us.html)

Recent news and updates on our web pages.

### [About registered charities](/en/revenue-agency/services/charities-giving/about-registered-charities.html)

Their regulation and obligations, how they differ from non-profit organizations.

## Features

[![](/content/dam/cra-arc/camp-promo/features/ft-285521-360x203.jpg)

Wildfires and natural disasters

Learn what your charity needs to do if impacted by wildfires, floods or other natural disasters.](/en/revenue-agency/services/charities-giving/charities/whats-new.html#2025-06-19)

[![](/content/dam/cra-arc/camp-promo/features/ft-250528-360x203.jpg)

It’s now easier to file your charity’s information return online (T3010)

No need to print, mail or fax your return! You can now fill out and upload your software-prepared T3010 online.](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/filing-t3010-charity-return/how-to-file/cra-certified-software-filing-charity-return.html)

[![](/content/dam/cra-arc/camp-promo/features/ft_360x203px_20231128-BIL8.jpg)

Make sure your charity’s information is up to date!

Does your charity have a new director or mailing address? Find out how you can make these important updates.](/en/revenue-agency/services/charities-giving/charities/operating-a-registered-charity/making-changes.html)

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-06-12

## About this site

### Canada Revenue Agency (CRA)

* [Contact the CRA](/en/revenue-agency/corporate/contact-information.html)
* [About the CRA](/en/revenue-agency/corporate/about-canada-revenue-agency-cra.html)
* [Compliance and enforcement](/en/revenue-agency/programs/about-canada-revenue-agency-cra/compliance.html)

### Government of Canada

* [All Contacts](https://www.canada.ca/en/contact.html)
* [Departments and agencies](https://www.canada.ca/en/government/dept.html)
* [About government](https://www.canada.ca/en/government/system.html)

#### Themes and topics

* [Jobs](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finance](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Indigenous peoples](https://www.canada.ca/en/services/indigenous-peoples.html)
* [Veterans and military](https://www.canada.ca/en/services/veterans.html)
* [Youth](https://www.canada.ca/en/services/youth.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](https://www.canada.ca/en/transparency/terms.html)
* [Privacy](https://www.canada.ca/en/revenue-agency/corporate/privacy-notice.html)

![Symbol of the Government of Canada](https://wet-boew.github.io/themes-dist/GCWeb/GCWeb/assets/wmms-blk.svg)
