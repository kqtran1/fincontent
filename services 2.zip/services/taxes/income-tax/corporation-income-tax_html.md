3. [Income tax](/en/services/taxes/income-tax.html)

# Corporation income tax

File corporation income tax, find tax rates, and get information about provincial and territorial corporate tax.

## Follow:

* [YouTube](http://www.youtube.com/user/CanRevAgency)
* [Twitter](https://twitter.com/CanRevAgency)

![](/content/dam/themes/taxes/features/income-tax/cra-rfi-202.jpg)

## Update on the taxability of the Canada Carbon Rebate for Small Businesses

Businesses can choose **not** to include the rebate in taxable income when filing their T2 Corporation Income Tax Return for the year in which it was received. However, they could be reassessed, with interest, in the event that the legislation does not receive Royal Assent. Read more: [Tax treatment of the rebate](/en/revenue-agency/services/tax/businesses/topics/corporations/business-tax-credits/canada-carbon-rebate-small-businesses/tax-treatment-rebate.html).

## Services and information

### [Corporation income tax overview](/en/revenue-agency/services/tax/businesses/topics/corporations/corporation-income-tax-return.html)

Summary of corporation tax rates, provincial and territorial corporation tax, and tax credits.

### [Corporation tax rates](/en/revenue-agency/services/tax/businesses/topics/corporations/corporation-tax-rates.html)

Get federal, provincial, or territorial rates, and learn when to apply the lower or higher rate.

### [Provincial and territorial corporation tax](/en/revenue-agency/services/tax/businesses/topics/corporations/provincial-territorial-corporation-tax.html)

What's new for corporations, reporting tax and claiming credits, and related forms and publications.

### [Federal tax credits](/en/revenue-agency/services/tax/businesses/topics/corporations/business-tax-credits.html)

Federal income tax credits you may be eligible to claim.

### [Record keeping](/en/revenue-agency/services/tax/businesses/topics/keeping-records.html)

Determine what constitutes a record, learn your responsibilities, and information about different types of records.

### [Dividends](/en/revenue-agency/services/tax/businesses/topics/corporations/eligible-dividends.html)

Designation of eligible dividends, information about Part III.1 tax, and general and low-rate income pools.

### [Corporate tax payments](/en/revenue-agency/services/tax/businesses/topics/corporations/corporation-payments.html)

Paying instalments, paying your balance of corporation tax, and prepaying reassessments.

### [Reassessments](/en/revenue-agency/services/tax/businesses/topics/corporations/after-you-file-your-corporation-income-tax-return/reassessments-adjustments-your-t2-return.html)

Request a reassessment of your T2 return, and learn the time limits for a reassessment.

### [Transfer pricing](/en/revenue-agency/services/tax/international-non-residents/information-been-moved/transfer-pricing.html)

International transfer pricing, including transfer pricing memoranda.

### [Foreign spin-offs](/en/revenue-agency/services/tax/businesses/topics/foreign-spin-offs.html)

Foreign spin-offs for Canadian shareholders of foreign corporations.

## Most requested

* [CRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)
* [All online services](/en/revenue-agency/services/e-services.html)
* [T2SHORT-T2 short return](/en/revenue-agency/services/forms-publications/forms/t2short.html)
* [T2 Corporation income tax return](/en/revenue-agency/services/tax/businesses/topics/corporations/corporation-income-tax-return.html)
* [Forms and publications](/en/revenue-agency/services/forms-publications.html)

## Features

[![](/content/dam/cra-arc/camp-promo/features/psb-20240612-360x203-en.jpg)

Personal services business fact sheet

Personal services businesses have different reporting and filing obligations than other corporations. Here’s what you need to know!](/en/revenue-agency/services/tax/businesses/topics/corporations/corporation-income-tax-return/personal-services-business-pilot/fact-sheet-personal-business.html)

## Page details

Date modified:
:   2025-07-04
