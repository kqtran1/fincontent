3. [Income tax](/en/services/taxes/income-tax.html)

# Trust income tax

File trust income tax, and get information about T3 slips, refunds, and payments.

![](/content/dam/themes/taxes/features/income-tax/cra-rfi-199.jpg)

## Most requested

* [CRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)
* [All online services](/en/revenue-agency/services/e-services.html)
* [Forms and publications](/en/revenue-agency/services/forms-publications.html)

## Services and information

### [Application for a Trust Account Number](/en/revenue-agency/services/tax/trust-administrators/t3-return/application-trust-account-number-overview.html)

You can apply for a trust account number using the Trust Account Registration service.

### [Trust Income Tax Return](/en/revenue-agency/services/tax/trust-administrators/t3-return.html)

Determine whether a trust should file a Trust Income Tax Return (T3), and where and when to a file a T3.

### [Trust Information returns – slips and summaries](/en/revenue-agency/services/tax/trust-administrators/t3-slip.html)

Determine when a trust has to complete and distribute T3 slips, filing methods for T3 slips, and due dates.

### [Trust types and codes](/en/revenue-agency/services/tax/trust-administrators/types-trusts.html)

Differentiate between testamentary and inter vivos trusts, and get the code numbers for different types of trusts.

### [Specified investment flow-through trust income and distribution tax](/en/revenue-agency/services/tax/trust-administrators/specified-investment-flow-through-sift-trust-income-distribution-tax.html)

Determine what a SIFT trust is, and get the tax calculation formula for SIFT trusts.

### [Retirement Compensation Arrangements](/en/services/taxes/income-tax/trust-income-tax/retirement-compensation-arrangements-guide.html)

Determine what is an RCA and how to file the T3-RCA Return.

### [Doing taxes for someone who died](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died.html)

Report the date of death, access tax records as a representative, file final and estate tax returns, settle the estate.

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-02-17
