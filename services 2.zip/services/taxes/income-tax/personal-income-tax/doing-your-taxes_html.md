3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)

Personal income tax

# Get ready to file a tax return

To receive the benefits and credits you may be eligible for, you need to file your income tax and benefit return every year.

Start by gathering your documents to report income and claim deductions, and choose how you want to file and send your completed tax return to the CRA.

## Steps to get ready for 2024 taxes

1. ### [Find out who should file a tax return](/en/services/taxes/income-tax/personal-income-tax/who-should-file-tax.html)

   Determine if you need to file a tax return and your obligations based on your tax situation.
2. ### [Learn what's new for 2024](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/whats-new.html)

   Changes to benefits, credits, and expenses for individuals and families, and updates to the income tax package.
3. ### [Be aware of key dates](/en/revenue-agency/services/tax/individuals/topics/important-dates-individuals.html)

   Filing and payment due dates for taxes, instalment payments, and any amounts you may owe.

   #### Filing dates for 2024 taxes

   * **February 24, 2025:** Earliest day to file your taxes online
   * **April 30, 2025:** Deadline to file your taxes
   * **June 15, 2025** (June 16, 2025, since June 15 is a Sunday): Deadline to file your taxes if you or your spouse or common-law partner is self-employed

   #### Payment due date for 2024 taxes

   * **April 30, 2025:** Deadline to pay your taxes
4. ### [Get tax slips](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/tax-slips.html)

   Understand your tax information slips, such as the T4 and T4A, when you will receive them from the issuer, and how to get a copy.
5. ### [Keep information up-to-date with the CRA](/en/revenue-agency/services/update-information-cra/personal.html)

   Notify the CRA about changes to a mailing or email address, phone number, name, or marital status.

   Update direct deposit details for payments and refunds, language and mail preferences to receive CRA mail.
6. ### [Choose how to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)

   * You can **file your own tax return** using:

     + Tax software
     + A paper tax return
     + A SimpleFile invitation
   * You can have **someone else file your tax return**, such as:

     + A professional tax preparer
     + A volunteer at a free tax clinic

   * #### Get your NETFILE access code

   If you plan to file a return electronically with tax software, you may be asked for a NETFILE access code. If you are filing a tax return for the first time, you will not have an access code.

   The unique 8-character access code is made up of numbers and letters and is located on the **right** side of your **previous year’s** [notice of assessment (NOA)](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html).

   Image of where to find the access code
   ![Sample Notice of Assessment showing where the access code is located](/content/dam/cra-arc/serv-info/eservices/noa-letter-info-en.jpg)

   The access code is **not mandatory**.

   If you do not provide the access code

   While this access code is not mandatory, if you do not enter the access code:

   * You will not be able to use any information from your most recent tax return to confirm your identity with the CRA
   * The CRA will have to use other information for authentication purposes

## Features

[![](/content/dam/cra-arc/camp-promo/features/ft-360x203-2021-12-20-7.jpg)

File to get your benefit and credit payments

File your return to receive benefit and credit payments you may be eligible for.](/en/services/taxes/child-and-family-benefits.html)

[![](/content/dam/cra-arc/camp-promo/features/ft-230126-360x203-3.jpg)

After filing a tax return

Information you may need after you file your tax return.](/en/services/taxes/income-tax/personal-income-tax/after-you-file.html)

[![](/content/dam/cra-arc/camp-promo/features/t1-ft-360x203-2021-12-20-20.jpg)

Request a change to your tax return online

For faster service, submit your change request online.](/en/services/taxes/income-tax/personal-income-tax/after-you-file/change-return.html)

## Page details

Date modified:
:   2025-07-09
