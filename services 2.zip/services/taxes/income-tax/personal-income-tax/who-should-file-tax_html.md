3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)

Personal income tax

# Who should file a tax return

Find out if you should file a tax return and what are your tax obligations. Your filing obligations may be different if you live in or leave Canada permanently or temporarily.

## Specific tax situations

* [Taxes and benefits for Indigenous peoples](/en/revenue-agency/services/indigenous-peoples.html)
* [Taxes for someone who died](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died.html)
* [Quebec resident taxes](https://www.revenuquebec.ca/en/citizens/income-tax-return/completing-your-income-tax-return/are-you-required-to-file-an-income-tax-return/)

* [Self-employed or small business owners](/en/services/taxes/income-tax/business-or-professional-income.html)
* [Foreign reporting](/en/revenue-agency/services/tax/international-non-residents/information-been-moved/foreign-reporting.html)

## You live in Canada permanently

### [Canadian residents](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/you-have-file-a-return.html)

You live and work in Canada, you have to pay taxes, and want to receive credits and benefit payments

### [Newcomers to Canada (immigrants)](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/newcomers-canada-immigrants.html)

You left another country to settle in and become a resident of Canada

## You leave Canada temporarily or permanently

### [Factual residents](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/factual-residents-temporarily-outside-canada.html)

You are a resident of Canada and you leave temporarily for work, school, a medical procedure, or vacation

### [Live part-time in the U.S.](/en/revenue-agency/services/tax/international-non-residents/canadian-residents-going-down-south.html)

You spend part of the year in the U.S. for vacation or health reasons and maintain residential ties in Canada

### [Government employees](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/government-employees-outside-canada.html)

You are a federal or provincial government employee who is posted abroad for work

### [Leave Canada permanently (emigrants)](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/leaving-canada-emigrants.html)

You leave Canada to live in another country and no longer have residential ties with Canada

## You live in Canada temporarily

### [Non-residents of Canada](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/non-residents-canada.html)

You live in Canada for less than 183 days in a year and do not have significant residential ties in Canada

### [Non-residents of Canada with rental income](/en/revenue-agency/services/tax/international-non-residents/information-been-moved/rental-income-non-resident-tax.html)

You receive rental income from real and immovable properties in Canada

### [Deemed residents](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/deemed-residents.html)

You live in Canada for 183 days or more in a year and do not have significant residential ties in Canada

### [International students](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/international-students-studying-canada.html)

You are an international student studying in Canada

### [Seasonal workers](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/seasonal-agricultural-workers-other-countries.html)

You are a seasonal agricultural worker from another country

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-01-28
