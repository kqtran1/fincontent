3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [COVID-19 benefits and your taxes](/en/revenue-agency/services/benefits/covid19-taxes.html)

Personal income tax

# Archived - COVID-19 related interest relief on 2020 taxes

**You may be looking for:**

* [Income tax relief options](/en/revenue-agency/services/about-canada-revenue-agency-cra/complaints-disputes/taxpayer-relief-provisions.html)

You may have been eligible for interest relief on your 2020 taxes owing if you received COVID-19 benefits in 2020. You must have met all the criteria to be eligible for interest relief.

The CRA would not have started charging interest on your 2020 taxes owing **until after April 30, 2022**.

## On this page

* [Eligibility criteria](#h_1)
* [Late-filing penalties on 2020 taxes still apply](#h_2)
* [Find payment options](#h_3)

## Eligibility criteria

Interest relief on 2020 taxes owing was given if you met **all** of the following:

* Your total 2020 taxable income was $75,000 or less
* You received **at least one** COVID-19 benefit in 2020:
  + Canada Emergency Response Benefit (CERB)
  + Canada Emergency Student Benefit (CESB)
  + Canada Recovery Benefit (CRB)
  + Canada Recovery Caregiving Benefit (CRCB)
  + Canada Recovery Sickness Benefit (CRSB)
  + Employment Insurance (EI) benefits
  + Provincial or territorial emergency benefits
* You filed your 2020 income tax and benefit return

You needed all the above to get interest relief on your 2020 taxes owing.

If you did not meet the criteria, you could review other [income tax relief options](/en/revenue-agency/services/about-canada-revenue-agency-cra/complaints-disputes/taxpayer-relief-provisions.html).

You’ve met the above criteria. The CRA will not charge interest on your 2020 taxes owing **until after April 30, 2022**.

### If you met all the criteria

If you had met all the eligibility criteria and had filed your 2020 tax return, the CRA would have automatically applied interest relief on your 2020 taxes owing.

You would not have had to pay interest on any amount owing from your 2020 taxes **until after April 30, 2022**.

Interest relief would have only been applied to your **2020 taxes owing** and not on previous or other debts with the CRA.

## Late-filing penalties on 2020 taxes still apply

Late-filing penalties would have still been charged if you filed your 2020 tax return after the filing due date.

For most people, the 2020 filing due date was April 30, 2021. If you or your spouse or common-law partner were self-employed, your 2020 filing due date was June 15, 2021.

The [late-filing penalty](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/interest-penalties/late-filing-penalty.html) is 5% of your 2020 balance owing. For each additional month you were late in filing your tax return, an extra 1% was added (up to a maximum of 12 months). Penalty charges still applied since they were not part of this interest relief.

## Find payment options

The CRA can work with you and find flexible options to pay your balance owing. For details: [Payments for individuals](/en/revenue-agency/services/payments-cra/individual-payments.html)

## Did you find what you were looking for?

Yes
No

If not, tell us why:

What was wrong?

I can't **find** the information

The information is hard to **understand**

There was an error or something **didn't work**

Other reason

Please provide more details

**You will not receive a reply. Telephone numbers and email addresses will be removed.**
Maximum 300 characters

Submit

Thank you for your feedback

Date modified:
:   2023-03-07
