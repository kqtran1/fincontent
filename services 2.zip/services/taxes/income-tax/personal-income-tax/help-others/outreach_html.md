3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)

# How outreach officers can help your community learn about tax and benefits

Benefit and credit payments can make a big difference to those in your community. The CRA’s outreach officers can help them learn about these payments and what they can get by doing their taxes.

## On this page

* [Who we support](#who)
* [What CRA outreach officers can do](#whatdo)
* [Get help from an outreach officer](#howget)
* [Help people with their taxes](#taxhelp)
* [Learning events, webinars and recordings](#upevent)
* [Outreach resources](#resources)
* [Related link](#link)

## Who we support

We can help if your organization provides services to:

* adults 65 years and older
* housing-insecure individuals
* Indigenous Peoples
* modest-income individuals
* newcomers to Canada
* persons with disabilities
* students and youth

Some of the organizations we help include non-profits, shelters, retirement homes, friendship centres, immigration associations and schools.

If you have questions about or need information for your personal taxes, please refer to [personal income tax](/en/services/taxes/income-tax/personal-income-tax.html) or call 1-800-959-8281 where an agent will be able to assist you. Outreach officers do not have access to personal tax information and cannot answer individual tax-related questions.

## What CRA outreach officers can do

### CRA outreach officers can:

* lead an information session for your employees or community
* host a booth at an event
* make a presentation at a conference
* provide handouts for your community
* offer information on how to get benefit and credit payments
* give training workshops

### CRA outreach officers can share information about:

* benefits and credits available, such as the:
  + Canada child benefit
  + GST/HST credit
  + Canada workers benefit
  + Disability tax credit
  + Child disability benefit
  + Canada caregiver credit
* who can apply for benefits and credits
* how to apply for benefits and credits
* Canada's tax system
* tax information for specific communities
* online services
* scams and frauds

## Get help from an outreach officer

Complete the request form and someone from one of our regional offices will contact you to discuss how the CRA can help your organization support your community’s needs.

Choose a province or territory

* [Alberta](https://cra-arc-survey-sondage.ca/f/s.aspx?s=fea5e7bc-12c2-490f-b5ee-9c0e26c70f6b&lang=EN)
* [British Columbia](https://cra-arc-survey-sondage.ca/f/s.aspx?s=44627e0d-2bc4-4cd5-a2f2-4258746e70a0&lang=EN)
* [Manitoba](https://cra-arc-survey-sondage.ca/f/s.aspx?s=fea5e7bc-12c2-490f-b5ee-9c0e26c70f6b&lang=EN)
* [New Brunswick](https://cra-arc-survey-sondage.ca/f/s.aspx?s=72a5ea3d-b147-438a-a501-c4ee50d520f9&lang=EN)
* [Newfoundland and Labrador](https://cra-arc-survey-sondage.ca/f/s.aspx?s=72a5ea3d-b147-438a-a501-c4ee50d520f9&lang=EN)
* [Northwest Territories](https://cra-arc-survey-sondage.ca/f/s.aspx?s=fea5e7bc-12c2-490f-b5ee-9c0e26c70f6b&lang=EN)
* [Nova Scotia](https://cra-arc-survey-sondage.ca/f/s.aspx?s=72a5ea3d-b147-438a-a501-c4ee50d520f9&lang=EN)
* [Nunavut](https://cra-arc-survey-sondage.ca/f/s.aspx?s=fea5e7bc-12c2-490f-b5ee-9c0e26c70f6b&lang=EN)
* [Ontario](https://cra-arc-survey-sondage.ca/f/s.aspx?s=e73c8d49-7b51-4264-88da-b9424098b212&lang=EN)
* [Prince Edward Island](https://cra-arc-survey-sondage.ca/f/s.aspx?s=72a5ea3d-b147-438a-a501-c4ee50d520f9&lang=EN)
* [Quebec](https://cra-arc-survey-sondage.ca/f/s.aspx?s=b41bb152-c97e-4ead-8ecf-26c22045b517&lang=EN)
* [Saskatchewan](https://cra-arc-survey-sondage.ca/f/s.aspx?s=fea5e7bc-12c2-490f-b5ee-9c0e26c70f6b&lang=EN)
* [Yukon](https://cra-arc-survey-sondage.ca/f/s.aspx?s=44627e0d-2bc4-4cd5-a2f2-4258746e70a0&lang=EN)

Fill out request form

## Help people with their taxes

The individuals your organization serves must do their taxes every year to receive their entitled benefits and credits. You can help by hosting a free tax clinic.

Host a free tax clinic

A free tax clinic is a place where eligible people can get their tax returns done by volunteers for free. To be eligible, a person must have a modest income and a simple tax situation. These tax clinics are hosted by community organizations across Canada through the [Community Volunteer Income Tax Program](/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program.html) (CVITP) and the [Income tax assistance – Volunteer Program](https://www.revenuquebec.ca/en/one-mission-concrete-actions/helping-you-meet-your-obligations/income-tax-assistance-volunteer-program/) (ITAVP) in Quebec.

This tax season, community organizations are hosting free tax clinics. If your organization chooses to host free tax clinics, your volunteers can complete taxes in person or virtually, by videoconference, by phone, or through a drop off clinic.

Funding may be available for eligible organizations that host free tax clinics. To find out more, see our [grant for hosting free tax clinics](/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program/grant.html).

[Learn more about hosting a free tax clinic](/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program/lend-a-hand-community-organizations.html) or register as a host organization.

[Register my organization](https://apps.cra-arc.gc.ca/ebci/oecv/external/prot/startOrganizationRegistration.action?request_locale=en_CA)

Become a volunteer at a free tax clinic

This tax season, community organizations are hosting free in-person and virtual tax clinics. You can participate as a tax preparer, a coordinator, or in a support role. If you volunteer as a tax preparer, you can choose to complete taxes in person or virtually, by videoconference, by phone, or through a drop-off clinic.

For more information and to register as a volunteer, go to [volunteer at a free tax clinic](/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program/lend-a-hand-individuals.html).

## Learning events, webinars and recordings

Join an upcoming interactive webinar or watch a recorded version of a past webinar.

[Learn about tax benefits and credits through webinars and recordings](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/upcoming-events-products.html).

## Outreach resources

### [Materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

Factsheets, posters, videos and more.

### [Resources for supporting communities](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/resources-for-supporting-communities.html)

Relevant links, forms and publications.

### [Benefits, credits, deductions and support](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/tax-related-benefits-credits-deductions-support.html)

Tax-related support programs.

## Related link

[Service Canada Community Outreach and Liaison Service](/en/employment-social-development/services/community-outreach-liaison-service.html)

Staff are available to visit communities across Canada to offer services to those who have no easy access to in person offices.

## Features

![A man working at a computer](/content/dam/cra-arc/camp-promo/features/ft-20221019-360x203.jpg)

### [Free CRA webinars: Learn about benefits and credits, being scam smart and more!](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/upcoming-events-products.html)

The CRA hosts a series of free webinars in the fall and winter months on various topics. View all of our webinars and register for the ones that interest you.

![image of a man talking with a headset](/content/dam/cra-arc/camp-promo/features/ft-20210303-360x203.jpg)

### [Free tax clinics](/en/revenue-agency/campaigns/free-tax-help.html)

Community organizations are hosting free tax clinics. Find out about the Community Volunteer Income Tax Program (CVITP).

![#](/content/dam/cra-arc/camp-promo/features/ft-20220502-360x203-en.png)

### [Be scam smart](/en/revenue-agency/campaigns/fraud-scams.html?utm_campaign=not-applicable&utm_medium=vanity-url&utm_source=canada-ca_be-scam-smart)

Learn how to avoid scams by knowing what to expect if we contact you.

## Page details

Date modified:
:   2024-10-21
