3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)

# Resources for supporting communities

Filter by audience:

* Adults 65 years and older
* Housing-insecure individuals
* Indigenous Peoples
* Modest-income individuals

* Newcomers
* Persons with disabilities
* Students

Filter your choices
Reset all filters

CRA resources for organizations supporting communities

| Link | Tags | Type |
| --- | --- | --- |
| [Benefit finder](/en/services/benefits/finder.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Benefit payment calculator](/en/revenue-agency/services/child-family-benefits/child-family-benefits-calculator.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Medical expenses](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/lines-33099-33199-eligible-medical-expenses-you-claim-on-your-tax-return.html) | disabilities | Forms and publications |
| [Newcomers to Canada (immigrants and returning residents)](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/newcomers-canada-immigrants.html) | new | Taxes, benefits, and credits |
| [Student aid](/en/services/benefits/education/student-aid.html) | students | Taxes, benefits, and credits |
| [Tax credits and deductions for persons with disabilities](/en/revenue-agency/services/tax/individuals/segments/tax-credits-deductions-persons-disabilities.html) | disabilities | Taxes, benefits, and credits |
| [Tax information for seniors](/en/revenue-agency/services/tax/individuals/segments/changes-your-taxes-when-you-retire-turn-65-years-old.html) | adults | Taxes, benefits, and credits |
| [Taxes and benefits for Indigenous peoples](/en/revenue-agency/services/indigenous-peoples.html) | indigenous | Taxes, benefits, and credits |
| [Tax information for students](/en/revenue-agency/services/tax/individuals/segments/students.html) | students | Taxes, benefits, and credits |
| [GST/HST and Indigenous peoples](/en/revenue-agency/services/tax/businesses/topics/gst-hst-businesses/charge-collect-indigenous-peoples.html) | indigenous | Taxes, benefits, and credits |
| [Northern residents deductions](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-25500-northern-residents-deductions.html) | indigenous | Taxes, benefits, and credits |
| [Northern service centres](/en/revenue-agency/corporate/contact-information/northern.html) | indigenous | Taxes, benefits, and credits |
| [Canada caregiver credit](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/canada-caregiver-amount.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Canada training credit](/en/revenue-agency/services/child-family-benefits/canada-training-credit.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Canada child benefit](/en/revenue-agency/services/child-family-benefits/canada-child-benefit-overview.html) | adults, housing-insecure, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Canada workers benefit disability supplement](/en/revenue-agency/services/child-family-benefits/canada-workers-benefit.html) | disabilities | Taxes, benefits, and credits |
| [Child disability benefit](/en/revenue-agency/services/child-family-benefits/child-disability-benefit.html) | housing-insecure, disabilities | Taxes, benefits, and credits |
| [Tax credits and benefits for individuals](/en/services/taxes/child-and-family-benefits.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Disability tax credit (DTC)](/en/revenue-agency/services/tax/individuals/segments/tax-credits-deductions-persons-disabilities/disability-tax-credit.html) | disabilities, housing-insecure | Taxes, benefits, and credits |
| [Find ways to do your taxes (including certified tax software)](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes/ways.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [Get ready to do your taxes](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [GST/HST credit](/en/revenue-agency/services/child-family-benefits/goods-services-tax-harmonized-sales-tax-gst-hst-credit.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Taxes, benefits, and credits |
| [CRA forms and publications](/en/revenue-agency/services/forms-publications.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Individuals video gallery](/en/revenue-agency/news/cra-multimedia-library/individuals-video-gallery.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Form AUT-01, Authorize a Representative for offline access](/en/revenue-agency/services/forms-publications/forms/aut-01.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [CTB9, Canada child benefit – Statement of income](/en/revenue-agency/services/forms-publications/forms/ctb9.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Form RC151, GST/HST Credit Application for Individuals who Became Residents of Canada](/en/revenue-agency/services/forms-publications/forms/rc151.html) | new | Forms and publications |
| [Form RC325, Address change request](/en/revenue-agency/services/forms-publications/forms/rc325.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Form RC65, Marital Status Change](/en/revenue-agency/services/forms-publications/forms/rc65.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Form RC66, Canada Child Benefits Application](/en/revenue-agency/services/forms-publications/forms/rc66.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Schedule RC66SCH, Status in Canada and Income](/en/revenue-agency/services/forms-publications/forms/rc66sch.html) | new | Forms and publications |
| [Form T1032 – Joint Election to Split Pension](/en/revenue-agency/services/forms-publications/forms/t1032.html) | adults | Forms and publications |
| [Form T1213 – Request to Reduce Tax Deductions at Source](/en/revenue-agency/services/forms-publications/forms/t1213.html) | adults | Forms and publications |
| [Form T2201, Disability Tax Credit Certificate](/en/revenue-agency/services/forms-publications/forms/t2201.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Guide P105, Students and Income Tax](/en/revenue-agency/services/forms-publications/publications/p105.html) | students | Forms and publications |
| [Information Sheet RC192, Information for Students - Educational Institutions Outside of Canada](/en/revenue-agency/services/forms-publications/publications/rc192.html) | students | Forms and publications |
| [Guide RC4064, Disability-Related Information](/en/revenue-agency/services/forms-publications/publications/rc4064.html) | disabilities | Forms and publications |
| [Guide RC4065, Medical Expenses](/en/revenue-agency/services/forms-publications/publications/rc4065.html) | disabilities | Forms and publications |
| [Guide T4040, RRSPs and Other Registered Plans](/en/revenue-agency/services/forms-publications/publications/t4040.html) | adults | Forms and publications |
| [Guide RC4055, Newcomers to Canada](/en/revenue-agency/services/forms-publications/publications/t4055.html) | new | Forms and publications |
| [Schedule 6, Canada Workers Benefit](/en/revenue-agency/services/forms-publications/tax-packages-years/general-income-tax-benefit-package/5000-s6.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |
| [Canada Direct Deposit enrollment form](https://www.tpsgc-pwgsc.gc.ca/recgen/form/inscription-enrolment-eng.html) | adults, housing-insecure, indigenous, modest-income, new, disabilities, students | Forms and publications |

## Page details

Date modified:
:   2022-06-23
