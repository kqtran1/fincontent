3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Indigenous Peoples

The official versions of the CRA factsheet and infographics on benefits and credits are the English and French versions. While reasonable efforts are made to provide accurate translations, due to the nuances in translating to another language, slight differences or inaccuracies may exist.

![a man, a man in a wheelchair, and a woman, all smiling](/content/dam/cra-arc/camp-promo/factsheet/fctsht_thmbnl_ndgns-en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns-en.pdf)

PDF, 318 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Factsheet
**Last update:** 2025-07-01

Are you First Nations, Inuit, or Métis? Doing your taxes has benefits.

## French factsheet

* [Personnes Autochtones](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns-fr.pdf)

## Other languages

* [Dene](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_dene.pdf)
* [Innu-Aimun](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_innu-aimun.pdf)
* [Inuinnaqtun](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_inuinnaqtun.pdf)
* [Michif-Cree](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_michifcree.pdf)
* [Michif-French](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_michiffrench.pdf)
* [Mi'kmaq](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_mikmaq.pdf)
* [Mohawk](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_mohawk.pdf)
* [North Slavey](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_northslavey.pdf)
* [Inuktitut (Nunavik)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_nunavik.pdf)
* [Inuktitut (Nunavut)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_nunavut.pdf)
* [Ojibway](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_ojibway.pdf)
* [Oji-Cree](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_ojicree.pdf)
* [Plains Cree](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_plainscree.pdf)
* [South Slavey](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_southslavey.pdf)
* [Stoney](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_stoney.pdf)
* [Swampy Cree](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_swampy.pdf)
* [Tlicho](/content/dam/cra-arc/camp-promo/factsheet/fctsht_ndgns_tilcho.pdf)

## Page details

Date modified:
:   2025-07-01
