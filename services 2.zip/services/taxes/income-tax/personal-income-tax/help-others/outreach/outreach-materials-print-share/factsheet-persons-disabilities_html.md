3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Persons with disabilities

![image of factsheet with picture of smiling woman in a wheelchair](/content/dam/cra-arc/camp-promo/factsheet/fctsht_thmbnl_prsns_dsblts-en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_prsns_dsblts-en.pdf)

PDF, 336 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Factsheet
**Last update:** 2025-07-01

Benefits and credits available for persons with disabilities and their caregivers.

## French factsheet

* [Les personnes en situation de handicap](/content/dam/cra-arc/camp-promo/factsheet/fctsht_prsns_dsblts-fr.pdf)

## Page details

Date modified:
:   2025-07-01
