3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Free tax clinics and outreach support

![image of factsheet with a man and a woman smiling](/content/dam/cra-arc/camp-promo/factsheet/fctsht_thmbnl_clnc_trch-en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_clnc_trch-en.pdf)

PDF, 440 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Factsheet
**Last update:** 2025-03-03

Organizations can learn about hosting free tax clinics and the CRA’s outreach program.

## French factsheet

* [Comptoirs d’impôts gratuits et soutien du programme de visibilité](/content/dam/cra-arc/camp-promo/factsheet/fctsht_clnc_trch-fr.pdf)

## Page details

Date modified:
:   2025-03-03
