3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Northern residents deductions

The official versions of the CRA factsheet and infographics on benefits and credits are the English and French versions. While reasonable efforts are made to provide accurate translations, due to the nuances in translating to another language, slight differences or inaccuracies may exist.

![image of factsheet](/content/dam/cra-arc/camp-promo/factsheet/thmbnl_nrthrnddcts_en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_nkttt_nglsh.pdf)

PDF, 284 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Factsheet
**Last update:** 2024-02-13

Did you live in a northern or remote area for six months or more in the year? The CRA can help.

## French factsheet

* [Déductions pour les habitants de régions éloignées](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_nkttt_frnch.pdf)

## Other languages

* [Cree](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_cr.pdf)
* [Dogrib](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_dgrb.pdf)
* [Innu](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_nn.pdf)
* [Inuktitut (Nunavik)](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_nkttt_nnvk.pdf)
* [Inuktitut (Nunavut)](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_nkttt_nnvt.pdf)
* [South Slavey](/content/dam/cra-arc/camp-promo/factsheet/fctsht__nrthrn_ddctns_sthslv.pdf)

## Page details

Date modified:
:   2025-03-14
