3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Steps for volunteering at a free tax clinic

![image de la fiche d'information avec la photo d'un homme et une femme souriant](/content/dam/cra-arc/camp-promo/factsheet/steps-volunteer-clinic-en.jpg)

Poster description

**Steps for volunteering at a free tax clinic**

Through the Community Volunteer Income Tax Program (CVITP), you can join thousands of volunteers across Canada who help people in need do their taxes. Free tax clinics can make a big difference in the lives of those with modest incomes by helping them access their benefits and tax credits. This is money they rely on to make rent, pay for childcare or buy food for their families.

You can volunteer in person or virtually. For virtual clinics, it helps if you have some CVITP experience, are comfortable working on your own, and are approved to use “Auto-fill my return,” which is an online service of the Canada Revenue Agency (CRA).

This checklist provides an overview of the steps for volunteering at a free tax clinic. You will find full instructions in the training and support materials that the CRA gives to CVITP volunteers and host organizations.

Checklist

**Register as a volunteer**

1. Go to [canada.ca/taxes-volunteer](/en/revenue-agency/campaigns/cvitp-taxes-volunteers.html) to register as a volunteer. We recommend that you register between the end of October and the start of February.
2. Choose a volunteer role: you can provide support, be a tax preparer or do both.
3. Identify the volunteer requirements for your role:
   * For a support role, the requirements depend on whether you will handle or have access to taxpayer information
   * For a tax preparer role, the requirements depend on how you will prepare and file returns (in person, virtual or both)

**Complete the volunteer requirements**

4. Affiliate with a CVITP community organization (this is required for volunteering). CRA coordinators can help match you with an organization.
5. Depending on your role, you may need to:
   * get a RepID on the CRA’s Represent a Client portal
   * apply for a CVITP EFILE account or renew your account
   * provide a valid police record check (obtained within the last three years)
6. If you volunteer at a virtual clinic, you may also need an email address and access to:
   * the Internet
   * video conferencing software (you may have to download an app)
   * a phone

**Take training**

7. Take free training offered by the CRA.

**Install software**

8. If you are going to be a tax preparer, install the current version of the UFile CVITP tax software. To use the software, you will need to enter a software activation key, which the CRA makes available starting in late January.

**Volunteer at a clinic**

9. Ask taxpayer for identification.
10. Get authorization to do their taxes.
11. Keep information secure and confidential.
12. Use the CRA’s electronic services, including EFILE for electronic filers, and Auto-fill my return.
13. Enter the CVITP organization identification number (COIN) on each return that is filed using the UFile CVITP tax software.
14. Call the CVITP help line to ask questions about income tax, EFILE and the UFile software.

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/steps-volunteer-clinic-en.pdf)

PDF, 216 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type :** Factsheet
**Last update:** 2025-06-04

An overview of the steps for volunteering at a free tax clinic with the Community Volunteer Income Tax Program (CVITP).

## French factsheet

* [Étapes pour devenir bénévole à un comptoir d’impôts gratuit](/content/dam/cra-arc/camp-promo/factsheet/etapes-benevole-comptoir-fr.pdf)

## Page details

Date modified:
:   2025-06-05
