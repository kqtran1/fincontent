3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Newcomers

The official versions of the CRA factsheet and infographics on benefits and credits are the English and French versions. While reasonable efforts are made to provide accurate translations, due to the nuances in translating to another language, slight differences or inaccuracies may exist.

![image of factsheet with picture of woman holding a smiling child](/content/dam/cra-arc/camp-promo/factsheet/fctsht_thmbnl_nw_cnd-en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd-en.pdf)

PDF, 263 KB, 2 pages
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Factsheet
**Last update:** 2025-07-01

Many of the benefits people enjoy in Canada are made possible through taxes.

## French factsheet

* [les nouveaux arrivants](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd-fr.pdf)

## Other languages

* [Arabic](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_arabic.pdf)
* [Dari](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_dari.pdf)
* [Pashto](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_pashto.pdf)
* [Punjabi](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_punjabi.pdf)
* [Russian](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_russian.pdf)
* [Simplified Chinese](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_simplifiedchinese.pdf)
* [Spanish](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_spanish.pdf)
* [Tagalog](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_tagalog.pdf)
* [Ukrainian](/content/dam/cra-arc/camp-promo/factsheet/fctsht_nw_cnd_Ukrainian.pdf)

## Page details

Date modified:
:   2025-07-01
