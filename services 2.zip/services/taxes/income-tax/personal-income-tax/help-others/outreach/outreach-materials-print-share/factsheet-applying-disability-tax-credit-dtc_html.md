3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Factsheet: Applying for the disability tax credit (DTC)

![image of poster](/content/dam/cra-arc/camp-promo/pstr_pplyng-dsblty-tx-crdt-dtc-en.jpg)

[Download factsheet (PDF)](/content/dam/cra-arc/camp-promo/t1300-23e-ctp.pdf)

PDF, 161 KB, 1 page
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Poster
**Last update:** 2024-09-13

The disability tax credit (DTC) is a non-refundable tax credit that helps people with physical or mental impairments, or their supporting family member, reduce the amount of income tax they may have to pay.

## French factsheet

* [Demander le crédit d’impôt pour personnes handicapées](/content/dam/cra-arc/camp-promo/t1300-23f-ctp.pdf)

## Page details

Date modified:
:   2024-09-17
