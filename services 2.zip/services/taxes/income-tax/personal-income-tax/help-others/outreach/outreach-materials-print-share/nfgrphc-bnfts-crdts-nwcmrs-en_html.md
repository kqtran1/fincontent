3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)
6. [How outreach officers can help your community learn about tax and benefits](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach.html)
7. [Outreach materials to print and share](/en/services/taxes/income-tax/personal-income-tax/help-others/outreach/outreach-materials-print-share.html)

# Infographic – Benefits and Credits for Newcomers – English

The official versions of the CRA factsheet and infographics on benefits and credits are the English and French versions. While reasonable efforts are made to provide accurate translations, due to the nuances in translating to another language, slight differences or inaccuracies may exist.

![Infographic – Benefits and Credits for Newcomers – English](/content/dam/cra-arc/camp-promo/nw-cnd-en.jpg)

[Download Infographic (PDF)](/content/dam/cra-arc/camp-promo/nw-cnd-en.pdf)

PDF, 198 KB, 1 page
**Organization:** [Canada Revenue Agency](/en/revenue-agency.html)
**Type:** Infographic
**Last update:** 2024-12-30

New to Canada? You may be eligible for benefits and credits.

## French infographic

* [Prestations et crédits pour les nouveaux arrivants](/content/dam/cra-arc/camp-promo/nw-cnd-fr.pdf)

## Other languages

* [Arabic](/content/dam/cra-arc/camp-promo/nw-cnd-rbc.pdf)
* [Dari](/content/dam/cra-arc/camp-promo/nw-cnd-dr.pdf)
* [Pashto](/content/dam/cra-arc/camp-promo/nw-cnd-psht.pdf)
* [Punjabi](/content/dam/cra-arc/camp-promo/nw-cnd-pnjb.pdf)
* [Russian](/content/dam/cra-arc/camp-promo/nw-cnd-rssn.pdf)
* [Simplified Chinese](/content/dam/cra-arc/camp-promo/nw-cnd-smplfd-chns.pdf)
* [Spanish](/content/dam/cra-arc/camp-promo/nw-cnd-spnsh.pdf)
* [Tagalog](/content/dam/cra-arc/camp-promo/nw-cnd-tg.pdf)
* [Ukrainian](/content/dam/cra-arc/camp-promo/nw-cnd-krnn.pdf)

## Page details

Date modified:
:   2025-01-01
