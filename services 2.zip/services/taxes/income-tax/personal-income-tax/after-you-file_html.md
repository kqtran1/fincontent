3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)

Personal income tax

# After filing a tax return

Get a notice of assessment (NOA) or notice of reassessment (NOR), check the status of your refund, how to pay
a balance owing, or make changes to a tax return after it has been assessed.

### [Notices of assessment](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html)

How to get and understand results from a tax return on a notice of assessment (NOA) or reassessment

### [Tax refunds](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/refunds.html)

When and how to get your refund, check the status, transferring to an instalment account

### [Paying your taxes](/en/revenue-agency/services/payments/payments-cra.html)

Find options to pay a debt now or over time, pay 2025 taxes by instalments

### [Changing a tax return](/en/services/taxes/income-tax/personal-income-tax/after-you-file/change-return.html)

Options for changing a return, how long it takes to process, what changes can be made

### [Get a proof of income statement](/en/revenue-agency/services/e-services/digital-services-individuals/a-proof-income-statement-option-print.html)

Summary of your income and deductions for a specific year used as proof of your finances

### [Keep tax documents](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/long-should-you-keep-your-income-tax-records.html)

Which tax documents you need to keep for 6 years in case the CRA asks to verify information

## Compliance, disputes, and your rights

### [Interest and penalties](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/interest-penalties.html)

When and how interest charges and penalties are applied, late-filing and other penalties

### [Review of your tax return](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/review-your-tax-return-cra.html)

Why a tax return is selected for further review, types of reviews, submitting documents for review

### [Objections, appeals, disputes, and relief measures](/en/revenue-agency/services/about-canada-revenue-agency-cra/complaints-disputes.html)

File an objection or appeal, request penalty or interest relief, remissions

### [Understand your rights as a taxpayer](/en/revenue-agency/corporate/about-canada-revenue-agency-cra/taxpayer-bill-rights.html)

Know your rights, entitlements, and obligations as a Canadian taxpayer when interacting with the CRA

## Page details

Date modified:
:   2025-07-09
