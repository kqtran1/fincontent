3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)

Personal income tax

# How to file a tax return – Personal income tax

You may choose to do your own taxes or have someone else do them for you using tax software or on paper. If eligible, you may be able to get your taxes done for free by invitation or at a free tax clinic.

## Filing due dates for 2024 taxes

* **April 30, 2025**: Deadline to file your taxes
* **June 15, 2025** (June 16, 2025, since June 15 is a Sunday): Deadline to file your taxes if you or your spouse or common-law partner are self-employed

## Services and information

### [Tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)

Find certified tax software to complete a tax return and send it using NETFILE

### [Using your SimpleFile invitation](/en/services/taxes/income-tax/personal-income-tax/how-file/simplefile.html)

How to access CRA's free tax filing service using your invitation

### [Free tax clinic](/en/revenue-agency/services/tax/individuals/community-volunteer-income-tax-program/need-a-hand-complete-your-tax-return.html)

Have a volunteer do your taxes for free if you have a modest income and simple tax situation

### [Using a professional tax preparer (EFILE)](/en/revenue-agency/services/e-services/digital-services-individuals/efile-individuals.html)

Find a registered tax professional to file your taxes for a service fee

### [Paper tax return (T1 tax package)](/en/revenue-agency/services/forms-publications/tax-packages-years/general-income-tax-benefit-package.html)

Complete a return using the income tax package, send by mail, allow 8 weeks to process

### [On behalf of someone who died](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died.html)

Report date of death, access tax records as a representative, file final returns

## Page details

Date modified:
:   2025-07-09
