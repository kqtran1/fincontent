3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)

# Tax software for filing personal taxes

**You may be looking for:**

* [Filing as a professional tax preparer (EFILE)](/en/revenue-agency/services/e-services/digital-services-businesses/efile-electronic-filers.html)

You can use tax software certified by the Canada Revenue Agency (CRA) to help calculate and file your personal income taxes electronically. A list of third-party software developers and their certified tax software products is provided each tax year.

Within certified tax software, you can choose how you want to enter your tax information, send your return to the CRA, and view your notice of assessment (NOA).

## Electronic filing dates

* **February 24, 2025**: Electronic filing services are open until January 30, 2026

## Sections

[Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
:   List of tax software, find options based on cost and software details

[Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
:   Steps and options to fill in your return using tax software, get your NETFILE access code

[Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)
:   Eligibility to send a return electronically, get your NOA in tax software

## Page details

Date modified:
:   2025-07-09
