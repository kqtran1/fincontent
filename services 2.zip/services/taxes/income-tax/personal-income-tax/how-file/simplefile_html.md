3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)

# Use your SimpleFile invitation to file your taxes

Simplified tax filing methods offered by the Canada Revenue Agency (CRA) to eligible individuals

SimpleFile services are simplified tax filing methods offered by the CRA to eligible individuals with a lower income and a simple tax situation. These services are **offered by invitation only**.

With SimpleFile services, you only need to answer a series of quick questions, and then the services use your answers and the information the CRA has on file, to complete and process an income tax and benefit return on your behalf. Once your return has been assessed, you will receive a [notice of assessment (NOA)](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/notice-assessment-understand.html).

SimpleFile services are:

* Free
* Fast
* Secure

## Ways to SimpleFile

### If you are a Quebec resident

The CRA's SimpleFile service options **only** complete the federal income tax and benefit return. You will still need to complete and submit a Quebec provincial income tax return with [Revenu Québec](https://www.revenuquebec.ca/en/).

SimpleFile by Phone

The invitation package provides the information you need to use the SimpleFile by Phone service, **including the phone number to call**. There are no forms to fill out or calculations to do. You do not need to speak to an agent to use this service.

Eligibility
:   You do not need to have income to use this service. If you do have income, it must be under a certain threshold and from certain sources.

    Income under a certain threshold

    The income threshold is based on factors that include age, province of residence, and disability status.

    Income from certain sources

    You must only have income from the following sources:

    Benefits
    :   Old Age Security – T4A(OAS)

        Guaranteed Income Supplement / Net federal supplements – T4A(OAS)

        Canada or Quebec Pension Plan benefits (including disability benefits) – T4A(P)

    Employment and related income supports
    :   Employment income – T4

        Employment Insurance Benefits – T4E

        Workers’ compensation benefits – T5007

        Social assistance payments – T5007

        Canada Emergency Benefits – T4A

    Investment income
    :   Some Interest Income – T5 (box 13)

Invitations
:   This service applies to invitations that are sent in:

    * February 2025
    * March 2025
    * Summer 2025

    If your personal situation has changed, you may no longer be able to use the service.

    How you will receive your invitation

    Delivery through email notifications
    :   If you are registered to receive email notifications, we will send you an email when your SimpleFile invitation package is available to view in [My Account](/en/revenue-agency/services/e-services/cra-login-services.html).

        If you have access to My Account, but are not registered for email notifications, you can also view your invitation in My Account.

    Delivery by mail
    :   Unless you are registered to receive email notifications, we will send your SimpleFile invitation package by mail to the mailing address we have on file.

Availability
:   This service is available 21 hours a day between 6 am and 3 am (Eastern time), 7 days a week starting February 24, 2025

Completion time
:   Approximately 5 to 10 minutes

Additional information
:   To use the phone service, you will need to:

    * Provide some personal information
    * Answer a series of short questions using the keypad on your phone

    If you are disconnected from the call

    If you hang up or are disconnected from the call before the end of the session, you will have to call again.

    If you think you have made an error before the end of the session, you can hang up and call back to start over.

    Your information will only be saved once you have completed the call.

    If you have a Personal Identification Number (PIN)

    You can receive an estimate of your net income, taxable income, and any refund that you may be eligible for at the end of the call. To receive this information, you will need to provide your PIN when prompted.

    For information on how to create a PIN, refer to: [Use a PIN when you call us](/en/revenue-agency/corporate/contact-information/use-pin-when-you-call-us.html)

SimpleFile Digital

The invitation package provides the information you need to use the SimpleFile Digital service, **including the link to the service**. There are no forms to fill out or calculations for you to do.

Eligibility
:   You do not need to have income to use this service. If you do have income, it must be under a certain threshold and from certain sources.

    Income under a certain threshold

    The income threshold is based on factors that include age, province of residence, and disability status.

    Income from certain sources

    You must only have income from the following sources:

    Benefits
    :   Old Age Security – T4A(OAS)

        Guaranteed Income Supplement / Net federal supplements – T4A(OAS)

        Canada or Quebec Pension Plan benefits (including disability benefits) – T4A(P)

    Employment and related income supports
    :   Employment income – T4

        Employment Insurance Benefits – T4E

        Workers’ compensation benefits – T5007

        Social assistance payments – T5007

        Canada Emergency Benefits – T4A

    Investment income
    :   Some Interest Income – T5 (box 13)

Invitations
:   This service **only** applies to invitations that are sent in:

    * March 2025
    * Summer 2025

    If your personal situation has changed, you may no longer be able to use this service.

    How you will receive your invitation

    Delivery through email notifications
    :   If you are registered to receive email notifications, we will send you an email when your SimpleFile invitation package is available to view in [My Account](/en/revenue-agency/services/e-services/cra-login-services.html).

        If you have access to My Account, but are not registered for email notifications, you can also view your invitation in My Account.

    Delivery by mail
    :   Unless you are registered on to receive email notifications, we will send your SimpleFile invitation package by mail to the mailing address we have on file.

Availability
:   This service is available 21 hours a day between 6 am and 3 am (Eastern time), 7 days a week starting February 24, 2025.

Completion time
:   Approximately 10 to 20 minutes

Additional information
:   To complete the web form, you will need to:

    * Log in through the link provided in the invitation package
    * Use the access code provided on the invitation letter
    * Provide some personal information
    * Answer a series of short questions

SimpleFile by Paper

The invitation package provides the information you need to use the SimpleFile by Paper service, **including the paper return**.

Eligibility
:   You do not need to have income to use this service. If you do have income, it must be under a certain threshold and from certain sources.

    You:

    * Do not need to have a filing history
    * Are allowed to have tax exempt income

    Income under a certain threshold

    The income threshold is based on factors that include age, province of residence, and disability status.

    Income from certain sources

    You must only have income from the following sources:

    Benefits
    :   Old Age Security – T4A(OAS)

        Guaranteed Income Supplement / Net federal supplements – T4A(OAS)

        Canada or Quebec Pension Plan benefits (including disability benefits) – T4A(P)

    Employment and related income supports
    :   Employment income – T4

        Employment Insurance Benefits – T4E

        Workers’ compensation benefits – T5007

        Social assistance payments – T5007

        Canada Emergency Benefits – T4A

    Investment income
    :   Some Interest Income – T5 (box 13)

Invitations
:   This service **only** applies to invitations that are sent in:

    * Summer 2025

    If your personal situation has changed, you may no longer be able to use the service.

    How you will receive your invitation

    Delivery by mail
    :   We will send your invitation package to the mailing address we have on file.

Availability
:   This service does not have a closing date, but the form can only be used for the tax year specified on the form.

Completion time
:   Approximately 25 minutes or less

Additional information
:   To complete the paper form, you will need to:

    * Provide some personal information
    * Provide information about your income on the form provided in the invitation package
    * Send the form back to the CRA using the envelope provided

Find out more about [automatic tax filing services](/en/revenue-agency/campaigns/offering-and-expanding-automatic-tax-filing-services.html).

## Page details

Date modified:
:   2025-07-17
