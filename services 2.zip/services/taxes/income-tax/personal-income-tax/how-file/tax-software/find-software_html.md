3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)

# Tax software for filing personal taxes

* [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
* [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
* [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

# Find certified tax software

## 2024 capital gains reporting available

As of March 27, 2025, you can report 2024 capital gains using any certified tax software.

Each year, the Canada Revenue Agency (CRA) certifies tax software developed by third party service providers. You can use certified tax software to electronically calculate and file a tax return.

Before choosing the tax software, review the software details to ensure it meets your tax filing needs.

Check the software developer's website to ensure you have the most recently updated version. If you need support using the software, contact the software developer directly.

Benefits
:   * Fast
    * Easy
    * Secure
    * Automated

Costs vary
:   If you have a modest income, most software will prepare a basic tax return for free, otherwise there is usually a service fee.

Disclaimer for using certified tax software

* The Canada Revenue Agency (CRA) does not look at the privacy policies of software developers.

  It is your responsibility to research the policies before buying or using the tax software.
* The use of the software is the responsibility of the user and the software developer.

  The CRA cannot be held responsible if omissions or programming errors affect the calculation of amounts payable.

Tax software companies whose products are certified for NETFILE are not representatives of the CRA. You are not obliged to send personal information directly to the tax software company when you ask for software assistance. Email is not a secure method of communication. Sending personal information by email is a big concern and increases the risk of identity theft.

The CRA respects the [Official Languages Act](https://lois-laws.justice.gc.ca/eng/acts/O-3.01/index.html) and the relevant Treasury Board policies, and it is committed to making sure all information and services on this site are available in English and French. However, users should be aware that some information from external sources that do not have to follow the *Official Languages Act* is offered only as a convenience and is available only in the language in which it was provided to the CRA.

## Certified tax software for 2024

The list below loads
in random order.

Filter:

* Free options

* Paid options

Reset filters

---

Filter items

results out of

Certified tax software

| Software provider | 2024 pricing | Software options | Details |
| --- | --- | --- | --- |
| [AdvTax](https://www.aclasssoft.com/) | * Paid * Free offerings [based on tax situation](#Y) | * Online | [AdvTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/advtax-details.html) |
| [Better Tax](https://www.bettertax.ca) | * Free | * Online | [Better Tax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/bettertax-details.html) |
| [CloudTax](https://www.cloudtax.ca/) | * Free * Optional paid services | * Online * Mobile app | [CloudTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/cloudtax-details.html) |
| [EachTax](https://www.eachtax.com/secure/home.php) | * Free * Paid * Free offerings [based on tax situation](#Y) | * Online | [EachTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/eachtax-details.html) |
| [FastnEasyTax](https://www.fastneasytax.com/ca/) | * Paid * Free offerings [based on tax situation](#Y) | * Online * Mobile app | [FastnEasyTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/fastneasytax-details.html) |
| [FutureTax](https://www.futuretax.ca/netfile) | * Paid * Free offerings [based on tax situation](#Y) | * Computer download | [FutureTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/futuretax-details.html) |
| [GenuTax Standard](https://www.genutax.ca) | * Free | * Computer download | [GenuTax Standard details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/genutax-details.html) |
| [H&R Block Tax Software Free](https://www.hrblock.ca/online-tax-software/) | * Paid * Free offerings [based on tax situation](#Y) | * Online | [H&R Block Tax Software Free details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/hrblock-details.html) |
| [myTaxExpress](https://www.mytaxexpress.com/index.html) | * Paid * Free offerings [based on tax situation](#Y) | * Computer download | [myTaxExpress details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/mytaxexpress-details.html) |
| [StudioTax](https://www.studiotax.com/home.html) | * Free (mobile app) * Paid (computer download) * Free offerings [based on tax situation](#Y) | * Computer download * Mobile app | [StudioTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/studiotax-details.html) |
| [Tax Chopper](https://www.taxchopper.ca) | * Paid * Free offerings [based on tax situation](#Y) | * Online | [Tax Chopper details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/taxchopper-details.html) |
| [TaxFreeway](https://www.taxfreeway.ca/) | * Paid * Free offerings [based on tax situation](#Y) | * Computer download * Mobile app | [TaxFreeway details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/taxfreeway-details.html) |
| [TaxTron](https://www.taxtron.ca) | * Free (online) * Paid (computer download) * Free offerings [based on tax situation](#Y) | * Online * Computer download | [TaxTron details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/taxtron-details.html) |
| [TurboTax](https://turbotax.intuit.ca/tax/software) | * Paid * Free offerings [based on tax situation](#Y) | * Online * Computer download * Mobile app | [TurboTax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/turbotax-details.html) |
| [UFile](https://www.ufile.ca) | * Paid * Free offerings [based on tax situation](#Y) | * Online * Computer download | [UFile details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/ufile-details.html) |
| [Wealthsimple Tax](https://www.wealthsimple.com/en-ca/) | * Free * Optional paid services | * Online | [Wealthsimple Tax details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/wealthsimple-details.html) |
| [WebTax4U.ca](https://secure.macront.com/WebTax4U.ca/) | * Paid * Free offerings [based on tax situation](#Y) | * Online | [WebTax4U.ca details](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software/webtax4u-details.html) |

## Free offerings based on tax situation

Depending on the year, some tax software may offer free options if you:

* Have a modest income
* Have a simple tax situation
* Live in certain provinces or territories
* Meet other criteria specified by the software provider

Check the software provider's website to find out which options may be free for the tax year you are filing.

## Filing for a previous tax year

You must use software certified for the tax year you are filing. Most providers from the [list above](#tax-soft) are also certified for previous years.

You can currently file with tax software for tax years 2017 to 2024. Check the software details for each provider to find out which years they are certified for.

## Document navigation

* [Next: Complete a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)

## Page details

Date modified:
:   2025-07-11
