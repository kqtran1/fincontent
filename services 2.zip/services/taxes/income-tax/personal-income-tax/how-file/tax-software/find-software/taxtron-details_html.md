3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for TaxTron

**Company Name**: TaxTron Inc.

**Product name:** [TaxTron for Windows](https://taxtron.ca/buy-online/pc) (2017 to 2024 tax years)

[TaxTron for Mac](https://taxtron.ca/buy-online/mac) (2017 to 2024 tax years)

[TaxTron for Web](https://taxtronweb.ca/) (2018 to 2024 tax years)

**Support:** email support@taxtron.ca

**Certified for the 2017 to 2024 tax years.**

**Available services:**

* **Auto-fill my return** – 2017 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2017 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2017 to 2024 tax years

**Not supported for the 2024 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, and Submit E-Documents
* Electronic transmission of Special Elections & Returns – Form UHT-2900 (TaxTron for Mac and TaxTron for Web only)
* Form T2203 – Provincial and Territorial Taxes –  Multiple Jurisdictions
* Form T1273 – Limited occurrences of Crop inventory valuation and productive capacity and Livestock inventory valuation

**Not supported for the 2023 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* Form T2203 – Provincial and Territorial Taxes –  Multiple Jurisdictions
* Form T1273 – Limited occurrences of Crop inventory valuation and productive capacity and Livestock inventory valuation

**Not supported for the 2017 to 2022 tax years:**

* Form T2203 – Provincial and Territorial Taxes –  Multiple Jurisdictions
* Form T1273 – Limited occurrences of Crop inventory valuation and productive capacity and Livestock inventory valuation
* Electronic transmission of Form T1134

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

---

## Page details

Date modified:
:   2025-07-09
