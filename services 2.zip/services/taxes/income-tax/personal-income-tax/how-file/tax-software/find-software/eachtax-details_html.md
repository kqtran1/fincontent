3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for EachTax.com

**Company name:** XInfo Technology Inc.

**Product name:** [EachTax.com](https://www.eachtax.com/secure/home.php) (Online)

[EachTax Free](https://www.eachtax.com/free/secure/home.php) (Online) (2021 to 2024 tax years only)

**Support:** support@eachtax.com

**Certified for the 2017 to 2024 tax years.**

**Available services:**

* **Auto-fill my return –**2017 to 2024 tax years
* **Notice of Assessment via Tax Software –**2017 to 2024 tax years
* **ReFILE –** 2021 to 2024 tax years
* **T1135 –**2017 to 2024 tax years (EachTax.com only)

**Not supported for the 2024 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Form T1135 (EachTax Free only)
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, and UHT-2900 and Submit E-Documents
* Form T2203 - Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2023 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Form T1135 (EachTax Free only)
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* T1 Provincial Quebec forms
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions

**Not supported for the 2021 and 2022 tax years:**

* Electronic transmission of Form T1134
* Electronic transmission of Form T1135 (EachTax Free only)
* T1 Provincial Quebec forms
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions

**Not supported for the 2017 to 2020 tax years:**

* Province of Quebec
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
