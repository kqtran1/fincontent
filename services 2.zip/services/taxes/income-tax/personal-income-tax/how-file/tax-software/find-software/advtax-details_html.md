3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for AdvTax

**Company name:** Aclasssoft Inc

**Product name:** [AdvTax](http://www.aclasssoft.com/) (Online)

**Support:** admin@aclasssoft.com

**Certified for the 2017 to 2024 tax years.**

**Available services:**

* **Auto-fill my return** – 2017 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2017 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2017 to 2024 tax years

**Not supported for the 2024 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns – Submit E-Documents
* T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms
* Diacritics

**Not supported for the 2023 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, and T2059
* T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms
* Diacritics

**Not supported for the 2017 to 2022 tax years:**

* Electronic transmission of Form T1134
* T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms
* Diacritics

**Note:** This software **does not support the calculation/production of the T1 Provincial Québec return**. For the list of software authorized by Revenu Québec for use by individuals in filing the personal income tax return **TP-1**, please visit the [Revenu Québec website](https://www.revenuquebec.ca/en/partners/authorized-products/authorized-software/personal-income-tax-return-individuals/).

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
