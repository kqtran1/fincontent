3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for TaxFreeway

**Company name:**

Entropy Technology Ltd.

**Product names:**

[TaxFreeway for Windows](https://www.taxfreeway.ca/)

[TaxFreeway for Mac](https://www.taxfreeway.ca/)

**Support:**

[TaxFreeway for Windows – Contact us](https://www.taxfreeway.ca/win/contactus.html)

[TaxFreeway for Mac – Contact us](https://www.taxfreeway.ca/mac/contactus.html)

**Certified for the 2017 to 2024 tax years.**

**Available services:**

* **Auto-fill my return** – 2017 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2017 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2017 to 2024 tax years
* **T1134** – 2021 to 2024 tax years

**Not supported for the 2024 tax year:**

* Non-Resident Status Returns – Emigrant Returns
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, UHT-2900, and Submit E-Documents
* T1 Provincial Quebec forms

**Not supported for the 2023 tax year:**

* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* T1 Provincial Quebec forms

**Not supported for the 2017 to 2022 tax years:**

* T1 Provincial Quebec forms

---

**Product name:**

[TaxFreeway for iPad](https://www.taxfreeway.ca/)

**Support:**

[TaxFreeway for iPad – Contact us](https://www.taxfreeway.ca/ipad/contactus.html)

**Certified for the 2017 to 2024 tax years.**

**Available services:**

* **Auto-fill my return** – 2017 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2017 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2017 to 2024 tax years
* **T1134** – 2021 to 2024 tax years

**Not supported for the 2024 tax year:**

* Non-Resident Status Returns – Emigrant Returns
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, UHT-2900, and Submit E-Documents
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms

**Not supported for the 2023 tax year:**

* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms

**Not supported for the 2017 to 2022 tax years:**

* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* T1 Provincial Quebec forms

**Note:** This software **does not support the calculation/production of the T1 Provincial Québec return**. For the list of software authorized by Revenu Québec for use by individuals in filing the personal income tax return **TP-1**, please visit the [Revenu Québec website](https://www.revenuquebec.ca/en/partners/authorized-products/authorized-software/personal-income-tax-return-individuals/).

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
