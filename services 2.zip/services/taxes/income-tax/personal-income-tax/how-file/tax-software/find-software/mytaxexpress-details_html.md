3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for myTaxExpress

**Company name :** Arcadia Solution Corp.

**Product names:** [myTaxExpress](http://www.mytaxexpress.com) (Windows)
                               [myTaxExpress](http://www.mytaxexpress.com) (MAC)

**Support:** email contact@mytaxexpress.com

**Certified for the 2017 to 2024 tax years.**

**Available services**:

* **Auto-fill my return** – 2017 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2017 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2017 to 2024 tax years

**Not supported for the 2024 tax year:**

* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, UHT-2900, and Submit E–Documents
* Form T2203, Provincial and Territorial Taxes – Multiple Jurisdictions
* Province of Quebec
* Form T1273 – Statement A – Harmonized AgriStability / AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Electronic transmission of Form T1134

**Not supported for the 2023 tax year:**

* Province of Quebec
* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* Form T1273 – Statement A – Harmonized AgriStability / AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2021 and 2022 tax years:**

* Province of Quebec
* Electronic transmission of Form T1134
* Form T1273 – Statement A – Harmonized AgriStability / AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2017 to 2020 tax years:**

* Province of Quebec
* Electronic transmission of Form T1134
* Form T1273 – Statement A – Harmonized AgriStability / AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203, Provincial and Territorial Taxes – Multiple Jurisdictions

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

---

## Page details

Date modified:
:   2025-07-09
