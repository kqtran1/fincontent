3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for CloudTax

**Company name:**

CloudTax Inc.

**Product names:**

[CloudTax Plus (Online)](https://cloudtax.ca/plus/?gspk=Y3JhbmV0ZmlsZTg4Njk&gsxid=tgZBf0HHInwV)

[CloudTax Plus (Android)](https://cloudtax.ca/plus/?gspk=Y3JhbmV0ZmlsZTg4Njk&gsxid=tgZBf0HHInwV)

[CloudTax Plus (Apple)](https://cloudtax.ca/plus/?gspk=Y3JhbmV0ZmlsZTg4Njk&gsxid=tgZBf0HHInwV)

[CloudTax API (Online)](https://www.cloudtax.ca/api) (2022 to 2024 only)

**Support:** info@cloudtax.ca

**Certified for the 2020 to 2024 tax years.**

**Available services:**

* **Auto-fill my return** – 2020 to 2024 tax years
* **Notice of Assessment via Tax Software** – 2020 to 2024 tax years
* **ReFILE** – 2021 to 2024 tax years
* **T1135** – 2020 to 2024 tax years

**Not supported for the 2024 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, UHT–2900, and Submit E–Documents
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Province of Quebec
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2023 tax year:**

* Province of Quebec
* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT–2900
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2022 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Electronic transmission of Form T1134
* Electronic transmission of Form T1135
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2038 – Investment Tax Credit (Individuals)
* Logging tax credit

**Not supported for the 2021 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Electronic transmission of Form T1134
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T2121 and T2042
* Form T2038 – Investment Tax Credit (Individuals)
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* Returns that report a spousal transfer from an ex-spouse with disability

**Not supported for the 2020 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T2121, T2042, T1255
* Form T2038 – Investment Tax Credit (Individuals)
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* More than 3 Selected Financial Data (SFD) entries per self-employment type

**Product names:**

[CloudTax Free](https://cloudtax.grsm.io/free) (Online)

[CloudTax Free](https://cloudtax.grsm.io/android) (Android)

[CloudTax Free](https://cloudtax.grsm.io/apple) (Apple)

**Support:** info@cloudtax.ca

**Certified for the 2018 to 2024 tax years.**

**Available services:**

* **Auto-fill my return –** 2018 to 2024 tax years
* **Notice of Assessment via Tax Software –** 2018 to 2024 tax years
* **ReFILE –** 2021 to 2024 tax years
* **T1135** – 2021 to 2024 tax years only

**Not supported for the 2024 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, UHT–2900, and Submit E–Documents
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Province of Quebec
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2023 tax year:**

* Province of Quebec
* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT–2900
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals

**Not supported for the 2022 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Electronic transmission of Form T1134
* Electronic transmission of Form T1135
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2038 – Investment Tax Credit (Individuals)
* Logging tax credit

**Not supported for the 2021 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Electronic transmission of Form T1134
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T2121 and T2042
* Form T2038 – Investment Tax Credit (Individuals)
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* Returns that report a spousal transfer from an ex-spouse with disability

**Not supported for the 2020 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T776, T2125, T2121, T2042, T777, TL2, T2091, T1255
* Form T2038 – Investment Tax Credit (Individuals)
* Non-capital losses of other years with restricted and prior year farming losses
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* More than 3 Selected Financial Data (SFD) entries per self-employment type

**Not supported for the 2019 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T776, T2125, T2121, T2042, T777, TL2, T2091, T1255
* Form T2038 – Investment Tax Credit (Individuals)
* Joint returns
* Non-capital losses of other years with restricted and prior year farming losses
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* More than 3 Selected Financial Data (SFD) entries per self-employment type

**Not supported for the 2018 tax year:**

* Provinces of Quebec, Northwest Territories, Yukon and Nunavut
* Joint returns
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self employment business statements: T776, T2125, T2121, T2042, T777, TL2, T2091, T1255
* Form T691 – Alternative Minimum Tax
* Form T2038 – Investment Tax Credit (Individuals)
* Form T936 – Calculation of Cumulative Net Investment Loss (CNIL)
* Form T657 – Calculation of Capital Gains Deduction
* Capital gains deduction
* Non-capital losses of other years with restricted and prior year farming losses
* Limited partnerships (T5013), including tax shelters
* Logging tax credit
* Canadian Indian income
* Diacritics (accents)

**Note:** This software **does not support the calculation/production of the T1 Provincial Québec return**. For the list of software authorized by Revenu Québec for use by individuals in filing the personal income tax return **TP-1**, please visit the [Revenu Québec website](https://www.revenuquebec.ca/en/partners/authorized-products/authorized-software/personal-income-tax-return-individuals/).

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
