3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for Better Tax

**Company name:** The Better Tax Company

**Product name:** Better Tax

**Support:** help@bettertax.ca

**Certified for the 2023 and 2024 tax years.**

**Available services:**

* **Auto-fill my return –**2023 and 2024 tax years
* **Notice of Assessment via Tax Software –**2023 and 2024 tax years
* **ReFILE –** 2023 and 2024 tax years
* **T1135 –**2023 and 2024 tax years

**Not supported for the 2024 tax year:**

* Non-Resident Status Returns – Emigrant Returns
* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, UHT–2900, and Submit E–Documents
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* T1 Provincial Quebec forms

**Not supported for the 2023 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns – Forms T217, T2057, T2059, and UHT–2900
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1273 – Limited occurrences of Crop inventory valuation and productive capacity and Livestock inventory valuation

**Note:** This software **does not support the calculation/production of the T1 Provincial Québec return**. For the list of software authorized by Revenu Québec for use by professional tax preparers in filing the personal income tax return **TP-1**, please visit the Revenu Québec website.

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
