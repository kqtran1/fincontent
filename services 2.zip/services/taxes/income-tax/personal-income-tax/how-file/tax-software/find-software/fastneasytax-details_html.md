3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)

# Detailed information for fastneasytax.com

**Company name:** Fastneasy Services Inc.

**Product names:** [fastneasytax.com](https://www.fastneasytax.com/ca/) (Online)
                               [eFile Canadian Tax Return (Apple)](https://www.fastneasytax.com/ca/)
                               [eFile Canadian Tax Return (Android)](https://www.fastneasytax.com/ca/)

**Support:** email support@fastneasytax.com and <https://www.facebook.com/fastneasytax/>

**Certified for the 2017 to 2024 tax years**

**Available services:**

* **Auto-fill my return –** 2017 to 2024 tax years
* **Notice of Assessment via Tax Software –** 2017 to 2024 tax years
* **ReFILE –** 2021 to 2024 tax years
* **T1135 –** 2023 and 2024 tax years

**Not supported for the 2024 tax year:**

* Non–Resident Status Returns – Emigrant Returns
* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900, and Submit E–Documents
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Territories of Northwest Territories, Yukon, Nunavut, and the province of Québec.
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Self-employed business statements - T2125, T2121 and T2042
* Limited or non-active partnership (T5013) including tax shelters
* Logging tax credit

**Not supported for the 2023 tax year:**

* Electronic transmission of Form T1134
* Electronic transmission of Special Elections & Returns - Forms T217, T2057, T2059, and UHT-2900
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Self-employed business statements - T2125, T2121 and T2042
* Limited or non-active partnership (T5013) including tax shelters
* Logging tax credit

**Not supported for the 2021 and 2022 tax years:**

* Electronic transmission of Form T1135
* Electronic transmission of Form T1134
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Self-employed business statements - T2125, T2121 and T2042
* Limited or non-active partnership (T5013) including tax shelters
* Logging tax credit

**Not supported for the 2020 tax year:**

* Form T1135 – Foreign Income Verification Statement
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 **–** Provincial and Territorial Taxes **–** Multiple Jurisdictions
* Self-employed business statements - T2125, T2121 and T2042
* Limited or non-active partnership (T5013) including tax shelters
* Logging tax credit

**Not supported for the 2019 tax year:**

* Form T1135 – Foreign Income Verification Statement
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 **–** Provincial and Territorial Taxes **–** Multiple Jurisdictions
* Self-employed business statements – T2125, T2121 and T2042
* Limited partnership including tax shelters
* Logging tax credit
* Non-capital losses of other years with restricted and prior year farming losse

**Not supported for the 2018 tax year:**

* Form T1135 – Foreign Income Verification Statement
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 – Provincial and Territorial Taxes – Multiple Jurisdictions
* Form T691 – Alternative Minimum Tax
* Self-employed business statements
* Limited partnership including tax shelters
* Non-capital losses of other years with restricted and prior year farming losses
* Logging tax credit
* Canadian Indian income

**Not supported for the 2017 tax year:**

* Form T1135 – Foreign Income Verification Statement
* Territories of Northwest Territories, Yukon and Nunavut
* Form T1273 – Statement A – Harmonized AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T1163 – Statement A – AgriStability and AgriInvest Programs Information and Statement of Farming Activities for Individuals
* Form T2203 **–** Provincial and Territorial Taxes **–** Multiple Jurisdictions
* Self-employed business statements
* Limited partnership including tax shelters
* Non-capital losses of other years with restricted and prior year farming losses
* Logging tax credit

Please note that this information was provided by the software developer. If you find discrepancies in the information provided, please contact the software developer directly. The links are provided for your convenience and are to be used at your own discretion.

## Page details

Date modified:
:   2025-07-09
