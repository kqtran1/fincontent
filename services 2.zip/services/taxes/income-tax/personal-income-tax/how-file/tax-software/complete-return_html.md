3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)

# Tax software for filing personal taxes

* [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
* [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
* [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

# Completing a tax return

**You may be looking for:**

* [Filing as a professional tax preparer (EFILE)](/en/revenue-agency/services/e-services/digital-services-businesses/efile-electronic-filers.html)

Follow the steps below as a guide to help you complete your tax return electronically with certified tax software.

Since each software option is different, you may need to follow the instructions in the software you selected.

If you are filing a tax return on behalf of a family member or friend

You must add a representative account to your existing CRA account to manage and have access to someone else's online tax information.

Once registered, you will get a RepID that you can share with a family member or friend, so they can authorize you as their representative.

For details: [Representative authorization](/en/revenue-agency/services/tax/representative-authorization.html)

## Check your CRA information and preferences

Make sure your details with the CRA are up-to-date.

If your circumstances have changed, you need to notify the CRA. Allow time for the CRA to process these changes before sending your tax return.

Change or confirm your:

* Direct deposit information
* Mailing address
* Notification preferences (online mail or letter mail)

These changes cannot be completed within tax software. Find out your options to [update your personal information with the CRA](/en/revenue-agency/services/update-information-cra/personal.html).

## Steps for using certified tax software

1. ### Enter personal information

   Fill in personal information such as name, address, and Social Insurance Number (SIN) or other taxation number.
2. ### Fill in your CRA information automatically (optional)

   In tax software, you can use the Auto-fill my return service to fill in available tax information the CRA has on file.

   If you select this option, you will be prompted to enter your CRA account user ID and password.

   For details: [Auto-fill my return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return/auto-fill.html)
3. ### Get the NETFILE access code

   If you chose to use the Auto-fill my return service, the access code will be automatically filled in.

   If you are entering the information manually, you can find the 8-character access code on the right side of the **previous tax year's** [notice of assessment (NOA)](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html). You will not have an access code if you are filing a tax return for the first time.

   Image of where to find the access code
   ![Sample Notice of Assessment showing where the access code is located](/content/dam/cra-arc/serv-info/eservices/noa-letter-info-en.jpg)

   Entering the access code is **not mandatory**.

   If you do not provide the access code

   Tax software can still electronically send the tax return to the CRA even if you don't provide the access code.

   While the access code is not mandatory, if you do not enter it:

   * You will not be able to use any information from your most recent tax return to confirm your identity with the CRA
   * The CRA will have to use other information for authentication purposes
4. ### Report income

   Use the tax information slips to report income.

   You must [report all income](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/personal-income/reporting-income.html) including self-employment income, foreign investment income, income from assets, tips, and any other earnings.

   If you chose to use the Auto-fill my return service, most tax slips and other tax related information may be available to [automatically fill in](https://test.canada.ca/cra-arc/jmlt333/t1/val-test/sub-autofill.html#info) parts of your tax return.

   #### Check if all information is included

   The CRA should receive most of the [tax slips](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/tax-slips.html) and tax information from third parties by mid-March of each year.

   If information is not available in your CRA account, we may not have yet received it. If you were issued a slip with errors in your personal information, it will not be available.

   You must contact the issuer if you are missing any tax slip information.
5. ### Claim deductions, credits, and expenses

   You can find and [claim deductions, credits, and expenses](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses.html) to reduce the amount of tax you owe.
6. ### Review the tax return

   It is your responsibility to review the information on the return.

   Whether you used the Auto-fill my return service or filled in information manually, you must make sure that all the proper fields on the return are filled in and that the information provided is true, accurate, and complete before you file your return.

   If needed, you can update some of your personal information on your tax return, including your:

   * Email address
   * Marital status
   * Language of correspondence
   If you are transferring amounts to an instalment account

   If you expect a refund and want to transfer it to an instalment account, select this option when you fill in your tax return.

   The CRA will transfer the **full amount of your refund** directly to your instalment account. This amount will be applied toward any tax owing and will be considered received on the date your return is assessed.

## Document navigation

* [Next: Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

## Page details

Date modified:
:   2025-07-09
