3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)

# Tax software for filing personal taxes

* [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
* [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
  + [Auto-fill my return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return/auto-fill.html)
* [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

# Auto-fill my return

**You may be looking for:**

* [Auto-fill my return for professional tax preparers](/en/revenue-agency/services/e-services/about-auto-fill-return.html)

You can use the Auto-fill my return service in tax software to automatically fill in parts of a tax return. The service can only use information the Canada Revenue Agency (CRA) has on file at the time of the request.

## Ensure you can access your CRA account

You must be registered and have access to your [CRA account](/en/revenue-agency/services/e-services/cra-login-services.html).

If you are having problems signing in, refer to [Help with using your CRA account](/en/revenue-agency/services/e-services/cra-login-services/help-cra-sign-in-services.html).

Filing a tax return on behalf of a family member or friend

If you don't already have a representative account (Represent a Client), you must add one to your existing CRA account.

To add a representative account:

1. Sign in to your [CRA account](/en/revenue-agency/services/e-services/cra-login-services.html)
2. From the Welcome page, select **Add account**
3. Select **Representative account**
4. Select **Register with Represent a Client**
5. Select **Register yourself**
6. After getting your confirmation, return to the Welcome page and select your **Representative** account to access Represent a Client

You will then be able to [request authorization to access someone else's tax information](/en/revenue-agency/services/e-services/cra-login-services/help-cra-sign-in-services/representatives-request-authorization.html).

### Provincial partner sign-in does not work with this service

If you use a provincial partner (Alberta.ca Account or BC Services Card) to sign in to your CRA account, you will **not** be able to use the Auto-fill my return service.

If a provincial partner is your only sign-in credential, you will need to register for a CRA user ID and password, or a Sign-in Partner.

## Information provided by the service

The CRA should receive most of the tax information from third parties by mid-March of each year. If information is not available, we may not have received it yet.

If a slip was issued to you with an error in your Social Insurance Number (SIN), first name, or last name, it will not be available on My Account, Represent a Client, or the Auto-fill my return service. Contact the issuer for any missing or incorrect slips.

The following information may be available in the tax software:

NETFILE access code

A unique 8-character access code can be used to electronically send your completed tax return to the CRA. Using the access code is not mandatory, but it will make it easier to authenticate yourself if you need to contact the CRA.

Tax information slips

Available for **2016 and subsequent tax years**:

* T3, Statement of Trust Income Allocations and Designations
* T4, Statement of Remuneration Paid
* T4A, Statement of Pension, Retirement, Annuity, and Other Income
  T4A slips for COVID-19 emergency relief amounts

  Amounts may include:

  + Canada Emergency Response Benefit (CERB)
  + Canada Emergency Student Benefit (CESB)
  + Canada Recovery Benefit (CRB)
  + Canada Recovery Sickness Benefit (CRSB)
  + Canada Recovery Caregiving Benefit (CRCB)
  + Canada Worker Lockdown Benefit (CWLB)
  + Provincial/Territorial COVID-19 Financial assistance payments
* T4A(OAS), Statement of Old Age Security
* T4A(P), Statement of Canada Pension Plan Benefits
* T4E, Statement of Employment Insurance and Other Benefits
* T4RIF, Statement of Income from a Registered Retirement Income Fund
* T4RSP, Statement of Registered Retirement Savings Plan Income
* T5, Statement of Investment Income
  If your T5 slip is in more than one name

  For example, in the case of couples, or a parent and child.

  The Auto-fill my return service gathers all tax income slips that the CRA has available in My Account for you to review in your software. You will be prompted to determine if the amount is accurate and who should report the income from slips showing more than one individual’s name. You will then be able to verify and choose if you wish to report the income in total, in part, or not at all.

  If you are splitting income from a T5 slip

  Once the Auto-fill my return service delivers the T5 slip into a NETFILE-certified software, you need to report your share of interest from a joint investment based on how much you contributed to it.

  You can enter the percentage of interest directly in the software. The difference would need to be declared by the other individual.
* T5007, Statement of Benefits
* T5008, Statement of Securities Transactions
  If you have more than 500 T5008 slips

  The Auto-fill my return service can only send up to 500 T5008 slips.

  If there are 501 or more slips, an error message will indicate there are too many slips to send. In these cases, all of the T5008 slips will have to be entered manually.
* RC62, Universal Child Care Benefit Statement
* RC210, Advanced Canada workers benefit statement
* RRSP, Registered Retirement Savings Plan contribution receipt
* PRPP, Pooled Registered Pension Plan contribution receipt
* T2202, Tuition and Enrolment Certificate
* T1204, Government Service Contract Payments
* T5013, Statement of Partnership income
* T4FHSA, First Home Savings Account Statement
* Manitoba Rent Assist

Availability of RRSP and PRPP receipts

Receipts for RRSP and PRPP contributions made in the first 60 days of the 2024 year may not be available until May 2024.

For more information, refer to [Tax slips](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/tax-slips.html).

Other tax related information

Available for **2024** income tax and benefit returns:

* Registered Retirement Savings Plan (RRSP) deduction limit
* Home Buyers’ Plan (HBP) required repayment, repayments to date, required repayment remaining and required repayment for the next tax year
* Lifelong Learning Plan (LLP) required repayment, repayments to date, required repayment remaining and required repayment for the next tax year
* First Home Savings Account (FHSA) amounts
* Non-capital losses
* Capital gains and losses
* Capital gains deductions
* Federal tuition, education, and textbook carryforward amounts
* Provincial tuition, education, and textbook carryforward amounts
* Canada training credit limit
* Employment Insurance (EI) election on self-employment
* Allowable business investment loss (ABIL), history of deductions
* Unused net capital losses
* Instalment amounts
* Direct deposit
* Returned mail
* Outstanding GST/HST returns
* Foreign Property Declared
* EI Election for self-employment
* Disability Tax Credit
* Electronic Correspondence Preference

## Your responsibilities

Before you file a tax return with the CRA using the information delivered by Auto-fill my return you have to ensure that all proper fields on the return are filled in correctly, including information not delivered by Auto-fill my return, and that the information provided is true, accurate and complete. It remains the taxpayer's responsibility to report accurately their income before a tax return is submitted to the CRA.

**Note:** It is your responsibility to contact the issuer for any missing or incorrect tax slips.

If you notice a mistake in the tax-related information, have an account-specific question about other tax-related information, or need additional information, call the Individual Tax enquiries service at 1-800-959-8281.

If you are having problems with the Auto-fill my return login process, go to CRA user ID and password help and FAQs or contact the Individual Tax enquiries service at 1-800-959-8281.

## Page details

Date modified:
:   2025-08-06
