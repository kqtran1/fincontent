3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)

# Tax software for filing personal taxes

* [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
* [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
* [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

# Sending a tax return

After completing your return in certified tax software, you can electronically send the return to the Canada Revenue Agency (CRA). Once you receive your confirmation, you may be able to view your notice of assessment (NOA) in tax software.

## On this page:

* [Send the return electronically](#sen)
* [Confirm the return was received](#con)
  + [View your NOA in tax software](#view)
* [After using tax software](#aft)

## Send the return electronically

You can use the NETFILE service in tax software to electronically send the tax return to the CRA.

The service is available daily with the following exceptions:

* 3 am to 6 am ET for daily maintenance
* February 1 to 23, 2025 for tax year updates

If you are unsure about any restrictions that may apply to your situation, you can check to confirm you can use the [NETFILE](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return/netfile.html) service.

If you cannot use the NETFILE service, you can print your return and [mail it to the CRA](/en/revenue-agency/corporate/contact-information/where-mail-your-paper-t1-return.html).

CRA security of your personal information

We accept responsibility for the security of information once we receive it. We take precautions to ensure that there is no unauthorized access to your data, and ensure the confidentiality of data you send using NETFILE. We use sophisticated security and encryption to protect this website and your personal information.

We are also responsible for making sure personal and financial information is sent in an encrypted format between your computer and our servers. This ensures that computer hackers and other Internet users can’t view or alter the data you send to us.

## Confirm the return was received

You will get a confirmation message in your tax software after sending the return to the CRA.

The message will include a code, which confirms the CRA has successfully received your completed tax return.

### View your NOA in tax software

You can view the notice of assessment (NOA) using the NOA in tax software service, right after sending the return. This notice will have the **same information** as the copies sent by mail and in your CRA account.

If you select this service, you will be prompted to enter your CRA account user ID and password after receiving your confirmation message.

For details: [NOA in tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return/noa-software.html)

## After using tax software

There are 3 possible outcomes from your tax return:

* Get a refund
* Have a balance owing
* Have no refund or balance owing

The CRA will send you a notice of assessment (NOA) with the outcome of your tax return. The NOA and any refund are usually sent within **2 weeks**.

## Page details

Date modified:
:   2025-07-09
