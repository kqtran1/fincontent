3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [How to file a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file.html)
6. [Tax software for filing personal taxes](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
7. [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

# Tax software for filing personal taxes

* [Find certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html)
* [Completing a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/complete-return.html)
* [Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)
  + [NETFILE](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return/netfile.html)
  + [NOA in tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return/noa-software.html)

# NETFILE

You can use the NETFILE service in tax software to electronically send personal tax returns directly to the Canada Revenue Agency (CRA).

NETFILE privacy notice

You will be prompted to view the NETFILE privacy notice in your tax software.

For details: [NETFILE Terms and Conditions and Privacy Notice](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return/netfile/terms-conditions.html)

## Who can use the service

To use the NETFILE service, you must have one of the following:

* A Social Insurance Number (SIN) starting with a number from 1 to 9
  + You must be a newcomer to Canada to use NETFILE if your SIN starts with a 0
* A temporary tax number (TTN) starting with a 01 or 03

### Sending provincial or territorial returns

All federal income tax returns are sent to the CRA using the NETFILE service. The electronic service used to send provincial or territorial tax returns is based on where you live as of December 31 of the tax year.

* #### All residents (except Quebec)

  Your provincial or territorial tax return is sent to the CRA using the NETFILE service.
* #### Quebec residents

  Your provincial tax return is sent to [Revenu Québec](https://www.revenuquebec.ca/en/citizens/income-tax-return/completing-your-income-tax-return/how-to-complete-your-income-tax-return/) using their electronic service.

## NETFILE restrictions

The service is available daily with the following exceptions:

* 3 am to 6 am ET for daily maintenance
* February 1 to 23, 2025 for tax year updates

Applicable to the current calendar year or tax year being filed, you are not able to use this service if you are filing:

* A deceased taxpayer return
* A bankruptcy return

You are not able to use this service if you are:

* Considered a [deemed resident](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/deemed-residents.html) (that is, you don’t have to pay provincial or territorial tax)
* Electing to defer tax on a distribution of spin-off shares by foreign corporations

If you are filing multiple returns on behalf of family members or friends

If you are registered for Represent a Client (RAC) to act on behalf of others, you may file up to 20 returns per computer or CRA account for each tax year.

Depending on your situation, you may not be able to use the NETFILE service if any of the following restrictions apply:

Reporting restrictions

You are **not** able to use the NETFILE service if you are reporting any of the following:

* Canadian-source income from Lloyds of London
* Registered disability savings plan (RDSP) income in field 12500 when you are not eligible for the disability tax credit for self for the current tax year and for the 2 immediately preceding tax years
* Employment income earned from an international organization
* Lump-sum pension income accrued to December 31, 1971
* More than 12 sets of financial statements
* An Ontario, Saskatchewan, British Columbia, or Yukon qualifying environmental trust tax credit (may also be referred to as a mining reclamation trust tax credit)
* Farming income with an AgriStability and/or AgriInvest Program application which involves:
  + Farming income from a partnership reported on a T5013 slip or a partnership that includes a corporate partner
  + A Canadian Indian reporting self-employed income which is “tax-exempt income”
  + More than 10 occurrences in "Livestock inventory valuation" or "Crop inventory valuation and productive capacity" from page 7 of Form T1273
  + More than 8 occurrences in "Purchased inputs", "Deferred income and receivables", or "Accounts payable" from page 7 of Form T1273

Claiming restrictions

You are **not** able to use the NETFILE service if you are claiming any of the following:

* A federal non-business foreign tax credit for more than 3 countries
* A federal business foreign tax credit for more than 3 countries
* Less than the maximum federal foreign tax credit
* A deduction for scientific research and experimental development (SR&ED) expenses
* An Alberta stock savings plan tax credit (Form T89)
* A Saskatchewan royalty tax rebate (Form T82)
* A Nova Scotia research and development tax credit recapture
* A Newfoundland and Labrador research and development tax credit (Form T1129)
* A claim that involves more than 22 children
* A deduction in field 20700 that includes amounts calculated from a combination of at least 2 of the following forms:
  + Form RC269, Employee Contributions to a Foreign Pension Plan or Social Security Arrangement – Non-United States Plans or Arrangements
  + Form RC267, Employee Contributions to a United States Retirement Plan – Temporary Assignments
  + Form RC268, Employee Contributions to a United States Retirement Plan – Cross-Border Commuters

## Document navigation

* [Previous: Sending a tax return](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/send-return.html)

## Page details

Date modified:
:   2025-07-09
