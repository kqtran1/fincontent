3. [Income tax](/en/services/taxes/income-tax.html)
4. [Personal income tax](/en/services/taxes/income-tax/personal-income-tax.html)
5. [After filing a tax return](/en/services/taxes/income-tax/personal-income-tax/after-you-file.html)

Personal income tax

# Changing a tax return

**You may be looking for:**

* [Notice of reassessment (NOR)](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html)

You may request changes to an assessed income tax and benefit return if you need to correct amounts or forgot to include information on your return.

## On this page:

* [When you can make a request](#re)
* [Options to make your changes](#op)
* [How long it takes to process your request](#how)

## When you can make a request

You must wait until you receive your notice of assessment (NOA) before you can request a change to your return. The return must have been filed by you or your tax preparer.

If you already submitted a request for changes, wait until you get a response from the Canada Revenue Agency (CRA) before requesting additional changes to the return.

### What you can change on a return

You can change your return if you need to adjust amounts or provide missing information, including:

* Reporting income (such as a T4 slip or tips)
* Claiming a deduction, credit, or expense (such as childcare or medical costs)
* Adding a missing tax slip (such as an RRSP contribution receipt)

You cannot change a return to:

* Apply for benefits or credits
* Make or revise an election
* Allocate a refund to other CRA accounts
* [Update personal information](/en/revenue-agency/services/update-information-cra/personal.html), including:

+ Mailing or email address
+ Direct deposit information
+ Marital status
+ Name

## Options to make your changes

You can request changes to your tax return either online or by mail. Using online services is faster and can help you avoid making errors and ensure you provide all the required information.

Online
:   **2 week** processing time

    Change your return with either your CRA account or certified tax software.

    **Your CRA account**

    You must have access to your CRA account.

    Using your CRA account to change a return

    To make changes to your return:

    1. [Sign in to your CRA account](/en/revenue-agency/services/e-services/cra-login-services.html)
    2. Select **Individual** if you are changing your own return or **Representative** if you are changing someone else's
    3. Select **Tax returns**
    4. Find and select **Change my return**

    For detailed instructions, refer to [Help using the "Change my return" service](/en/revenue-agency/services/e-services/digital-services-individuals/account-individuals/change-return.html).

    **Changing someone else's return**

    You must be an [authorized representative](/en/revenue-agency/services/tax/representative-authorization.html) with at least level 2 access.

    For most tax situations, you can use the "Change my return" service. If you are not sure about restrictions that may apply to you, [confirm which option you can use](#deter).

    **Certified tax software**

    Tax software must have been used to send the tax return.

    Using tax software to change a return

    In certified tax software, look for the option to change your return using the "ReFILE" service. It may be easier to use the same certified tax software you previously used to also change your return, however all certified software products now include the "ReFILE" service.

    The service is available daily with the following exceptions:

    * 3 am to 6 am ET for daily maintenance
    * February 1 to 24, 2025 for tax year updates

    **Changing your own return**

    You must have used [certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html) to file the return you are requesting to change.

    **Changing someone else's return**

    If you are a family member or friend, you must have used NETFILE [certified tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software/find-software.html) to file the return you are requesting to change. You must also be an [authorized representative](/en/revenue-agency/services/tax/representative-authorization.html).

    For professional tax preparers, such as an accountant or discounter, you must have used [EFILE certified tax software](/en/revenue-agency/services/e-services/digital-services-businesses/efile-electronic-filers/efile-certified-software-efile-program.html).

    For most tax situations, you can use the "ReFILE" service. If you are unsure about any restrictions that may apply to you, [confirm which option you can use](#deter).

By mail
:   **30 week** processing time

    Use the paper form and provide your supporting documents.

    Using the paper form to change a return

    Send any request to change a previous return **separately** from your current year tax return.

    1. Complete [Form T1-ADJ, T1 Adjustment Request](/en/revenue-agency/services/forms-publications/forms/t1-adj.html) to provide:

    * Social Insurance Number (SIN)
    * Tax year you want to change
    * Name and address
    * Authorization details, if applicable
    * Adjustment details (including revised amounts)
    * Daytime phone number

    2. Attach supporting documents for the entire amount, including amounts you already claimed but did not previously send documents for
    3. Send the completed T1-ADJ form and all supporting documents to [your tax centre](/en/revenue-agency/corporate/contact-information/where-mail-your-paper-t1-return.html)

### Confirm which option you can use

Most changes can be made online. Determine your available options based on your tax situation.

Answer interactive questions

A [text version](#full-text) is available if needed.

Choose the situation that applies to you and **scroll down** for further questions and results.

Select the option that includes the tax year of the return you are changing:

* 2015 to 2024

  Do any of the following apply to the return you are changing?

  + Year of bankruptcy (or any year before the year of bankruptcy)
  + Filed with the incorrect province or territory of residence
  + Return for a deceased taxpayer

    You are changing:

    - The Final Return (T1) for a Canadian resident

      How was the return originally filed?

      * Electronically using certified tax software

        Are you making changes to a return before 2020?

        + Yes
        + No
      * By mail using the paper return
    - One of the optional T1 returns for a Canadian resident
    - An international or non-resident return
  + Business income outside of the residing province or territory (Form T2203)
  + None of the above

    What type of return are you changing?

    - Income Tax and Benefit Return for Canadian residents

      How was the return originally filed?

      * Electronically using certified tax software

        Are you making changes to a return before 2020?

        + Yes
        + No
      * By mail using the paper return
    - International or non-resident return

      Select the kind of return you are changing:

      * Immigrant return (or resident returning to Canada)

        You are:

        + Changing your own tax return
        + Changing someone else's tax return

          How was the return originally filed?

          - Electronically using certified tax software
          - By mail using the paper return
      * Emigrant return
      * Factual resident return
      * Deemed resident return
      * Deemed non-resident return
      * Non-residents earned income return (section 115)
      * Other
* 2014 or earlier

Based on your selections above:

### You can use either online option

To electronically request changes to your tax return, you are able to use either the:

* "ReFILE" service within your tax software
* "Change my return" service within your CRA account

Find out how to use either [online option](#on-list).

Based on your selections above:

### You can use your CRA account

To request changes to your tax return, your only online option is the "Change my return" service.

Find out how to use this service in [your CRA account](#acc-list).

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

A refund **cannot** be issued for adjustment request beyond 10 calendar years.

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

For a bankruptcy return, you should also contact your trustee about making changes.

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

For more information about filing a tax return for someone who died, refer to [What returns you need to file](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died/prepare-returns/what-to-file.html).

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

You may also need to submit all the required [forms for the province or territory](/en/revenue-agency/services/forms-publications/tax-packages-years.html#h-3) of your actual residence.

Based on your selections above:

### You can only request changes by mail

There are no online options to make these changes.

Find out how to make your changes [by mail](#mail-list).

For more information about international or non-resident returns, refer to [Non-residents of Canada](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/non-residents-canada.html).

Based on your selections above:

### You can use your CRA account

You can use the "Change my return" service in [your CRA account](#acc-list).

You may be able to use the "ReFILE" service in your [certified tax software](#soft-list) if:

* You are using EFILE certified tax software
* You are changing a return for the 2023 tax year or later

View text version

Use this version if you do not want to answer [interactive questions](#interactive).

#### "ReFILE" service in certified tax software

You **cannot** use "ReFILE" to change:

* A return before the 2020 tax year
* A bankruptcy return (or any year before the year of bankruptcy)
* An optional T1 return for a deceased taxpayer
* A return filed with the incorrect province or territory of residence
* A return for an international or non-resident taxpayer, including deemed residents of Canada and individuals who left Canada during the year
* A return where you have to complete Form T2203, for income from a business that has a permanent establishment outside your province or territory of residence

If you are a professional tax preparer

EFILE service providers can use the "ReFILE" service for returning residents to Canada and immigrants starting with the 2023 tax year.

#### "Change my return" service in your CRA account

You **cannot** use "Change my return" to change:

* A return for the 2014 tax year or earlier
* A bankruptcy return (or any year before the year of bankruptcy)
* An optional T1 return for a deceased taxpayer
* A return filed with the incorrect province or territory of residence
* Certain international and non-resident returns
  Eligible international and non-resident returns

  You can use "Change my return" to change certain international and non-resident returns, such as:

  + Immigrant returns (and returning residents to Canada)
  + Emigrant returns
  + Factual resident returns
  + Deemed resident returns
  + Deemed non-resident returns
  + Non-residents earned income return (section 115)
* A return where you have to complete Form T2203, for income from a business that has a permanent establishment outside your province or territory of residence

#### Changing a return by mail

If you are unable to change a return online, you can request the change to the return by mail. In some situations, there are limitations or additional steps.

A return for the 2014 tax year or earlier

You can request changes by mail, but a refund **cannot** be issued for an adjustment request made more than 10 calendar years after the end of the tax year.

Bankruptcy return (or any year before the year of bankruptcy)

You can request changes by mail. Consult your trustee about the changes before making your request.

A return for a deceased taxpayer

Only the Final Return can be adjusted online. You can request changes by mail for optional T1 returns.

For more information about filing a tax return for someone who died, refer to [What returns you need to file](/en/revenue-agency/services/tax/individuals/life-events/doing-taxes-someone-died/prepare-returns/what-to-file.html).

A return filed with the incorrect province or territory of residence

You can request changes by mail. Submit all the required [forms for the province or territory](/en/revenue-agency/services/forms-publications/tax-packages-years.html#h-3) where you lived on December 31 of the tax year for the changes.

International and non-resident return

If you are not eligible to request changes online, you can request changes by mail.

For more information about international or non-resident returns, refer to [Non-residents of Canada](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/non-residents-canada.html).

## How long it takes to process your request

The method you use to request a change to your return affects how long it takes the CRA to process it.

Any refund as a result of your changes will be sent as soon as the request is processed.

* ### Online request

  **Processing time:** Within 2 weeks
* ### Request by mail

  **Processing time:** Within 30 weeks from receiving the request

Situations that may take longer to process

It may take up to **50 weeks** to process changes related to:

* Multiple tax returns
* Tax years beyond the normal 3-year reassessment period
* A bankruptcy return
* A deceased taxpayer
* A carryback amount, such as a capital or non-capital loss
* The elected split-pension amount
* A request from the CRA to you or your authorized representative for more information or documents

Requests filed for international and non-resident returns (including emigrant returns) may take longer to process.

For details, refer to: [CRA processing times](/en/revenue-agency/corporate/contact-information/check-cra-processing-times.html)

### What to expect when your request is processed

After the CRA completes a review and makes a decision, you will get a response either electronically through your CRA online mail or by letter mail.

The CRA sends you online mail unless you set your preferences to letter mail, or if you have never provided us with your email address.

There are 3 possible outcomes from your request:

Adjustments complete
:   You will get a [notice of reassessment (NOR)](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html) showing the changes made to your tax return.

Some adjustments made
:   You will get a [notice of reassessment (NOR)](/en/services/taxes/income-tax/personal-income-tax/after-you-file/noa-nor.html) showing the changes made **and** an explanation for the changes that were not made.

    If the full explanation cannot be included on the NOR, you may also get a letter with more details.

No adjustments made
:   You will get a letter explaining why your requested changes were not made.

## Page details

Date modified:
:   2025-07-09

## About this site

### Canada Revenue Agency (CRA)

* [Contact the CRA](https://www.canada.ca/en/revenue-agency/corporate/contact-information.html)
* [Update your information](https://www.canada.ca/en/revenue-agency/services/update-information-cra.html)
* [About the CRA](https://www.canada.ca/en/revenue-agency/corporate/about-canada-revenue-agency-cra.html)

### Government of Canada

* [All Contacts](https://www.canada.ca/en/contact.html)
* [Departments and agencies](https://www.canada.ca/en/government/dept.html)
* [About government](https://www.canada.ca/en/government/system.html)

#### Themes and topics

* [Jobs](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finance](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Indigenous peoples](https://www.canada.ca/en/services/indigenous-peoples.html)
* [Veterans and military](https://www.canada.ca/en/services/veterans.html)
* [Youth](https://www.canada.ca/en/services/youth.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](https://www.canada.ca/en/transparency/terms.html)
* [Privacy](https://www.canada.ca/en/transparency/privacy.html)

![Symbol of the Government of Canada](https://wet-boew.github.io/themes-dist/GCWeb/GCWeb/assets/wmms-blk.svg)
