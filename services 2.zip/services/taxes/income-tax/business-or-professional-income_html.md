3. [Income tax](/en/services/taxes/income-tax.html)

# Business or professional income

Calculate business or professional income, get industry codes, and report various income types.

![](/content/dam/themes/taxes/features/income-tax/20140528.jpg)

## Most requested

* [CRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)
* [Motor vehicle expenses](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/business-expenses/motor-vehicle-expenses.html)
* [Business-use-of-home expenses](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/report-business-income-expenses/completing-form-t2125/business-use-home-expenses.html)
* [Forms and publications](/en/revenue-agency/services/forms-publications.html)
* [Form T2125-Statement of business or professional activities](/en/revenue-agency/services/forms-publications/forms/t2125.html)

## Services and information

### [Business or professional income overview](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/report-business-income-expenses/completing-form-t2125.html)

Summary of business or professional income types, industry codes, capital cost allowance, and expenses.

### [Industry codes](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/report-business-income-expenses/industry-codes.html)

Find the industry code for your main business activity.

### [Business or professional income types](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/personal-income/self-employment-income-lines-13499-14299-gross-income-lines-13500-14300-net-income.html)

Report income from farming, fishing, rentals, and partnerships.

### [Capital cost allowance](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/report-business-income-expenses/claiming-capital-cost-allowance.html)

Claim capital cost allowance, key topics of interest, and related forms and publications.

### [Business expenses](/en/revenue-agency/services/tax/businesses/topics/sole-proprietorships-partnerships/business-expenses.html)

How to report business expenses, and learn what qualifies as a business expense.

### [Business tax credits](https://innovation.ised-isde.canada.ca/s/list-liste?language=en_CA&token=a0B5W000000ZbIUUA0)

How to claim business tax credits, including provincial or territorial tax credits.

### [Record keeping](/en/revenue-agency/services/tax/businesses/topics/keeping-records.html)

Determine what constitutes a record, how to keep records, and information about different types of records.

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-03-20
