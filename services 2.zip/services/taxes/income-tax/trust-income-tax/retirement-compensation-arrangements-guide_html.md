3. [Income tax](/en/services/taxes/income-tax.html)
4. [Trust income tax](/en/services/taxes/income-tax/trust-income-tax.html)

# Retirement Compensation Arrangements

## On this page

* [Overview](#h_1)
* [General information](#h_2)
* [Employer responsibilities](#h_3)
* [Custodian responsibilities](#h_4)
* [Penalties and interest](#h_5)
* [Appendix 1 – Person who bought an interest in an RCA](#appendix1)
* [Appendix 2 – Additional topics](#appendix2)

## Overview

This page is for you if one of the following applies:

* You are an **employer** and you make contributions to a custodian for a retirement compensation arrangement (RCA). For an explanation of RCAs, see [Definition of an RCA](#P78_4135)
* You are a **custodian** of an RCA trust who does any of the following:
  + receives contributions from an employee or employer for an RCA
  + files a [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) for an RCA trust
  + makes distributions out of an RCA trust to a beneficiary
* You **buy an interest** in an RCA.
* You submitted a pension plan for registration and **the CRA refused to register the plan** as a registered pension plan (RPP). In this case, the CRA generally consider that any contributions made to the plan before the date of final determination are contributions to an RCA.

Before you start, be sure to read [Appendix 1](#appendix1).

### Confidentiality of information

Under the [Privacy Act](https://laws-lois.justice.gc.ca/eng/acts/P-21/index.html), the personal information you give on RCA information and tax returns and related forms can be used only for the purposes authorized by law.

### Income Tax Act references

Unless otherwise stated, all legislative references are to the [Income Tax Act (ITA)](https://laws.justice.gc.ca/eng/acts/I-3.3/) or the [Income Tax Regulations](https://laws.justice.gc.ca/eng/regulations/C.R.C.%2C_c._945/).

## General information

### Definition of an RCA

A retirement compensation arrangement (RCA) is a plan or an arrangement under which an employer, former employer, and in some cases an employee makes contributions to a person or partnership, referred to as a custodian.

The custodian holds the funds in trust with the intent of eventually distributing them to the employee, former employee or other beneficiary on, after, or in contemplation of the following:

* an employee's retirement
* an employee's loss of an office or employment
* any substantial change in the services the employee provides (for example, a senior corporate director who, after termination, is retained on a part time basis to teach a management course to new trainees may be considered to have substantially changed the services being provided for the purposes of the definition of an RCA)

An employer or former employer may acquire an interest in a life insurance policy (including an annuity) to fund benefits on, after, or in contemplation of any of the situations listed above. In that case, the Canada Revenue Agency (CRA) would consider the interest to be the property of an RCA and the employer to be the custodian of the RCA.

In most situations, there is one RCA trust under an RCA. For simplicity of presentation, the information in this page reflects such situations. However, there could be a situation where there is more than one RCA trust under an RCA. With regard to such situations, the information in this page should be read with necessary modifications to correspond with the Income Tax Act and the Income Tax Regulations. For help with completing Form T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return, and for information on the [Employer responsibilities](#h_2) and [Custodian responsibilities](#h_3), call the CRA at **1-800-959-8281**.

#### Refundable tax

The contributions made by the employer to the custodian are taxable under Part XI.3 of the [ITA](https://laws.justice.gc.ca/eng/acts/I-3.3/page-176.html#h-313483). The withholding tax under income tax regulation 103(7) is equal to 50% of the amount of the contributions. The employer sends this tax to the Canada Revenue Agency (CRA) for the RCA trust. However, the tax is refundable to the custodian upon processing of the [T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html), taking into account any distributions made out of the RCA trust and income earned by the trust during the year.

Any income from business or property, any capital gains earned in the RCA trust and any employee contributions are also taxable under Part XI.3 of the ITA at the 50% refundable tax rate (other than an excluded contribution made on or after March 28, 2023). The custodian sends this tax to the CRA and the CRA refunds the tax as distributions are made.

The custodian has to file a [T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) each year, even if there has been no activity in an RCA trust in the year. When filing the tax return, the custodian ensures that the correct amount of refundable tax has been sent to CRA or has been refunded to the RCA trust.

#### Distributions

All distributions from an RCA trust are taxable. The custodian has to provide the beneficiary with a [T4A-RCA slip, Statement of Distributions from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html), showing the amount of distributions and the income tax deducted. The beneficiary reports the amount distributed as income and claims the income tax deducted on their income tax and benefit return for the year the income is received.

#### **Annuity contract**

When the custodian of an RCA buys an annuity contract to be held by the beneficiary as the legal owner, the CRA  considers that the amount paid to buy the contract is a taxable distribution out of the RCA trust to the beneficiary. The full amount is taxable in the year the custodian buys the contract and the custodian has to issue a T4A-RCA slip showing the amount of the distribution and the income tax deducted.

#### Excluded arrangements

Certain retirement arrangements (such as registered pension plans, deferred profit sharing plans, salary deferral arrangements, and employee trusts) **do not** qualify as RCAs. For other excluded arrangements, see the definition of **retirement compensation arrangement** in subsection 248(1) of the ITA.

## Employer responsibilities

This section covers the following employer responsibilities:

* filing Form [T733, Application for a Retirement Compensation Arrangement (RCA) Account Number](/en/revenue-agency/services/forms-publications/forms/t733.html), to apply for employer (**RC**) and custodian (**T**) trust account numbers
* withholding refundable tax and remitting it to the CRA using Form T901B, Statement of Account
* filing the T737-RCA slips ([T737-RCA Statement of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA](/en/revenue-agency/services/forms-publications/forms/t737-rca.html))) and summary ([T737-RCASUM, Summary of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html)), to report contributions you made to the custodian of an RCA trust
* reporting deductible RCA contributions to the employee
* providing a certificate of amendment when there is a change to the legal name

### Applying for RC and T accounts

After establishing an RCA with a custodian, you have to complete [Form T733](/en/revenue-agency/services/forms-publications/forms/t733.html). The CRA uses this form to open the following two accounts:

* the **RC** employer account that the CRA and the employer use to monitor the 50% refundable tax on hand for contributions made to the custodian
* the **T** custodian trust account that the CRA and the custodian use to monitor the balance of the refundable tax on hand for the RCA trust

When the CRA receives your completed [Form T733](/en/revenue-agency/services/forms-publications/forms/t733.html) along with a copy of the RCA trust agreement (with an original signature), the CRA will give you an employer account number starting with the letters **RC**. The CRA will also give the custodian a separate custodian trust account number starting with the letter **T**.

* the employer uses the **RC** employer account number when remitting the refundable tax on contributions made to the custodian
* the custodian uses the **T** custodian trust account number when filing a [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) and when remitting refundable tax on employee contributions and on income earned in the RCA trust

#### Completing Form T733, Application for a Retirement Compensation Arrangement (RCA) Account Number

You have to enter the following information on [Form T733](/en/revenue-agency/services/forms-publications/forms/t733.html):

Employer's language of correspondence

Tick (✓) the appropriate box.

Custodian's language of correspondence

Tick (✓) the appropriate box.

Employer's legal name

Enter the employer's legal name. The employer may operate under a different name; however, the CRA needs the legal name, not the operating name (do not use more than 60 characters). The employer's legal name will be modified to meet our requirements if it is longer than 60 characters.

Employer's address

Enter the employer's complete address.

Name and telephone number of employer's representative

Enter the name and telephone number of the person the CRA can contact if it needs more information about the RCA. The appropriate representative is usually the employer's controller or payroll clerk, not the accounting firm that prepares the financial information.

RCA trust's name

Enter the full name of the RCA trust (do not use more than 60 characters). The same name must be used on all returns and correspondence when referring to the trust. The name of the trust will be modified to meet our requirements if it is longer than 60 characters.

Date the RCA became effective

Enter the date the RCA became effective.

Custodian's name and telephone number

Enter the full name and telephone number of the custodian for the RCA trust. The custodian is often a trust company or other financial institution.

Custodian's address

Enter the custodian's complete address.

Name and telephone number of custodian's representative

Enter the name and telephone number (including the area code) of the person the CRA can contact if it needs more information about the RCA trust.

Contributions already made to the custodian for this RCA trust

If you made contributions to the custodian, list the dates and amounts of those contributions.

Contributions to be made in the year the RCA becomes effective

If you intend to make contributions to the custodian in the year the RCA becomes effective, list the expected dates and amounts of those contributions.

Address for books and records

Tick (✓) the appropriate box. If the address is not the same as the one on line 2 or 6, enter the address where the books and records of the RCA will be kept.

Distributions out of this RCA trust

Tick (✓) the **yes**or **no**box, whichever applies, to indicate whether more than one employee will receive distributions from this RCA trust.

Certification

An authorized officer of the employer has to complete and sign this area.

#### Filing Form T733

Send the completed original of [Form T733](/en/revenue-agency/services/forms-publications/forms/t733.html) and a signed copy of the RCA trust agreement to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

Keep a photocopy for your records.

### Withholding and remitting the refundable tax

When an employer makes a contribution to a custodian for an RCA trust, the employer has to withhold tax equal to 50% of the amount of the contribution and remit the tax to the CRA. For more information about remitting the refundable tax, see [Remitting the refundable tax](#P187_15978).

If an employer does not withhold the 50% refundable tax on contributions made to a custodian, the employer has to remit to the CRA an amount equal to the amount of the contribution made to the custodian. Failure to withhold tax may result in an excessive contribution.

For example, on a $5,000 contribution to an RCA, $2,500 has to be withheld and remitted to the CRA and $2,500 goes to the custodian. If the employer fails to withhold the tax and contributes $5,000 directly to the RCA custodian, the law requires the employer to remit $5,000 to the CRA. In this case, the gross RCA contribution would be considered to be $10,000, which may be in excess of the RCA's terms and provisions. For more information, see [Refundable tax on contributions](#P615_65747).

The CRA will apply a **penalty** if the employer fails to comply with withholding requirements. For more information, see [Penalties for not withholding tax](#P614_65694).

If an employer made payments to acquire an interest in a life insurance policy that the CRA considers to be an RCA, the employer has to remit to the CRA an amount of refundable tax equal to those payments.

#### Withholding refundable tax on transfers between RCA trusts

Subsection 207.6(7) provides special rules that govern the transfer of amounts between RCA trusts when **all** of the following conditions are met:

* a lump-sum amount is transferred **directly** from one RCA trust (the **transferring plan**) to another RCA trust (the **receiving plan**)
* the receiving plan **does not** have a non-resident custodian
* the receiving plan is **not** a foreign plan that is considered by subsection 207.6(5) to be an RCA for Canadian residents participating in the plan

To make sure the refundable tax is transferred from the transferring plan's account to the receiving plan's account, representatives from both plans should have signed a letter of agreement. When you send this letter to the CRA, the CRA will be able to transfer the refundable tax from the transferring plan's account to the receiving plan's account. For more information, see [Transferring amounts between RCA trusts](#P591_62953).

You may receive funds from an RCA trust that you want to transfer to another RCA trust. If the transfer **does not** meet the conditions described above, you should receive a [T4A-RCA slip, Statement of Distributions from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html), from the RCA trust. You have to include in income the refund of employer contributions shown in box 12 of the [T4A-RCA slip](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html). When you contribute the funds to the custodian of another RCA trust, you have to withhold 50% refundable tax on the funds you contribute. You have to remit the 50% refundable tax to the CRA and prepare the [T737-RCA slips and summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html) to report the amounts you contribute to the other RCA trust.

#### Remitting the refundable tax

The CRA has to receive the refundable tax on or before the 15th day of the month after the month in which it was withheld. If you remit this tax late, you will be subject to a penalty. For more information, see [Refundable tax on contributions](#P615_65747) and [Penalties for not remitting the refundable tax](#P626_refundable).

Send your first payment of refundable tax to the RCA Unit at the [Winnipeg Tax Centre](#P172_13108) by cheque or money order made out to the Receiver General for Canada.

If you have to remit this tax but have not received an **RC** employer account number, complete Form T733 and send it with your payment directly to the Winnipeg Tax Centre.

You can print or download [Form T733](/en/revenue-agency/services/forms-publications/forms/t733.html) by visiting [Forms and publications](/en/revenue-agency/services/forms-publications.html). You may also request the form by calling **1-800-959-5525**.

After the CRA receives this information, it will send you confirmation of your **RC** employer account number. Also, after the CRA processes the payment, it will acknowledge receipt and issue Form T901B, Statement of Account, which includes a blank remittance voucher.

### Filing the T737-RCA slips and summary to report contributions you made to the custodian of an RCA trust

To report the amount of contributions you made to the custodian, you have to submit a completed [Form T737-RCA SUM, Summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html) of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA), and the related [T737-RCA slips](/en/revenue-agency/services/forms-publications/forms/t737-rca.html). Statement of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA). If there has been a change to the business name or to the authorized contact, send documentation outlining the change to the CRA, along with the [T737-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html) and the slips. You have to file the slips and summary no later than the last day of February following the calendar year in which you made contributions to the custodian. The CRA will apply a penalty if you are late in filing the slips or the summary. For more information, see [Penalties and interest](#h_5). If you **did not** make any contributions during the year, you do not have to file the T737-RCA slips or the summary.

#### Completing the T737-RCA slip, Statement of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA)

The [T737-RCA](/en/revenue-agency/services/forms-publications/forms/t737-rca.html) slip is available as a one page form and as a PDF fillable form. To get either version, go to [Forms and publications](/en/revenue-agency/services/forms-publications.html).

Enter the following information on the T737-RCA slip:

Year

Enter the four-digit calendar year for which you are preparing the T737-RCA slip.

Box 18 – Gross contributions by employer under an RCA

Enter the amount of gross contributions under the RCA. This is the total of the net contributions you made to the custodian **plus**the amount of refundable tax you deducted from the contributions during the year and remitted to the CRA.

##### Note

Do **not** include on the T737-RCA slip the contributions an **employee** made directly to the RCA trust. The custodian will issue a letter to the employee for these contributions.

The amount of contributions you made to the custodian may also include one or more of the following:

* amounts considered to be contributions to an RCA trust under subsection 207.6(4)
* amounts withheld from income for the employee
* transfers of funds to another RCA trust if the receiving plan has a non-resident custodian when the transfer is made
* transfers of funds to another RCA trust if, when the transfer is made, the receiving plan is a foreign plan considered under subsection 207.6(5) to be an RCA for Canadian residents participating in the plan
* if the contributor is a corporation, contributions made by a predecessor corporation or subsidiary corporation (if wound up into the parent corporation), or
* if the contributor acquired an interest in a life insurance policy (including an annuity) to meet an employer’s obligation to provide benefits under an RCA, twice the amount of any premium paid for the interest or any repayment of a policy loan

As an employer, you may be able to deduct the amount of contributions in box 18 when you calculate income from a business or property.

##### Note

The CRA may deny the deduction if the amounts are paid as a series of contributions and refunds of contributions under the RCA.

For example, if the employer makes a contribution to the RCA trust at year-end and the custodian refunds that amount to the employer in the next year, the CRA may deny the deduction if it determines that the amount was contributed to obtain a deduction rather than to provide for retirement distributions.

Box 20 – Net contributions made to the custodian

Enter the amount of net contributions you made to the custodian, or the amount you paid to buy an interest in a life insurance policy that the CRA considers to be an RCA. This amount will equal half of the amount entered in **box 18**.

Box 22 – Refundable tax deducted

Enter the amount of refundable tax you deducted during the year and remitted, or will remit, to the CRA. This amount will equal the amount entered in **box 20**.

Custodian's name and address

Enter the custodian's full name and complete address.

Employer's name

Enter the employer's full name.

Box 26 – Employer account number

Enter the **RC**employer account number the CRA assigned to the employer. Your account number should not appear on the two copies of the T737-RCA slip that you give to the custodian.

#### Completing Form T737-RCA SUM, Summary

Enter the following information on the [T737-RCA SUM, Summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html):

Language of correspondence

Tick (✓) the appropriate box.

Year

Enter the four-digit calendar year for which you are preparing the T737-RCA Summary.

Employer account number

Enter the RC employer account number that the CRA assigned to the employer. You can find this number on Form T901B, Statement of Account.

Employer’s name and address

Enter the employer's full name and complete address. This name has to be the same as the employer's name on Form T901B, Statement of Account.

Has the address changed since the last T737-RCA Summary?

Tick (✓) the appropriate box.

Line 88 – Total number of T737-RCA slips filed

Enter the total number of [T737-RCA slips](/en/revenue-agency/services/forms-publications/forms/t737-rca.html) filed with this [T737-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html). In most cases, there will only be one slip.

Line 18 – Gross contributions by employer under an RCA

Enter the amount of gross contributions you made to the custodian.

This is the contribution amount **before** tax deductions and equals the total of the amounts in box 18 of all
T737-RCA slips filed with this T737-RCA Summary.

Line 20 – Net contributions made to the custodian

Enter the amount of net contributions you made to the custodian. This is the contribution amount **after** tax deductions and equals the total of the amounts in box 20 of all T737-RCA slips filed with this T737-RCA Summary.

Line 22 – Refundable tax deducted

Enter the amount of refundable tax deducted. This equals the total of the amounts in box 22 of all T737-RCA slips filed with this T737-RCA Summary.

Line 82 – Remittances

Enter the amount of refundable tax you remitted to the CRA for the year. You can get this amount from your most recent Form T901B, Statement of Account.

Difference

**Subtract** line 82 from line 22. This is the amount of refundable tax owing or, if the result is negative, it is the amount overpaid.

Line 84 – Overpayment

Enter the amount of refundable tax overpaid, if applicable. Generally, if the difference is $2 or less, you will not receive a refund.

Line 86 – Balance owing

Enter the amount of refundable tax owing, if applicable. Generally, if the difference is $2 or less, you do not have to make a payment.

You will be subject to a penalty for late payment if you have a balance owing. For more information, see [Penalties and interest](/en/services/taxes/income-tax/trust-income-tax/retirement-compensation-arrangements-guide.html#h_5).

Line 76 – Contact person

Enter the name of the person the CRA may contact about this summary.

Line 78 – Telephone number

Enter the area code and telephone number of the person the CRA may contact about this summary.

Certification

An authorized officer of the employer has to complete and sign this area.

#### Distributing the slips and summary

Send the CRA one copy of every [T737-RCA slip](/en/revenue-agency/services/forms-publications/forms/t737-rca.html) with the completed original of the [T737-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t737-rcasum.html), and send them with your payment for any balance owing to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

Send the slips and summary no later than the last day of February following the year to which they relate.

Send two copies of every T737-RCA slip to the custodian for this RCA no later than the last day of February following the year to which the slip relates.

Keep a photocopy of the completed T737-RCA Summary and one copy of every T737-RCA slip for your records.

#### Electronic fillable slips

If you use the PDF fillable T737-RCA slip, you can print it on plain white paper. You can also make photocopies to distribute to the custodian. The CRA now accepts copies of the forms, not only original pre-printed forms.

##### Note

You can send the custodian an electronic copy of the T737-RCA slip(s). However, the custodian has to consent in writing (in a letter or by email) to receive the slip(s) electronically.

If you file a T737-RCA slip or a T737-RCA Summary late or distribute a slip late, you will be subject to a late-filing penalty. For more information, see [Penalties and interest](#h_5).

### Reporting deductible RCA contributions to the employee

Include in box 20 of the [T4 slip, Statement of Remuneration Paid](/en/revenue-agency/services/forms-publications/forms/t4.html), which you issue to the employee any deductible RCA contributions you withheld from income for that employee. Do not include amounts that are not deductible. If the amount in box 20 of the T4 slip includes registered pension plan contributions and deductible RCA contributions, send a letter with the employee's copy of the T4 slip showing each amount separately to the CRA.

For more information on the deductibility of RCA contributions, see [Appendix 2](#appendix2).

### Change to the employer's legal name

If the employer's legal name has changed, the employer has to send a notification letter to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

The letter has to include the employer's payroll account number and supporting documents.

For example, in the case of a corporation, the CRA requires a copy of the “certificate of amendment” or “articles of amendment” issued by the provincial, territorial or federal incorporating authority or registrar of corporations that approved the new name. For an unincorporated entity (such as an entity established by a constitution or trust deed), the CRA requires a copy of a resolution or written agreement signed by the directors or trustees of the entity indicating the new name and showing the effective date of the change of name.

## Custodian responsibilities

This section discusses the following custodian responsibilities:

* Receiving employee contributions.
* Remitting refundable tax to the Canada Revenue Agency (CRA) on amounts received directly from an RCA member (employee), using the remittance voucher on Form T901B, Statement of Account.
* Completing and filing [Form T3-RCA Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html), and remitting the refundable tax owing.
* Providing the CRA with any change of address information (information to be supplied by an authorized individual).
* Providing the CRA with any information on changes to the RCA's custodian. (The CRA would need copies of the amended trust agreement signed by both the resigning and the new custodian of the RCA).
* Providing the CRA with details of any funds transferred to or from another RCA trust.
* Filing Form [T735, Application for a Remittance Number for Tax Withheld from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t735.html), to apply for a remittance account number for income tax withheld on distributions.
* Withholding income tax on distributions made out of the RCA trust.
* Filing [Form PD7A, Remittance Form – Statement of Account for Current Source Deductions](/en/revenue-agency/services/forms-publications/request-payment-forms-remittance-vouchers.html), to remit income tax withheld on distributions.
* Filing the [T4A-RCA slips and summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) to report distributions made out of the RCA trust.
* Filing Form NR76, Non-resident Tax – Statement of Account, to remit income tax withheld on distributions to non-residents.
* Filing the [NR4 slip and Summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html) to report distributions to non-residents.

### Note

**A person who bought another person's interest in an RCA** has many of the same responsibilities as a custodian. [Appendix 1](#appendix1) addresses those responsibilities and directs buyers to the applicable areas of this section.

### Receiving employee contributions

Under the terms of some employment agreements, an employee is required to contribute an amount to the RCA trust.

* some agreements require the **employer** to withhold the amounts from the employee's income
* other agreements require the **employee** to make these contributions directly to the custodian

To be deductible by the employee under paragraph 8(1)(m.2), the total amount contributed by the employee for the year **cannot be more** than the total amount contributed in the year by the employer for the employee. Refer to [Appendix 2](#appendix2) for other conditions that apply to deductions of employee contributions to RCAs.

#### Contributions that the employer withheld from income

If you receive a contribution for an employee that was withheld from income by the employer, you have to send a letter to the employee. The letter must also explain whether the amount is deductible and, if so, to deduct it on line 20700 of their income tax and benefit return. The employee may need this letter to support the deduction on their return.

When an employer makes a contribution to a custodian for an RCA trust, the employer has to withhold tax equal to 50% of the contribution and remit the refundable tax to the CRA. The employer will issue you a [T737-RCA slip, Statement of Contributions Paid to a Custodian of a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t737-rca.html), to tell you the amount of tax they withheld and remitted to the CRA.

#### Amounts received directly from an RCA member (employee)

If the employer receives a contribution **directly** from an employee, send a letter of acknowledgement to them. The letter must also explain whether the amount is deductible and, if so, to deduct it on line 20700 of their income tax and benefit return. The employee may need this letter to support the deduction on their return.

#### Remitting the refundable tax on amounts received directly from an RCA member (employee)

Contributions that an employee made directly to an RCA trust will not have refundable tax withheld. However, the custodian of the trust can remit the refundable tax on all contributions that the employee made. To do this, use the remittance voucher provided by the CRA on Form T901B, Statement of Account, which is available only in a **personalized, pre-printed** format. The CRA will issue Form T901B after it processes your first payment. The refundable tax under Part XI.3 for employee contributions is calculated on the Form T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return.

### Filing a  Form T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return

As a custodian of an RCA trust, you have to file Form [T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html), every year, within 90 days after the end of the RCA trust's tax year. The tax year of an RCA trust is the calendar year. The CRA will apply a penalty if you file this return late. For more information, see [Penalties and interest](#h_5).

#### Note

If the CRA denies an employer's request to register the RCA as a registered pension plan, the T3-RCA tax return is due on whichever of these dates is later: 90 days after the date of the final determination about the request, or 90 days after the trust’s tax year. When you file the T3-RCA tax return, include a copy of the denial letter you received from the CRA's Registered Plans Directorate. Doing so may help avoid a late filing-penalty.

#### Tax on RCA advantages and prohibited investments

An RCA custodian is subject to tax under section 207.62 when an advantage as defined under subsection 207.5(1) of the Income Tax Act (ITA), is obtained in relation to the RCA.

An RCA custodian is also subject to tax under section 207.61 of the ITA when an RCA has a prohibited investment as defined under subsection 207.5(1).

Under section 207.63 of the ITA, a specified beneficiary of an RCA as defined under subsection 207.5(1), may also be liable for tax under section 207.61 or 207.62.

#### Waiver or cancellation of tax

Under section 207.64 of the ITA, the Minister of National Revenue may waive or cancel all or part of the tax payable under sections 207.61 to 207.63 for a prohibited investment or in respect of an advantage if the Minister of National Revenue is satisfied that it is just and equitable to do so after reviewing all factors, including whether:

* the tax arose because of a reasonable error
* the extent to which the transaction or series of transactions that gave rise to the tax also gave rise to another tax under the ITA

#### Completing the T3-RCA tax return

Enter the following information when you complete the [T3-RCA](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) tax return:

RCA trust's tax year

Enter the four digits of the RCA trust's tax year for which you are filing this return.

Is this the first T3-RCA tax return filed?

Tick (✓) the **yes** or **no** box, whichever applies. If you tick **yes**, send the CRA a copy of the trust agreement if it was not already sent.

Is this the final return of the RCA trust?

Tick (✓) the **yes** or **no** box, whichever applies. If you tick **yes**, send the CRA an extra sheet to explain why the trust is being closed.

Language of correspondence

Tick (✓) the appropriate box.

RCA trust's name

Enter the full name of the RCA trust. Use the same name on all returns and correspondence for the trust. If the trust name is longer than 60 characters, the CRA will modify it to meet our requirements.

Custodian trust account number

Enter the **T** custodian trust account number the CRA assigned to the custodian.

Custodian information

Enter the custodian's full name. The custodian can be an individual or a non-individual. Choose only one of the two options and fill in the required information about the custodian.

Area code and telephone number

Enter the area code and telephone number where the CRA can contact the custodian about this tax return. If the custodian is not an individual, enter the area code and phone number of the contact person.

Custodian's address

Enter the custodian's complete address. If the custodian is not an individual, enter the complete address of the contact person.

Mailing address (if different)

Enter the custodian's mailing address if it is different than the custodian's address. The CRA may change part of your address to meet Canada Post’s requirements. Therefore, the address on cheques or correspondence sent by the CRA may be different from what you indicate on the trust’s return.

If you include the name and mailing address of a contact person, the CRA will send all cheques and correspondence for the trust in care of that person.

**Step 1 – Supporting documents**

Tick (✓) the **yes** or **no** boxes as they apply. If you answer **yes** to any of the questions in Step 1, enter the information requested or send the applicable documents with the [T3-RCA](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) tax return to the CRA, as indicated.

If you answered **yes** to question 8, send the CRA a copy of the loan agreement.

If you answered **yes** to question 9, send the CRA a copy of the letter of agreement between the two RCA trusts, and provide the custodian trust account number of the other RCA. For more information about the information that you should include in the letter of agreement, see [Transferring amounts between RCA trusts](/en/services/taxes/income-tax/trust-income-tax/retirement-compensation-arrangements-guide.html#P591_62953).

Question 11

An RCA trust (other than a deemed trust under subsection 207.6(1)) which is resident in Canada will have to include Schedule 15, Beneficial Ownership Information of a Trust with its T3-RCA Return for the 2023 and subsequent tax years if it does not meet one of the exceptions listed in subsection 150(1.2).

The exceptions which may apply to an RCA can be found in paragraphs 150(1.2)(a) and (b):

* trusts that have been in existence for less than three months at the end of the year;
* trusts that hold assets with a total fair market value that does not exceed $50,000 throughout the year, where the only assets held by the trust throughout the year are one or more of
  + money,
  + certain government debt obligations,
  + a share, debt obligation or right listed on a designated stock exchange,
  + a share of the capital stock of a mutual fund corporation,
  + a unit of a mutual fund trust,
  + an interest in a related segregated fund (within the meaning assigned by paragraph 138.1(1)(a)), and
  + an interest, as a beneficiary under a trust, all the units of which are listed on a designated stock exchange.

If you are required to file a Schedule 15 with your tax return, see the T4013, T3 Trust Guide for information on how to complete Schedule 15.

Question 12

Is the trust a specified arrangement under which an eligible employer is electing under subsection 207.71(2)?

Tick (✓) the yes or no box, whichever applies.

**Step 2** **– Details of contributions received during the year**

##### Note

If you do not complete Step 2, the CRA cannot process your return.

Part 1 – Amounts received from employer

Give details for each contribution received from an employer during the year. If there is not enough space on the form, include a separate sheet. Send copy 2 of the [T737-RCA slips](/en/revenue-agency/services/forms-publications/forms/t737-rca.html) to the CRA to support the amount on line 1.

Also give details of any lump-sum amounts that were transferred from another RCA trust to this RCA trust if either of the following applies to the receiving trust:

* its custodian is a non-resident
* it is a foreign plan considered under subsection 207.6(5) to be an RCA for Canadian residents participating in the plan.

Part 2 – Amounts received directly from an RCA member

Give details of all amounts received directly from an RCA member. If there is not enough space on the form, include a separate sheet.

Part 3 – Amounts transferred directly from another RCA trust

If funds have been transferred **directly** from another RCA trust (the **transferring plan**) to this RCA trust (the **receiving plan**), and the receiving plan does **not** have a non-resident custodian and is **not** a foreign plan that is considered by subsection 207.6(5) to be an RCA for Canadian residents participating in the plan, include in Part 3 any lump-sum amounts transferred directly to the receiving plan. For more information, see [Transferring amounts between RCA trusts](/en/services/taxes/income-tax/trust-income-tax/retirement-compensation-arrangements-guide.html#P591_62953).

##### Notes

1. Do not include the transfer in Part 3 if either of the following apply:

* the custodian of this RCA trust is a non-resident
* this arrangement is a foreign plan that is considered under subsection 207.6(5) to be an RCA for Canadian residents participating in the plan.

    Instead, enter the transfer as an employer contribution in Part 1.

2. If there is not enough space on the form to record all amounts transferred, include a separate sheet.

3. Send the CRA a copy of the letter of agreement between the two RCA trusts. This letter will authorize the CRA to make the transfer of the related refundable tax on hand to your RCA trust's account.

**Step 3** – Specified refundable tax

A refund of 50% of certain retirement benefits paid may be claimed (up to the amount of specified refundable tax at the end of the taxation year) where certain conditions are met. One of the conditions requires the eligible employer to file an election with the CRA under subsection 207.71(2) of the ITA.

**Employer One Time Election under Subsection 207.71(2)**

The election is to be made by the employer and it should be submitted to the CRA separately from the T3RCA return via the submit document service.

The employer is only required to make this election one time in the first year they are electing under subsection 207.71(2) to receive a refund of previously submitted specified refundable tax.

The employer must provide a signed letter electing under subsection 207.71(2) which includes the following information:

* The trust account number and tax year of election
* Employers account number
* Employers RCA “RC” account number
* Employers legal name and address
* The  employers signature and date of election

If the trust is a specified arrangement under which an eligible employer is electing under subsection 207.71(2), complete this step, otherwise, go to step 4.

Line 1 -  Amount elected under subsection 207.71(2) in the year

Enter the amount of previously remitted specified refundable tax available at the beginning of the tax year.

Line 2 – Benefits paid directly by employer (benefits secured under the specified arrangement with a letter of credit or surety bonds)

Include on line 2 any benefits paid directly by the employer to a beneficiary throughout the year.

Line 3 – **Multiply** line 2 by 50%

Multiply Benefits paid directly by employer by 50% to determine the amount paid directly from the employer.

Line 4 – Current year specified refundable tax credit claim

Amount cannot be more than the lesser of line 1 and line 3.

Line 5 – Multiply line 4 by 2

You can transfer this amount to line 24 of step 4.

Line 6 – Total specified refundable tax after the current year claim

Subtract line 4 from line 1 to determine the remaining amount of specified refundable tax after the current year claim.

Are you requesting that the refund for the credit of specified refundable tax to be issued directly to the employer?

Tick (✓) the yes or no box, whichever applies.

If no, send a copy of the T4A-RCA Summary or NR4 Summary to the CRA.

If yes, any available credit will be held and the refund issued directly to the employer under the employer’s RCA account.

You can provide the employer’s RCA account details.

**Step 4** – Calculating the refundable tax on hand for the current year

Part 1 – Refundable tax on hand before distributions or election

Complete lines 1 to 18, as they apply.

Line 1 – Refundable tax on total contributions at the beginning of the year

You can get this amount from line 7 of Step 3, of the prior year's tax return.

Line 2 – Current year's employer contributions

You can get this amount from line 1 of Step 2.

Line 3 – Current year's member contributions

You can get this amount from line 2 of Step 2.

Line 4 – Current year's amount transferred from another RCA trust

You can get this amount from line 3 of Step 2.

Line 6 – Refundable tax on total contributions

Multiply line 5 by 50% to determine the amount of refundable tax.

Line 7 – Refundable tax on total contributions at the end of the year

Add the amounts on lines 1 and 6.

Line  8 – Income and capital gains at the beginning of the year

You can get this amount from line 11 of Step 3, of the prior year's tax return.

Line 9 – Current year's income from business and property

Enter the RCA trust's income for the year from business and property. Do not include the dividend gross-up amount calculated under paragraph 82(1)(b). Send the CRA the financial statements for the business or property on the
T3-RCA tax return.

Line 10 – Current year's capital gains

Enter the RCA trust's capital gains for the year and send the CRA the financial statements for the capital gains on the T3-RCA tax return.

Line 11 – Total income and capital gains

Add lines 8 to 10.

Line 12 – Losses and capital losses at the beginning of the year

You can get this amount from line 15 of Step 3, of the prior year's tax return.

Line 13 – Current year's losses from business and property

Enter the RCA trust's losses for the year from business and property. Send the financial statements for the business and property of the T3-RCA tax return to the CRA.

Line 14 – Current year's capital losses

Enter the RCA trust's capital losses for the year. Send the financial statements supporting the capital loss of the T3-RCA tax return to the CRA.

Line 15 – Total losses and capital losses

Add lines 12 to 14.

Line 16 – Excess of income and capital gains over losses and capital losses

Subtract the amount on line 15 from the amount on line 11. If this amount is negative, enter "0".

Line 17 – Refundable tax on excess of income and capital gains over losses and capital losses

Multiply the amount on line 16 by 50% to determine the amount of refundable tax you have to enter on line 17.

Line 18 – Refundable tax on hand before distributions or election

Add the amounts on lines 7 and 17. Transfer this amount to line 26 of Part 3.

Part 2 – Distributions

You need to complete Part 2 if, while the arrangement was an RCA, you made distributions, returned amounts to the employer, or transferred amounts to another RCA.

Section 207.65 of the ITA provides a rule for the calculation of “refundable tax” of an RCA in circumstances where the custodian of an RCA has a liability to pay a tax on prohibited investments under section 207.61 or tax on advantages under section 207.62. The payment of these taxes out of property of the RCA is deemed to be a distribution from the RCA.

Line 19 – Distributions at the beginning of the year

You can get this amount from line 24 of Step 3 of the prior year's tax return.

Line 20 – Current year's distributions out of the RCA trust

Include on line 20 any funds you distributed out of the RCA trust to a beneficiary throughout the year. Do **not** include on line 20 amounts transferred to another RCA or amounts returned to the employer. Send a copy of the [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) or [NR4 Summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html) to the CRA.

Line 21 – Current year's amounts returned to employer or employee to be included in employer's or employee's income

Include on line 21 any amounts you returned to the employer or employee. Send a copy of the [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) or [NR4 Summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html) to the CRA.

If you transferred funds to another RCA trust and the custodian of the other RCA trust is a non-resident, or if the other arrangement is a foreign plan considered under subsection 207.6(5) to be an RCA for Canadian residents participating in the plan, include the transfers on line 20 as amounts returned to the employer.

Line 22 – Current year's amounts transferred directly to another RCA trust

If you transferred funds **directly** from this RCA trust (the **transferring plan**) to another RCA trust (the **receiving plan**) and the receiving plan **does not** have a non-resident custodian and is **not** a foreign plan that is considered by subsection 207.6(5) to be an RCA for Canadian residents participating in the plan, include on line 22 the total of any lump-sum amounts transferred directly to the receiving plan. You have to multiply that total by 2 because, under the letter of agreement, the CRA will transfer the same amount of refundable tax from the transferring plan to the receiving plan. For more information, see [Transferring amounts between RCA trusts](/en/services/taxes/income-tax/trust-income-tax/retirement-compensation-arrangements-guide.html#P591_62953).

Line 23 – Taxes on prohibited investments and advantages paid in the current year, to the extent that these taxes have not been waived, refunded or cancelled (distribution under section 207.65)

Enter the current year's taxes on a prohibited investment or an advantage paid in the current year and distributed under section 207.65. To the extent that these taxes have been waived, refunded, or cancelled, they are **not** included on line 23.

##### Note

If the tax on a prohibited investment reported in a year is refunded (or waived) in a later tax year, it will be necessary for the custodian to make an adjustment to the prior year’s return amending taxes and distributions as required.

Line 24 – Current year’s credit of specified refundable tax

You can get this amount from line 5 of Step 3

Line 25 – Total distributions

Add lines 19 to 24. Transfer this amount to line 27 of Part 3.

Part 3 – Refundable tax on hand (after distributions) at the end of the tax year

**Option A**– Election under subsection 207.5(2):

If you are electing under subsection 207.5(2), you may not have to complete Part 3. For information on when you make this election, see [Step 5 – Election under subsection 207.5(2) to recover refundable tax on hand](#Step_4).

If you are closing the RCA and have distributed all of the property held by the RCA so that no property remains in the RCA at the end of the year (other than the right to receive a refund of the refundable tax), you should complete Option B to recover all the refundable tax on hand.

**Option B** – Complete this option if, during the tax year, **all** of the following apply:

* you distributed **all** the funds out of the RCA trust
* **no property** remains in the RCA trust at the end of the tax year
* you are entitled to recover a refund of all the refundable tax on hand held for this RCA trust

In this case, enter the amount from line 29 on line 30 and enter on line 31 the amount that you will distribute when you receive the current year refund. To support the amount on line 31, send the CRA a copy of the [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html), the [NR4 Summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html), or both, along with the [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) for the next tax year.

Complete the calculations on lines 32 to 33.

If the amount on line 33 is a positive amount, you must either use Option A if available (complete and sign the election in Step 5) **or** follow Option C to recover a refund of all the refundable tax on hand held for this RCA.

If the amount on line 33 is “0” transfer “0” to line 40 of Step 6 of the tax return. You do not have to complete the election in Step 5.

**Option C** – If you are **not** following Option A to elect under subsection 207.5(2), and Option B **does not** apply (or the amount on line 33 is positive and you are not electing under option A), follow Option C. Complete the calculation on lines 26 to 29 to determine the amount of refundable tax on hand (after distributions) at the end of the tax year, and transfer the amount on line 29 to line 40 of Step 6.

**Step 5** – Election under subsection 207.5(2) to recover refundable tax on hand

In some cases, you may benefit from making an election so that the refundable tax on hand at the end of the tax year equals the adjusted amount of the fair market value of all the property held in the RCA trust at the end of the tax year.

To make this election, you have to complete and sign Step 5 of the [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html). You can make this election for one or more tax years. If the custodian does not sign the election, the CRA will not refund any amount.

If lines 35 and 36 do not provide enough space for all the debt obligations, send a separate sheet to the CRA. If you enter amounts for debt obligations or shares listed on a designated stock exchange (on line 38), send details of the amounts with the T3-RCA tax return to the CRA.

##### Notes

You can make this election **only** if all of the property in the RCA trust at the end of the tax year (other than a right to claim a refund under subsections 164(1) or 207.7(2)) consists of cash, debt obligations, shares listed on a designated stock exchange, units of a mutual fund trust that are listed on a designated stock exchange, or any combination of these.

Units in a mutual fund trust or shares in a mutual fund corporation that are **not** listed on a designated stock exchange **do not** qualify for the purposes of the election under subsection 207.5(2). The election is generally not available if any part of the decline in value of the property is attributable to a prohibited investment or advantage.

**Property of the RCA trust (at the end of the tax year):**

Line 34 – Cash

Enter the amount of cash of the RCA trust at the end of the tax year.

Line 35 – Debt obligations: Principal amounts

Enter the principal amount of debt obligations outstanding at the end of the tax year.

Line 36 – Debt obligations: Fair market value (FMV)

Enter the FMV of debt obligations outstanding at the end of the tax year.

Line 37 – Enter line 36 or 36, whichever is more

Enter on line 37 either the principal amount of debt obligations entered on line 35 or the FMV entered on line 36, whichever is more.

Line 38 – Fair market value of shares listed on a designated stock exchange

Enter the FMV of shares of the RCA at the end of the tax year.

Line 39 – Total property of the RCA trust at the end of the tax year

Add lines 34, 37 and 38. The result is the amount of the total property of the RCA trust at the end of the tax year. This amount is used to calculate Part XI.3 tax payable or refundable. Transfer this amount to line 40.

**Step 6** – Part XI.3 tax payable or refundable

Complete Step 6 to determine the amount of refundable tax payable or refundable.

Line 40 – Refundable tax on hand at the end of the tax year (line 29, 33, or 39, whichever one applies)

The amount on line 40 is the refundable tax on hand at the end of the tax year.

Line 41 – Refundable tax on hand at the beginning of the year

Enter the amount of refundable tax on hand at the beginning of the tax year. This amount can be found on line 40.

Line 42 – Refundable tax on hand transferred during the year to another RCA

Enter the amount of refundable tax on hand transferred during the year **to** another RCA.

Line 43 – Refundable tax on hand transferred during the year from another RCA

Enter the amount of refundable tax on hand transferred during the year **from** another RCA.

Line 44

Enter the amount of line 41 **minus** line 42 **plus** line 43.

Line 45 – Subtotal: Total Part XI.3 tax payable or refundable in the year

Enter the amount of line 40 **minus** line 44. This subtotal is the amount of Part XI.3 tax payable or refundable in the year. If the amount is negative, enclose it in brackets.

**Step 7** – Tax on advantages and prohibited investments

If the RCA owes tax on prohibited investments under section 207.61 or advantages under section 207.62, complete Step 7.

Line 46 – Tax under section 207.61 on prohibited investments

Enter the amount of tax on prohibited investments. The amount of tax payable for property described in subsection 207.61(1) is 50% of the fair market value (FMV) of the property.

Line 47 – Tax under section 207.62 on advantages

Enter the amount of tax on advantages. The amount of tax payable for an advantage described in 207.62(1) is the FMV of a benefit, the amount of a loan or indebtedness, and in the case of an RCA strip, the amount of the RCA strip.

Line 48 – Minus refund of the tax on prohibited investments

Subtract the refund of the tax on prohibited investments that was not waived or cancelled.

To claim a refund, you must send the following supporting documents with the [T3-RCA return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) to the CRA:

* a letter explaining why you are requesting a refund
* the appropriate documents detailing the information relating to the acquisition and disposition of the prohibited investment

The documents must contain:

* the name and description of the investment
* the number of shares or units
* the date the investment was acquired or became a prohibited investment
* the date of the disposition or the date the investment ceased to be prohibited

If you disposed of a prohibited investment reported at line 46 of Step 7, you may be entitled to a refund of tax paid if any of the following applies:

* The RCA trust disposes of the property in question before the end of the calendar year following the calendar year in which the tax arose
* The property ceases to be a prohibited investment before the end of the calendar year following the calendar year in which the tax arose

However, no refund will be issued if it is reasonable to expect that when the RCA trust acquired the property, the custodian or a specified beneficiary knew, or should have known, that the property was or would become a prohibited investment.

If you disposed of a prohibited investment reported at line 46 of Step 7 in the same calendar (tax) year that prohibited investment was acquired then remittance of the tax is not required. However, remittance of the tax is required if it is reasonable to expect that the custodian or specified beneficiary of the arrangement knew, or should have known, at the time the property was acquired by the RCA trust, that the property was, or would become a prohibited investment.

Line 49 – Subtotal: Refund or balance owing

Enter the amount of line 46 **plus** line 47 **minus** line 48.

**Step 8** – Refundable tax remitted

Complete Step 8 to calculate the amount of refundable tax remitted during the tax year.

Line 50 – Refundable tax deducted and remitted by employer or contributor during the year

Enter the amount of refundable tax deducted and remitted by the employer or contributor during the tax year.

Line 51 – Payments on account remitted by custodian during the year

Enter the amount of payments on account remitted by the RCA custodian during the tax year.

Line 52 – Subtotal

Enter the amount of line 50 **plus** line 51.

**Step 9** – Refund or balance owing

To determine your refund or balance owing, complete Step 9.

Line 53 – Enter the amount of line 45 **plus** line 49 **minus** line 52

If the amount on line 53 is positive, you have a balance owing. If the amount on line 53 is negative, you have a refund.

You have to send your payment for any tax owing along with the completed [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html). The amount shown on line 53 is due within 90 days after the end of the RCA trust's tax year for which you are filing the tax return. You will have to pay a penalty for late payment if you have a balance owing. For more information, see [Penalty for filing a return late](#P636_68432).

Line 54 – Enter the amount of the payment you are sending the CRA with your tax return.

Make your cheque payable to the Receiver General for Canada and write your name, the T custodian trust account number, and “Form T3-RCA” on the front of your payment.

Line 55 – Refund code

If the trust is entitled to a refund, enter one of the following codes on line 55:

**0** if you want the CRA to refund the credit

**1**  if you want the CRA to hold the credit for next year

**2** if you want the CRA to hold the credit and apply it to an expected assessment of an additional amount to be paid. Send a letter to the CRA providing details

The CRA considers the credit to have been received on the date the CRA assesses your return. The CRA first applies a credit to any outstanding balance. Then, the CRA directs any amount left over according to the code you enter. If you do not enter a code, the CRA will refund the credit.

**Step 10 –** Certification

The custodian's authorized representative has to complete and sign this area.

#### Filing the T3-RCA tax return

Send the completed T3-RCA tax return within 90 days after the end of the RCA's tax year.

#### Filing through EFILE

You have the option to file this return through EFILE. For more information about this filing method, go to [EFILE for electronic filers](/en/revenue-agency/services/e-services/digital-services-businesses/efile-electronic-filers.html).

##### Note

You do not have to send other supporting documents when filing online. Keep all supporting documents used to prepare a return, such as books, records, forms, schedules and receipts, for six years from the end of the last tax year to which they relate. Be ready to send those documents to the Canada Revenue Agency on request.

#### Filing on paper

Send the completed return together with all required attachments and payment for any balance owing, to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

Send this tax return separately from any other return.

If you need to change a return after you send it to the CRA, **do not** file another return for that tax year. Send a completed [Form T3-ADJ, T3 Adjustment Request](/en/revenue-agency/services/forms-publications/forms/t3-adj.html), or a letter providing the details of the change to the CRA.

Keep a photocopy for your records.

### Applying for an RP or NR account number for income tax withheld on distributions

When you are ready to make the first distribution out of the retirement compensation arrangement (RCA) trust to a beneficiary that is a resident of Canada, a non-resident, or both, you should apply for a remittance account number by completing Form [T735, Application for a Remittance Number for Tax Withheld from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t735.html). The CRA uses this form to open two accounts:

* The **RP** employer remittance account, which is a payroll account for the RCA trust only
* The **NR** account, which is a non-resident deduction remittance account beginning with the letters NRQ. This account is used to report payments you make to non-residents and for the income tax you withhold from the payments. For more information about the reporting requirements, see [Reporting distributions made to non-residents of Canada](#P585_62067).

#### Completing Form T735, Application for a Remittance Number for Tax Withheld from a Retirement Compensation Arrangement (RCA)

The custodian should complete sections A and B and the certification area of [Form T735](/en/revenue-agency/services/forms-publications/forms/t735.html).

##### Note

**A person who bought an interest in an RCA** should complete sections A and C and the certification area of Form T735.

**Section A**

If you are a custodian, to whom will you make distributions out of the RCA trust?

Tick (✓) the appropriate box.

If you bought an interest in an RCA, from whom did you buy the interest?

Tick (✓) the appropriate box.

If you are a custodian, you have to complete section B.

**Section B** – Custodian

RCA trust's name

Enter the full name of the RCA trust.

Custodian trust account number

Enter the **T** custodian trust account number the CRA assigned to the custodian.

Custodian's name

Enter the custodian's full name.

Custodian's address

Enter the custodian's complete address.

Name and telephone number of the custodian's representative

Enter the name of the person the CRA can contact about this application and their area code and telephone number.

Address where books and records are kept

Tick (✓) the box if the address is the same as the address on line 3, or enter the address where the books and records of the RCA trust are kept.

If you have made distributions out of the RCA trust

Give the details of distributions as requested in this area. If there is not enough space, attach a separate detailed list.

If you have not made any distributions out of the RCA trust

Give the date when you expect to make distributions.

Language of correspondence

Tick (✓) the appropriate box.

**Section C** – Person who bought an interest in an RCA

If you bought an interest in an RCA, you have to complete Section C.

RCA trust's name

Enter the full name of the RCA trust.

Name and telephone number of person who bought an interest in the RCA

Enter the full name of the person who bought an interest in the RCA and their area code and telephone number where the CRA can contact them about the application.

Address of the person who bought an interest in the RCA

Enter the complete address of the person who bought an interest in the RCA.

Address where books and records are kept

Tick (✓) the box if the address is the same as the address on line 3 or enter the address where the books and records of the RCA trust are kept.

When did you buy the interest in the RCA?

Enter the date you bought the interest in the RCA.

What was the purchase price for the interest in the RCA?

Enter the amount you paid for the interest in the RCA.

Language of correspondence

Tick (✓) the appropriate box.

Certification

The custodian's authorized representative or the person who bought an interest in the RCA has to complete and sign this area.

#### Filing Form T735

Send the completed original of [Form T735](/en/revenue-agency/services/forms-publications/forms/t735.html) to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

Keep a photocopy for your records.

##### Notes

When you file Form T735, the CRA will send you a Form PD7A, Remittance Form Voucher – Statement of Account for Current Source Deductions. Following the first Form PD7A, the CRA will send you a new statement every time a payment is made. If no payment is received, the CRA will not send a Form PD7A unless you request it.

For more information, see the next three subheadings.

### Withholding and remitting income tax on distributions

#### Withholding income tax on distributions

As a custodian, you have to withhold income tax on any distributions you make to beneficiaries out of the RCA trust. This includes periodic payments and lump-sum payments. You usually have to remit this tax on or before the 15th day of the month after you withheld it.

To calculate the amount of income tax you have to deduct and to determine when you have to remit the income tax, see [Calculate payroll deductions and contributions](/en/revenue-agency/services/tax/businesses/topics/payroll/calculating-deductions.html), and [Special payments chart](/en/revenue-agency/services/tax/businesses/topics/payroll/payroll-deductions-contributions/special-payments/special-payments-chart.html).

If you do not deduct the required tax from these payments (including payments made to non-residents), the CRA will charge you a penalty. For more information, see [Income tax on distributions](#P618_66144).

If you buy an annuity contract for the beneficiary, the CRA considers that the amount paid to buy the contract is a taxable distribution to the beneficiary out of the RCA trust. The full amount is taxable in the year you buy the contract and you have to withhold income tax from this amount.

If you distributed an amount out of the RCA trust to a non-resident, see [Distributions to non-residents of Canada](#P573_60270).

##### Notes

**If you bought an interest in an RCA from a resident of Canada**, you have to withhold tax at a rate of 50% of the purchase price.

**If you bought an interest from a non-resident**, see [Withholding income tax on distributions made to non-residents of Canada](#P575_60559).

When you are ready to make the first distribution out of the RCA trust to a beneficiary, you have to file a completed [Form T735](/en/revenue-agency/services/forms-publications/forms/t735.html) to apply for a remittance account number. For more information, see [Applying for an RP or NR account number for income tax withheld on distributions](#P406_44346).

#### Remitting income tax withheld on distributions made out of the RCA trust using Form PD7A, Remittance Form Voucher – Statement of Account for Current Source Deductions

The PD7A is available only in **personalized**, **pre-printed** format. Our agents will personalize and mail them to you. To replace lost remittance vouchers or to get a limited number of personalized forms, call **1-800-959-5525**.

Your remitter type will determine the frequency and the due dates to remit income tax withheld on distributions. For more information, see [Calculate payroll deductions and contributions](/en/revenue-agency/services/tax/businesses/topics/payroll/calculating-deductions.html), and [Special payments chart](/en/revenue-agency/services/tax/businesses/topics/payroll/payroll-deductions-contributions/special-payments/special-payments-chart.html).

#### Remitting income tax withheld on distributions before you receive an account number

If you have withheld income tax as required but have not received a remittance account number or a non-resident tax deduction remittance account number, or if you have filed Form T735 but **have not** received Form PD7A in time for your next payment, do not delay making the payment.

Send it to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB  R3C 3M2

Send your payment with a note stating that you did not receive Form PD7A. In your note, you should also give the following information:

* your name and address
* the full name of the RCA trust
* if you are the custodian, the **T** custodian trust account number
* the month during which the tax was withheld

When the CRA receives this information, the CRA will send you Form T735 with an assigned remittance account number. When you get this form, complete it and send it to the RCA Unit at the Winnipeg Tax Centre. Once the CRA processes the payment, the CRA will send you a receipt and a blank Form PD7A.

### Filing  T4A-RCA slips and the summary to report distributions made out of an RCA trust

A custodian who makes a distribution out of an RCA trust has to file a [T4A-RCA SUM, Summary of Distributions from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html), and the related [T4A-RCA slips, Statement of Distributions from a Retirement Compensation Arrangement (RCA)](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html).

#### Note

**If you bought an interest in an RCA**, you have to file the T4A-RCA slips and summary to report the purchase.

You have to file the T4A-RCA slips and summary no later than the last day of February following the year you made the distributions or bought the interest, as the case may be.

#### Completing the T4A-RCA slip, Statement of Distributions from a Retirement Compensation Arrangement (RCA)

The [T4A-RCA slip](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html) is available as one-page form and as a PDF fillable version.  You can get these forms from our website.

You have to complete a T4A-RCA slip for each beneficiary who received a payment and for each person who sold an interest in an RCA, as the case may be. In some cases, you have to prepare a T4A-RCA slip for amounts the RCA trust refunded to the employer or the employee.

You have to enter the following information on the T4A-RCA slips:

Year

Enter the four-digit calendar year for which you are preparing the T4A-RCA slip.

Box 12 – Refund to employer

Enter the amount, if any, that the RCA trust refunded to a participating employer, which has to be included in their income under paragraph 12(1)(n.3). If the custodian of the receiving plan is a non-resident, or if the receiving plan is a foreign plan that is considered by subsection 207.6(5) to be an RCA for Canadian residents participating in the plan, include a transfer of funds from this RCA trust (the **transferring plan**) to another RCA trust (the **receiving plan**).

##### Notes

If the custodian of a receiving plan **is not** a non-resident **and** the receiving plan **is not** a foreign plan that is considered by subsection 207.6(5) to be an RCA for Canadian residents participating in the plan, **do not** include in box 12 any transfer of funds made **directly** from a transferring plan to the receiving plan.

For more information about transfers between RCA trusts, see [Transferring amounts between RCA trusts](#P591_62953).

Box 14 – Refund of employee contributions

Enter the amount, if any, that the RCA trust refunded to the employee, including voluntary employee contributions made to the RCA.

Box 16 – Distributions

Enter the amount you paid to the beneficiary as benefits from the RCA trust. Do not include a refund of employee contributions or amounts paid to buy an interest in the RCA.

Box 17 – Distributions eligible for pension income splitting

Enter the amount included in box 16 consisting of payments made in the year to the individual out of or under an RCA that:

* are in respect of a life annuity that is attributable to periods of employment for which benefits are also provided to the individual under a registered pension plan
* provide benefits that supplement the benefits provided under a registered pension plan (other than an individual pension plan for the purposes of Part LXXXIII of the Income Tax Regulations)

Include this amount in the calculation of the maximum split pension amount on [Form T1032, Joint Election to Split Pension Income](/en/revenue-agency/services/forms-publications/forms/t1032.html), **if you are age 65 or more at the end of the calendar year and are electing to split your eligible pension income with your spouse or common-law partner.**

Box 18 – Selling price of an interest in the RCA

If you bought an interest in the RCA, enter the amount you paid to the recipient for the interest in the RCA (the purchase recipient price before you withheld 50% tax).

Box 20 – Other amounts

Complete box 20 if the RCA trust:

* disposed of property for consideration less than the fair market value (FMV) of the property
* acquired property for consideration greater than the FMV of the property
* permitted the RCA trust's property to be used for consideration less than the FMV of such use

Under subsection 56(11), the amount to include in box 20 is the difference between the consideration and the FMV.

Box 22 – Income tax deducted

Enter the amount of income tax deducted from distributions or from the purchase price of the interest, as the case may be.

Box 24 – Social insurance number

Enter the recipient's social insurance number.

Recipient's name and address

Enter the last name in capital letters, followed by the first name and initial, and the complete address of either the individual who received an amount from the RCA, or of the person who sold an interest in the RCA to another person, as the case may be.

Name of custodian, or person who bought an interest in the RCA

Enter the full name of the custodian or the full name of the person who bought an interest in the RCA, as the case may be.

Box 61 – Payroll account number

Enter the custodian's payroll account number or the payroll account number of the person who bought an interest in the RCA, as the case may be. The custodian's payroll account number has to be the same as it is on your Form PD7A receipt. The custodian's payroll account number should not appear on the two copies of the T4A-RCA slip that you give to the recipient.

#### Completing the T4A-RCA SUM, Summary of Distributions from a Retirement Compensation Arrangement (RCA)

You have to enter the following information on the [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html):

Year

Enter the four-digit calendar year for which you are preparing the T4A-RCA Summary.

Payroll account number

Enter the custodian's payroll account number or the payroll account number of the person who bought an interest in the RCA, as the case may be.

Corresponding custodian trust account number

Enter the corresponding custodian trust account number. This is a nine-character account number beginning with the letter T, followed by eight numbers.

Name and address of custodian, or person who bought an interest in the RCA

Enter the full name and complete address of the custodian, or the person who bought an interest in the RCA, as the case may be.

##### Note

The custodian's name and payroll account number have to be the same as on your Form PD7A receipt.

Name of the RCA trust

Enter the full name of the RCA trust.

Line 88 – Total number of T4A-RCA slips filed

Enter the number of T4A-RCA slips filed with this [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html).

Line 12 – Refund of employer contributions

Enter the total of all amounts shown in box 12 of all [T4A-RCA slips](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html) filed with this summary.

Line 14 – Refund of employee contributions

Enter the total of all amounts shown in box 14 of all T4A-RCA slips filed with this summary.

Line 16 – Distributions

Enter the total of all amounts shown in box 16 of all T4A-RCA slips filed with this summary.

Line 17 – Distributions eligible for pension income splitting

Enter the total of all amounts shown in box 17 of all T4A-RCA slips filed with this summary.

Line 18 – Selling price of an interest in the RCA

Enter the total of all amounts shown in box 18 of all T4A-RCA slips filed with this summary.

Line 20 – Other amounts

Enter the total of all amounts shown in box 20 of all T4A-RCA slips filed with this summary.

Line 22 – Income tax deducted

Enter the total of all amounts shown in box 22 of all T4A-RCA slips filed with this summary.

Line 82 – Remittances

Enter the total amount of tax you remitted to the CRA. You can get this amount from your most recent Form PD7A receipt.

Difference

Subtract line 82 from line 22.

If this amount is positive, there is a balance owing. Enter the result on line 86.

If the amount is negative, there is an overpayment. Enter the result on line 84.

Line 84 – Overpayment

Enter the amount of tax overpaid. Generally, if the difference is $2 or less, you will not receive a refund.

Line 86 – Balance owing

Enter the amount of tax owing. Generally, if the difference is $2 or less, you do not have to make a payment.

If you have a balance owing, you may be subject to a penalty for late payment. For more information, see [Penalties and interest](#h_5).

Line 76 – Contact person

Enter the name of the person the CRA can contact about this summary.

Line 78 – Telephone number

Enter the area code and telephone number of the person the CRA can contact about this summary.

Certification

An authorized officer of the custodian, or the person who bought an interest in the RCA, has to complete and sign this area.

#### Distributing the slips and summary

Attach one copy of every [T4A-RCA slip](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html) to the completed [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html), and send them with your payment for any balance owing to:

RCA Unit
Winnipeg Tax Centre
66 Stapon Rd
Winnipeg MB   R3C 3M2

Send the slips and summary no later than the last day of February following the calendar year to which they relate.

Send two copies of every T4A-RCA slip to the custodian no later than the last day of February following the calendar year to which the slip relates.

If you are a custodian, attach a copy of the T4A-RCA Summary to your [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html).

Keep a photocopy of the completed T4A-RCA Summary and one copy of every T4A-RCA slip for your records.

#### Electronic fillable slips

If you use PDF fillable T4A-RCA slips, you can print them on plain white paper. You can also make photocopies to distribute to the custodian. The CRA accepts copies of our forms, not only the preprinted original forms.

##### Notes

You can send the custodian an electronic copy of the T4A-RCA slips. However, each custodian has to consent in writing (in a letter or by email) to receive the slips electronically.

If you file the T4A-RCA slips and summary late or distribute the information slips late, you may be subject to a late-filing penalty. For more information, see [Penalties and interest](#h_5).

#### Filing the final T4A-RCA slips and summary

What should you do if your RCA closes?

* Remit all income tax deductions from the distributions.
* Complete the [T4A-RCA slips](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html) and the [T4A-RCA Summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) and send them to the [Winnipeg Tax Centre](#P172_13108) within 30 days of the day that the RCA closes.
* Give copies of the T4A-RCA slips to the appropriate individuals.
* File the final [T3-RCA, Retirement Compensation Arrangement (RCA) Part XI.3 Tax Return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html).

### Distributions to non-residents of Canada

Part XIII of the [ITA](https://laws.justice.gc.ca/eng/acts/I-3.3/page-180.html#h-314143) imposes a withholding tax on certain amounts paid or credited to persons not resident in Canada. For a general description of Part XIII tax, go to [Part XIII withholding tax](/en/revenue-agency/services/tax/international-non-residents/payments-non-residents/nr4-part-xiii-tax/part-xiii-withholding-tax.html).

#### Withholding income tax on distributions made to non-residents of Canada

As a custodian, you have to withhold income tax on any distributions you make out of the RCA trust to non-resident beneficiaries. This applies to periodic payments and lump-sum payments.

The income tax is 25% of the amount you paid or credited to the non-resident. However, if the payments qualify as "periodic pension payments" the income tax convention or agreement between Canada and the other country may reduce the rate of Part XIII tax. For more information about non-resident income tax, the treaty countries, and treaty rates, see the following publications:

* **[NR4 slip](/en/revenue-agency/services/tax/international-non-residents/payments-non-residents/nr4-part-xiii-tax/nr4/nr4-slip.html)**
* [Non-resident Tax Calculator](/en/revenue-agency/services/e-services/non-resident-tax-calculator-disclaimer.html)
* [Part XIII withholding tax](/en/revenue-agency/services/tax/international-non-residents/payments-non-residents/nr4-part-xiii-tax/part-xiii-withholding-tax.html)

##### Note

**If you bought an interest in an RCA from a non-resident**, you have to withhold income tax at a rate of 25% of the price you paid.

#### Remitting income tax withheld on distributions made to non-residents of Canada

Use the non-resident tax remittance voucher of Form NR76, Non-Resident Tax – Statement of Account, to remit the income tax you withheld under Part XIII of the [ITA](https://laws.justice.gc.ca/eng/acts/I-3.3/page-180.html#h-314143). You have to remit this tax on or before the 15th day of the month after the month you withheld it. For more information on Form NR76 and on remitting the non-resident withholdings, see **[NR4 slip](/en/revenue-agency/services/tax/international-non-residents/payments-non-residents/nr4-part-xiii-tax/nr4/nr4-slip.html)**.

#### Reporting distributions made to non-residents of Canada

If you are a trustee who has allocated an amount from the RCA trust to a non-resident, you must file the following slips:

* [NR4SUM – Return of Amounts Paid or Credited to Non-Residents of Canada](/en/revenue-agency/services/forms-publications/forms/nr4sum.html), and
* [NR4 – Statement of Amounts Paid or Credited to Non-Residents of Canada.](/en/revenue-agency/services/forms-publications/forms/nr4.html)

##### Note

If you bought an interest in an RCA from a non-resident, you have to file the NR4 slip and summary to report your purchase.

You have to file the NR4 slips and summary:

* on or before March 31 of the year after you made the distribution or bought the interest
* within 90 days after the end of the trust's tax year, or
* within 30 days after the end of the business or activity if you discontinue your business

For more information on completing the NR4 slips and summary, see [NR4 – Services and information](/en/revenue-agency/services/tax/international-non-residents/payments-non-residents/nr4-part-xiii-tax/nr4.html).

### Transferring amounts between RCA trusts

Under subsection 207.6(7), you do not have to pay tax under Part I of the ITA when you transfer a lump-sum amount **directly** from one RCA trust (the **transferring plan**) to another RCA trust (the **receiving plan**).

If you transferred funds to another RCA trust, you **must** send to the CRA, a copy of the letter of agreement between the two RCA trusts showing the following information:

* the name, complete address, and social insurance number of each member whose funds were transferred
* the transferring RCA trust's full name, complete address, and custodian's trust account number
* the receiving RCA trust's full name, complete address, and custodian's trust account number
* the amount transferred, supported by a letter to the CRA requesting that the transfer be made

This letter will authorize the CRA to transfer the related refundable tax on hand from the transferring plan's account to the receiving plan's account.

**If you received funds from another RCA trust**, the CRA **must** receive a copy of the letter of agreement between the two RCA trusts showing the information in the list above. When you file your [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html), send a copy of the letter of agreement to the CRA. This will authorize the CRA to transfer the related refundable tax on hand to your RCA trust’s account.

This transfer of funds does not apply if the receiving plan has a non-resident custodian or is a foreign plan that, under subsection 207.6(5) is considered to be an RCA for Canadian residents participating in the plan.

#### Note

Subsection 207.6(7) does not apply to amounts refunded to the employer that are later transferred to an RCA trust. These amounts are reported in box 12 of a T4A-RCA slip as a refund of employer contributions. For more information, see [Completing the T4A-RCA slip, Statement of Distributions from a Retirement Compensation Arrangement (RCA)](#P518_55846).

## Penalties and interest

An employer, a custodian, or a person who bought an interest in an RCA has to meet the terms of the withholding, remitting, and filing requirements. If they do not, the CRA will apply penalties.

### Penalties for not complying with filing requirements

#### Employer, custodian, or person who bought an interest in an RCA

If you do not meet the filing requirements, you may be prosecuted. If convicted, you could be fined from $100 to $2,500. These penalties apply unless another provision of the ITA sets out a different penalty for not complying.

### Penalties for not withholding tax

#### Refundable tax on contributions

##### **Employer**

If an employer does not withhold the 50% refundable tax on contributions made to a custodian, the employer must remit to the CRA, the same amount they contributed to the custodian. The employer can deduct this amount when they calculate their business income. This amount is considered a payment on account of refundable tax.

#### Income tax on distributions

##### Custodian or person who bought an interest in an RCA

If you are a custodian who made distributions out of an RCA trust or a person who made a payment to buy an interest in an RCA trust,  you have to withhold tax from those payments. If you do not deduct or withhold the required tax from these payments (including payments made to non-residents), the CRA will charge you a penalty. The penalty for not deducting or withholding the required tax is:

* 10% of the amount that you should have withheld, or
* 20% of the amount that you should have withheld if:
  + the CRA already charged you a penalty during the year for not withholding the required tax on distributions, and
  + you knowingly **or**under circumstances amounting to gross negligence did not withhold the second time.

#### Interest

##### Employer, custodian, or person who bought an interest in an RCA

If you do not pay an amount, the CRA will apply interest from the day your payment was due. The interest rate the CRA uses may change every three months, based on prescribed interest rates. Interest is compounded daily. The CRA also applies interest to unpaid penalties. For the prescribed interest rates, go to [Prescribed interest rates](/en/revenue-agency/services/tax/prescribed-interest-rates.html).

### Penalties for not remitting the withholding tax or remitting it late

#### Employer, custodian, or person who bought an interest in an RCA

The CRA assesses a penalty on the amount you did not remit when:

* you deduct the amounts, but do not remit them
* the CRA receives the amounts you deducted after the due date

If the remittance due date is a Saturday, a Sunday, or a public holiday, your remittance is due on the next business day.

The penalty for **remitting late** is:

* 3% if the amount is one to three days late
* 5% if it is four or five days late
* 7% if it is six or seven days late
* 10% if it is more than seven days late, or if no amount is remitted

Generally, the CRA applies this penalty to the part of the amount you did not remit that is more than $500. However, in certain circumstances, the CRA may apply the penalty to the total amount.

If the CRA already charged you this penalty once in a calendar year, the CRA will assess you a 20% penalty on any further times if you knowingly or under circumstances of gross negligence did not remit the withholding tax.

##### Note

The CRA considers a non-sufficient funds (NSF) payment to be a failure to remit and will automatically apply a penalty, as well as an administrative charge.

### Penalties for not remitting the refundable tax or remitting it late

#### Employer, custodian, or person who bought an interest in an RCA

You may have to remit refundable tax in a year. The CRA will assess a penalty if the CRA receives the amount after the due date.

The CRA calculates the penalty for remitting the refundable tax late, or for not remitting it when required as follows:

* 3% if the amount is one to three days late
* 5% if it is four or five days late
* 7% if it is six or seven days late
* 10% if it is more than seven days late

Generally, the CRA applies this penalty only to the part of the amount you did not remit that is more than $500. However, in certain circumstances, the CRA may apply the penalty to the total amount.

If the CRA already charged you this penalty in the calendar year, the CRA will assess you a 20% penalty on any further times if you knowingly or under circumstances of gross negligence did not remit the refundable tax.

##### Note

The CRA will apply a penalty on a non-sufficient funds (NSF) payment and apply penalties for late or deficient remittances on amounts of more than $500. This $500 threshold does not apply:

* to remittances required under Part XIII of the ITA (non-residents), or
* if the person required to remit the amount knowingly or under circumstances amounting to gross negligence delayed remitting or remitted less than the required amount

### Penalty for filing a return late

#### Custodian

##### Failure to file a return of income

If the custodian files a [T3-RCA tax return](/en/revenue-agency/services/forms-publications/forms/t3-rca.html) late, a penalty applies.

The penalty is:

* 5% of the unpaid tax owing on the filing deadline

**plus**

* 1% of this unpaid tax for each complete month that the tax return is late, up to a maximum of 12 months

##### Repeated failure to file a return of income

The CRA will charge an even larger penalty if:

* the custodian repeatedly files the T3-RCA tax return late, **and**
* the CRA has already charged the custodian a late-filing penalty in any of the previous three tax years

In this case, the penalty is:

* 10% of the unpaid tax when the tax return was due,

**plus**

* 2% of this unpaid tax for each complete month the tax return is late, up to a maximum of 20 months.

### Employer, custodian, or person who bought an interest in an RCA, or an employer who made contributions to a custodian of an RCA trust

#### Failure to file slips and summary

You need to file the [T4A-RCA](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) and the [T737-RCA](/en/revenue-agency/services/forms-publications/forms/t737-rca.html) slips and summary on or before the last day of February following the calendar year to which they apply.

If you file the slips and summary late, the minimum penalty is $100 and the maximum penalty is $7,500.

#### Cancel or waive penalties or interest

The CRA administers legislation, commonly called taxpayer relief provisions, that allows the CRA discretion to cancel or waive penalties or interest when taxpayers cannot meet their tax obligations due to circumstances beyond their control.

The CRA’s discretion to grant relief is limited to any period that ends within 10 calendar years before the year in which a relief request is made.

For penalties, the CRA will consider your request only if it relates to a tax year or fiscal period ending in any of the 10 calendar years before the year in which you make your request. For example, your request made in 2024 must relate to a penalty for a tax year or fiscal period ending in 2014 or later.

For interest on a balance owing for any tax year or fiscal period, the CRA will consider only the amounts that accrued during the 10 calendar years before the year in which you make your request. For example, your request made in 2024 must relate to interest that accrued in 2014 or later.

To make a request, fill out Form [RC4288, Request for Taxpayer Relief – Cancel or Waive Penalties or Interest](/en/revenue-agency/services/forms-publications/forms/rc4288.html). For more information about relief from penalties or interest and how to submit your request, go to [Taxpayer relief provisions](/en/revenue-agency/services/about-canada-revenue-agency-cra/complaints-disputes/taxpayer-relief-provisions.html).

### Failure to provide a social insurance number (SIN) or other information

#### Employer, custodian, or person who bought an interest in an RCA

The CRA can charge you a penalty if you are missing information on a tax or information return. You have to make a reasonable effort to get the necessary information to complete the tax or information return.

The CRA may charge you a $100 penalty each time you omit a SIN on an information slip unless you made a reasonable effort to get the SIN. The CRA will not charge this penalty if the individual applied for a SIN but did not receive it before you filed the information return.

If you are preparing an information slip for an individual and you ask them for their SIN, they must give it to you . They may be charged a penalty of $100 for each time you ask and they do not comply.

An individual who does not have a SIN has to apply for one at any [Service Canada Centre](/en/employment-social-development/corporate/portfolio/service-canada.html) within 15 days of your request. When the individual receives their SIN, they have 15 days to give it to you.

A person younger than 18 at the end of the tax year does not need a SIN if their total income for the year is $2,500 or less.

For more information, see Information Circular [IC82-2R, Social Insurance Number Legislation that Relates to the Preparation of Information Slips](/en/revenue-agency/services/forms-publications/publications/ic82-2.html).

### Use of the SIN

#### Employer, custodian, or person who bought an interest in an RCA

When you prepare a tax or information return, you can only use, communicate, or let someone else communicate an individual's SIN for the reason the individual provided it for. You cannot use or communicate their SIN for any other reason unless you are required or authorized by law. If you do, you are guilty of an offence and can be fined up to $5,000 or imprisoned for up to 12 months, or both.

## Appendix 1 – Person who bought an interest in an RCA

A person who buys an interest in an RCA has many of the same responsibilities that a custodian does. The following rules apply if you bought an interest in an RCA:

Appendix 1 – Person who bought an interest in an RCA

| Topic | Information and references |
| --- | --- |
| Your responsibilities if you bought an interest in an RCA | * Withholding and remitting tax * Filing [Form T735](/en/revenue-agency/services/forms-publications/forms/t735.html) to apply for a remittance account number for tax withheld from the purchase price of an interest in an RCA * Filing the [T4A-RCA slips and summary](/en/revenue-agency/services/forms-publications/forms/t4a-rca-sum.html) to report the purchase of an interest in an RCA * Filing the [NR4 slips and summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html) to report payments made to non-residents who sold an interest in an RCA * Reporting amounts you received from an RCA |
| Withholding and remitting tax | You have to withhold tax at a rate of 50% of the purchase price of your interest in the RCA (25% if you bought the interest from a non-resident). For more information, see [Withholding and remitting income tax on distributions](#P460_48374) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif) and [Withholding income tax on distributions made to non-residents of Canada](#P575_60559) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif)   You have to send the tax to the CRA no later than the 15th day of the month following the month in which you withheld it. If you do not withhold this tax or if you remit the tax late, the CRA will apply penalties. For more information about the penalties, see [Penalties for not withholding tax](#P614_65694) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif) |
| Applying for a remittance account number for the tax withheld | Fill out Form T735 to apply for a remittance account number for the tax withheld. For more information, see [Completing Form T735, Application for a Remittance Number for Tax Withheld from a Retirement Compensation Arrangement (RCA)](#P410_45333) |
| Filing the T4A-RCA slips and summary to report that you purchased an interest in an RCA | You have to file the T4A-RCA slips and summary to report the purchase and to provide the seller with a tax information slip.  For more information, see [Filing T4A-RCA slips and summary to report distributions made out of an RCA trust](#P480_51611) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif)   You have to file the slips and summary no later than the last day of February after the year when you bought the interest. |
| Filing the T4A-RCA slips and summary to report distributions you made out of an RCA | For details on how to fill out the T4A-RCA slip, see [Completing the T4A-RCA slip, Statement of Distributions from a Retirement Compensation Arrangement (RCA)](#P485_52322) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif) and [Completing the T4A-RCA Summary of Distributions from a Retirement Compensation Arrangement (RCA)](#P518_55846) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif)  If you file the summary late, the CRA will apply the late-filing penalties discussed in [Penalties for not remitting the withholding tax or remitting it late](#P626_refundable) ![black triangle: topic to read if you bought an interest in an RCA](/content/dam/cra-arc/migration/cra-arc/E/pub/tg/t4041/trngl.gif) |
| Filing the NR4 slips and summary to report payments you made to non-residents | If you bought an interest in an RCA from a non-resident, you have to file the [NR4 slips](/en/revenue-agency/services/forms-publications/forms/nr4.html) and [NR4 summary](/en/revenue-agency/services/forms-publications/forms/nr4sum.html).   For more information, see [Reporting distributions made to non-residents of Canada](#P585_62067).   You have to file the slips and summary on or before:  * March 31 of the year you bought the interest, or * 90 days after the end of the trust's tax year |
| Failure to comply | The CRA will apply penalties if you do not withhold or remit the tax, file any of the slips and summary late or remit the tax late. For more information, see [Penalties and interest](#h_5). |
| Reporting amounts you received from an RCA trust | You have to report amounts you received from the RCA trust. The custodian of the RCA trust will send you a [T4A-RCA slip](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html) for any distributions the RCA made to you. |
| Selling your interest in an RCA | If you dispose of an interest in an RCA, you have to include the amount you received in your income. The buyer will send you a T4A-RCA slip for tax purposes. You may be eligible to claim a deduction for amounts received from the disposition of your interest in the RCA. See the instructions under box 18 on the back of the T4A-RCA slip. |
| Claiming deductions for amounts you received from an RCA | You may be eligible to claim a deduction for the amounts you received from an RCA. See "More information" on the back of the T4A-RCA slip. |

## Appendix 2 – More topics

Appendix 2 – More topics

| Topic | Information and Income Tax Act references |
| --- | --- |
| Amalgamated corporations | The CRA considers that an amalgamated corporation has contributed to any RCA that any of the predecessor corporations previously contributed to. **Paragraph 87(2)(j.3).** |
| Are contributions that an employee made to an RCA deductible? | The contributions an employee made to an RCA are deductible if the contributions meet the provisions of **paragraph 8(1)(m.2)**.  That paragraph allows an employee to deduct those contributions if:   * the terms of their employment require them to contribute the amount and the total amount they contributed in the year is not more than the total amount the employer (or any other person) contributed in the year for the employee, or * they contributed the amount to a registered pension plan under the terms of that plan but the plan’s registration was revoked   In both cases, the employee has to make the contributions to a custodian who is a resident of Canada.  If the employee’s contribution is not deductible under paragraph**8(1)(m.2)**, the employee may be eligible to deduct an amount in the year they receive an amount from the RCA. For more information, see "Additional information" on the back of the [T4A-RCA slip](/en/revenue-agency/services/forms-publications/forms/t4a-rca.html). |
| Definition of an RCA | **Retirement compensation arrangement** (RCA) is defined in **subsection 248(1)**. The definition covers the circumstances under which the CRA considers an arrangement to be an RCA. Also, it includes a list of plans, arrangements, trusts and policies that are excluded from the definition of an RCA. |
| Definition of an RCA trust | **RCA trust** is defined in **subsection 207.5(1)** as a trust governed by an RCA. **Subsection 207.6(1)** includes special rules that apply when an RCA is established without creating a trust. |
| Distribution of property by an RCA trust | The rules for how an RCA trust distributes property are in **section 107.2**. Generally, the RCA trust must recognize any gain or loss based on the fair market value (FMV) of any or all of the property when it distributes that property. Therefore, the CRA considers that the RCA trust has made a distribution equal to the FMV of the property and that the recipient has received the property at that FMV. |
| Employee benefit plan (EBP) | The CRA considers that the custodian of an employee benefit plan (EBP) has made a contribution to an RCA:   * when the employee benefit plan becomes an RCA because the custodian changed * when the custodian stops carrying on business through a fixed place of business in Canada, or * if the custodian is no longer licensed or otherwise authorized under the laws of Canada or of a province or territory to offer services as a trustee   If an EBP includes a provision for a change of trustees, it is the CRA's view that  **subsection 207.6(4)** of the ITA does not apply when there is a change of trustees and the new trustee is resident in Canada.  Under **subsection 207.6(4)**, the CRA considers the contribution to be made right after that time and to be equal to the FMV of all the properties of the employee benefit plan. As a result, under **section 153**, the custodian has to remit 50% of the amount that the CRA considers to be a contribution to an RCA. They must remit this amount to the Receiver General for Canada. An employer who made non-deductible contributions to the plan while the plan was an employee benefit plan may also get a deduction under **section 32.1** when calculating income for the contribution. |
| Life insurance policies | **Subsection 207.6(2)** includes special rules for when an employer acquires an interest in a life insurance policy (including an annuity) to meet their obligation to provide benefits that an employee receives or enjoys on, after, or when an employer is considering:   * any substantial change in the services the employee rendered * the retirement of the employee, or * the employee's loss of an office or employment  Under this subsection, the CRA considers:  * the person or partnership who acquires the interest in the policy to be the custodian of an RCA * the interest in the life insurance policy to be the "subject property" of the arrangement * that twice the amount of the premiums paid under the policy, or the repayment of a policy loan, are contributions to the arrangement * that payments under the policy, including a policy loan, and refunds of refundable tax are distributions by the arrangement  The person who buys the interest in the policy has to:  * withhold tax from any payment toward the policy, * file the required returns, and * pay the special refundable tax.   The special rules apply when the plan or arrangement is not normally considered to be an RCA and not excluded by any of **paragraphs (a)** to **(l)** and **(n)** under the definition of **retirement compensation arrangement** in **subsection 248(1)**.  **Note**  The rules in **subsection 207.6(2)** do not apply to insurance policies a beneficiary holds. Refer to [Annuity contract](#P92_6513). |
| Parent corporation | The CRA considers that a parent corporation has contributed to any RCA that any subsidiary which has wound up into the parent corporation, had previously contributed to. **Paragraph 88(1)(e.2)**. |
| Personal services corporation | **Subsection 207.6(3)** has rules that apply to an incorporated employee when:  * a personal services corporation or its employee enters into an arrangement with a person or a partnership (referred to as the **employer**) the corporation is providing services to * the corporation or the corporation’s employee will provide benefits under the arrangement on, after, or for any substantial change in, the services provided to the employer or on, after, or for the end of those services  In these circumstances, the following rules apply:  * an employer-employee relationship exists between the employer and the personal service corporation * the distributions made to a person under the arrangement are benefits that person received or enjoyed on, after, or for a substantial change in the services the corporation provided  In this case, the CRA may consider that the plan or arrangement is an RCA as defined in **subsection** **248(1)**, depending on its terms. |
| Refusal to register a pension plan | A pension plan submitted for registration under the ITA reverts to its status as an RCA if the CRA refuses to register it as a registered pension plan as defined in **subsection 147.1(3).** |
| Resident's arrangement | The definition of an RCA excludes a retirement plan (but includes an athlete's plan) kept mainly for the benefit of non-residents for services provided outside Canada. However, special rules apply (except as noted below) if employers make contributions to a foreign plan for employees resident in Canada. In this case, the CRA considers the foreign plan to be an RCA and any contributions to it (and the investment income derived from these contributions) are subject to the refundable RCA tax.   Contributions made for an employee who has been resident in Canada for less than 60 of the preceding 72 months are excluded if the employee:   * was a member of the foreign plan before becoming a Canadian resident, or * became a plan member by the end of the calendar month following the month in which the employee became a resident. |

## Page details

Date modified:
:   2025-05-30
