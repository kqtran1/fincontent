---
source_url: https://www.canada.ca/en/services/taxes/income-tax/personal-income-tax.html
scraped_at: 2025-08-24 12:52:40
filename: en/services/taxes/income-tax/personal-income-tax_html.md
---

* [Skip to main content](#wb-cont)
* [Skip to "About this site"](#wb-info)

## Language selection

* [Français
  fr](/fr/services/impots/impot-sur-le-revenu/impot-sur-le-revenu-des-particuliers.html)

[![Government of Canada](/etc/designs/canada/wet-boew/assets/sig-blk-en.svg)
 /
Gouvernement du Canada](https://www.canada.ca/en.html)

## Search

Search Canada.ca

Search

---

## Menu

Main Menu

* [Jobs and the workplace](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business and industry](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](http://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finances](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)

## Sign in

[Sign inCRA sign in](/en/revenue-agency/services/e-services/cra-login-services.html)

## You are here:

1. [Home](/en.html)
2. [Taxes](/en/services/taxes.html)
3. [Income tax](/en/services/taxes/income-tax.html)

# Personal income tax

## Switching some benefit recipients from paper to online mail

Starting July 3, 2025, some benefit recipients will now receive their CRA mail online. If you are registered for a CRA account and currently receive paper mail, you may now receive most of your mail in My Account. For more information, go to: [Change from paper to online mail for some benefit recipients](/en/revenue-agency/campaigns/changes-from-paper-to-online-mail-for-some-benefit-recipients.html).

Who should file a tax return, how to get ready and file taxes, payment and filing due dates, reporting income and claiming deductions, and how to make payments or check the status of your refund.

## Most requested

* [File a return with tax software](/en/services/taxes/income-tax/personal-income-tax/how-file/tax-software.html)
* [File a paper return](/en/revenue-agency/services/forms-publications/tax-packages-years/general-income-tax-benefit-package.html)
* [Tax slips](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/tax-slips.html)
* [Forms and publications](/en/revenue-agency/services/forms-publications.html)
* [Make a payment](/en/revenue-agency/services/payments/payments-cra/individual-payments/make-payment.html)
* [Tax refund](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/refunds.html)
* [Change your address](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/change-your-address.html)
* [Direct deposit](/en/revenue-agency/services/about-canada-revenue-agency-cra/direct-deposit/individuals.html)

### [Who should file](/en/services/taxes/income-tax/personal-income-tax/who-should-file-tax.html)

Determine if you need to file a tax return, what are your tax obligations

### [Get ready to file](/en/services/taxes/income-tax/personal-income-tax/get-ready-taxes.html)

What's new for 2024, get tax slips, NETFILE access code, update your information

### [How to file](/en/services/taxes/income-tax/personal-income-tax/how-file.html)

File using tax software or by paper, get help from a tax specialist or service

### [Paying your taxes](/en/revenue-agency/services/payments/payments-cra.html)

Find options to pay a debt now or over time, pay 2025 taxes by instalments

### [After you file](/en/services/taxes/income-tax/personal-income-tax/after-you-file.html)

Get your notice of assessment (NOA), refund, proof of income, pay a balance owing, change a return

### [Help others with their taxes](/en/services/taxes/income-tax/personal-income-tax/help-others.html)

Authorized representatives, free tax clinics, filing for someone who died

## Understand how taxes work

### [Due dates and payment dates](/en/revenue-agency/services/tax/individuals/topics/important-dates-individuals.html)

Filing and payment due dates for taxes, contributions, instalments or other amounts

### [Types of income to report](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/personal-income/reporting-income.html)

What you need to report as income, how to enter amounts on your tax return

### [Deductions, credits, and expenses to claim](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses.html)

Deductions, credits, and expenses to reduce the amount of tax you have to pay

### [Tax rates and income brackets](/en/revenue-agency/services/tax/individuals/frequently-asked-questions-individuals/canadian-income-tax-rates-individuals-current-previous-years.html)

Find federal, provincial and territorial tax rates, understand income tax brackets

### [Interest and penalties](/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/interest-penalties.html)

When and how interest charges and penalties are applied, late-filing, other penalties

### [Learn about your taxes](/en/revenue-agency/services/tax/individuals/educational-programs.html)

Learn about our tax system, how it works, why we pay taxes

## Focus on

* [Persons with disabilities and their caregivers](/en/revenue-agency/services/tax/individuals/segments/tax-credits-deductions-persons-disabilities.html)
* [Adults 65 years and older](/en/revenue-agency/services/tax/individuals/segments/changes-your-taxes-when-you-retire-turn-65-years-old.html)
* [Newcomers to Canada](/en/revenue-agency/services/tax/international-non-residents/individuals-leaving-entering-canada-non-residents/newcomers-canada-immigrants.html)
* [Students](/en/revenue-agency/services/tax/individuals/segments/students.html)

## Features

[![](/content/dam/cra-arc/camp-promo/features/ft-20250516-360x203.jpg)

Dedicated Telephone Service

Income tax service providers – register for our free telephone service for help with your interpretive income tax questions.](/en/revenue-agency/campaigns/dedicated-telephone-service.html)

[![](/content/dam/cra-arc/camp-promo/features/ft-230126-360x203-3.jpg)

After filing a tax return

Information you may need after you file your tax return.](/en/services/taxes/income-tax/personal-income-tax/after-you-file.html)

[![](/content/dam/cra-arc/camp-promo/features/t1-ft-360x203-2021-12-20-20.jpg)

Request a change to your tax return online

For faster service, submit your change request online.](/en/services/taxes/income-tax/personal-income-tax/after-you-file/change-return.html)

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-07-09

## About this site

### Canada Revenue Agency (CRA)

* [Contact the CRA](https://www.canada.ca/en/revenue-agency/corporate/contact-information.html)
* [Update your information](https://www.canada.ca/en/revenue-agency/services/update-information-cra.html)
* [About the CRA](https://www.canada.ca/en/revenue-agency/corporate/about-canada-revenue-agency-cra.html)

### Government of Canada

* [All Contacts](https://www.canada.ca/en/contact.html)
* [Departments and agencies](https://www.canada.ca/en/government/dept.html)
* [About government](https://www.canada.ca/en/government/system.html)

#### Themes and topics

* [Jobs](https://www.canada.ca/en/services/jobs.html)
* [Immigration and citizenship](https://www.canada.ca/en/services/immigration-citizenship.html)
* [Travel and tourism](https://travel.gc.ca/)
* [Business](https://www.canada.ca/en/services/business.html)
* [Benefits](https://www.canada.ca/en/services/benefits.html)
* [Health](https://www.canada.ca/en/services/health.html)
* [Taxes](https://www.canada.ca/en/services/taxes.html)
* [Environment and natural resources](https://www.canada.ca/en/services/environment.html)
* [National security and defence](https://www.canada.ca/en/services/defence.html)
* [Culture, history and sport](https://www.canada.ca/en/services/culture.html)
* [Policing, justice and emergencies](https://www.canada.ca/en/services/policing.html)
* [Transport and infrastructure](https://www.canada.ca/en/services/transport.html)
* [Canada and the world](https://international.gc.ca/world-monde/index.aspx?lang=eng)
* [Money and finance](https://www.canada.ca/en/services/finance.html)
* [Science and innovation](https://www.canada.ca/en/services/science.html)
* [Indigenous peoples](https://www.canada.ca/en/services/indigenous-peoples.html)
* [Veterans and military](https://www.canada.ca/en/services/veterans.html)
* [Youth](https://www.canada.ca/en/services/youth.html)

### Government of Canada Corporate

* [Social media](https://www.canada.ca/en/social.html)
* [Mobile applications](https://www.canada.ca/en/mobile.html)
* [About Canada.ca](https://www.canada.ca/en/government/about.html)
* [Terms and conditions](https://www.canada.ca/en/transparency/terms.html)
* [Privacy](https://www.canada.ca/en/transparency/privacy.html)

![Symbol of the Government of Canada](https://wet-boew.github.io/themes-dist/GCWeb/GCWeb/assets/wmms-blk.svg)
