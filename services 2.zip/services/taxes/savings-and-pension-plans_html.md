# Savings and pension plans

Registered plans information for individuals (contributors) and plan administrators.

![](/content/dam/themes/taxes/features/savings-and-pension-plans/cra-rfi-251.jpg)

## Services and information

### [Registered retirement savings plan](/en/revenue-agency/services/tax/individuals/topics/rrsps-related-plans.html)

Set up a registered retirement savings plan, and make a contribution.

### [Tax-free savings accounts](/en/revenue-agency/services/tax/individuals/topics/tax-free-savings-account.html)

How to open a tax free savings account, information about annual contribution limits, and withdrawals.

### [Registered education savings plan](/en/revenue-agency/services/tax/individuals/topics/registered-education-savings-plans-resps.html)

Learn how registered education savings plans work, who can apply and receive payments, and the rules on contributions.

### [Registered disability savings plan](/en/revenue-agency/services/tax/individuals/topics/registered-disability-savings-plan-rdsp.html)

Learn how registered disability savings plans work, who can apply and receive payments, and the rules on contributions.

### [Pooled registered pension plan](/en/revenue-agency/services/tax/individuals/topics/pooled-registered-pension-plan-prpp-information-individuals.html)

Join a pooled registered pension plan, and get information about contributions, transfers, and withdrawals.

### [Savings and pension plan administration](/en/services/taxes/savings-and-pension-plans/savings-and-pension-plan-administration.html)

Annual limits, administrative procedures for registered plans, and links to bulletins, newsletters, and manuals.

### [First home savings account](/en/revenue-agency/services/tax/individuals/topics/first-home-savings-account.html) New

Who can open a first home savings account, annual and lifetime limits, and the rules on contributions, transfers, and withdrawals.

## From:

* [Canada Revenue Agency](/en/revenue-agency.html)

## Page details

Date modified:
:   2025-01-31
