select
    order_date,
    store_id,
    count(distinct order_id)        as order_count,
    sum(quantity)                   as units_sold,
    round(sum(revenue), 2)          as revenue,
    round(sum(gross_margin), 2)     as gross_margin
from {{ ref('fct_order_items') }}
group by 1, 2
