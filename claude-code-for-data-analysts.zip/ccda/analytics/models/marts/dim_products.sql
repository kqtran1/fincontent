select
    product_id,
    product_name,
    category,
    unit_price,
    unit_cost,
    round(unit_price - unit_cost, 2)                              as unit_margin,
    round((unit_price - unit_cost) / nullif(unit_price, 0), 4)    as margin_pct
from {{ ref('stg_products') }}
