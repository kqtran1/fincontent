with items as (
    select * from {{ ref('stg_order_items') }}
),
orders as (
    select * from {{ ref('stg_orders') }}
),
products as (
    select * from {{ ref('stg_products') }}
)
select
    i.order_item_id,
    i.order_id,
    o.order_date,
    o.ordered_at,
    o.store_id,
    o.customer_id,
    o.channel,
    i.product_id,
    p.category                                   as product_category,
    i.quantity,
    i.line_total                                 as revenue,
    round(p.unit_cost * i.quantity, 2)           as cost,
    round(i.line_total - p.unit_cost * i.quantity, 2) as gross_margin
from items i
left join orders   o on i.order_id   = o.order_id
left join products p on i.product_id = p.product_id
