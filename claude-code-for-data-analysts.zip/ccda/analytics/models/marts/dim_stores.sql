select
    store_id,
    store_name,
    city,
    state,
    store_type,
    open_date
from {{ ref('stg_stores') }}
