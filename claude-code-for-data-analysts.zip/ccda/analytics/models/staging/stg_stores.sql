with source as (
    select * from {{ source('raw', 'stores') }}
)
select
    cast(store_id as integer)      as store_id,
    trim(store_name)               as store_name,
    trim(city)                     as city,
    upper(trim(state))             as state,
    cast(open_date as date)        as open_date,
    lower(trim(store_type))        as store_type
from source
