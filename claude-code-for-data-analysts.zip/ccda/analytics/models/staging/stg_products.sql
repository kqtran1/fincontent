with source as (
    select * from {{ source('raw', 'products') }}
)
select
    cast(product_id as integer)        as product_id,
    trim(product_name)                 as product_name,
    trim(category)                     as category,
    cast(unit_price as decimal(10,2))  as unit_price,
    cast(unit_cost  as decimal(10,2))  as unit_cost
from source
