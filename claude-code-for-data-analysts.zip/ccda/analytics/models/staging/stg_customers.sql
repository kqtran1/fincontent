with source as (
    select * from {{ source('raw', 'customers') }}
)
select
    cast(customer_id as integer)   as customer_id,
    trim(first_name)               as first_name,
    trim(last_name)                as last_name,
    lower(trim(email))             as email,
    lower(trim(loyalty_tier))      as loyalty_tier,
    cast(signup_date as date)      as signup_date
from source
