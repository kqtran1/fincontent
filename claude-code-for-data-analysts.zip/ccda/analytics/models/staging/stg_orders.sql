with source as (
    select * from {{ source('raw', 'orders') }}
)
select
    cast(order_id as integer)                 as order_id,
    cast(order_ts as timestamp)               as ordered_at,
    cast(order_ts as date)                    as order_date,
    cast(store_id as integer)                 as store_id,
    -- empty string means a non-loyalty (guest) order
    nullif(trim(cast(customer_id as varchar)), '')::integer as customer_id,
    lower(trim(channel))                      as channel,
    lower(trim(payment_method))               as payment_method,
    cast(order_total as decimal(10,2))        as order_total
from source
