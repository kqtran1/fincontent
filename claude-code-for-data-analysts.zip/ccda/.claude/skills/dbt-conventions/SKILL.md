---
name: dbt-conventions
description: "Northwind analytics dbt conventions. Use whenever creating or editing dbt models, sources, tests, or YAML in the analytics/ project, so models follow the team's layering, naming, materialization and testing standards."
---

# Northwind dbt conventions

Apply these whenever you touch the `analytics/` dbt project.

## Layering
- **staging** (`stg_<source>`): 1:1 with a source table. Clean, cast, rename only.
  No joins, no aggregation, no business logic. Materialize as **view**.
- **marts** (`dim_*`, `fct_*`): business entities and facts. Joins and metrics live
  here. Materialize as **table**. Build from `ref()` of staging/marts only.

## Naming & style
- snake_case everywhere; lowercase SQL keywords.
- Use CTEs (named `with source as (...)`), not nested subqueries.
- Final SELECT: one column per line, aligned aliases.
- Never hard-code a table name — always `{{ ref() }}` or `{{ source() }}`.

## Testing & docs
- Every mart's key column gets `unique` + `not_null`.
- Add `relationships` tests on foreign keys and `accepted_values` on low-cardinality
  enums.
- Put tests and descriptions in a `_<folder>.yml` file next to the models.

## Before finishing
Run `cd analytics && dbt build --profiles-dir . --select <model>` and confirm it passes.
