---
description: Scaffold a new dbt model following this project's conventions
---
Create a new dbt model named `$1` in the `analytics/models/` tree.

Rules:
- If the name starts with `stg_`, put it in `models/staging/`, materialize as a view,
  and only clean/cast/rename from the matching `{{ source(...) }}` — no joins.
- If it starts with `dim_` or `fct_`, put it in `models/marts/`, materialize as a table,
  and build it from `{{ ref(...) }}` of staging or other marts.
- Follow the SQL style in CLAUDE.md (lowercase keywords, CTEs, one column per line).
- Add a description and at least one test for the model's key column in the relevant
  `_*.yml` file.
- After creating it, run `cd analytics && dbt build --profiles-dir . --select $1` and
  report the result.

The user's description of what the model should contain: $ARGUMENTS
