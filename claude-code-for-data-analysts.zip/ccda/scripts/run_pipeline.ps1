# run_pipeline.ps1 — run the whole Northwind pipeline end to end on Windows.
# Usage (from the repo root, in PowerShell):
#     ./scripts/run_pipeline.ps1
# If your execution policy blocks it:
#     powershell -ExecutionPolicy Bypass -File scripts/run_pipeline.ps1
# Force a specific interpreter (single command token):
#     $env:PYTHON = "py"; ./scripts/run_pipeline.ps1
#
# Steps: generate data -> dbt deps -> dbt build -> PySpark clean -> export for Power BI.

$ErrorActionPreference = "Stop"

# repo root = parent of this script's folder
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# On Windows the interpreter is normally `python` (there is no `python3`).
$py = if ($env:PYTHON) { $env:PYTHON } else { "python" }

# verify it actually runs
try { & $py -c "import sys" | Out-Null }
catch {
    Write-Error "Could not run '$py'. Install Python 3.9+ (and tick 'Add to PATH'), or set `$env:PYTHON."
    exit 1
}
Write-Host "Using interpreter: $py ($(& $py --version))"

function Invoke-Step([string]$label, [scriptblock]$action) {
    Write-Host "==> $label"
    & $action
    if ($LASTEXITCODE -ne 0) { throw "Step failed: $label (exit $LASTEXITCODE)" }
}

Invoke-Step "1/5  Generating sample data"                 { & $py scripts/generate_data.py }
Invoke-Step "2/5  Installing dbt packages"                { Push-Location analytics; dbt deps; Pop-Location }
Invoke-Step "3/5  Building the dbt warehouse (DuckDB)"    { Push-Location analytics; dbt build --profiles-dir .; Pop-Location }
Invoke-Step "4/5  Cleaning the messy POS export (Spark)"  { & $py scripts/clean_pos_data.py }
Invoke-Step "5/5  Exporting marts for Power BI"           { & $py scripts/export_for_powerbi.py }

Write-Host ""
Write-Host "All done. The warehouse is in warehouse.duckdb, cleaned data in data/clean/,"
Write-Host "and Power BI CSVs in data/exports/. You're ready for the lessons in course/."
