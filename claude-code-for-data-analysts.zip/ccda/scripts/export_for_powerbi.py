"""
export_for_powerbi.py — read the dbt marts out of the local DuckDB warehouse
and write them as CSVs that Power BI (or any BI tool) can import.

Power BI Desktop is Windows-only and GUI-driven, but the *model* behind a .pbix
lives in text files (PBIP/TMDL, DAX, Power Query M) that Claude Code can edit.
This script just gives Power Query something to point at.

Run after `dbt build`:  python scripts/export_for_powerbi.py
"""
import os, duckdb

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "..", "warehouse.duckdb")
OUT = os.path.join(HERE, "..", "data", "exports")
os.makedirs(OUT, exist_ok=True)

con = duckdb.connect(DB, read_only=True)
for tbl in ["fct_daily_sales", "fct_order_items", "dim_stores", "dim_products", "dim_customers"]:
    con.execute(f"COPY {tbl} TO '{os.path.join(OUT, tbl + '.csv')}' (HEADER, DELIMITER ',')")
    n = con.execute(f"SELECT count(*) FROM {tbl}").fetchone()[0]
    print(f"  exported {tbl:18} {n:>7,} rows")
con.close()
print("\nCSVs written to data/exports/ — point Power Query at this folder.")
