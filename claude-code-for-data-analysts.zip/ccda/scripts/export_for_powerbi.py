"""
export_for_powerbi.py — read the dbt marts out of the local DuckDB warehouse
and write them as CSVs that Power BI (or any BI tool) can import.

Power BI Desktop is Windows-only and GUI-driven, but the *model* behind a .pbix
lives in text files (PBIP/TMDL, DAX, Power Query M) that Claude Code can edit.
This script just gives Power Query something to point at.

Run after `dbt build`:  python scripts/export_for_powerbi.py
"""
import os
import duckdb

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "..", "warehouse.duckdb")
OUT = os.path.join(HERE, "..", "data", "exports")
os.makedirs(OUT, exist_ok=True)

# Core marts that ship in the base project — always present after `dbt build`.
CORE = ["fct_daily_sales", "fct_order_items", "dim_stores", "dim_products", "dim_customers"]

# Lesson 4 deliverables. These only exist once you've built them (see Lesson 4 /
# solutions/dbt). dim_date is required by the time-intelligence DAX measures in
# Lesson 5 (Revenue PY/YoY %/MTD/7-Day Avg), so we export it automatically once it's there.
LESSON4 = ["dim_date", "fct_customer_monthly"]

con = duckdb.connect(DB, read_only=True)
existing = {r[0] for r in con.execute(
    "select table_name from information_schema.tables where table_schema = 'main'"
).fetchall()}


def export(tbl):
    con.execute(f"COPY {tbl} TO '{os.path.join(OUT, tbl + '.csv')}' (HEADER, DELIMITER ',')")
    n = con.execute(f"SELECT count(*) FROM {tbl}").fetchone()[0]
    print(f"  exported {tbl:20} {n:>7,} rows")


for tbl in CORE:
    export(tbl)

for tbl in LESSON4:
    if tbl in existing:
        export(tbl)

con.close()

missing = [t for t in LESSON4 if t not in existing]
print("\nCSVs written to data/exports/ — point Power Query at this folder.")
if "dim_date" in missing:
    print(
        "\nNote: dim_date was not found, so it wasn't exported. You build dim_date in "
        "Lesson 4 (analytics/models/marts/, see solutions/dbt). Power BI's "
        "time-intelligence measures (Revenue PY, YoY %, MTD, 7-Day Avg) need it — "
        "complete Lesson 4, run `dbt build`, then re-run this script."
    )
