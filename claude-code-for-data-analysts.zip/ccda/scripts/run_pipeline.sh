#!/usr/bin/env bash
# run_pipeline.sh — run the whole Northwind pipeline end to end and verify it works.
# Usage:  bash scripts/run_pipeline.sh        (macOS / Linux / WSL / Git Bash)
#         PYTHON=python bash scripts/run_pipeline.sh   # force a specific interpreter
#
# Windows (PowerShell) users: run scripts/run_pipeline.ps1 instead.
#
# Steps: generate data -> dbt deps -> dbt build -> PySpark clean -> export for Power BI.
set -euo pipefail

# repo root = parent of this script's dir
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# Pick a working Python. Prefer $PYTHON, then python3, then python — but only accept
# an interpreter that actually RUNS. (On Windows, `python3` is often the Microsoft
# Store stub, which is on PATH but fails when invoked; the exec test skips it.)
pick_python() {
  if [ -n "${PYTHON:-}" ]; then echo "$PYTHON"; return; fi
  for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c "import sys" >/dev/null 2>&1; then
      echo "$c"; return
    fi
  done
  echo "" # none found
}
PY="$(pick_python)"
if [ -z "$PY" ]; then
  echo "ERROR: no working Python found. Install Python 3.9+ and re-run," >&2
  echo "       or set PYTHON, e.g.  PYTHON=python bash scripts/run_pipeline.sh" >&2
  exit 1
fi
echo "Using interpreter: $PY ($("$PY" --version 2>&1))"

echo "==> 1/5  Generating sample data"
"$PY" scripts/generate_data.py

echo "==> 2/5  Installing dbt packages"
( cd analytics && dbt deps )

echo "==> 3/5  Building the dbt warehouse (DuckDB)"
( cd analytics && dbt build --profiles-dir . )

echo "==> 4/5  Cleaning the messy POS export with PySpark"
"$PY" scripts/clean_pos_data.py

echo "==> 5/5  Exporting marts for Power BI"
"$PY" scripts/export_for_powerbi.py

echo ""
echo "All done. The warehouse is in warehouse.duckdb, cleaned data in data/clean/,"
echo "and Power BI CSVs in data/exports/. You're ready for the lessons in course/."
