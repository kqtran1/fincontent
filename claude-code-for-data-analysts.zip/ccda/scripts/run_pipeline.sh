#!/usr/bin/env bash
# run_pipeline.sh — run the whole Northwind pipeline end to end and verify it works.
# Usage:  bash scripts/run_pipeline.sh
#
# Steps: generate data -> dbt deps -> dbt build -> PySpark clean -> export for Power BI.
# Use this as a smoke test that your environment is set up correctly.
set -euo pipefail

# repo root = parent of this script's dir
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PY="${PYTHON:-python3}"   # override with PYTHON=python if you prefer

echo "==> 1/5  Generating sample data"
"$PY" scripts/generate_data.py

echo "==> 2/5  Installing dbt packages"
( cd analytics && dbt deps )

echo "==> 3/5  Building the dbt warehouse (DuckDB)"
( cd analytics && dbt build --profiles-dir . )

echo "==> 4/5  Cleaning the messy POS export with PySpark"
"$PY" scripts/clean_pos_data.py

echo "==> 5/5  Exporting marts for Power BI"
"$PY" scripts/export_for_powerbi.py

echo ""
echo "All done. The warehouse is in warehouse.duckdb, cleaned data in data/clean/,"
echo "and Power BI CSVs in data/exports/. You're ready for the lessons in course/."
