"""
generate_data.py — builds the sample dataset for the
"Claude Code for Data Analysts" course.

Scenario: Northwind Coffee Co., a regional coffee-shop chain.

Produces, under data/raw/:
  stores.csv          clean reference data (12 stores)
  products.csv        clean reference data (~30 products)
  customers.csv       clean reference data (~2,000 loyalty members)
  orders.csv          clean warehouse landing table (~22k orders)
  order_items.csv     clean warehouse landing table (~55k line items)
  pos_export_messy.csv a deliberately messy POS export for the PySpark lesson

Everything is seeded so the data is identical on every machine.
Run:  python scripts/generate_data.py
"""

import csv
import os
import random
from datetime import datetime, timedelta

random.seed(42)

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "data", "raw")
os.makedirs(RAW, exist_ok=True)


def write_csv(name, header, rows):
    path = os.path.join(RAW, name)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"  wrote {name:24} {len(rows):>7,} rows")


# ---------------------------------------------------------------- stores
CITIES = [
    ("Seattle", "WA"), ("Portland", "OR"), ("San Francisco", "CA"),
    ("Austin", "TX"), ("Denver", "CO"), ("Chicago", "IL"),
    ("Boston", "MA"), ("New York", "NY"), ("Atlanta", "GA"),
    ("Nashville", "TN"), ("Minneapolis", "MN"), ("Phoenix", "AZ"),
]
stores = []
for i, (city, state) in enumerate(CITIES, start=1):
    open_date = datetime(2019, 1, 1) + timedelta(days=random.randint(0, 1500))
    stores.append([
        i, f"{city} {random.choice(['Downtown','Uptown','Riverside','Market','Central'])}",
        city, state, open_date.strftime("%Y-%m-%d"),
        random.choice(["flagship", "standard", "kiosk"]),
    ])
write_csv("stores.csv",
          ["store_id", "store_name", "city", "state", "open_date", "store_type"],
          stores)

# ---------------------------------------------------------------- products
PRODUCTS = [
    # name, category, price, cost
    ("Espresso", "Coffee", 2.75, 0.55), ("Americano", "Coffee", 3.25, 0.60),
    ("Latte", "Coffee", 4.50, 0.95), ("Cappuccino", "Coffee", 4.25, 0.90),
    ("Flat White", "Coffee", 4.75, 1.00), ("Cold Brew", "Coffee", 4.95, 0.85),
    ("Mocha", "Coffee", 5.25, 1.20), ("Macchiato", "Coffee", 4.00, 0.85),
    ("Drip Coffee", "Coffee", 2.50, 0.40), ("Nitro Cold Brew", "Coffee", 5.50, 1.10),
    ("Green Tea", "Tea", 3.25, 0.45), ("Chai Latte", "Tea", 4.75, 0.95),
    ("Earl Grey", "Tea", 3.25, 0.45), ("Matcha Latte", "Tea", 5.25, 1.30),
    ("Herbal Tea", "Tea", 3.00, 0.40),
    ("Croissant", "Food", 3.75, 1.10), ("Blueberry Muffin", "Food", 3.50, 0.95),
    ("Avocado Toast", "Food", 8.50, 3.20), ("Bagel & Cream Cheese", "Food", 4.25, 1.30),
    ("Chocolate Chip Cookie", "Food", 2.95, 0.70), ("Banana Bread", "Food", 3.95, 1.05),
    ("Breakfast Sandwich", "Food", 6.50, 2.40), ("Granola Bowl", "Food", 7.25, 2.60),
    ("Bottled Water", "Retail", 2.25, 0.50), ("Sparkling Water", "Retail", 3.00, 0.75),
    ("Coffee Beans 12oz", "Retail", 16.00, 6.50), ("Travel Mug", "Retail", 24.00, 9.00),
    ("Gift Card", "Retail", 25.00, 0.00), ("Reusable Cup", "Retail", 12.00, 4.50),
    ("Bottled Juice", "Retail", 4.50, 1.40),
]
products = []
for i, (name, cat, price, cost) in enumerate(PRODUCTS, start=1):
    products.append([i, name, cat, f"{price:.2f}", f"{cost:.2f}"])
write_csv("products.csv",
          ["product_id", "product_name", "category", "unit_price", "unit_cost"],
          products)

# ---------------------------------------------------------------- customers
FIRST = ["Alex", "Sam", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Jamie",
         "Avery", "Quinn", "Drew", "Sky", "Devin", "Reese", "Parker", "Rowan",
         "Maria", "Liam", "Noah", "Olivia", "Emma", "Ethan", "Sofia", "Mateo"]
LAST = ["Smith", "Johnson", "Lee", "Garcia", "Brown", "Martinez", "Davis", "Lopez",
        "Wilson", "Anderson", "Thomas", "Nguyen", "Patel", "Kim", "Chen", "Khan",
        "Rossi", "Schmidt", "Dubois", "Silva"]
TIERS = ["bronze", "bronze", "bronze", "silver", "silver", "gold"]
customers = []
N_CUST = 2000
for i in range(1, N_CUST + 1):
    signup = datetime(2021, 1, 1) + timedelta(days=random.randint(0, 1400))
    fn, ln = random.choice(FIRST), random.choice(LAST)
    customers.append([
        i, fn, ln,
        f"{fn.lower()}.{ln.lower()}{random.randint(1,999)}@example.com",
        random.choice(TIERS), signup.strftime("%Y-%m-%d"),
    ])
write_csv("customers.csv",
          ["customer_id", "first_name", "last_name", "email", "loyalty_tier", "signup_date"],
          customers)

# ---------------------------------------------------------------- orders + items
PAYMENT = ["card", "card", "card", "cash", "mobile", "mobile"]
CHANNEL = ["in_store", "in_store", "in_store", "mobile_app", "drive_thru"]
price_by_id = {p[0]: float(p[3]) for p in products}

orders = []
order_items = []
order_id = 0
item_id = 0
start = datetime(2024, 1, 1)
days = 545  # ~18 months

for day in range(days):
    date = start + timedelta(days=day)
    # weekend + seasonal-ish volume wobble
    base = 40 if date.weekday() < 5 else 55
    daily = int(base * random.uniform(0.7, 1.3))
    for _ in range(daily):
        order_id += 1
        store = random.randint(1, len(stores))
        # ~65% of orders tied to a loyalty member
        cust = random.randint(1, N_CUST) if random.random() < 0.65 else ""
        hour = random.choices(range(6, 21),
                              weights=[2,6,9,8,5,4,4,4,3,3,4,3,2,2,1])[0]
        ts = date + timedelta(hours=hour, minutes=random.randint(0, 59))
        n_items = random.choices([1, 2, 3, 4], weights=[45, 35, 15, 5])[0]
        order_total = 0.0
        for _ in range(n_items):
            item_id += 1
            pid = random.randint(1, len(products))
            qty = random.choices([1, 2, 3], weights=[80, 16, 4])[0]
            unit = price_by_id[pid]
            line = round(unit * qty, 2)
            order_total += line
            order_items.append([item_id, order_id, pid, qty,
                                f"{unit:.2f}", f"{line:.2f}"])
        orders.append([
            order_id, ts.strftime("%Y-%m-%d %H:%M:%S"), store, cust,
            random.choice(CHANNEL), random.choice(PAYMENT),
            f"{order_total:.2f}",
        ])

write_csv("orders.csv",
          ["order_id", "order_ts", "store_id", "customer_id",
           "channel", "payment_method", "order_total"],
          orders)
write_csv("order_items.csv",
          ["order_item_id", "order_id", "product_id", "quantity",
           "unit_price", "line_total"],
          order_items)

# ---------------------------------------------------------------- messy POS export
# A separate, intentionally dirty extract from the legacy POS, used in the
# PySpark data-prep lesson. Same shape as orders but full of real-world mess.
messy_header = ["txn_id", "txn_date", "store", "amount", "pay_type", "notes"]
messy_rows = []
date_formats = ["%Y-%m-%d", "%m/%d/%Y", "%d-%b-%Y", "%Y/%m/%d"]
store_aliases = {  # the legacy POS uses inconsistent store labels
    1: ["Seattle", "seattle ", "SEATTLE", "Seattle Downtown"],
    2: ["Portland", "PDX", "portland"],
    3: ["SF", "San Francisco", "san francisco"],
}
sample_orders = random.sample(orders, 6000)
for o in sample_orders:
    oid, ts, store, *_rest, total = o
    d = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
    fmt = random.choice(date_formats)
    date_str = d.strftime(fmt)
    # messy store label
    if store in store_aliases:
        store_label = random.choice(store_aliases[store])
    else:
        store_label = f"store_{store}"
    # messy amount: currency symbols, stray spaces, occasional blanks
    amt = total
    r = random.random()
    if r < 0.15:
        amt = f"${total}"
    elif r < 0.25:
        amt = f" {total} "
    elif r < 0.30:
        amt = ""  # missing
    pay = random.choice(["Card", "card", "CARD", "Cash", "cash", "Mobile", "mobile", ""])
    note = random.choice(["", "", "", "refund processed", "comp - manager", "loyalty x2"])
    messy_rows.append([oid, date_str, store_label, amt, pay, note])

# inject a block of exact duplicate rows
messy_rows.extend(messy_rows[:200])
# a few completely empty / partial rows
for _ in range(40):
    messy_rows.append([random.choice([o[0] for o in sample_orders]), "", "", "", "", ""])
random.shuffle(messy_rows)
write_csv("pos_export_messy.csv", messy_header, messy_rows)

print("\nDone. Sample data is in data/raw/")
