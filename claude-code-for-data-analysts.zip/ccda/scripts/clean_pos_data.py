"""
clean_pos_data.py — the script form of Lesson 3's PySpark cleaning.

Same logic as notebooks/03_data_prep.ipynb, packaged as a plain Python script you
run with your interpreter:

    python scripts/clean_pos_data.py

Reads  data/raw/pos_export_messy.csv
Writes data/clean/pos_transactions  (Parquet)
"""
import os
import sys

# Force Spark's driver AND workers to use THIS Python interpreter. Without this,
# Spark may pick a different 'python3' and fail with a driver/worker version
# mismatch. Setting it before importing pyspark is the reliable fix.
os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, "..", "data", "raw", "pos_export_messy.csv")
OUT = os.path.join(HERE, "..", "data", "clean", "pos_transactions")


def main() -> None:
    spark = (
        SparkSession.builder.appName("pos_clean")
        .master("local[*]")
        .config("spark.sql.shuffle.partitions", "4")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    print(f"Spark {spark.version} | Python {sys.version.split()[0]}")

    raw = spark.read.csv(RAW, header=True, inferSchema=False)
    print("raw rows:", raw.count())

    # trim every string column
    df = raw.select([F.trim(F.col(c)).alias(c) for c in raw.columns])

    # amount: keep digits and dots -> double; blanks -> null
    df = df.withColumn(
        "amount_clean", F.regexp_replace(F.col("amount"), r"[^0-9.]", "").cast("double")
    )

    # pay_type: lower-case; blanks -> null
    df = df.withColumn(
        "pay_type_clean",
        F.when(F.col("pay_type") == "", None).otherwise(F.lower(F.col("pay_type"))),
    )

    # store: normalize inconsistent labels -> store_id
    norm = F.lower(F.regexp_replace(F.col("store"), r"\s+", ""))
    df = df.withColumn(
        "store_id",
        F.when(norm.startswith("store_"),
               F.regexp_extract(F.col("store"), r"store_(\d+)", 1).cast("int"))
        .when(norm.rlike("seattle"), F.lit(1))
        .when(norm.isin("portland", "pdx"), F.lit(2))
        .when(norm.isin("sf", "sanfrancisco"), F.lit(3))
        .otherwise(F.lit(None)),
    )

    # txn_date: four possible formats; try_to_date is ANSI-safe (null, not error)
    fmts = ["yyyy-MM-dd", "MM/dd/yyyy", "dd-MMM-yyyy", "yyyy/MM/dd"]
    df = df.withColumn(
        "txn_date_clean", F.coalesce(*[F.try_to_date(F.col("txn_date"), f) for f in fmts])
    )

    clean = (
        df.dropDuplicates()
        .filter(F.col("txn_id").isNotNull() & (F.col("txn_id") != ""))
        .filter(F.col("amount_clean").isNotNull())
        .filter(F.col("txn_date_clean").isNotNull())
        .filter(F.col("store_id").isNotNull())
        .select(
            F.col("txn_id").cast("int").alias("txn_id"),
            F.col("txn_date_clean").alias("txn_date"),
            "store_id",
            F.col("amount_clean").alias("amount"),
            F.col("pay_type_clean").alias("payment_method"),
            "notes",
        )
    )

    n = clean.count()
    stores = sorted(r[0] for r in clean.select("store_id").distinct().collect())
    assert clean.filter(F.col("amount").isNull()).count() == 0
    assert clean.filter(F.col("txn_date").isNull()).count() == 0
    print(f"clean rows: {n} | distinct store_ids: {stores}")

    clean.write.mode("overwrite").parquet(OUT)
    print(f"written to data/clean/pos_transactions")
    spark.stop()


if __name__ == "__main__":
    main()
