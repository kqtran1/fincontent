"""
query.py — run SQL against the local DuckDB warehouse WITHOUT installing the
standalone DuckDB CLI. Uses the `duckdb` Python package (already in requirements.txt).

Usage:
    python scripts/query.py "select * from dim_stores limit 5"
    python scripts/query.py path/to/query.sql
    echo "select count(*) from fct_order_items" | python scripts/query.py

(Prefer the real DuckDB CLI? It's a separate download from https://duckdb.org/docs/installation/ ,
then: duckdb warehouse.duckdb)
"""
import os
import sys
import duckdb

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "..", "warehouse.duckdb")


def main() -> None:
    if not os.path.exists(DB):
        sys.exit("warehouse.duckdb not found. Build it first:\n"
                 "  cd analytics && dbt build --profiles-dir .")

    arg = " ".join(sys.argv[1:]).strip()
    if arg and os.path.isfile(arg):
        sql = open(arg).read()
    elif arg:
        sql = arg
    else:
        sql = sys.stdin.read()

    if not sql.strip():
        sys.exit('Provide SQL as an argument, a .sql file path, or via stdin, e.g.\n'
                 '  python scripts/query.py "select * from dim_products limit 5"')

    con = duckdb.connect(DB, read_only=True)
    con.sql(sql).show()   # pretty-prints the result table
    con.close()


if __name__ == "__main__":
    main()
