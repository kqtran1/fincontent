// Power Query (M) — loads the dbt daily-sales mart for Power BI.
// In Power BI Desktop: Home > Transform data > New Source > Blank Query,
// then Advanced Editor, and paste this. Adjust the path to your repo.
//
// Claude Code can write and refactor these M scripts for you. Try:
//   "write a Power Query M script that loads data/exports/fct_daily_sales.csv,
//    types the columns, and parses order_date as a date"
let
    Source = Csv.Document(
        File.Contents("C:\path\to\ccda\data\exports\fct_daily_sales.csv"),
        [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]
    ),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed = Table.TransformColumnTypes(Promoted, {
        {"order_date", type date},
        {"store_id", Int64.Type},
        {"order_count", Int64.Type},
        {"units_sold", Int64.Type},
        {"revenue", type number},
        {"gross_margin", type number}
    })
in
    Typed
