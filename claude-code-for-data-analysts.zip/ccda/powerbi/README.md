# Power BI layer

Power BI Desktop is a Windows-only, GUI tool — so how does a terminal agent like
Claude Code help? Because **everything that defines a Power BI model is text**:

| Artifact | What it is | Claude Code can… |
|---|---|---|
| `.pbip` / **TMDL** (`*.tmdl`) | The model: tables, columns, relationships | read it, add columns, fix relationships, refactor |
| **DAX** (`measures.dax`) | Measures and calculated columns | write, explain, debug, optimize measures |
| **Power Query / M** (`*.m`) | Data-loading and shaping steps | generate and refactor query steps |

Save any Power BI report as a **`.pbip` project** (File → Save as → *Power BI project*)
and the model becomes folders of TMDL you can version-control and edit with Claude Code.

## Files here
- `model/northwind.tmdl` — an illustrative semantic model (star schema) so you can see
  what TMDL looks like.
- `model/measures.dax` — a measure library with worked examples and four TODO exercises.
- `powerquery/Sales.m` — a Power Query script that loads the dbt daily-sales mart.

## Getting the data into Power BI
1. Build the warehouse: `cd analytics && dbt build --profiles-dir .`
2. Export the marts to CSV: `python scripts/export_for_powerbi.py` (writes `data/exports/`).
3. In Power BI Desktop, **Get Data → Text/CSV** (or paste `powerquery/Sales.m` into a Blank Query),
   load `fct_daily_sales`, `dim_stores`, `dim_products`, `dim_date`, build relationships,
   then add the measures from `measures.dax`.

> **`dim_date` is built in Lesson 4** (it's the date dimension exercise). The export script
> only writes it once it exists, and the time-intelligence measures (Revenue PY, YoY %, MTD,
> 7-Day Avg) depend on it — so complete Lesson 4 before the optional Power BI render here.

> No Power BI Desktop / Windows? You still do the whole lesson: have Claude Code
> author the DAX and TMDL, and reason about the model design. The thinking — grain,
> star schema, measure logic — is the transferable skill.
