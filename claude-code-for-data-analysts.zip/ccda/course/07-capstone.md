# Lesson 7 — Capstone

⏱️ ~75 min · No step-by-step prompts this time. You drive; Claude Code assists.

## The brief
The Northwind Coffee leadership team wants a clear answer to one question:

> **"Which stores and product categories should we focus on next quarter, and why?"**

You'll take it end to end — raw data to a documented metric to a written recommendation —
using everything from Lessons 0–6. The point of the capstone is to work the way you would
on the job: you decide the approach, you write the prompts, you verify the results.

## What to produce
A short analysis (a paragraph or two plus a few supporting numbers) backed by **new work
in the repo**:

1. **Clean input (PySpark).** Make sure the messy POS export is cleaned and written
   (`data/clean/`), and reconcile its row count against your expectations. Note any data
   you had to drop and why.

2. **A new modeled metric (dbt).** Add at least one new mart that the question needs —
   for example a store-level monthly growth or margin model — with **tests** and a
   **description**. It must `dbt build` green.

3. **The analysis (SQL).** Answer the brief with queries against your marts. Verify the
   numbers (sanity-check magnitudes, spot-check a row).

4. **The reporting layer (Power BI).** Add or adjust a **DAX measure** that expresses your
   key metric, and describe the one dashboard view you'd build to communicate it.

5. **The write-up.** Lead with the recommendation, give 2–3 supporting numbers, and state
   one honest caveat about the data. (If you built the `analysis-writeup` skill in Lesson
   6, let it shape this.)

## How to work it
- Start in **plan mode**: have Claude Code propose the whole approach before building, and
  critique the plan yourself.
- Commit to a branch (`capstone`) and commit after each of the five steps.
- Use the **custom command**, the **skill**, and a **subagent** at least once each — this
  is your chance to feel the workflow, not just the individual tools.
- Verify everything. The deliverable is only as good as your checking.

## What "good" looks like
- The new dbt model is in the right layer, named correctly, tested, and documented.
- The numbers in your write-up trace back to queries you can re-run and trust.
- Your recommendation is specific ("focus on X because Y"), not generic.
- You can explain every piece of code in the repo that you added — including the parts
  Claude Code wrote.

## Reference
There's no single "answer key" — the brief is open-ended on purpose. But the building
blocks are all demonstrated in [`solutions/`](../solutions/): the dbt model patterns, the
SQL style, the DAX measures, and the PySpark cleaning. Lean on them for *form*, not for the
specific conclusion.

## 🚀 Stretch goals
- Add a **hook** that runs `dbt build --select state:modified+` so a broken model is
  caught the moment you save it.
- Write a `/weekly-sales-summary` command that regenerates your headline numbers on demand.
- Sketch how you'd swap the local DuckDB for a real warehouse over **MCP**, and what would
  change about your workflow (and your safeguards).

## ✅ You're done when…
You can hand someone the branch and the write-up, and they could re-run your pipeline, see
green tests, trace your numbers, and understand your recommendation — without you in the
room.

---

### Where to go next
- Keep the habits: **plan before acting**, **verify every result**, **automate the second
  time you do anything**.
- Bring Claude Code to your real repo. Start by writing a `CLAUDE.md` and one skill that
  captures how your team actually works.
- Explore the official docs for deeper features:
  [Claude Code documentation](https://code.claude.com/docs).

Nice work. You came in new to AI tools and you've now run a full analytics workflow with
one as your collaborator — while staying firmly in control of the results.
