# Lesson 1 — Claude Code Fundamentals

⏱️ ~45 min

## What you'll learn
- How to write requests that get good results.
- **Plan mode** — review the approach before any code is written.
- How to review and approve changes safely.
- **CLAUDE.md** — giving Claude Code lasting memory of your project.
- Using git conversationally, and managing context with `/clear`.

## 1. Be specific (the single biggest lever)
Claude Code is literal. Vague in, vague out. Compare:

> ❌ "fix the data"
> ✅ "in `data/raw/pos_export_messy.csv` the `amount` column has values like `$2.95` and
> ` 12.95 `. I want a clean numeric column. Show me the approach before changing anything."

Good requests usually include **what**, **where**, and **what done looks like**. When a
task is big, break it into numbered steps — Claude Code follows them in order.

**Try it.** In a session, ask the vague version, then the specific version, of:
*"summarize sales."* Notice how much better the specific one is:
```
summarize total revenue, order count, and average order value by month,
reading from the fct_daily_sales table in warehouse.duckdb. show it as a table.
```

## 2. Plan mode: look before it leaps
For anything non-trivial, you want to see the *plan* before the *edits*. Press
**`Shift+Tab`** to cycle permission modes until you see **plan mode**. In plan mode,
Claude Code researches and proposes an approach **without touching files**. You read it,
correct it, and only then let it proceed.

**Try it.** Switch to plan mode and ask:
```
I want to add a model that shows revenue per customer per month. Plan it.
```
Read the plan. Is the grain right? Does it follow the project's layering? Push back if
not — e.g. "it should be a mart, not staging, and build from fct_order_items." Then
approve. (You'll actually build this in Lesson 4 — for now, practice steering the plan.)

## 3. Reviewing changes
When Claude Code edits a file, it shows you a **diff** (the before/after) and waits for
approval. Treat this like a code review of a colleague's pull request:
- Read the diff. Does it do what you asked — and *only* that?
- For a session where you trust the direction, you can choose "accept edits" to stop
  approving each one individually. Use this when you're following along, not when you're
  unsure.
- If something's off, say so in plain language: "you also changed the join condition —
  revert that, I only wanted the new column."

## 4. CLAUDE.md — project memory
Open [`CLAUDE.md`](../CLAUDE.md) in the repo root. Claude Code reads this file
automatically at the start of every session in this project. It's where you record the
things you'd otherwise repeat every time: how to run the project, naming conventions,
"always do X," "never touch Y." Good CLAUDE.md files make every later request shorter and
every result more consistent.

**Try it.** Ask Claude Code:
```
read CLAUDE.md, then propose one improvement to it that would make your future
work on this project more reliable. show me the diff.
```
Review and (if it's sensible) approve. You just taught the project something permanent.

## 5. Git, conversationally
Claude Code makes version control approachable:
```
what files have I changed?
commit my changes with a clear message
create a branch called lesson1-practice
```
Get into the habit of committing before and after each lesson — it gives you a safety net
and lets you `diff` your work against the starting point.

## 6. Managing context with /clear
A long session accumulates context, which can make Claude Code slower and less focused.
When you switch to an unrelated task, run `/clear` to start fresh (your files are
untouched — this only clears the conversation). Rule of thumb: **one task per
conversation.**

## Exercise
1. Create a branch: ask Claude Code to make `lesson1-practice`.
2. Have it add a short "## Glossary" section to `CLAUDE.md` defining *grain*, *staging*,
   and *mart* in one line each. Review the diff before approving.
3. Ask it to commit the change with a descriptive message.
4. Ask `what did I just change and why?` — confirm its summary matches reality.

## 🚀 Level-up challenge
Ask Claude Code, in plan mode: *"if you were onboarding a new analyst to this repo, what
three things would you add to CLAUDE.md?"* Evaluate its suggestions — accept the ones you
agree with, reject the rest. Practicing judgment is the point.

## ✅ Checkpoint
You can write specific requests, use plan mode to review an approach first, read and
approve diffs, edit CLAUDE.md, and do basic git through Claude Code.

## 🛠️ Technique spotlight: *plan, then act*
For any task bigger than a one-liner: **plan mode first.** Cheap to redirect a plan;
expensive to unpick a dozen wrong edits. The habit of reviewing the approach before the
work is most of what separates productive Claude Code users from frustrated ones.

➡️ Next: [Lesson 2 — SQL with Claude Code](02-sql-with-claude-code.md)
