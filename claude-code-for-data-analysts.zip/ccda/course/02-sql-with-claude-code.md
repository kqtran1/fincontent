# Lesson 2 — SQL with Claude Code

⏱️ ~45 min · Works against the local **DuckDB** warehouse you built in setup
(`warehouse.duckdb`).

## What you'll learn
- Doing real ad-hoc analysis by describing questions in plain language.
- Having Claude Code **explain**, **optimize**, and **debug** SQL.
- The habit that keeps you safe: **verify the results, don't just trust them.**

## Why this matters
This is the most immediately useful thing Claude Code does for an analyst. You think in
*questions* ("which stores are underperforming on margin?"); SQL is just the translation
layer. Claude Code does the translation fast — but you still own the question and the
interpretation.

## Setup for this lesson
Make sure the warehouse exists (`cd analytics && dbt build --profiles-dir .` if not).
You'll query it either through Claude Code (it can run DuckDB for you) or the DuckDB CLI
(`duckdb warehouse.duckdb`). Start a fresh session: `cd ccda && claude`, then `/clear`.

## 1. Let it learn the schema first
Before asking questions, ground it:
```
the warehouse is in warehouse.duckdb. list the tables and, for the marts
(dim_* and fct_*), show me the columns. don't run any analysis yet.
```
Now it knows the shape of the data, so its queries will reference real columns instead of
guessing.

## 2. Ask questions, not queries
```
using fct_order_items joined to dim_products, what are the top 5 products by
total revenue? run it and show me the result.
```
Claude Code writes the SQL, runs it, and shows the answer. Read the SQL it wrote — does
the join and the grain make sense? This is the verify step, and it's not optional.

Now iterate, the way you actually work:
```
now break that down by product category instead, and add gross margin %.
```
```
which day of the week has the highest average revenue?
```

## 3. Explain unfamiliar SQL
When Claude Code (or a teammate, or your past self) writes something you don't fully
follow:
```
explain this query line by line, especially the window function:
<paste the query>
```
Use it as a tutor, not just a generator. Understanding the output is what makes you able
to trust or reject it.

## 4. Optimize and debug
```
this query is slow on the full table — how would you make it faster, and why?
```
```
this query returns no rows but I expected ~12. find the bug.
```
A great debugging prompt includes **what you expected vs. what you got** — that's the
clue Claude Code needs.

## Exercise — answer these business questions
Have Claude Code write and run a query for each. Read every query before trusting the
answer. Reference solutions: [`solutions/sql/business_questions.sql`](../solutions/sql/business_questions.sql).

1. Top 5 products by revenue.
2. Monthly revenue trend over the whole period.
3. Revenue and margin % by store, ranked highest to lowest.
4. What share of orders are from loyalty members vs. guests?
5. Average order value by channel (`in_store`, `mobile_app`, `drive_thru`).
6. Revenue by product category broken out by store type.
7. Revenue per loyalty tier (bronze / silver / gold).

> Sanity checks you can apply: do the store percentages add to ~100%? Is margin % between
> 0 and 1? Does the loyalty/guest split look like ~65/35? If a number looks wrong, it
> probably is — ask Claude Code to re-examine.

## 🚀 Level-up challenge
Ask: *"find something surprising or worth flagging in this data, write the query that
shows it, and explain in two sentences why it matters to the business."* Then pressure-
test its claim yourself.

## ✅ Checkpoint
You can answer ad-hoc business questions by describing them, you read the SQL before
trusting the result, and you can ask Claude Code to explain or fix a query.

## 🛠️ Technique spotlight: *trust, but verify*
Claude Code is fast and usually right — which makes the occasional wrong answer dangerous,
because it arrives with the same confidence as the right ones. Build the reflex: glance at
the SQL, sanity-check the magnitude of the result, and spot-check one row. The speed it
gives you is only a win if the answer is correct.

➡️ Next: [Lesson 3 — Data Prep with PySpark](03-pyspark-data-prep.md)
