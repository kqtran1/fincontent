# Lesson 4 — Building with dbt

⏱️ ~55 min · Works in the [`analytics/`](../analytics/) dbt project (DuckDB).

## What you'll learn
- Reading and understanding an existing dbt project with Claude Code.
- Building **new models** that follow the project's conventions.
- Adding **tests** and **documentation**.
- Debugging a failed `dbt build`.
- Using a **custom slash command** and a **skill** so Claude Code applies your team's
  standards automatically.

## Why this matters
dbt is where ad-hoc SQL becomes a maintainable, tested transformation layer. The hard
part isn't the SQL — it's consistency: the right layering, naming, materialization, and
tests, every time. That's a perfect fit for Claude Code *if* you give it your conventions.
This lesson shows you how to make it build models the way your team wants.

## 1. Understand the project first
Start a fresh session (`claude`, then `/clear`) and ask:
```
explain the analytics/ dbt project: the staging vs marts layers, how sources
read the CSVs, and how the models depend on each other.
```
Then have it draw the lineage in words:
```
list the models and what each one depends on, from sources down to fct_daily_sales.
```

## 2. Build a new model — `dim_date`
A reporting model needs a date dimension. In **plan mode** (`Shift+Tab`) first:
```
plan a dim_date model: one row per calendar day covering the order history,
with year, month, month_name, day_of_month, day_of_week, and an is_weekend flag.
use dbt_utils.date_spine. it's a mart (a table).
```
Review the plan. Two things worth catching, because they're the kind of mistake that
costs you a confusing debugging session:
- The date range should come from the data (`min`/`max` of `order_date` in
  `fct_order_items`), not be hard-coded.
- `dbt_utils.date_spine` builds its own CTE, so the start/end bounds must be **inline
  scalar subqueries**, not a separate `bounds` CTE it references (that won't be in scope
  inside the macro).

Let it build the model, then:
```
build just this model: dbt build --profiles-dir . --select dim_date, and show me 3 rows.
```
You should get **545 rows** (about 18 months of days).

## 3. Build a second model — `fct_customer_monthly`
```
create a mart fct_customer_monthly: one row per loyalty customer per month, with
orders, units, revenue and gross_margin, built from fct_order_items. exclude guests
(null customer_id). then build it and tell me how many rows it produced.
```

## 4. Add tests and docs
Models without tests are a liability. Ask:
```
add tests for both new models in a yml file: unique+not_null on dim_date.date_day,
not_null on fct_customer_monthly.customer_id, and an accepted_range so revenue >= 0.
add a one-line description for each model. then run dbt build for both and confirm green.
```
Reference answers: [`solutions/dbt/`](../solutions/dbt/) (models + `_solution_tests.yml`).

## 5. Debug a failure on purpose
Real dbt work involves failed builds. Create one and fix it:
```
temporarily change a column reference in fct_customer_monthly to a column that
doesn't exist, run dbt build, then read the error and fix it. explain what the
error message told you.
```
Learning to *read the dbt error* — which model, which line, what DuckDB complained about —
is a skill that pays off on every real project.

## 6. Make conventions automatic
You shouldn't have to re-explain your standards every time. This repo already ships two
mechanisms (you'll learn to *build* these in Lesson 6):

- A **slash command**: [`.claude/commands/new-dbt-model.md`](../.claude/commands/new-dbt-model.md).
  Try it:
  ```
  /new-dbt-model fct_store_daily a mart with revenue and order_count per store per day
  ```
  It scaffolds the model in the right folder, with the right materialization and a test —
  following the rules baked into the command.
- A **skill**: [`.claude/skills/dbt-conventions/`](../.claude/skills/dbt-conventions/).
  Claude Code consults it automatically whenever it touches the dbt project, so models
  come out consistent without you spelling out the conventions each time.

## Exercise
Build `dim_date` **and** `fct_customer_monthly` yourself (steps 2–4), with tests and
descriptions, until `dbt build --profiles-dir .` is fully green. Then delete the throwaway
`fct_store_daily` from step 6 (or keep it and add a test — your call).

## 🚀 Level-up challenge
Ask Claude Code to `generate dbt docs and describe what the lineage graph would show`,
then to propose **one** additional test on an existing mart that would have caught a real
data problem — and justify why that test matters.

## ✅ Checkpoint
Two new, tested, documented models build green; you can read and fix a dbt error; and
you've used both the custom command and the skill.

## 🛠️ Technique spotlight: *encode conventions once*
The leap from "Claude Code writes SQL" to "Claude Code writes *our* SQL" is
**CLAUDE.md + skills + commands**. Put your standards somewhere it reads automatically and
every future model inherits them — no repetition, no drift. That's how teams scale this.

➡️ Next: [Lesson 5 — Power BI as Code](05-powerbi-semantic-model.md)
