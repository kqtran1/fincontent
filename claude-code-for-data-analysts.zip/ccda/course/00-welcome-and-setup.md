# Lesson 0 — Welcome & Your First Claude Code Session

⏱️ ~30 min · **Prerequisite:** you've finished everything in [`SETUP.md`](../SETUP.md)
and `dbt build` showed `PASS=23`.

## What you'll learn
- What Claude Code is, and how it's different from a chatbot.
- The "agentic loop" — how Claude Code actually does work for you.
- How to start a session, ask questions, and stay in control.

## Why this matters
You already know how to write SQL and analyze data. Claude Code doesn't replace that —
it removes the friction around it: the boilerplate, the syntax you half-remember, the
unfamiliar tool, the "I know what I want but not the exact incantation" moments. The
analysts who get the most from it treat it like a fast, literal, tireless junior
colleague who can read your whole project. This course is about learning to delegate to
that colleague well.

## What Claude Code is
Claude Code is a coding agent that runs **in your terminal** and can read and edit the
files in your project, run commands, and use git — all by talking to it in plain
language. Unlike a chat window where you copy-paste snippets back and forth, Claude Code
works *inside your project*: it opens files, makes changes you approve, runs your tests,
and reports back.

It's also available in VS Code, JetBrains, a desktop app, and on the web — but this
course uses the terminal, because that's where the core skills transfer everywhere else.

## The agentic loop
When you give Claude Code a task, it runs a loop: **understand → plan → act → check**.
It reads the relevant files, decides what to do, proposes an action (like editing a file
or running a command), and — crucially — **asks your permission before doing anything
that changes your project**. You stay in the driver's seat. Approving, redirecting, and
reviewing its work is *your* job, and it's the skill this course builds.

## Do it: start your first session
Open a terminal, go to the project, and start Claude Code:
```bash
cd ccda
claude
```
You'll see the welcome screen. Type `/help` to see available commands. Now ask it to
get its bearings — type this exactly:
```
what does this project do? give me a tour of the folder structure.
```
Claude Code will read files on its own (you don't paste anything) and summarize the
project. Read its answer. Then ask a follow-up:
```
which files would I touch to change how revenue is calculated?
```

Notice what just happened: you didn't tell it *where* anything was. It explored and
found out. That's the shift — **you describe the goal, it does the legwork.**

## Do it: ask it to run something
Type:
```
build the warehouse and then tell me total revenue by product category
```
Claude Code will propose running `dbt build` and a query. It will **ask before running**.
Approve it, and watch it work through the steps and report the numbers back. (You ran
`dbt build` yourself in setup — now you've watched Claude Code do it.)

## Staying in control
Three things to internalize from day one:
- **It asks before changing anything.** Read what it proposes before you approve.
- **You can interrupt.** Press `Esc` to stop it mid-task and redirect.
- **It can be wrong.** It's confident and fast, which means a wrong turn is also fast.
  You are the reviewer. Never approve a change you haven't understood.

## Exercise
1. In your session, ask: `what technologies does this project use and why?`
2. Ask: `explain the difference between the staging and marts folders in analytics/`
3. Ask one thing you're genuinely curious about in this repo. Read the answer
   critically — does it match what you see in the files?

There's nothing to submit. The goal is to get comfortable talking to it.

## ✅ Checkpoint
You can start a session, ask Claude Code about the project, and have it run a command
with your approval. You understand that it asks permission before changing things.

## 🛠️ Technique spotlight: *let it explore first*
Before asking Claude Code to change anything, ask it to **explain** the relevant part of
the project first. It grounds its later work in what's actually there — and it lets you
catch a misunderstanding before it turns into a bad edit.

➡️ Next: [Lesson 1 — Claude Code Fundamentals](01-claude-code-fundamentals.md)
