# Lesson 5 — Power BI as Code

⏱️ ~45 min · Files in [`powerbi/`](../powerbi/). Power BI Desktop is optional (Windows) —
you can do the whole lesson without it.

## What you'll learn
- Why a terminal agent *can* help with a GUI tool like Power BI.
- Authoring **DAX measures** with Claude Code.
- Reading and editing the model as **TMDL**, and shaping data with **Power Query (M)**.

## Why this matters
Power BI feels like a click-and-drag tool, so analysts assume Claude Code can't help. But
**everything that defines a Power BI model is text**: the semantic model is TMDL, measures
are DAX, data loading is Power Query M. Save any report as a `.pbip` project and it becomes
folders of files you can version-control and edit with Claude Code. The transferable skill
here is *modeling thinking* — grain, star schema, measure logic — which is tool-agnostic.

Read [`powerbi/README.md`](../powerbi/README.md) before continuing; it explains the
file-based workflow and how to get the dbt marts into Power BI.

## 1. Get the data ready
The Power BI model sits on the dbt marts. Export them to CSV:
```
build the warehouse if needed, then run scripts/export_for_powerbi.py and tell me
what files it produced.
```
This writes `data/exports/*.csv` for `fct_daily_sales`, the dimensions, etc.

## 2. Understand the model (TMDL)
Open [`powerbi/model/northwind.tmdl`](../powerbi/model/northwind.tmdl) and ask:
```
explain this TMDL file: what tables, columns and relationships does it define,
and why is this a star schema?
```
Then practice editing the model as code:
```
add a 'quarter' column to the dim_date table in the TMDL, with the right data type.
show me the diff.
```

## 3. Author DAX measures
Open [`powerbi/model/measures.dax`](../powerbi/model/measures.dax). It has worked examples
(Total Revenue, Gross Margin %, Revenue YoY %) and **four TODO measures**. Have Claude Code
write them — but ask it to explain each, because DAX's filter-context behavior is the part
people get wrong:
```
write the four TODO measures in measures.dax (Revenue MTD, Revenue 7-Day Avg,
Revenue Rank by Store, % of Total Revenue). for each, explain in one line what the
CALCULATE/ALL/RANKX is doing to the filter context.
```
Reference: [`solutions/powerbi/measures_solution.dax`](../solutions/powerbi/measures_solution.dax).

Test your understanding — ask:
```
why does "% of Total Revenue" need ALL(dim_stores), and what would happen if I
forgot it?
```

## 4. Power Query (M)
Open [`powerbi/powerquery/Sales.m`](../powerbi/powerquery/Sales.m). Ask:
```
explain each step in this M script, then write a second query that loads
data/exports/dim_stores.csv and types its columns correctly.
```

## 5. (Optional) See it in Power BI Desktop
If you're on Windows with Power BI Desktop: Get Data → Text/CSV the exported files (or
paste the M scripts into Blank Queries), wire up relationships per the TMDL, paste in the
measures, and build a one-page dashboard: revenue trend, revenue by store, margin % card.
No Desktop? You've still authored the model — that's the skill.

## Exercise
Write all four TODO measures and confirm they match the reference logic. Add the
`dim_stores` Power Query from step 4. If you have Desktop, build a simple dashboard page.

## 🚀 Level-up challenge
Ask Claude Code to design a measure that answers a *business* question it isn't given
verbatim — e.g. *"which stores grew revenue fastest month-over-month?"* — and to explain
the DAX. Then sanity-check the logic against the SQL you'd write for the same question.

## ✅ Checkpoint
You can explain the TMDL model, write and reason about DAX measures, and read/write Power
Query M — all as code, with or without Power BI Desktop open.

## 🛠️ Technique spotlight: *the GUI is just text underneath*
When a tool feels un-automatable, ask what its **source format** is. Power BI → TMDL/DAX/M.
Tableau → XML. Once you find the text layer, Claude Code can read, write, review, and
diff it like any other code. "Where does this tool keep its definitions as files?" is a
question worth asking of everything in your stack.

➡️ Next: [Lesson 6 — Automate Your Workflow](06-automate-your-workflow.md)
