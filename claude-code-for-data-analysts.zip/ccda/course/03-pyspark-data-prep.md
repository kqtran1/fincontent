# Lesson 3 — Data Prep with PySpark

⏱️ ~50 min · Uses [`notebooks/03_data_prep.ipynb`](../notebooks/03_data_prep.ipynb).
Needs a JDK installed (see [`SETUP.md`](../SETUP.md) §4).

## What you'll learn
- Working with Claude Code inside a **Jupyter notebook**.
- Profiling and cleaning genuinely messy data with PySpark.
- Asking Claude Code to **explain code you don't recognize** — and to **debug a real
  error** (Spark's strict ANSI date parsing).

## Why this matters
Raw operational data is never clean. The legacy point-of-sale system at Northwind dumps
`data/raw/pos_export_messy.csv`: four different date formats, dollar signs stuck to
amounts, the same store written five different ways, duplicate rows, and blank lines. This
is the unglamorous 60% of analytics work — and it's exactly where Claude Code earns its
keep, because the *transformations* are mechanical once you've decided *what clean means*.

## 1. Open the notebook and start a session
Launch Claude Code from the repo root (`claude`). You can either edit the notebook through
Claude Code from the terminal, or open it in Jupyter (`jupyter lab`) and run cells
yourself while Claude Code writes them. Either way, keep the notebook
`notebooks/03_data_prep.ipynb` in front of you — it has the skeleton and the TODOs.

> The first cell pins Spark to **your** Python interpreter via
> `PYSPARK_PYTHON`/`PYSPARK_DRIVER_PYTHON = sys.executable`, then prints the versions it's
> using. That's what prevents "Python in worker has different version than driver" errors —
> run the notebook from the same virtualenv where you `pip install`ed pyspark. (There's a
> script form of this whole lesson at `scripts/clean_pos_data.py` if you want to see it as
> a runnable `.py`.)

Tell Claude Code what you're doing:
```
open notebooks/03_data_prep.ipynb. we're cleaning data/raw/pos_export_messy.csv.
walk me through what's already in the notebook before we change anything.
```

## 2. Profile before you clean (TODO cell 3)
You can't clean what you haven't measured. Ask:
```
fill in the profiling cell: for every column in `raw`, report non-null count,
distinct count, count of blank/empty strings, and a few example values.
```
Run it. Read the output. You'll see the mess concretely — that's your cleaning checklist.

## 3. Clean each column (TODO cell 4)
Work issue by issue. Let Claude Code write the transforms, but make sure *you* decide the
rules. Useful prompts:
```
the amount column has values like "$2.95" and " 12.95 " and some blanks.
write a column that keeps only digits and the decimal point, casts to double,
and leaves blanks as null.
```
```
the store column is inconsistent: "SEATTLE", "seattle ", "PDX", "SF",
"store_5", etc. map them to a numeric store_id (Seattle=1, Portland=2,
San Francisco=3; store_N keeps N).
```

### The error you'll hit (and how to debug it)
The `txn_date` column has four formats. The obvious approach — `to_date(col, fmt)` — will
**throw an error** on the first row it can't parse, because **Spark runs in ANSI mode**
and refuses to silently produce nulls. When you see something like
`CANNOT_PARSE_TIMESTAMP ... Use try_to_date`, that's the lesson. Ask Claude Code:
```
to_date is throwing CANNOT_PARSE_TIMESTAMP on the bad dates. I want unparseable
values to become null instead of erroring. fix it, and explain why this happens.
```
The fix is `try_to_date`, coalesced across the four formats. Have Claude Code explain the
difference between `to_date` and `try_to_date` so you understand *why* it works — that's
the transferable knowledge.

## 4. Dedupe, drop junk, validate (TODO cells 5–6)
```
drop exact duplicate rows, then drop rows missing a txn_id, a parseable date,
an amount, or a store_id. call the result `clean`.
```
```
now prove it worked: how many rows survived, are all 12 store_ids present,
and are there any nulls left in amount or txn_date?
```
You started with 6,240 raw rows. A correct pipeline lands around **5,682 clean rows** with
all 12 stores present and no nulls in the key fields. If your numbers are far off, ask
Claude Code to help you find where rows were lost.

## 5. Write the output (cell 7)
Uncomment the write cell and save the cleaned data to `data/clean/pos_transactions` as
Parquet. (It's gitignored — a build output, not source.)

## Exercise
Complete every TODO cell in `notebooks/03_data_prep.ipynb` so the notebook runs top to
bottom and the validation passes. Reference:
[`solutions/pyspark/03_data_prep_solution.ipynb`](../solutions/pyspark/03_data_prep_solution.ipynb).

## 🚀 Level-up challenge
Ask Claude Code to add a **data-quality report** cell: rows in, rows out, and rows dropped
*per reason* (bad date / missing amount / unmapped store / duplicate). Then ask: *"how
would I turn this notebook into a scheduled job, and what would I monitor?"* — and discuss
the trade-offs it raises.

## ✅ Checkpoint
The notebook runs end to end, the validation passes, and you can explain what
`try_to_date` does and why Spark's ANSI mode required it.

## 🛠️ Technique spotlight: *paste the error, state the expectation*
When code breaks, give Claude Code the **actual error text** plus **what you expected to
happen**. "It says CANNOT_PARSE_TIMESTAMP but I want bad dates to become null" gets a
correct fix far faster than "the date thing is broken." The error message is usually the
answer — Claude Code just reads it faster than you can.

➡️ Next: [Lesson 4 — Building with dbt](04-building-with-dbt.md)
