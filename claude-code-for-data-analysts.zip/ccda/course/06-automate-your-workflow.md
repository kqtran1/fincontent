# Lesson 6 — Automate Your Workflow

⏱️ ~55 min

## What you'll learn
The five ways to extend Claude Code so it fits *your* work, not the other way around:
- **CLAUDE.md** — project memory (you've used this; we'll go deeper).
- **Custom slash commands** — reusable prompts for tasks you repeat.
- **Skills** — packaged know-how Claude Code pulls in automatically when relevant.
- **Subagents** — delegate a sub-task to a separate context.
- **MCP** — connect Claude Code to external systems (your real warehouse, a ticketing
  tool, etc.).
- **Hooks** — run your own commands automatically at set points.

## Why this matters
Up to now you've *used* Claude Code. Now you'll *shape* it. Every analyst has a handful of
chores they do constantly — profiling a new table, writing a standard model, formatting a
weekly summary. Each one can become a command, a skill, or a hook you build once and reuse
forever. This is where the time savings compound.

## 1. Custom slash commands
A slash command is just a Markdown file in `.claude/commands/`. The filename is the
command name; `$ARGUMENTS` (or `$1`, `$2`, …) are filled in from what you type. Study the
one this repo ships: [`.claude/commands/new-dbt-model.md`](../.claude/commands/new-dbt-model.md).

**Build your own.** Ask Claude Code:
```
create a slash command called "profile-table" in .claude/commands that takes a
table name, runs a profiling query against warehouse.duckdb (row count, and for
each column: null count, distinct count, min/max or top values), and prints a
tidy summary.
```
Then use it:
```
/profile-table fct_order_items
```
You just turned a recurring chore into one line.

## 2. Skills
A **skill** is a folder under `.claude/skills/<name>/` with a `SKILL.md` that has a
`name` and `description`. Claude Code reads the description and pulls the skill in
**automatically** when a task matches — you don't have to invoke it. Study
[`.claude/skills/dbt-conventions/SKILL.md`](../.claude/skills/dbt-conventions/SKILL.md):
its description says "use whenever creating or editing dbt models," so it activates on its
own during Lesson 4's work.

**Build your own.** A good analyst skill captures *standards*, not one-off instructions:
```
create a skill called "analysis-writeup" that defines how we present findings:
lead with the answer, then 2-3 supporting numbers, then one caveat about the data.
no jargon. it should trigger whenever I ask for a written summary of results.
```
Command vs. skill, rule of thumb: a **command** is something you explicitly fire; a
**skill** is knowledge Claude Code should apply on its own when the situation fits.

## 3. Subagents
For a big task, Claude Code can spin up a **subagent** with its own context window to
handle a chunk of work and report back — keeping your main conversation focused. You
mostly just ask for it:
```
use a subagent to review every model in analytics/models for missing tests, and
come back with a prioritized list. don't change anything yet.
```
This is great for "go investigate broadly, then summarize" jobs that would otherwise
clutter your main session.

## 4. MCP — connect to the outside world
**MCP (Model Context Protocol)** lets Claude Code talk to external systems through
connectors: a real Postgres/Snowflake/BigQuery warehouse, a BI server, Jira, Google
Drive, and so on. In this course you've used a local DuckDB file; in real life you'd add
an MCP connector so Claude Code can query your actual warehouse (read-only, ideally) the
same conversational way.

You don't need to wire one up today, but know the shape of it: connectors are configured
for the project, then their tools appear to Claude Code automatically. Ask:
```
explain how I would connect Claude Code to a real Snowflake warehouse via MCP, and
what permissions I'd give it to stay safe.
```
> Safety note: scope database connectors to **read-only** for analysis work, and never
> point an agent at production write access without a human approval step.

## 5. Hooks
**Hooks** run your own shell commands automatically at lifecycle points — e.g. after every
file edit, or when a task finishes. Analyst-useful examples:
- After Claude Code edits any `.sql` model, auto-run `sqlfluff`/`dbt parse` to catch errors
  immediately.
- When a task ends, run the relevant `dbt build --select` to confirm nothing broke.

Ask Claude Code:
```
explain how I'd add a hook that runs `dbt parse` after any edit to a file under
analytics/models, so I find compile errors right away. don't enable it yet —
just show me what it would look like.
```

## Exercise
1. Build the `/profile-table` command and run it on two different tables.
2. Build the `analysis-writeup` skill, then ask for a written summary of "revenue by
   category" and confirm the skill's format was applied automatically.
3. Use a subagent to audit the project for missing tests.

## 🚀 Level-up challenge
Design (don't necessarily build) a small **toolkit** for your *real* job: list three
chores you do weekly and decide for each whether it should be a command, a skill, or a
hook — and why. Have Claude Code draft one of them.

## ✅ Checkpoint
You've created a working command and a working skill, used a subagent, and can explain
when to reach for MCP vs. a hook vs. a command.

## 🛠️ Technique spotlight: *automate the second time*
The first time you do a task, just do it. The **second** time, ask: "should this be a
command, a skill, or a hook?" That single habit is what turns Claude Code from a faster way
to type into a system that quietly removes whole categories of work from your week.

➡️ Next: [Lesson 7 — Capstone](07-capstone.md)
