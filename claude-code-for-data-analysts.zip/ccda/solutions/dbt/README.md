# dbt exercise solutions (Lesson 4)

Reference answers for the "build a new model" exercises.

- `marts/dim_date.sql` — a date dimension built with `dbt_utils.date_spine`, sized
  automatically to the order history.
- `marts/fct_customer_monthly.sql` — customer × month fact (orders, units, revenue, margin).
- `marts/_solution_tests.yml` — schema tests for both.

To run them: copy the `.sql` files into `analytics/models/marts/`, merge the tests
into `analytics/models/marts/_marts.yml`, then `dbt build --profiles-dir .`.
