{{ config(materialized='table') }}

select
    customer_id,
    date_trunc('month', order_date)   as order_month,
    count(distinct order_id)          as orders,
    sum(quantity)                     as units,
    round(sum(revenue), 2)            as revenue,
    round(sum(gross_margin), 2)       as gross_margin
from {{ ref('fct_order_items') }}
where customer_id is not null
group by 1, 2
