{{ config(materialized='table') }}

with spine as (
    {{ dbt_utils.date_spine(
        datepart="day",
        start_date="(select min(order_date) from " ~ ref('fct_order_items') ~ ")",
        end_date="(select max(order_date) + interval 1 day from " ~ ref('fct_order_items') ~ ")"
    ) }}
)
select
    cast(date_day as date)              as date_day,
    extract(year  from date_day)        as year,
    extract(month from date_day)        as month,
    strftime(date_day, '%B')            as month_name,
    extract(day   from date_day)        as day_of_month,
    strftime(date_day, '%A')            as day_of_week,
    case when extract(dow from date_day) in (0,6) then true else false end as is_weekend
from spine
