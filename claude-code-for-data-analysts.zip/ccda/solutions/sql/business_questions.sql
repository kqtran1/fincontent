-- Reference SQL for Lesson 2. Run against warehouse.duckdb, e.g.:
--   duckdb warehouse.duckdb
-- then paste a query, or:  python -c "import duckdb;duckdb.connect('warehouse.duckdb')..."
-- These read from the dbt marts/staging models.

-- Q1. Top 5 products by total revenue
select p.product_name, round(sum(f.revenue), 2) as revenue
from fct_order_items f
join dim_products p using (product_id)
group by 1 order by revenue desc limit 5;

-- Q2. Monthly revenue trend
select date_trunc('month', order_date) as month,
       round(sum(revenue), 2) as revenue
from fct_order_items group by 1 order by 1;

-- Q3. Revenue and margin % by store, ranked
select s.store_name,
       round(sum(f.revenue), 2)      as revenue,
       round(sum(f.gross_margin), 2) as margin,
       round(sum(f.gross_margin) / nullif(sum(f.revenue), 0), 3) as margin_pct
from fct_order_items f
join dim_stores s using (store_id)
group by 1 order by revenue desc;

-- Q4. Loyalty vs guest order share
select case when customer_id is null then 'guest' else 'loyalty' end as cust_type,
       count(distinct order_id) as orders,
       round(100.0 * count(distinct order_id)
             / sum(count(distinct order_id)) over (), 1) as pct
from fct_order_items group by 1;

-- Q5. Average order value by channel
with orders as (
    select order_id, channel, sum(revenue) as order_revenue
    from fct_order_items group by 1, 2
)
select channel, count(*) as orders, round(avg(order_revenue), 2) as avg_order_value
from orders group by 1 order by avg_order_value desc;

-- Q6. Revenue by product category and store type
select st.store_type, f.product_category,
       round(sum(f.revenue), 2) as revenue
from fct_order_items f
join dim_stores st using (store_id)
group by 1, 2 order by 1, revenue desc;

-- Q7. Revenue per loyalty tier
select c.loyalty_tier,
       count(distinct f.order_id) as orders,
       round(sum(f.revenue), 2)   as revenue
from fct_order_items f
join dim_customers c using (customer_id)
group by 1 order by revenue desc;
