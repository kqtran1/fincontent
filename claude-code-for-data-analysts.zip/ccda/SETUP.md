# Setup

Do this once before Lesson 0. Budget ~20 minutes.

## 1. Install Claude Code
Pick one (the native installer is recommended and auto-updates):

**macOS / Linux / WSL**
```bash
curl -fsSL https://claude.ai/install.sh | bash
```
**Windows PowerShell**
```powershell
irm https://claude.ai/install.ps1 | iex
```
Other options: `brew install --cask claude-code`, `winget install Anthropic.ClaudeCode`,
or the legacy npm install `npm install -g @anthropic-ai/claude-code` (needs Node.js 18+).

Then start it once and log in:
```bash
claude
# follow the browser prompt; or type /login inside the session
```
You need a Claude subscription (Pro, Max, Team, or Enterprise) or a Claude Console
account. Full guide: https://code.claude.com/docs/en/quickstart

## 2. Get the project
```bash
# unzip the course archive, then:
cd ccda
```

## 3. Python tools
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 4. Java (for the PySpark lesson only)
PySpark needs a JDK (17 or newer). Check with `java -version`. If missing:
- macOS: `brew install temurin`
- Ubuntu/Debian: `sudo apt-get install default-jdk`
- Windows: install Temurin/Adoptium and set `JAVA_HOME`.

## 5. Build the sample warehouse (verifies everything works)

**Fast path — one command runs the whole pipeline end to end:**
```bash
bash scripts/run_pipeline.sh
```
This generates data, builds the dbt warehouse, runs the PySpark cleaning, and exports the
Power BI CSVs. You should see `PASS=23` and `clean rows: 5682`. If so, you're ready.

> The PySpark step prints something like `Spark 4.1.2 | Python 3.12.3`. The scripts pin
> Spark to **your** Python interpreter (`PYSPARK_PYTHON`/`PYSPARK_DRIVER_PYTHON`), so you
> won't hit driver/worker version mismatches. Run inside your virtualenv and it just works.
> Prefer a different interpreter? `PYTHON=python bash scripts/run_pipeline.sh`.

**Manual path** (what the script does, step by step):
```bash
python scripts/generate_data.py
cd analytics
dbt deps
dbt build --profiles-dir .          # expect PASS=23
cd ..
python scripts/clean_pos_data.py    # PySpark; expect clean rows: 5682
python scripts/export_for_powerbi.py
```
If you see `PASS=23`, you're ready — open `course/00-welcome-and-setup.md`.

> Note: `dbt deps` here installs `dbt_utils` from GitHub (see `packages.yml`). If your
> network allows the dbt hub, you can switch back to the standard hub package.

## 6. Power BI (optional, Windows)
Lesson 5 uses Power BI Desktop (free, Windows). If you don't have it, you can still
do the lesson — you'll author the DAX/TMDL with Claude Code without rendering a report.
