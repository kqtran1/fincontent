# Setup

Do this once before Lesson 0. Budget ~20 minutes.

## 1. Install Claude Code
Pick one (the native installer is recommended and auto-updates):

**macOS / Linux / WSL**
```bash
curl -fsSL https://claude.ai/install.sh | bash
```
**Windows PowerShell**
```powershell
irm https://claude.ai/install.ps1 | iex
```
Other options: `brew install --cask claude-code`, `winget install Anthropic.ClaudeCode`,
or the legacy npm install `npm install -g @anthropic-ai/claude-code` (needs Node.js 18+).

Then start it once and log in:
```bash
claude
# follow the browser prompt; or type /login inside the session
```
You need a Claude subscription (Pro, Max, Team, or Enterprise) or a Claude Console
account. Full guide: https://code.claude.com/docs/en/quickstart

## 2. Get the project
```bash
# unzip the course archive, then:
cd ccda
```

## 3. Python tools
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 4. Java (for the PySpark lesson only)
PySpark needs a JDK (17 or newer). Check with `java -version`. If missing:
- macOS: `brew install temurin`
- Ubuntu/Debian: `sudo apt-get install default-jdk`
- Windows: install Temurin/Adoptium and set `JAVA_HOME`.

## 5. Build the sample warehouse (verifies everything works)

**One command runs the whole pipeline end to end** (generate data → dbt build → PySpark
clean → Power BI export). Pick the line for your shell:

**macOS / Linux / WSL / Git Bash**
```bash
bash scripts/run_pipeline.sh
```
**Windows (PowerShell)**
```powershell
./scripts/run_pipeline.ps1
# if execution policy blocks it:
powershell -ExecutionPolicy Bypass -File scripts/run_pipeline.ps1
```
You should see `PASS=23` and `clean rows: 5682`. If so, you're ready.

> **Which Python?** The runners auto-detect your interpreter. On macOS/Linux that's
> usually `python3`; on Windows it's `python` (Windows has no `python3` — that name often
> launches the Microsoft Store stub, which the bash runner deliberately skips). Force a
> specific one with `PYTHON=...` (bash) or `$env:PYTHON="..."` (PowerShell).
>
> **PySpark uses *your* Python.** The Spark step prints e.g. `Spark 4.1.2 | Python 3.12.3`.
> The scripts pin Spark to your interpreter (`PYSPARK_PYTHON`/`PYSPARK_DRIVER_PYTHON`), so
> there's no driver/worker mismatch. Run inside the virtualenv where you installed pyspark.

**Manual path** (any OS — what the runners do, step by step). Use `python` on Windows,
`python3` on macOS/Linux:
```bash
python scripts/generate_data.py
cd analytics
dbt deps
dbt build --profiles-dir .          # expect PASS=23
cd ..
python scripts/clean_pos_data.py    # PySpark; expect clean rows: 5682
python scripts/export_for_powerbi.py
```
If you see `PASS=23`, you're ready — open `course/00-welcome-and-setup.md`.

> Note: `dbt deps` here installs `dbt_utils` from GitHub (see `packages.yml`). If your
> network allows the dbt hub, you can switch back to the standard hub package.

> Querying the warehouse: use `python scripts/query.py "select ..."` (no install) or ask
> Claude Code. The standalone **DuckDB CLI** (`duckdb warehouse.duckdb`) is optional and a
> separate download from <https://duckdb.org/docs/installation/> — it is *not* installed by
> `requirements.txt`.

## 6. Power BI (optional, Windows)
Lesson 5 uses Power BI Desktop (free, Windows). If you don't have it, you can still
do the lesson — you'll author the DAX/TMDL with Claude Code without rendering a report.
**Heads-up:** the time-intelligence measures need the `dim_date` table, which you build in
Lesson 4. Do Lesson 4 before the optional Power BI render in Lesson 5.
